import { BaseApiService } from './base';
import { apiService } from './api';
import { attachmentsService } from './attachments';
import type { Case } from '@/types/case';
import type { ApiResponse, PaginationQuery } from '@/types/api';
import type {
  CompleteCaseData,
  CreateCaseWithMultipleTasksPayload,
  CreateCaseWithMultipleTasksResponse
} from '@/types/dto/case.dto';

export interface CaseListQuery extends PaginationQuery {
  status?: string;
  search?: string;
  assignedTo?: string;
  clientId?: string;
  priority?: string;
  dateFrom?: string;
  dateTo?: string;
}

export interface CaseUpdateData {
  status?: string;
  priority?: string;
  notes?: string;
  assignedToId?: string;
  customerName?: string;
  customerPhone?: string;
  clientId?: number;
  productId?: number;
  backendContactNumber?: string;
}

export interface CreateCaseData {
  // Core case fields
  customerName: string;
  customerCallingCode?: string;
  customerPhone?: string;
  createdByBackendUser?: string;
  verificationType?: string;
  address: string;
  pincode: string;
  verificationTypeId?: string;
  assignedToId: string;
  clientId: string;
  productId?: string;
  applicantType?: string;
  backendContactNumber?: string;
  priority?: string;
  trigger?: string;
  rateTypeId?: string;

  // Deduplication fields
  panNumber?: string;
  deduplicationDecision?: string;
  deduplicationRationale?: string;
}

export class CasesService extends BaseApiService {
  constructor() {
    super('/cases');
  }

  async getCases(query: CaseListQuery = {}): Promise<ApiResponse<Case[]>> {
    return this.get('', query as unknown as Record<string, unknown>);
  }

  async getCaseById(id: string): Promise<ApiResponse<Case>> {
    return this.get(`/${id}`);
  }

  async createCase(data: CreateCaseData): Promise<ApiResponse<CreateCaseWithMultipleTasksResponse>> {
    // Transform old format to new unified format
    const unifiedPayload = {
      case_details: {
        customerName: data.customerName,
        customerPhone: data.customerPhone,
        customerCallingCode: data.customerCallingCode,
        clientId: typeof data.clientId === 'string' ? parseInt(data.clientId) : data.clientId,
        productId: data.productId ? (typeof data.productId === 'string' ? parseInt(data.productId) : data.productId) : undefined,
        backendContactNumber: data.backendContactNumber,
        priority: data.priority,
        pincode: data.pincode,
        deduplicationDecision: data.deduplicationDecision,
        deduplicationRationale: data.deduplicationRationale,
        panNumber: data.panNumber,
      },
      verification_tasks: [{
        verification_type_id: data.verificationTypeId ? parseInt(data.verificationTypeId) : 0,
        task_title: `${data.verificationType || 'Verification'} Task`,
        task_description: data.trigger,
        priority: data.priority,
        assigned_to: data.assignedToId || undefined,
        rate_type_id: data.rateTypeId ? (typeof data.rateTypeId === 'string' ? parseInt(data.rateTypeId) : data.rateTypeId) : undefined,
        address: data.address,
        pincode: data.pincode,
        applicant_type: data.applicantType,
        trigger: data.trigger,
      }]
    };

    return this.post('/create', unifiedPayload);
  }

  async createCaseWithAttachments(data: CreateCaseData, attachments: File[]): Promise<ApiResponse<CreateCaseWithMultipleTasksResponse>> {
    const formData = new FormData();

    // Transform to unified format
    const unifiedPayload = {
      case_details: {
        customerName: data.customerName,
        customerPhone: data.customerPhone,
        customerCallingCode: data.customerCallingCode,
        clientId: typeof data.clientId === 'string' ? parseInt(data.clientId) : data.clientId,
        productId: data.productId ? (typeof data.productId === 'string' ? parseInt(data.productId) : data.productId) : undefined,
        backendContactNumber: data.backendContactNumber,
        priority: data.priority,
        pincode: data.pincode,
        deduplicationDecision: data.deduplicationDecision,
        deduplicationRationale: data.deduplicationRationale,
        panNumber: data.panNumber,
      },
      verification_tasks: [{
        verification_type_id: data.verificationTypeId ? parseInt(data.verificationTypeId) : 0,
        task_title: `${data.verificationType || 'Verification'} Task`,
        task_description: data.trigger,
        priority: data.priority,
        assigned_to: data.assignedToId || undefined,
        rate_type_id: data.rateTypeId ? (typeof data.rateTypeId === 'string' ? parseInt(data.rateTypeId) : data.rateTypeId) : undefined,
        address: data.address,
        pincode: data.pincode,
        applicant_type: data.applicantType,
        trigger: data.trigger,
      }]
    };

    // Add unified payload as JSON string
    formData.append('data', JSON.stringify(unifiedPayload));

    // Add attachment files
    attachments.forEach((file) => {
      formData.append('attachments', file);
    });

    // Use this.post() which uses apiService.post() -> axios.post()
    // Axios handles FormData automatically (sets multipart/form-data boundary)
    return this.post<CreateCaseWithMultipleTasksResponse>('/create', formData);
  }

  async createCaseWithMultipleTasks(payload: CreateCaseWithMultipleTasksPayload): Promise<ApiResponse<CreateCaseWithMultipleTasksResponse>> {
    // Payload is already in unified format from CaseWithTasksCreationForm
    return this.post('/create', payload);
  }

  async updateCaseDetails(id: string, data: CreateCaseData): Promise<ApiResponse<Case>> {
    return this.put(`/${id}`, data);
  }

  async updateCaseStatus(id: string, status: string): Promise<ApiResponse<Case>> {
    return this.put(`/${id}/status`, { status });
  }

  async updateCasePriority(id: string, priority: string): Promise<ApiResponse<Case>> {
    return this.put(`/${id}/priority`, { priority });
  }

  async updateCase(id: string, data: CaseUpdateData): Promise<ApiResponse<Case>> {
    return this.put(`/${id}`, data);
  }

  async assignCase(id: string, assignedToId: string, reason?: string): Promise<ApiResponse<Case>> {
    return this.put(`/${id}/assign`, { assignedToId, reason });
  }

  async addCaseNote(id: string, note: string): Promise<ApiResponse<Case>> {
    return this.post(`/${id}/notes`, { note });
  }

  async completeCase(id: string, data: CompleteCaseData): Promise<ApiResponse<Case>> {
    return this.post(`/${id}/complete`, data);
  }

  async getCaseAttachments(id: string): Promise<ApiResponse<unknown[]>> {
    // Delegate to attachments service which uses the correct /api/attachments base path
    return attachmentsService.getAttachmentsByCase(id);
  }

  // eslint-disable-next-line camelcase
  async uploadCaseAttachments(caseId: string, files: File[], verification_task_id?: string): Promise<ApiResponse<unknown>> {
    // Delegate to attachments service which uses the correct /api/attachments base path
    return attachmentsService.uploadAttachments({ caseId, files, verification_task_id });
  }

  async downloadAttachment(id: string): Promise<Blob> {
    // Delegate to attachments service which uses the correct /api/attachments base path
    return attachmentsService.downloadAttachment(id);
  }

  async getCaseHistory(id: string): Promise<ApiResponse<unknown[]>> {
    return this.get(`/${id}/history`);
  }

  async getCasesByStatus(status: string): Promise<ApiResponse<Case[]>> {
    return this.getCases({ status });
  }

  async getPendingReviewCases(): Promise<ApiResponse<Case[]>> {
    return this.getCases({ status: 'COMPLETED' });
  }

  async getPendingCases(): Promise<ApiResponse<Case[]>> {
    // Fetch cases with PENDING and IN_PROGRESS status using custom pending duration sorting
    const [pendingResponse, inProgressResponse] = await Promise.all([
      this.getCases({
        status: 'PENDING',
        sortBy: 'pendingDuration',
        sortOrder: 'desc'
      }),
      this.getCases({
        status: 'IN_PROGRESS',
        sortBy: 'pendingDuration',
        sortOrder: 'desc'
      })
    ]);

    // Combine the results and sort by pending duration
    const pendingCases = pendingResponse.data || [];
    const inProgressCases = inProgressResponse.data || [];
    const allCases = [...pendingCases, ...inProgressCases];

    // Sort combined cases by pending duration (longest pending first)
    allCases.sort((a, b) => {
      const aPendingDuration = a.pendingDurationSeconds || 0;
      const bPendingDuration = b.pendingDurationSeconds || 0;
      return bPendingDuration - aPendingDuration;
    });

    return {
      success: true,
      data: allCases,
      message: 'Pending cases retrieved successfully'
    };
  }

  async approveCase(id: string, feedback?: string): Promise<ApiResponse<Case>> {
    return this.post(`/${id}/approve`, { feedback });
  }

  async rejectCase(id: string, reason: string): Promise<ApiResponse<Case>> {
    return this.post(`/${id}/reject`, { reason });
  }

  async requestRework(id: string, feedback: string): Promise<ApiResponse<Case>> {
    return this.post(`/${id}/rework`, { feedback });
  }

  async exportCases(params: {
    exportType?: 'all' | 'pending' | 'in-progress' | 'completed';
    status?: string;
    search?: string;
    assignedTo?: string;
    clientId?: string;
    priority?: string;
    dateFrom?: string;
    dateTo?: string;
  } = {}): Promise<{ blob: Blob; filename: string }> {
    const queryParams: Record<string, string> = {};

    Object.entries(params).forEach(([key, value]) => {
      if (value !== undefined && value !== null && value !== '') {
        queryParams[key] = String(value);
      }
    });

    const response = await apiService.getRaw<Blob>('/cases/export', undefined, { 
        params: queryParams,
        responseType: 'blob' 
    });

    // Extract filename from Content-Disposition header
    const contentDisposition = response.headers['content-disposition'];
    let filename = 'cases_export.xlsx'; // fallback filename

    if (contentDisposition) {
      const filenameMatch = contentDisposition.match(/filename="([^"]+)"/);
      if (filenameMatch) {
        filename = filenameMatch[1];
      }
    }

    return { blob: response.data, filename };
  }
}

export const casesService = new CasesService();
