import { apiService } from './api';
import { 
  Designation, 
  CreateDesignationRequest, 
  UpdateDesignationRequest 
} from '@/types/user';

export interface DesignationsResponse {
  success: boolean;
  data: Designation[];
  pagination?: {
    page: number;
    limit: number;
    total: number;
    totalPages: number;
    hasNext: boolean;
    hasPrev: boolean;
  };
}

export interface DesignationResponse {
  success: boolean;
  data: Designation;
}

export interface DesignationsParams {
  page?: number;
  limit?: number;
  search?: string;
  isActive?: boolean;
  departmentId?: number;
}

class DesignationsService {
  private baseUrl = '/designations';

  async getDesignations(params: DesignationsParams = {}): Promise<DesignationsResponse> {
    const searchParams = new URLSearchParams();

    if (params.page) {searchParams.append('page', params.page.toString());}
    if (params.limit) {searchParams.append('limit', params.limit.toString());}
    if (params.search) {searchParams.append('search', params.search);}
    if (params.isActive !== undefined) {searchParams.append('isActive', params.isActive.toString());}
    if (params.departmentId) {searchParams.append('departmentId', params.departmentId.toString());}

    const queryString = searchParams.toString();
    const url = queryString ? `${this.baseUrl}?${queryString}` : this.baseUrl;

    const response = await apiService.get<Designation[]>(url);
    return response as DesignationsResponse;
  }

  async getDesignationById(id: number): Promise<DesignationResponse> {
    const response = await apiService.get<Designation>(`${this.baseUrl}/${id}`);
    return response as DesignationResponse;
  }

  async createDesignation(data: CreateDesignationRequest): Promise<DesignationResponse> {
    const response = await apiService.post<Designation>(this.baseUrl, data);
    return response as DesignationResponse;
  }

  async updateDesignation(id: number, data: UpdateDesignationRequest): Promise<DesignationResponse> {
    const response = await apiService.put<Designation>(`${this.baseUrl}/${id}`, data);
    return response as DesignationResponse;
  }

  async deleteDesignation(id: number): Promise<{ success: boolean; message: string }> {
    const response = await apiService.delete<{ success: boolean; message: string }>(`${this.baseUrl}/${id}`);
    return response;
  }

  async getActiveDesignations(departmentId?: number): Promise<DesignationsResponse> {
    const searchParams = new URLSearchParams();
    if (departmentId) {searchParams.append('departmentId', departmentId.toString());}

    const queryString = searchParams.toString();
    const url = queryString ? `${this.baseUrl}/active?${queryString}` : `${this.baseUrl}/active`;

    const response = await apiService.get<Designation[]>(url);
    return response as DesignationsResponse;
  }

  // Helper method to get designations for a specific department
  async getDesignationsByDepartment(departmentId: number): Promise<DesignationsResponse> {
    return this.getDesignations({ departmentId, isActive: true });
  }

  // Helper method to search designations
  async searchDesignations(searchTerm: string, departmentId?: number): Promise<DesignationsResponse> {
    return this.getDesignations({
      search: searchTerm,
      departmentId,
      isActive: true
    });
  }
}

export const designationsService = new DesignationsService();
