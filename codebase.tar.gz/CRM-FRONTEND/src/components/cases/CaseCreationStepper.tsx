import React, { useState, useEffect } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Check, User, Target } from 'lucide-react';
import { CustomerInfoStep, type CustomerInfoData } from './CustomerInfoStep';
import { FullCaseFormStep, type FullCaseFormData } from './FullCaseFormStep';
import { TaskCaseCreationForm, type CaseLevelFormData, type TaskFormData } from './TaskCaseCreationForm';

import { DeduplicationDialog } from './DeduplicationDialog';
import { deduplicationService, type DeduplicationResult } from '@/services/deduplication';
import { casesService, type CreateCaseData } from '@/services/cases';
import { attachmentsService } from '@/services/attachments';
import { usePincodes } from '@/hooks/useLocations';
import { useVerificationTypes } from '@/hooks/useClients';
import { toast } from 'sonner';
import type { CaseFormAttachment } from '@/components/attachments/CaseFormAttachmentsSection';

// Extended type for case updates that might include task ID
interface UpdateCasePayload extends CreateCaseData {
  taskId?: string;
}

interface CaseCreationStepperProps {
  onSuccess?: (caseId: string) => void;
  onCancel?: () => void;
  editMode?: boolean;
  editCaseId?: string;
  initialData?: {
    customerInfo?: CustomerInfoData;
    caseFormData?: FullCaseFormData;
    caseLevelData?: {
      clientId: string;
      productId: string;
      backendContactNumber: string;
      createdByBackendUser: string;
    };
    tasks?: TaskFormData[];
  };
}

type Step = 'mode-selection' | 'customer-info' | 'case-details' | 'multi-task-details';
type CaseCreationMode = 'single-task' | 'multi-task';

// Helper function to map verification type names to backend expected values
const mapVerificationType = (verificationType: string): string => {
  const typeMap: Record<string, string> = {
    'Residence Verification': 'RESIDENCE',
    'Office Verification': 'OFFICE',
    'Business Verification': 'BUSINESS',
    'Other Verification': 'OTHER',
    'RESIDENCE': 'RESIDENCE',
    'OFFICE': 'OFFICE',
    'BUSINESS': 'BUSINESS',
    'OTHER': 'OTHER'
  };
  return typeMap[verificationType] || 'OTHER';
};

export const CaseCreationStepper: React.FC<CaseCreationStepperProps> = ({
  onSuccess,
  // onCancel - unused, keeping for interface compatibility
  editMode = false,
  editCaseId,
  initialData
}) => {
  const [currentStep, setCurrentStep] = useState<Step>(
    editMode ? 'multi-task-details' : 'customer-info'
  );
  // Always using multi-task mode - keeping state for future use
  const [_caseCreationMode, _setCaseCreationMode] = useState<CaseCreationMode>('multi-task');
  const [customerInfo, setCustomerInfo] = useState<CustomerInfoData | null>(
    initialData?.customerInfo || null
  );
  const [caseFormData, setCaseFormData] = useState<FullCaseFormData | null>(
    initialData?.caseFormData || null
  );

  // Deduplication state
  const [isSearching, setIsSearching] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [deduplicationResult, setDeduplicationResult] = useState<DeduplicationResult | null>(null);
  const [showDeduplicationDialog, setShowDeduplicationDialog] = useState(false);
  const [deduplicationCompleted, setDeduplicationCompleted] = useState(false);
  const [deduplicationRationale, setDeduplicationRationale] = useState<string>('Case created through two-step workflow');

  // Fetch pincodes for code lookup
  const { data: pincodesResponse } = usePincodes();
  const pincodes = pincodesResponse?.data || [];

  // Fetch verification types for ID lookup
  const { data: verificationTypesResponse } = useVerificationTypes();
  const verificationTypes = verificationTypesResponse?.data || [];

  // Update state when initialData changes (for edit mode)
  useEffect(() => {
    if (editMode && initialData) {
      if (initialData.customerInfo) {
        setCustomerInfo(initialData.customerInfo);
      }
      if (initialData.caseFormData) {
        setCaseFormData(initialData.caseFormData);
      }
    }
  }, [editMode, initialData]);

  const steps = editMode ? [
    {
      id: 'customer-info' as const,
      title: 'Customer Information',
      description: 'Update customer details',
      icon: User,
      completed: currentStep === 'multi-task-details',
    },
    {
      id: 'multi-task-details' as const,
      title: 'Case & Task Details',
      description: 'Update case and verification tasks',
      icon: Target,
      completed: false,
    },
  ] : [
    {
      id: 'customer-info' as const,
      title: 'Customer Information',
      description: 'Enter customer details',
      icon: User,
      completed: currentStep === 'multi-task-details' || (currentStep === 'customer-info' && customerInfo !== null),
    },
    {
      id: 'multi-task-details' as const,
      title: 'Case & Task Details',
      description: 'Configure case and verification task',
      icon: Target,
      completed: false,
    },
  ];

  const performDeduplicationSearch = async (data: CustomerInfoData) => {
    setIsSearching(true);

    // Store customer info immediately when search is performed
    setCustomerInfo(data);

    try {
      const criteria = deduplicationService.cleanCriteria({
        customerName: data.customerName,
        panNumber: data.panNumber,
        customerPhone: data.mobileNumber,
      });

      const validation = deduplicationService.validateCriteria(criteria);
      if (!validation.isValid) {
        toast.error(`Validation errors: ${validation.errors.join(', ')}`);
        setIsSearching(false);
        return;
      }

      console.warn('🔍 Performing deduplication search with criteria:', criteria);
      const result = await deduplicationService.searchDuplicates(criteria);
      console.warn('🔍 Deduplication search result:', result);

      if (result.success && result.data && result.data.duplicatesFound.length > 0) {
        // CRITICAL FIX: Show ALL duplicates, not just 100% matches
        // Let the user review and decide what to do
        console.warn(`⚠️ Found ${result.data.duplicatesFound.length} potential duplicate(s)`);

        // Show detailed match information in console for debugging
        result.data.duplicatesFound.forEach((dup, index) => {
          console.warn(`  Duplicate ${index + 1}:`, {
            caseId: dup.caseId,
            customerName: dup.customerName,
            matchScore: dup.matchScore,
            matchType: dup.matchType,
          });
        });

        // Always show the dialog when duplicates are found
        setDeduplicationResult(result.data);
        setShowDeduplicationDialog(true);
        setDeduplicationCompleted(true);

        // Use toast.error with orange/warning styling for duplicate alerts
        toast(`⚠️ Found ${result.data.duplicatesFound.length} potential duplicate case(s). Please review.`, {
          duration: 5000,
          icon: '⚠️',
          style: {
            background: '#FEF3C7',
            color: '#92400E',
            border: '1px solid #FCD34D',
          },
        });
      } else {
        // No duplicates at all - auto-proceed as "No Duplicates Found"
        console.warn('✅ No duplicate cases found');
        toast.success('No duplicate cases found. Proceeding to create new case.');
        setDeduplicationRationale('No duplicate cases found during automated check');
        setDeduplicationCompleted(true);
        proceedToCaseDetails(data);
      }
    } catch (error) {
      console.error('❌ Deduplication search failed:', error);
      toast.error('Deduplication search failed. Please try again or contact support.');
      setDeduplicationCompleted(false);
      setIsSearching(false);
    } finally {
      setIsSearching(false);
    }
  };

  const proceedToCaseDetails = (data: CustomerInfoData) => {
    setCustomerInfo(data);
    setCurrentStep('multi-task-details');
  };

  const handleSearchExisting = (data: CustomerInfoData) => {
    performDeduplicationSearch(data);
  };

  const handleCreateNew = (data: CustomerInfoData) => {
    proceedToCaseDetails(data);
  };

  const handleCustomerDataChange = () => {
    // Reset deduplication when customer data changes
    setDeduplicationCompleted(false);
    setDeduplicationResult(null);
    setDeduplicationRationale('Case created through two-step workflow');
  };

  const handleBackToCustomerInfo = () => {
    setCurrentStep('customer-info');
    setCaseFormData(null);
    // Reset deduplication when going back to customer info
    setDeduplicationCompleted(false);
    setDeduplicationResult(null);
    setDeduplicationRationale('Case created through two-step workflow');
  };



  const handleMultiTaskCaseCreation = async (caseLevelData: CaseLevelFormData, tasks: TaskFormData[]) => {
    if (!customerInfo) {
      toast.error('Customer information is missing');
      return;
    }

    setIsSubmitting(true);

    try {
      // Get verification type names for task titles
      const getVerificationTypeName = (id: number) => {
        const vt = verificationTypes.find(v => v.id === id);
        return vt?.name || 'Verification';
      };

      // Get pincode code from pincode ID
      const getPincodeCode = (pincodeId: string) => {
        const pincode = pincodes.find(p => p.id.toString() === pincodeId);
        return pincode?.code || pincodeId;
      };

      // Handle Edit Mode - Update Case
      if (editMode && editCaseId) {
        // For edit mode, we currently only support updating the case details and the first task
        // This is a limitation of the current backend API for updates
        const task = tasks[0];
        const selectedVerificationType = verificationTypes.find(vt => vt.id === task.verificationTypeId);
        const verificationTypeName = selectedVerificationType?.name || '';

        const caseData: UpdateCasePayload = {
          // Core case fields
          customerName: customerInfo.customerName,
          customerCallingCode: customerInfo.customerCallingCode,
          customerPhone: customerInfo.mobileNumber,
          createdByBackendUser: caseLevelData.createdByBackendUser,
          verificationType: mapVerificationType(verificationTypeName),
          address: task.address,
          pincode: getPincodeCode(task.pincodeId),
          assignedToId: task.assignedTo,
          clientId: caseLevelData.clientId,
          productId: caseLevelData.productId,
          verificationTypeId: (task.verificationTypeId || '').toString(),
          applicantType: task.applicantType,
          backendContactNumber: caseLevelData.backendContactNumber,
          priority: task.priority,
          trigger: task.trigger,
          rateTypeId: task.rateTypeId,
          taskId: task.id, // ✅ Pass the specific task ID to update

          // Deduplication fields
          panNumber: customerInfo.panNumber,
          deduplicationDecision: 'NO_DUPLICATES_FOUND', // Not relevant for update
          deduplicationRationale: 'Case update',
        };

        const response = await casesService.updateCaseDetails(editCaseId, caseData);

        if (response.success) {
          // Upload attachments if any
          if (task.attachments && task.attachments.length > 0) {
            try {
              const files = task.attachments.map(att => att.file);
              // For updates, we upload to the case generally or need task ID if available
              // Current update response might not return task IDs easily, so we upload to case
              // Ideally we should get the task ID for the updated task
              
            const uploadResponse = await attachmentsService.uploadAttachments({
                caseId: editCaseId,
                files,
                category: 'DOCUMENT'
            });

              if (uploadResponse.success) {
                toast.success(`${files.length} attachment(s) uploaded successfully`);
              } else {
                console.error('Attachment upload failed');
                toast.error('Case updated but attachments failed to upload');
              }
            // eslint-disable-next-line @typescript-eslint/no-explicit-any
            } catch (error: any) {
              console.error('Error uploading attachments:', error);
              toast.error(`Case updated but attachments failed: ${error.message || 'Unknown error'}`);
            }
          } else {
            toast.success('Case updated successfully!');
          }

          if (onSuccess) {
            onSuccess(editCaseId);
          }
        } else {
          toast.error(response.message || 'Failed to update case');
        }
        return;
      }

      // If only 1 task, use the regular single-task case creation endpoint
      if (tasks.length === 1) {
        const task = tasks[0];
        const selectedVerificationType = verificationTypes.find(vt => vt.id === task.verificationTypeId);
        const verificationTypeName = selectedVerificationType?.name || '';

        const caseData: CreateCaseData = {
          // Core case fields
          customerName: customerInfo.customerName,
          customerCallingCode: customerInfo.customerCallingCode,
          customerPhone: customerInfo.mobileNumber,
          createdByBackendUser: caseLevelData.createdByBackendUser,
          verificationType: mapVerificationType(verificationTypeName),
          address: task.address,
          pincode: getPincodeCode(task.pincodeId),
          assignedToId: task.assignedTo,
          clientId: caseLevelData.clientId,
          productId: caseLevelData.productId,
          verificationTypeId: (task.verificationTypeId || '').toString(),
          applicantType: task.applicantType,
          backendContactNumber: caseLevelData.backendContactNumber,
          priority: task.priority,
          trigger: task.trigger,
          rateTypeId: task.rateTypeId,

          // Deduplication fields
          panNumber: customerInfo.panNumber,
          deduplicationDecision: deduplicationRationale.includes('No duplicate cases found') ? 'NO_DUPLICATES_FOUND' : 'CREATE_NEW',
          deduplicationRationale,
        };

        const response = await casesService.createCase(caseData);

        if (response.success) {
          // Upload attachments if any
          if (task.attachments && task.attachments.length > 0) {
            try {
              const files = task.attachments.map(att => att.file);
              // Extract caseId (integer) and taskId (UUID) from response
              // Note: createCase uses unified /create endpoint which returns CreateCaseWithMultipleTasksResponse
              const caseId = response.data?.case?.caseId ? String(response.data.case.caseId) : null;
              const createdTasks = response.data?.tasks || [];
              const taskId = createdTasks.length > 0 ? createdTasks[0].id : null;

              console.warn('📎 Uploading attachments:', {
                caseId,
                taskId,
                caseIdType: typeof response.data?.case?.caseId,
                fileCount: files.length,
                responseData: response.data
              });

              if (caseId && taskId) {
                await casesService.uploadCaseAttachments(caseId, files, taskId);
                toast.success(`Case created successfully with ${task.attachments.length} attachment(s)!`);
              } else {
                console.error('❌ No caseId or taskId found in response:', response.data);
                toast.error('Case created but caseId/taskId not found for attachment upload');
              }
            // eslint-disable-next-line @typescript-eslint/no-explicit-any
            } catch (error: any) {
              console.error('❌ Error uploading attachments:', {
                error: error.message || error,
                stack: error.stack,
                caseId: response.data?.case?.caseId,
                taskId: response.data?.tasks?.[0]?.id
              });
              toast.error(`Case created but attachments failed: ${error.message || 'Unknown error'}`);
            }
          } else {
            toast.success('Case created successfully!');
          }

          if (onSuccess && response.data?.case?.caseId) {
            onSuccess(response.data.case.caseId.toString());
          }
        } else {
          toast.error(response.message || 'Failed to create case');
        }
      } else {
        // Multiple tasks - use multi-task endpoint
        const payload = {
          case_details: {
            customerName: customerInfo.customerName,
            customerPhone: customerInfo.mobileNumber,
            customerCallingCode: customerInfo.customerCallingCode,
            clientId: parseInt(caseLevelData.clientId),
            productId: parseInt(caseLevelData.productId),
            backendContactNumber: caseLevelData.backendContactNumber,
            priority: 'MEDIUM',
            pincode: tasks.length > 0 ? getPincodeCode(tasks[0].pincodeId) : '', // Use first task's pincode for case-level pincode
            panNumber: customerInfo.panNumber,
            deduplicationDecision: deduplicationRationale.includes('No duplicate cases found') ? 'NO_DUPLICATES_FOUND' : 'CREATE_NEW',
            deduplicationRationale,
          },
          verification_tasks: tasks.map((task, index) => {
            if (!task.verificationTypeId) {
              throw new Error(`Verification type missing for task ${index + 1}`);
            }
            return {
              verification_type_id: task.verificationTypeId,
              task_title: `${getVerificationTypeName(task.verificationTypeId)} - Task ${index + 1}`,
              task_description: task.trigger,
              priority: task.priority,
              assignedTo: task.assignedTo, // Use camelCase for consistency
              rate_type_id: task.rateTypeId ? parseInt(task.rateTypeId) : undefined,
              address: task.address,
              pincode: getPincodeCode(task.pincodeId),
              applicantType: task.applicantType, // Use camelCase for consistency with single task endpoint
              trigger: task.trigger,
              document_type: task.documentType || undefined,
              document_number: task.documentNumber || undefined,
            };
          })
        };

        const response = await casesService.createCaseWithMultipleTasks(payload);

        if (response.success && response.data) {
          // Upload attachments for each task if any
          // Extract caseId (integer) from response - must use integer for backend
          const caseId = response.data.case?.caseId ? String(response.data.case.caseId) : null;
          const createdTasks = response.data.tasks || [];
          let totalAttachments = 0;

          console.warn('📎 Multi-task case created, preparing to upload attachments:', {
            caseId,
            caseIdType: typeof response.data?.case?.caseId,
            tasksWithAttachments: tasks.filter(t => t.attachments && t.attachments.length > 0).length,
            createdTasksCount: createdTasks.length,
            responseData: response.data
          });

          if (caseId && createdTasks.length > 0) {
            // Match frontend tasks with backend tasks by index (they're in the same order)
            for (let i = 0; i < tasks.length; i++) {
              const frontendTask = tasks[i];
              const backendTask = createdTasks[i];

              if (frontendTask.attachments && frontendTask.attachments.length > 0 && backendTask) {
                try {
                  const files = frontendTask.attachments.map(att => att.file);
                  const taskId = backendTask.id; // UUID of the created verification task

                  console.warn(`📎 Uploading ${files.length} files for task ${i + 1} (ID: ${taskId})`);

                  // Upload attachments with verification_task_id
                  await casesService.uploadCaseAttachments(caseId, files, taskId);
                  totalAttachments += files.length;
                // eslint-disable-next-line @typescript-eslint/no-explicit-any
                } catch (error: any) {
                  console.error('❌ Error uploading task attachments:', {
                    taskIndex: i,
                    taskId: backendTask?.id,
                    error: error.message || error,
                    stack: error.stack
                  });
                  toast.error(`Some attachments failed: ${error.message || 'Unknown error'}`);
                }
              }
            }
          } else {
            console.error('❌ No caseId or tasks found in multi-task response:', response.data);
            if (tasks.some(t => t.attachments && t.attachments.length > 0)) {
              toast.error('Case created but caseId/tasks not found for attachment upload');
            }
          }

          if (totalAttachments > 0) {
            toast.success(`Case created successfully with ${tasks.length} tasks and ${totalAttachments} attachment(s)!`);
          } else {
            toast.success(`Case created successfully with ${tasks.length} tasks!`);
          }

          if (onSuccess && response.data?.case?.caseId) {
            onSuccess(response.data.case.caseId.toString());
          }
        } else {
          toast.error(response.message || 'Failed to create case');
        }
      }
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    } catch (error: any) {
      console.error('Error creating case:', error);
      toast.error(error.response?.data?.message || 'Failed to create case');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleCaseFormSubmit = async (data: FullCaseFormData, attachments: CaseFormAttachment[] = []) => {
    if (!customerInfo) {
      toast.error('Customer information is missing');
      return;
    }

    setIsSubmitting(true);
    
    try {
      // Get pincode code from pincode ID for backend compatibility
      const selectedPincode = pincodes.find(p => p.id.toString() === data.pincodeId);
      const pincodeCode = selectedPincode?.code || data.pincodeId;

      // Use verification type ID directly from form data
      const verificationTypeId = data.verificationTypeId;

      // Get verification type name for legacy verificationType field
      const selectedVerificationType = verificationTypes.find(vt => vt.id.toString() === data.verificationTypeId);
      const verificationTypeName = selectedVerificationType?.name || '';

      const caseData: CreateCaseData = {
        // Core case fields
        customerName: customerInfo.customerName,
        customerCallingCode: customerInfo.customerCallingCode,
        customerPhone: customerInfo.mobileNumber,
        createdByBackendUser: data.createdByBackendUser,
        verificationType: mapVerificationType(verificationTypeName),
        address: data.address,
        pincode: pincodeCode, // Use actual pincode code, not ID
        assignedToId: data.assignedToId,
        clientId: data.clientId, // Keep as string - backend will convert
        productId: data.productId, // Keep as string - backend will convert
        verificationTypeId, // Keep as string - backend will convert
        applicantType: data.applicantType,
        backendContactNumber: data.backendContactNumber,
        priority: data.priority,
        trigger: data.trigger,
        rateTypeId: data.rateTypeId, // Keep as string - backend will convert

        // Deduplication fields
        panNumber: customerInfo.panNumber,
        deduplicationDecision: deduplicationRationale.includes('No duplicate cases found') ? 'NO_DUPLICATES_FOUND' : 'CREATE_NEW',
        deduplicationRationale,
      };

      let result;
      if (editMode && editCaseId) {
        result = await casesService.updateCaseDetails(editCaseId, caseData);

        // Handle attachments separately for edit mode (if needed)
        if (attachments.length > 0) {
          try {
            const files = attachments.map(att => att.file);
            const uploadResponse = await attachmentsService.uploadAttachments({
                caseId: editCaseId,
                files,
                category: 'DOCUMENT'
            });

            if (uploadResponse.success) {
              toast.success(`${attachments.length} file(s) uploaded successfully`);
            } else {
              toast.error('Case updated but some attachments failed to upload');
            }
          } catch (uploadError) {
            console.error('Attachment upload failed:', uploadError);
            toast.error('Case updated but attachments failed to upload');
          }
        }
      } else {
        // Create new case with attachments in single request
        if (attachments.length > 0) {
          const attachmentFiles = attachments.map(att => att.file);
          result = await casesService.createCaseWithAttachments(caseData, attachmentFiles);

          if (result.success) {
            toast.success(`Case created successfully with ${attachments.length} attachment(s)!`);
          }
        } else {
          // No attachments, use regular create endpoint
          result = await casesService.createCase(caseData);
        }
      }

      if (result.success && result.data) {
        // Handle different response structures: Case (from update) vs CreateCaseWithMultipleTasksResponse (from create)
        const caseId = 'case' in result.data ? result.data.case.caseId : (result.data.caseId || result.data.id);

        const action = editMode ? 'updated' : 'created';
        toast.success(`Case ${action} successfully! Case ID: ${caseId}`);
        onSuccess?.(String(caseId));
      } else {
        const action = editMode ? 'update' : 'create';
        toast.error(`Failed to ${action} case`);
      }
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    } catch (error: any) {
      const errorMessage = error.response?.data?.error?.message || error.response?.data?.message || 'Failed to create case';
      toast.error(errorMessage);
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleCreateNewFromDialog = async (rationale: string) => {
    console.warn('🚀 Create New Case Anyway button clicked with rationale:', rationale);

    if (!customerInfo) {
      console.error('❌ No customer info available');
      toast.error('Customer information is missing');
      return;
    }

    try {
      // Record the deduplication decision for creating new case (but don't block UI on this)
      if (deduplicationResult) {
        console.warn('📝 Recording deduplication decision...');
        const decision = {
          caseId: 'NEW_CASE_PLACEHOLDER', // This will be updated by the backend
          decision: 'CREATE_NEW' as const,
          rationale,
          selectedExistingCaseId: undefined // No existing case selected
        };

        // Don't await this - let it happen in background
        deduplicationService.recordDeduplicationDecision(
          decision,
          deduplicationResult.duplicatesFound,
          deduplicationResult.searchCriteria
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        ).catch((error: any) => {
          console.error('Error recording deduplication decision (background):', error);
        });
      }

      // Immediately proceed to next step
      console.warn('✅ Proceeding to case details step...');
      setDeduplicationRationale(rationale);
      setShowDeduplicationDialog(false);
      setDeduplicationResult(null);
      proceedToCaseDetails(customerInfo);
      toast.success('Proceeding to create new case despite duplicates');

    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    } catch (error: any) {
      console.error('Error in handleCreateNewFromDialog:', error);
      toast.error('An error occurred, but proceeding to create case anyway');

      // Still proceed even if there's an error
      setDeduplicationRationale(rationale);
      setShowDeduplicationDialog(false);
      setDeduplicationResult(null);
      proceedToCaseDetails(customerInfo);
    }
  };

  const handleUseExistingFromDialog = async (caseId: string, rationale: string) => {
    try {
      // Record the deduplication decision
      if (deduplicationResult && customerInfo) {
        const decision = {
          caseId: 'NEW_CASE_PLACEHOLDER', // This will be updated by the backend
          decision: 'USE_EXISTING' as const,
          rationale,
          selectedExistingCaseId: caseId
        };

        await deduplicationService.recordDeduplicationDecision(
          decision,
          deduplicationResult.duplicatesFound,
          deduplicationResult.searchCriteria
        );
      }

      toast.success(`Redirecting to existing case: ${caseId}`);
      setShowDeduplicationDialog(false);
      setDeduplicationResult(null);

      // Navigate to the existing case instead of canceling
      onSuccess?.(caseId);
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    } catch (error: any) {
      console.error('Error recording deduplication decision:', error);
      toast.error('Failed to record decision, but redirecting to case anyway');

      // Still navigate even if recording fails
      setShowDeduplicationDialog(false);
      setDeduplicationResult(null);
      onSuccess?.(caseId);
    }
  };

  return (
    <div className="max-w-6xl mx-auto space-y-6">
      {/* Progress Stepper */}
      <Card>
        <CardContent className="p-6">
          <div className="flex items-center justify-between">
            {steps.map((step, index) => {
              const isActive = currentStep === step.id;
              const isCompleted = step.completed;
              const Icon = step.icon;

              return (
                <React.Fragment key={step.id}>
                  <div className="flex items-center space-x-3">
                    <div
                      className={`
                        flex items-center justify-center w-10 h-10 rounded-full border-2 transition-colors
                        ${isCompleted 
                          ? 'bg-green-500 border-green-500 text-white' 
                          : isActive 
                            ? 'bg-green-500 border-green-500 text-white' 
                            : 'bg-muted border-border text-gray-600'
                        }
                      `}
                    >
                      {isCompleted ? (
                        <Check className="h-5 w-5" />
                      ) : (
                        <Icon className="h-5 w-5" />
                      )}
                    </div>
                    <div className="flex flex-col">
                      <span
                        className={`text-sm font-medium ${
                          isActive ? 'text-green-600' : isCompleted ? 'text-green-600' : 'text-gray-600'
                        }`}
                      >
                        {step.title}
                      </span>
                      <span className="text-xs text-gray-600">{step.description}</span>
                    </div>
                  </div>
                  
                  {index < steps.length - 1 && (
                    <div
                      className={`flex-1 h-0.5 mx-4 ${
                        isCompleted ? 'bg-green-500' : 'bg-muted'
                      }`}
                    />
                  )}
                </React.Fragment>
              );
            })}
          </div>
        </CardContent>
      </Card>

      {/* Step Content */}
      <div className="min-h-[600px]">
        {currentStep === 'customer-info' && (
          <CustomerInfoStep
            onSearchExisting={handleSearchExisting}
            onCreateNew={handleCreateNew}
            isSearching={isSearching}
            initialData={customerInfo || {}}
            deduplicationCompleted={deduplicationCompleted}
            onDataChange={handleCustomerDataChange}
          />
        )}

        {/* FullCaseFormStep removed for edit mode as we now use TaskCaseCreationForm */}
        {/* Keeping logic for reference if needed, but it won't be rendered based on steps config */}
        {currentStep === 'case-details' && !editMode && (editMode || customerInfo) && (
          <FullCaseFormStep
            customerInfo={(customerInfo || initialData?.customerInfo || {}) as CustomerInfoData}
            onSubmit={handleCaseFormSubmit}
            onBack={editMode ? undefined : handleBackToCustomerInfo}
            isSubmitting={isSubmitting}
            initialData={caseFormData || initialData?.caseFormData || {}}
            editMode={editMode}
          />
        )}

        {currentStep === 'multi-task-details' && (editMode || customerInfo) && (
          <TaskCaseCreationForm
            customerInfo={(customerInfo || initialData?.customerInfo || {}) as CustomerInfoData}
            onSubmit={handleMultiTaskCaseCreation}
            onBack={editMode ? undefined : handleBackToCustomerInfo}
            isSubmitting={isSubmitting}
            initialData={editMode && initialData ? {
              caseLevelData: initialData.caseLevelData || initialData.caseFormData,
              tasks: initialData.tasks // ✅ Use tasks directly from NewCasePage
            } : undefined}
            editMode={editMode}
          />
        )}
      </div>

      {/* Deduplication Dialog */}
      <DeduplicationDialog
        isOpen={showDeduplicationDialog}
        onClose={() => {
          setShowDeduplicationDialog(false);
          setDeduplicationResult(null);
        }}
        deduplicationResult={deduplicationResult}
        onCreateNew={handleCreateNewFromDialog}
        onUseExisting={handleUseExistingFromDialog}
        isProcessing={isSubmitting}
      />
    </div>
  );
};
