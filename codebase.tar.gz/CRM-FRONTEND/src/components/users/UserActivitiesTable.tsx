import { Activity, Clock } from 'lucide-react';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { Badge, BadgeProps } from '@/components/ui/badge';
import { LoadingState } from '@/components/ui/loading';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { UserActivity } from '@/types/user';

interface UserActivitiesTableProps {
  data: UserActivity[];
  isLoading: boolean;
}

export function UserActivitiesTable({ data, isLoading }: UserActivitiesTableProps) {
  if (isLoading) {
    return <LoadingState message="Loading activities..." size="lg" />;
  }

  if (!data || data.length === 0) {
    return (
      <div className="text-center py-12">
        <Activity className="mx-auto h-12 w-12 text-gray-600" />
        <h3 className="mt-4 text-lg font-semibold">No activities found</h3>
        <p className="text-gray-600">
          User activities will appear here as they interact with the system.
        </p>
      </div>
    );
  }

  const getActionBadge = (action: string) => {
    const actionConfig: Record<string, { variant: BadgeProps['variant']; label: string }> = {
      LOGIN: { variant: 'default', label: 'Login' },
      LOGOUT: { variant: 'secondary', label: 'Logout' },
      CREATE: { variant: 'default', label: 'Create' },
      UPDATE: { variant: 'outline', label: 'Update' },
      DELETE: { variant: 'destructive', label: 'Delete' },
      VIEW: { variant: 'secondary', label: 'View' },
    };
    
    const config = actionConfig[action] || { variant: 'outline', label: action };
    return <Badge variant={config.variant}>{config.label}</Badge>;
  };

  return (
    <div className="rounded-md border overflow-auto">
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead>User</TableHead>
            <TableHead>Action</TableHead>
            <TableHead>Description</TableHead>
            <TableHead>IP Address</TableHead>
            <TableHead>Timestamp</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {data.map((activity) => (
            <TableRow key={activity.id}>
              <TableCell>
                <div className="flex items-center space-x-3">
                  <Avatar className="h-8 w-8">
                    <AvatarFallback>
                      {(activity.userName || 'U').split(' ').map(n => n[0]).join('').toUpperCase()}
                    </AvatarFallback>
                  </Avatar>
                  <div>
                    <div className="font-medium">{activity.userName || 'Unknown User'}</div>
                    <div className="text-sm text-gray-600">{activity.userId}</div>
                  </div>
                </div>
              </TableCell>
              <TableCell>
                {getActionBadge(activity.action)}
              </TableCell>
              <TableCell>
                <code className="text-[10px] bg-gray-100 p-1 rounded block max-w-[200px] truncate">
                  {JSON.stringify(activity.details || {})}
                </code>
              </TableCell>
              <TableCell>
                <span className="text-sm font-mono">{activity.ipAddress || 'N/A'}</span>
              </TableCell>
              <TableCell>
                <div className="flex items-center space-x-1 whitespace-nowrap">
                  <Clock className="h-3 w-3 text-gray-600" />
                  <span className="text-sm">
                    {new Date(activity.createdAt).toLocaleString()}
                  </span>
                </div>
              </TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </div>
  );
}
