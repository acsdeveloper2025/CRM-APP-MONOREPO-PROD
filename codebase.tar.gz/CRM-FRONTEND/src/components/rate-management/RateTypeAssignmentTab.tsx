import { useState, useEffect } from 'react';
import { useStandardizedQuery } from '@/hooks/useStandardizedQuery';
import { useMutationWithInvalidation } from '@/hooks/useStandardizedMutation';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Checkbox } from '@/components/ui/checkbox';
import { Badge } from '@/components/ui/badge';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { clientsService } from '@/services/clients';
import { productsService } from '@/services/products';
import { verificationTypesService } from '@/services/verificationTypes';
import { rateTypeAssignmentsService } from '@/services/rateTypeAssignments';

export function RateTypeAssignmentTab() {
  const [selectedClientId, setSelectedClientId] = useState<string>('');
  const [selectedProductId, setSelectedProductId] = useState<string>('');
  const [selectedVerificationTypeId, setSelectedVerificationTypeId] = useState<string>('');
  const [assignedRateTypeIds, setAssignedRateTypeIds] = useState<string[]>([]);

  // Fetch clients
  const { data: clientsData } = useStandardizedQuery({
    queryKey: ['clients'],
    queryFn: () => clientsService.getClients({ limit: 100 }),
    errorContext: 'Loading Clients',
    errorFallbackMessage: 'Failed to load clients',
  });

  // Fetch products for selected client
  const { data: productsData } = useStandardizedQuery({
    queryKey: ['client-products', selectedClientId],
    queryFn: () => productsService.getProductsByClient(selectedClientId),
    enabled: !!selectedClientId,
    errorContext: 'Loading Products',
    errorFallbackMessage: 'Failed to load products',
  });

  // Fetch verification types for selected product
  const { data: verificationTypesData } = useStandardizedQuery({
    queryKey: ['product-verification-types', selectedProductId],
    queryFn: () => verificationTypesService.getVerificationTypesByProduct(selectedProductId),
    enabled: !!selectedProductId,
    errorContext: 'Loading Verification Types',
    errorFallbackMessage: 'Failed to load verification types',
  });

  // Fetch assignment status for selected combination
  const { data: assignmentStatusData, isLoading: assignmentLoading } = useStandardizedQuery({
    queryKey: ['rate-type-assignments', selectedClientId, selectedProductId, selectedVerificationTypeId],
    queryFn: () => rateTypeAssignmentsService.getAssignmentsByCombination({
      clientId: Number(selectedClientId),
      productId: Number(selectedProductId),
      verificationTypeId: Number(selectedVerificationTypeId),
    }),
    enabled: !!(selectedClientId && selectedProductId && selectedVerificationTypeId),
    errorContext: 'Loading Rate Type Assignments',
    errorFallbackMessage: 'Failed to load rate type assignments',
  });

  // Update assigned rate types when assignment status changes
  useEffect(() => {
    if (assignmentStatusData?.data) {
      const assigned = assignmentStatusData.data
        .filter(item => item.isAssigned)
        .map(item => String(item.rateTypeId));
      setAssignedRateTypeIds(assigned);
    }
  }, [assignmentStatusData]);

  // Save assignments mutation
  const saveAssignmentsMutation = useMutationWithInvalidation({
    mutationFn: () => rateTypeAssignmentsService.bulkAssignRateTypes({
      clientId: Number(selectedClientId),
      productId: Number(selectedProductId),
      verificationTypeId: Number(selectedVerificationTypeId),
      rateTypeIds: assignedRateTypeIds.map(Number),
    }),
    invalidateKeys: [
      ['rate-type-assignments', selectedClientId, selectedProductId, selectedVerificationTypeId],
      ['rate-management-stats']
    ],
    successMessage: 'Rate type assignments saved successfully',
    errorContext: 'Rate Type Assignment',
    errorFallbackMessage: 'Failed to save rate type assignments',
  });

  const clients = clientsData?.data || [];
  const products = productsData?.data || [];
  const verificationTypes = verificationTypesData?.data || [];
  const assignmentStatus = assignmentStatusData?.data || [];

  const handleClientChange = (clientId: string) => {
    setSelectedClientId(clientId);
    setSelectedProductId('');
    setSelectedVerificationTypeId('');
    setAssignedRateTypeIds([]);
  };

  const handleProductChange = (productId: string) => {
    setSelectedProductId(productId);
    setSelectedVerificationTypeId('');
    setAssignedRateTypeIds([]);
  };

  const handleVerificationTypeChange = (verificationTypeId: string) => {
    setSelectedVerificationTypeId(verificationTypeId);
    setAssignedRateTypeIds([]);
  };

  const handleRateTypeToggle = (rateTypeId: string, checked: boolean) => {
    if (checked) {
      setAssignedRateTypeIds(prev => [...prev, rateTypeId]);
    } else {
      setAssignedRateTypeIds(prev => prev.filter(id => id !== rateTypeId));
    }
  };

  const handleSaveAssignments = () => {
    saveAssignmentsMutation.mutate();
  };

  const canShowAssignments = selectedClientId && selectedProductId && selectedVerificationTypeId;
  const hasChanges = assignmentStatus.length > 0 &&
    JSON.stringify(assignedRateTypeIds.sort()) !==
    JSON.stringify(assignmentStatus.filter(item => item.isAssigned).map(item => String(item.rateTypeId)).sort());

  return (
    <div className="space-y-6">
      {/* Selection Form */}
      <Card>
        <CardHeader>
          <CardTitle>Select Client-Product-Verification Type Combination</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {/* Client Selection */}
            <div className="space-y-2">
              <Label htmlFor="client-select">Client *</Label>
              <Select value={selectedClientId} onValueChange={handleClientChange}>
                <SelectTrigger>
                  <SelectValue placeholder="Select a client" />
                </SelectTrigger>
                <SelectContent>
                  {clients.map((client) => (
                    <SelectItem key={client.id} value={String(client.id)}>
                      {client.name} ({client.code})
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {/* Product Selection */}
            <div className="space-y-2">
              <Label htmlFor="product-select">Product *</Label>
              <Select
                value={selectedProductId}
                onValueChange={handleProductChange}
                disabled={!selectedClientId}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select a product" />
                </SelectTrigger>
                <SelectContent>
                  {products.map((product) => (
                    <SelectItem key={product.id} value={String(product.id)}>
                      {product.name} ({product.code})
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {/* Verification Type Selection */}
            <div className="space-y-2">
              <Label htmlFor="verification-type-select">Verification Type *</Label>
              <Select
                value={selectedVerificationTypeId}
                onValueChange={handleVerificationTypeChange}
                disabled={!selectedProductId}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select verification type" />
                </SelectTrigger>
                <SelectContent>
                  {verificationTypes.map((vt) => (
                    <SelectItem key={vt.id} value={String(vt.id)}>
                      {vt.name} ({vt.code})
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          {/* Selection Summary */}
          {canShowAssignments && (
            <div className="mt-4 p-4 bg-muted rounded-lg">
              <h4 className="font-medium mb-2">Selected Combination:</h4>
              <div className="flex flex-wrap gap-2">
                <Badge variant="outline">
                  Client: {clients.find(c => String(c.id) === selectedClientId)?.name}
                </Badge>
                <Badge variant="outline">
                  Product: {products.find(p => String(p.id) === selectedProductId)?.name}
                </Badge>
                <Badge variant="outline">
                  Verification: {verificationTypes.find(vt => String(vt.id) === selectedVerificationTypeId)?.name}
                </Badge>
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Rate Type Assignment */}
      {canShowAssignments && (
        <Card>
          <CardHeader>
            <CardTitle>Assign Rate Types</CardTitle>
          </CardHeader>
          <CardContent>
            {assignmentLoading ? (
              <div className="flex items-center justify-center py-8">
                <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary" />
              </div>
            ) : assignmentStatus.length === 0 ? (
              <p className="text-gray-600 text-center py-8">
                No rate types available for assignment
              </p>
            ) : (
              <div className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {assignmentStatus.map((rateType) => (
                    <div
                      key={rateType.rateTypeId}
                      className="flex items-center space-x-3 p-3 border rounded-lg"
                    >
                      <Checkbox
                        id={String(rateType.rateTypeId)}
                        checked={assignedRateTypeIds.includes(String(rateType.rateTypeId))}
                        onCheckedChange={(checked) =>
                          handleRateTypeToggle(String(rateType.rateTypeId), checked as boolean)
                        }
                      />
                      <div className="flex-1">
                        <Label
                          htmlFor={String(rateType.rateTypeId)}
                          className="font-medium cursor-pointer"
                        >
                          {rateType.rateTypeName}
                        </Label>
                        {rateType.rateTypeDescription && (
                          <p className="text-xs text-gray-600 mt-1">
                            {rateType.rateTypeDescription}
                          </p>
                        )}
                      </div>
                    </div>
                  ))}
                </div>

                {/* Save Button */}
                <div className="flex justify-end pt-4">
                  <Button
                    onClick={handleSaveAssignments}
                    disabled={!hasChanges || saveAssignmentsMutation.isPending}
                  >
                    {saveAssignmentsMutation.isPending ? 'Saving...' : 'Save Assignments'}
                  </Button>
                </div>

                {/* Assignment Summary */}
                <div className="mt-4 p-4 bg-muted rounded-lg">
                  <h4 className="font-medium mb-2">
                    Assigned Rate Types ({assignedRateTypeIds.length}):
                  </h4>
                  <div className="flex flex-wrap gap-2">
                    {assignedRateTypeIds.length === 0 ? (
                      <span className="text-gray-600 text-sm">No rate types assigned</span>
                    ) : (
                        assignedRateTypeIds.map(rateTypeId => {
                          const rateType = assignmentStatus.find(rt => String(rt.rateTypeId) === rateTypeId);
                        return (
                          <Badge key={rateTypeId} variant="default">
                            {rateType?.rateTypeName}
                          </Badge>
                        );
                      })
                    )}
                  </div>
                </div>
              </div>
            )}
          </CardContent>
        </Card>
      )}

      {/* Instructions */}
      <Card>
        <CardHeader>
          <CardTitle>Instructions</CardTitle>
        </CardHeader>
        <CardContent>
          <ol className="list-decimal list-inside space-y-2 text-sm text-gray-600">
            <li>Select a client from the dropdown to see available products and verification types</li>
            <li>Choose a product that is assigned to the selected client</li>
            <li>Select a verification type that is available for the client</li>
            <li>Check the rate types you want to assign to this combination</li>
            <li>Click &quot;Save Assignments&quot; to apply the changes</li>
            <li>Assigned rate types will be available for rate setting in the next tab</li>
          </ol>
        </CardContent>
      </Card>
    </div>
  );
}
