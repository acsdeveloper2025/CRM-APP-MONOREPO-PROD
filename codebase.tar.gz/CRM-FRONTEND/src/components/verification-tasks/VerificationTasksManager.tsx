import React, { useState } from 'react';
import { Card, CardContent, CardHeader } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Tabs, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { useVerificationTasks } from '@/hooks/useVerificationTasks';
import { VerificationTasksList } from './VerificationTasksList';
import { CreateTaskModal } from './CreateTaskModal';
import { TaskAssignmentModal } from './TaskAssignmentModal';
import { TaskCompletionModal } from './TaskCompletionModal';
import { TaskSummaryCards } from './TaskSummaryCards';
import { BulkActionsToolbar } from './BulkActionsToolbar';
import {
  Plus,
  Filter,
  RefreshCw,
  AlertCircle
} from 'lucide-react';

interface VerificationTasksManagerProps {
  caseId: string;
  caseNumber?: string;
  customerName?: string;
  readonly?: boolean;
}

export const VerificationTasksManager: React.FC<VerificationTasksManagerProps> = ({
  caseId,
  caseNumber,
  customerName,
  readonly = false
}) => {
  const [activeTab, setActiveTab] = useState<string>('all');
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [showAssignModal, setShowAssignModal] = useState(false);
  const [showCompleteModal, setShowCompleteModal] = useState(false);
  const [showFilters, setShowFilters] = useState(false);
  const [selectedTaskId, setSelectedTaskId] = useState<string | null>(null);
  const [selectedTasks, setSelectedTasks] = useState<string[]>([]);

  // Use the actual hook structure
  const { data, isLoading, error, refetch } = useVerificationTasks(caseId);
  
  const tasks = data?.tasks || [];
  const loading = isLoading;

  // Helper function to filter tasks by status
  const getTasksByStatus = (status: string) => {
    return tasks.filter(task => task.status === status);
  };

  // Get tasks by status for tabs
  const pendingTasks = getTasksByStatus('PENDING');
  const assignedTasks = getTasksByStatus('ASSIGNED');
  const inProgressTasks = getTasksByStatus('IN_PROGRESS');
  const completedTasks = getTasksByStatus('COMPLETED');
  const cancelledTasks = getTasksByStatus('CANCELLED');

  // Calculate summary
  const summary = {
    totalTasks: tasks.length,
    completedTasks: completedTasks.length,
    completionPercentage: tasks.length > 0 ? Math.round((completedTasks.length / tasks.length) * 100) : 0,
  };

  // Selection handlers
  const selectTask = (taskId: string) => {
    setSelectedTasks(prev => 
      prev.includes(taskId) 
        ? prev.filter(id => id !== taskId)
        : [...prev, taskId]
    );
  };

  const selectAllTasks = () => {
    if (selectedTasks.length === tasks.length) {
      setSelectedTasks([]);
    } else {
      setSelectedTasks(tasks.map(t => t.id));
    }
  };

  const clearSelection = () => {
    setSelectedTasks([]);
  };

  // Handle task actions
  const handleCreateTasks = async (_taskData: unknown[]) => {
    // TODO: Implement create tasks
    setShowCreateModal(false);
  };

  const handleAssignTask = async (_assignmentData: unknown) => {
    // TODO: Implement assign task
    setShowAssignModal(false);
    setSelectedTaskId(null);
  };

  const handleCompleteTask = async (_completionData: unknown) => {
    // TODO: Implement complete task
    setShowCompleteModal(false);
    setSelectedTaskId(null);
  };

  const handleBulkAssign = async (_assignedTo: string, _reason?: string) => {
    // TODO: Implement bulk assign
    clearSelection();
  };

  const handleRefresh = () => {
    refetch();
  };

  // Filter tasks based on active tab
  const getFilteredTasks = () => {
    switch (activeTab) {
      case 'pending':
        return pendingTasks;
      case 'assigned':
        return assignedTasks;
      case 'in-progress':
        return inProgressTasks;
      case 'completed':
        return completedTasks;
      case 'cancelled':
        return cancelledTasks;
      default:
        return tasks;
    }
  };

  const filteredTasks = getFilteredTasks();

  if (error) {
    return (
      <Card className="border-red-200">
        <CardContent className="p-6">
          <div className="flex items-center space-x-2 text-red-600">
            <AlertCircle className="h-5 w-5" />
            <span>Error loading verification tasks: {(error as Error).message}</span>
          </div>
          <Button 
            onClick={handleRefresh} 
            variant="outline" 
            size="sm" 
            className="mt-4"
          >
            <RefreshCw className="h-4 w-4 mr-2" />
            Retry
          </Button>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-gray-900">
            Verification Tasks
          </h2>
          {caseNumber && customerName && (
            <p className="text-sm text-gray-600 mt-1">
              Case #{caseNumber} - {customerName}
            </p>
          )}
        </div>
        
        <div className="flex items-center space-x-3">
          <Button
            onClick={() => setShowFilters(!showFilters)}
            variant="outline"
            size="sm"
          >
            <Filter className="h-4 w-4 mr-2" />
            Filters
          </Button>
          
          <Button
            onClick={handleRefresh}
            variant="outline"
            size="sm"
            disabled={loading}
          >
            <RefreshCw className={`h-4 w-4 mr-2 ${loading ? 'animate-spin' : ''}`} />
            Refresh
          </Button>
          
          {!readonly && (
            <Button
              onClick={() => setShowCreateModal(true)}
              size="sm"
            >
              <Plus className="h-4 w-4 mr-2" />
              Add Tasks
            </Button>
          )}
        </div>
      </div>

      {/* Summary Cards */}
      <TaskSummaryCards
        totalTasks={summary.totalTasks}
        completedTasks={summary.completedTasks}
        completionPercentage={summary.completionPercentage}
        pendingCount={pendingTasks.length}
        assignedCount={assignedTasks.length}
        inProgressCount={inProgressTasks.length}
      />

      {/* Bulk Actions */}
      {selectedTasks.length > 0 && !readonly && (
        <BulkActionsToolbar
          selectedCount={selectedTasks.length}
          onBulkAssign={handleBulkAssign}
          onClearSelection={clearSelection}
        />
      )}

      {/* Tasks Tabs */}
      <Card>
        <CardHeader className="pb-3">
          <Tabs value={activeTab} onValueChange={setActiveTab}>
            <TabsList className="grid w-full grid-cols-6">
              <TabsTrigger value="all" className="text-xs">
                All ({tasks.length})
              </TabsTrigger>
              <TabsTrigger value="pending" className="text-xs">
                Pending ({pendingTasks.length})
              </TabsTrigger>
              <TabsTrigger value="assigned" className="text-xs">
                Assigned ({assignedTasks.length})
              </TabsTrigger>
              <TabsTrigger value="in-progress" className="text-xs">
                In Progress ({inProgressTasks.length})
              </TabsTrigger>
              <TabsTrigger value="completed" className="text-xs">
                Completed ({completedTasks.length})
              </TabsTrigger>
              <TabsTrigger value="cancelled" className="text-xs">
                Cancelled ({cancelledTasks.length})
              </TabsTrigger>
            </TabsList>
          </Tabs>
        </CardHeader>
        
        <CardContent>
          <VerificationTasksList
            tasks={filteredTasks}
            loading={loading}
            selectedTasks={selectedTasks}
            readonly={readonly}
            onSelectTask={selectTask}
            onSelectAll={selectAllTasks}
            onAssignTask={(taskId) => {
              setSelectedTaskId(taskId);
              setShowAssignModal(true);
            }}
            onCompleteTask={(taskId) => {
              setSelectedTaskId(taskId);
              setShowCompleteModal(true);
            }}
          />
        </CardContent>
      </Card>

      {/* Modals */}
      {showCreateModal && (
        <CreateTaskModal
          caseId={caseId}
          onClose={() => setShowCreateModal(false)}
          onSubmit={handleCreateTasks}
        />
      )}

      {showAssignModal && selectedTaskId && (
        <TaskAssignmentModal
          taskId={selectedTaskId}
          onClose={() => {
            setShowAssignModal(false);
            setSelectedTaskId(null);
          }}
          onSubmit={handleAssignTask}
        />
      )}

      {showCompleteModal && selectedTaskId && (
        <TaskCompletionModal
          taskId={selectedTaskId}
          onClose={() => {
            setShowCompleteModal(false);
            setSelectedTaskId(null);
          }}
          onSubmit={handleCompleteTask}
        />
      )}
    </div>
  );
};
