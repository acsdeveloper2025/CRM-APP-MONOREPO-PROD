import React, { useState } from 'react';
import { Header } from './Header';
import { Sidebar } from './Sidebar';

interface LayoutProps {
  children: React.ReactNode;
}

export const Layout: React.FC<LayoutProps> = ({ children }) => {
  const [sidebarOpen, setSidebarOpen] = useState(false);

  const handleMenuClick = () => {
    setSidebarOpen(!sidebarOpen);
  };

  const handleSidebarClose = () => {
    setSidebarOpen(false);
  };

  return (
    <div className="min-h-screen bg-[#FAFAFA] overflow-x-hidden">
      <Sidebar isOpen={sidebarOpen} onClose={handleSidebarClose} />
      <div className="lg:pl-64 transition-all duration-300 min-h-screen flex flex-col">
        <Header onMenuClick={handleMenuClick} />
        <main className="flex-1 py-3 sm:py-4 lg:py-6 animate-fade-in">
          <div className="container mx-auto px-4 sm:px-6 lg:px-8 h-full max-w-none lg:max-w-7xl">
            {children}
          </div>
        </main>
      </div>
    </div>
  );
};
