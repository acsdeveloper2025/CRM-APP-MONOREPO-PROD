--
-- PostgreSQL database dump
--

\restrict iC0bCh7To5NZbPBCxTPvStnGc93ArZHhMGKcis4f4Ll6G92dPxPpA5pe40qaE4M

-- Dumped from database version 17.8 (Homebrew)
-- Dumped by pg_dump version 17.8 (Homebrew)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON SCHEMA public IS '';


--
-- Name: pg_trgm; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pg_trgm WITH SCHEMA public;


--
-- Name: EXTENSION pg_trgm; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION pg_trgm IS 'text similarity measurement and index searching based on trigrams';


--
-- Name: pgcrypto; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pgcrypto WITH SCHEMA public;


--
-- Name: EXTENSION pgcrypto; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION pgcrypto IS 'cryptographic functions';


--
-- Name: task_type_enum; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.task_type_enum AS ENUM (
    'NORMAL',
    'REVISIT'
);


--
-- Name: assign_rate_types_to_area(uuid, uuid[], uuid); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.assign_rate_types_to_area(area_id uuid, rate_type_ids uuid[], user_id uuid) RETURNS integer
    LANGUAGE plpgsql
    AS $$
DECLARE
    rate_type_id UUID;
    inserted_count INTEGER := 0;
BEGIN
    -- Deactivate existing assignments
    UPDATE area_rate_types 
    SET "isActive" = false, "updatedBy" = user_id, "updatedAt" = CURRENT_TIMESTAMP
    WHERE "areaId" = area_id AND "isActive" = true;
    
    -- Insert new assignments
    FOREACH rate_type_id IN ARRAY rate_type_ids
    LOOP
        INSERT INTO area_rate_types ("areaId", "rateTypeId", "createdBy")
        VALUES (area_id, rate_type_id, user_id)
        ON CONFLICT ("areaId", "rateTypeId") 
        DO UPDATE SET 
            "isActive" = true,
            "updatedBy" = user_id,
            "updatedAt" = CURRENT_TIMESTAMP;
        
        inserted_count := inserted_count + 1;
    END LOOP;
    
    RETURN inserted_count;
END;
$$;


--
-- Name: audit_territory_assignment_changes(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.audit_territory_assignment_changes() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    -- Handle INSERT (new assignments)
    IF TG_OP = 'INSERT' THEN
        INSERT INTO "territoryAssignmentAudit" (
            "userId", "assignmentType", "assignmentId", "action", 
            "previousData", "newData", "performedBy", "reason"
        ) VALUES (
            NEW."userId",
            CASE WHEN TG_TABLE_NAME = 'userPincodeAssignments' THEN 'PINCODE' ELSE 'AREA' END,
            NEW.id,
            'ASSIGNED',
            NULL,
            row_to_json(NEW),
            NEW."assignedBy",
            'Territory assignment created'
        );
        RETURN NEW;
    END IF;
    
    -- Handle UPDATE (assignment modifications)
    IF TG_OP = 'UPDATE' THEN
        INSERT INTO "territoryAssignmentAudit" (
            "userId", "assignmentType", "assignmentId", "action", 
            "previousData", "newData", "performedBy", "reason"
        ) VALUES (
            NEW."userId",
            CASE WHEN TG_TABLE_NAME = 'userPincodeAssignments' THEN 'PINCODE' ELSE 'AREA' END,
            NEW.id,
            CASE WHEN OLD."isActive" = true AND NEW."isActive" = false THEN 'UNASSIGNED' ELSE 'MODIFIED' END,
            row_to_json(OLD),
            row_to_json(NEW),
            COALESCE(NEW."assignedBy", OLD."assignedBy"),
            CASE WHEN OLD."isActive" = true AND NEW."isActive" = false THEN 'Territory assignment deactivated' ELSE 'Territory assignment modified' END
        );
        RETURN NEW;
    END IF;
    
    RETURN NULL;
END;
$$;


--
-- Name: cleanup_performance_data(integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.cleanup_performance_data(days_to_keep integer DEFAULT 30) RETURNS integer
    LANGUAGE plpgsql
    AS $$
DECLARE
    deleted_count INTEGER;
BEGIN
    -- Clean up old performance metrics
    DELETE FROM performance_metrics WHERE timestamp < NOW() - INTERVAL '1 day' * days_to_keep;
    GET DIAGNOSTICS deleted_count = ROW_COUNT;
    
    -- Clean up old query performance data
    DELETE FROM query_performance WHERE timestamp < NOW() - INTERVAL '1 day' * days_to_keep;
    
    -- Clean up old error logs (keep longer for analysis)
    DELETE FROM error_logs WHERE timestamp < NOW() - INTERVAL '1 day' * (days_to_keep * 2);
    
    -- Clean up old system health metrics
    DELETE FROM system_health_metrics WHERE timestamp < NOW() - INTERVAL '1 day' * days_to_keep;
    
    RETURN deleted_count;
END;
$$;


--
-- Name: FUNCTION cleanup_performance_data(days_to_keep integer); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION public.cleanup_performance_data(days_to_keep integer) IS 'Cleans up old performance monitoring data to prevent table bloat';


--
-- Name: create_default_notification_preferences(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.create_default_notification_preferences() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  INSERT INTO notification_preferences (user_id)
  VALUES (NEW.id)
  ON CONFLICT (user_id) DO NOTHING;
  RETURN NEW;
END;
$$;


--
-- Name: create_rate_history(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.create_rate_history() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    IF TG_OP = 'UPDATE' AND OLD.amount != NEW.amount THEN
        INSERT INTO "rateHistory" ("rateId", "oldAmount", "newAmount", "changedBy")
        VALUES (NEW.id, OLD.amount, NEW.amount, NEW."createdBy");
    END IF;
    RETURN NEW;
END;
$$;


--
-- Name: generate_task_number(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.generate_task_number() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    IF NEW.task_number IS NULL THEN
        NEW.task_number := 'VT-' || LPAD(nextval('verification_task_number_seq')::TEXT, 6, '0');
    END IF;
    RETURN NEW;
END;
$$;


--
-- Name: get_index_usage(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.get_index_usage() RETURNS TABLE(schemaname text, tablename text, indexname text, idx_scan bigint, idx_tup_read bigint, idx_tup_fetch bigint)
    LANGUAGE plpgsql
    AS $$
BEGIN
    RETURN QUERY
    SELECT 
        s.schemaname::TEXT,
        s.tablename::TEXT,
        s.indexname::TEXT,
        s.idx_scan,
        s.idx_tup_read,
        s.idx_tup_fetch
    FROM pg_stat_user_indexes s
    ORDER BY s.idx_scan DESC;
END;
$$;


--
-- Name: FUNCTION get_index_usage(); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION public.get_index_usage() IS 'Returns index usage statistics to identify unused indexes';


--
-- Name: get_migration_summary(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.get_migration_summary() RETURNS TABLE(metric text, value bigint, description text)
    LANGUAGE plpgsql
    AS $$
BEGIN
    RETURN QUERY
    SELECT 
        'Total Cases'::TEXT,
        (SELECT COUNT(*) FROM cases)::BIGINT,
        'Total number of cases in the system'::TEXT
    UNION ALL
    SELECT 
        'Cases with Tasks'::TEXT,
        (SELECT COUNT(DISTINCT case_id) FROM verification_tasks)::BIGINT,
        'Cases that have been migrated to multi-task structure'::TEXT
    UNION ALL
    SELECT 
        'Total Tasks'::TEXT,
        (SELECT COUNT(*) FROM verification_tasks)::BIGINT,
        'Total number of verification tasks'::TEXT
    UNION ALL
    SELECT 
        'Multi-Task Cases'::TEXT,
        (SELECT COUNT(*) FROM cases WHERE has_multiple_tasks = true)::BIGINT,
        'Cases with multiple verification tasks'::TEXT
    UNION ALL
    SELECT 
        'Task Commissions'::TEXT,
        (SELECT COUNT(*) FROM task_commission_calculations)::BIGINT,
        'Commission calculations for individual tasks'::TEXT
    UNION ALL
    SELECT 
        'Completed Tasks'::TEXT,
        (SELECT COUNT(*) FROM verification_tasks WHERE status = 'COMPLETED')::BIGINT,
        'Tasks that have been completed'::TEXT;
END;
$$;


--
-- Name: is_rate_type_available_for_area(uuid, uuid); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.is_rate_type_available_for_area(area_id uuid, rate_type_id uuid) RETURNS boolean
    LANGUAGE plpgsql
    AS $$
BEGIN
    RETURN EXISTS (
        SELECT 1 FROM area_rate_types 
        WHERE "areaId" = area_id 
          AND "rateTypeId" = rate_type_id 
          AND "isActive" = true
    );
END;
$$;


--
-- Name: log_rate_changes(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.log_rate_changes() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    IF TG_OP = 'INSERT' THEN
        INSERT INTO rate_history (
            "rateId", "clientId", "productId", "verificationTypeId", 
            "pincodeId", "areaId", "rateTypeId", "newRateAmount", 
            "effectiveFrom", "effectiveTo", "action", "changedBy"
        ) VALUES (
            NEW.id, NEW."clientId", NEW."productId", NEW."verificationTypeId",
            NEW."pincodeId", NEW."areaId", NEW."rateTypeId", NEW."rateAmount",
            NEW."effectiveFrom", NEW."effectiveTo", 'CREATE', NEW."createdBy"
        );
        RETURN NEW;
    ELSIF TG_OP = 'UPDATE' THEN
        IF OLD."rateAmount" != NEW."rateAmount" OR OLD."effectiveFrom" != NEW."effectiveFrom" OR OLD."effectiveTo" != NEW."effectiveTo" THEN
            INSERT INTO rate_history (
                "rateId", "clientId", "productId", "verificationTypeId", 
                "pincodeId", "areaId", "rateTypeId", "oldRateAmount", "newRateAmount", 
                "effectiveFrom", "effectiveTo", "action", "changedBy"
            ) VALUES (
                NEW.id, NEW."clientId", NEW."productId", NEW."verificationTypeId",
                NEW."pincodeId", NEW."areaId", NEW."rateTypeId", OLD."rateAmount", NEW."rateAmount",
                NEW."effectiveFrom", NEW."effectiveTo", 'UPDATE', NEW."updatedBy"
            );
        END IF;
        RETURN NEW;
    ELSIF TG_OP = 'DELETE' THEN
        INSERT INTO rate_history (
            "rateId", "clientId", "productId", "verificationTypeId", 
            "pincodeId", "areaId", "rateTypeId", "oldRateAmount", "newRateAmount", 
            "effectiveFrom", "effectiveTo", "action", "changedBy"
        ) VALUES (
            OLD.id, OLD."clientId", OLD."productId", OLD."verificationTypeId",
            OLD."pincodeId", OLD."areaId", OLD."rateTypeId", OLD."rateAmount", 0,
            OLD."effectiveFrom", OLD."effectiveTo", 'DELETE', OLD."updatedBy"
        );
        RETURN OLD;
    END IF;
    RETURN NULL;
END;
$$;


--
-- Name: migrate_existing_cases_to_multi_verification(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.migrate_existing_cases_to_multi_verification() RETURNS TABLE(migrated_cases integer, migrated_tasks integer, migrated_commissions integer, errors text[])
    LANGUAGE plpgsql
    AS $$
DECLARE
    case_record RECORD;
    task_id UUID;
    migrated_count INTEGER := 0;
    task_count INTEGER := 0;
    commission_count INTEGER := 0;
    error_messages TEXT[] := ARRAY[]::TEXT[];
    commission_record RECORD;
    estimated_rate NUMERIC(10,2);
BEGIN
    -- Start transaction for data safety
    RAISE NOTICE 'Starting migration of existing cases to multi-verification structure...';
    
    -- Loop through all existing cases that don't have verification tasks
    FOR case_record IN 
        SELECT c.* FROM cases c 
        LEFT JOIN verification_tasks vt ON c.id = vt.case_id 
        WHERE vt.id IS NULL
        AND c."verificationTypeId" IS NOT NULL  -- Only migrate cases with verification types
    LOOP
        BEGIN
            -- Get estimated rate for this case
            SELECT r.amount INTO estimated_rate
            FROM rates r 
            WHERE r."rateTypeId" = case_record."rateTypeId"
            AND r."clientId" = case_record."clientId"
            AND r."verificationTypeId" = case_record."verificationTypeId"
            AND r."isActive" = true
            ORDER BY r."effectiveFrom" DESC
            LIMIT 1;
            
            -- Use default if no rate found
            IF estimated_rate IS NULL THEN
                estimated_rate := 500.00;
            END IF;
            
            -- Create a verification task for each existing case
            INSERT INTO verification_tasks (
                case_id,
                verification_type_id,
                task_title,
                task_description,
                priority,
                assigned_to,
                assigned_by,
                assigned_at,
                status,
                verification_outcome,
                rate_type_id,
                estimated_amount,
                actual_amount,
                address,
                pincode,
                completed_at,
                started_at,
                created_at,
                updated_at,
                created_by
            ) VALUES (
                case_record.id,
                case_record."verificationTypeId",
                'Legacy Verification Task',
                'Migrated from existing case structure',
                COALESCE(case_record.priority, 'MEDIUM'),
                case_record."assignedTo",
                case_record."createdByBackendUser",
                CASE 
                    WHEN case_record."assignedTo" IS NOT NULL THEN case_record."createdAt"
                    ELSE NULL 
                END,
                CASE 
                    WHEN case_record.status = 'COMPLETED' THEN 'COMPLETED'
                    WHEN case_record.status = 'IN_PROGRESS' THEN 'IN_PROGRESS'
                    WHEN case_record."assignedTo" IS NOT NULL THEN 'ASSIGNED'
                    ELSE 'PENDING'
                END,
                case_record."verificationOutcome",
                case_record."rateTypeId",
                estimated_rate,
                -- Actual amount same as estimated for completed cases
                CASE 
                    WHEN case_record.status = 'COMPLETED' THEN estimated_rate
                    ELSE NULL
                END,
                case_record.address,
                case_record.pincode,
                case_record."completedAt",
                CASE 
                    WHEN case_record.status IN ('IN_PROGRESS', 'COMPLETED') THEN case_record."createdAt"
                    ELSE NULL 
                END,
                case_record."createdAt",
                case_record."updatedAt",
                case_record."createdByBackendUser"
            ) RETURNING id INTO task_id;
            
            task_count := task_count + 1;
            
            -- Create assignment history if task was assigned
            IF case_record."assignedTo" IS NOT NULL THEN
                INSERT INTO task_assignment_history (
                    verification_task_id, 
                    case_id, 
                    assigned_to, 
                    assigned_by,
                    assignment_reason, 
                    task_status_before, 
                    task_status_after,
                    assigned_at
                ) VALUES (
                    task_id, 
                    case_record.id, 
                    case_record."assignedTo", 
                    case_record."createdByBackendUser",
                    'Migrated from legacy case assignment', 
                    'PENDING', 
                    CASE 
                        WHEN case_record.status = 'COMPLETED' THEN 'COMPLETED'
                        WHEN case_record.status = 'IN_PROGRESS' THEN 'IN_PROGRESS'
                        ELSE 'ASSIGNED'
                    END,
                    case_record."createdAt"
                );
            END IF;
            
            -- Update the case to reflect it now has tasks
            UPDATE cases 
            SET 
                has_multiple_tasks = FALSE,  -- Single task migration
                total_tasks_count = 1,
                completed_tasks_count = CASE WHEN case_record.status = 'COMPLETED' THEN 1 ELSE 0 END,
                case_completion_percentage = CASE WHEN case_record.status = 'COMPLETED' THEN 100.00 ELSE 0.00 END,
                "updatedAt" = CURRENT_TIMESTAMP
            WHERE id = case_record.id;
            
            -- Migrate existing commission calculations
            FOR commission_record IN 
                SELECT * FROM commission_calculations 
                WHERE case_id = case_record.id 
                AND verification_task_id IS NULL
            LOOP
                -- Create new task commission calculation
                INSERT INTO task_commission_calculations (
                    verification_task_id,
                    case_id,
                    task_number,
                    user_id,
                    client_id,
                    rate_type_id,
                    base_amount,
                    commission_amount,
                    calculated_commission,
                    calculation_method,
                    calculation_date,
                    status,
                    task_completed_at,
                    verification_outcome,
                    created_at,
                    updated_at,
                    notes
                ) VALUES (
                    task_id,
                    commission_record.case_id,
                    (SELECT task_number FROM verification_tasks WHERE id = task_id),
                    commission_record.user_id,
                    case_record."clientId",
                    COALESCE(case_record."rateTypeId", commission_record.rate_type_id),
                    commission_record.commission_amount,
                    commission_record.commission_amount,
                    commission_record.commission_amount,
                    COALESCE(commission_record.calculation_method, 'FIXED_AMOUNT'),
                    COALESCE(commission_record.created_at, case_record."createdAt"),
                    COALESCE(commission_record.status, 'CALCULATED'),
                    COALESCE(case_record."completedAt", case_record."createdAt"),
                    case_record."verificationOutcome",
                    commission_record.created_at,
                    CURRENT_TIMESTAMP,
                    'Migrated from legacy commission calculation'
                );
                
                -- Link the old commission calculation to the new task
                UPDATE commission_calculations 
                SET verification_task_id = task_id
                WHERE id = commission_record.id;
                
                commission_count := commission_count + 1;
            END LOOP;
            
            migrated_count := migrated_count + 1;
            
            -- Log progress every 100 cases
            IF migrated_count % 100 = 0 THEN
                RAISE NOTICE 'Migrated % cases so far...', migrated_count;
            END IF;
            
        EXCEPTION WHEN OTHERS THEN
            error_messages := array_append(error_messages, 
                'Error migrating case ' || case_record.id || ': ' || SQLERRM);
            RAISE NOTICE 'Error migrating case %: %', case_record.id, SQLERRM;
        END;
    END LOOP;
    
    -- Return migration statistics
    RAISE NOTICE 'Migration completed: % cases, % tasks, % commissions', 
        migrated_count, task_count, commission_count;
    
    RETURN QUERY SELECT migrated_count, task_count, commission_count, error_messages;
END;
$$;


--
-- Name: rollback_migration(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.rollback_migration() RETURNS text
    LANGUAGE plpgsql
    AS $$
DECLARE
    result_text TEXT;
BEGIN
    -- This function provides a way to rollback the migration
    -- WARNING: This will delete all migrated data
    
    RAISE NOTICE 'Starting migration rollback...';
    
    -- Delete task commission calculations
    DELETE FROM task_commission_calculations;
    
    -- Delete task assignment history
    DELETE FROM task_assignment_history;
    
    -- Delete task form submissions
    DELETE FROM task_form_submissions;
    
    -- Delete verification tasks
    DELETE FROM verification_tasks;
    
    -- Reset case fields
    UPDATE cases SET 
        has_multiple_tasks = NULL,
        total_tasks_count = NULL,
        completed_tasks_count = NULL,
        case_completion_percentage = NULL,
        updated_at = CURRENT_TIMESTAMP;
    
    -- Reset commission calculations
    UPDATE commission_calculations SET 
        verification_task_id = NULL,
        updated_at = CURRENT_TIMESTAMP;
    
    -- Reset sequences
    ALTER SEQUENCE verification_task_number_seq RESTART WITH 1;
    
    result_text := 'Migration rollback completed successfully';
    RAISE NOTICE '%', result_text;
    
    RETURN result_text;
END;
$$;


--
-- Name: set_updated_at_roles_v2(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.set_updated_at_roles_v2() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  NEW.updated_at = CURRENT_TIMESTAMP;
  RETURN NEW;
END;
$$;


--
-- Name: update_ai_reports_updated_at(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.update_ai_reports_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$;


--
-- Name: update_areas_updated_at(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.update_areas_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$;


--
-- Name: update_builder_verification_updated_at(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.update_builder_verification_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$;


--
-- Name: update_business_verification_updated_at(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.update_business_verification_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$;


--
-- Name: update_camel_case_updated_at(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.update_camel_case_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW."updatedAt" = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$;


--
-- Name: update_case_completion_percentage(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.update_case_completion_percentage() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
    total_tasks INTEGER;
    completed_tasks INTEGER;
    in_progress_tasks INTEGER;
    assigned_tasks INTEGER;
    new_status VARCHAR;
BEGIN
    -- Get counts
    SELECT 
        COUNT(*),
        COUNT(CASE WHEN status = 'COMPLETED' THEN 1 END),
        COUNT(CASE WHEN status = 'IN_PROGRESS' THEN 1 END),
        COUNT(CASE WHEN status = 'ASSIGNED' THEN 1 END)
    INTO 
        total_tasks,
        completed_tasks,
        in_progress_tasks,
        assigned_tasks
    FROM verification_tasks
    WHERE case_id = NEW.case_id;

    -- Determine Status
    IF total_tasks > 0 AND completed_tasks = total_tasks THEN
        new_status := 'COMPLETED';
    ELSIF in_progress_tasks > 0 THEN
        new_status := 'IN_PROGRESS';
    ELSIF assigned_tasks > 0 THEN
        new_status := 'ASSIGNED';
    ELSE
        new_status := 'PENDING';
    END IF;

    -- Update Case
    UPDATE cases
    SET
        completed_tasks_count = completed_tasks,
        case_completion_percentage = CASE 
            WHEN total_tasks = 0 THEN 0 
            ELSE ROUND((completed_tasks::DECIMAL / total_tasks::DECIMAL) * 100, 2) 
        END,
        status = new_status,
        "updatedAt" = CURRENT_TIMESTAMP
    WHERE id = NEW.case_id;

    RETURN NEW;
END;
$$;


--
-- Name: update_cases_updated_at(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.update_cases_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  NEW."updatedAt" = NOW();
  RETURN NEW;
END;
$$;


--
-- Name: update_cities_updated_at(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.update_cities_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN NEW."updatedAt" = CURRENT_TIMESTAMP; RETURN NEW; END; $$;


--
-- Name: update_clients_updated_at(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.update_clients_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN NEW."updatedAt" = CURRENT_TIMESTAMP; RETURN NEW; END; $$;


--
-- Name: update_countries_updated_at(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.update_countries_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN NEW."updatedAt" = CURRENT_TIMESTAMP; RETURN NEW; END; $$;


--
-- Name: update_departments_updated_at(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.update_departments_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW."updatedAt" = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$;


--
-- Name: update_designations_updated_at(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.update_designations_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW."updatedAt" = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$;


--
-- Name: update_document_type_rates_updated_at(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.update_document_type_rates_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW."updatedAt" = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$;


--
-- Name: update_dsa_connector_verification_updated_at(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.update_dsa_connector_verification_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$;


--
-- Name: update_mac_addresses_updated_at(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.update_mac_addresses_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  NEW."updatedAt" = CURRENT_TIMESTAMP;
  RETURN NEW;
END;
$$;


--
-- Name: update_mobile_notification_audit_updated_at(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.update_mobile_notification_audit_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW."updatedAt" = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$;


--
-- Name: update_noc_verification_updated_at(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.update_noc_verification_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$;


--
-- Name: update_office_verification_updated_at(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.update_office_verification_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$;


--
-- Name: update_pincode_areas_updated_at(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.update_pincode_areas_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$;


--
-- Name: update_pincodes_updated_at(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.update_pincodes_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN NEW."updatedAt" = CURRENT_TIMESTAMP; RETURN NEW; END; $$;


--
-- Name: update_products_updated_at(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.update_products_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN NEW."updatedAt" = CURRENT_TIMESTAMP; RETURN NEW; END; $$;


--
-- Name: update_property_apf_verification_updated_at(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.update_property_apf_verification_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$;


--
-- Name: update_property_individual_verification_updated_at(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.update_property_individual_verification_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$;


--
-- Name: update_residence_cum_office_verification_updated_at(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.update_residence_cum_office_verification_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$;


--
-- Name: update_residence_verification_updated_at(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.update_residence_verification_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$;


--
-- Name: update_roles_updated_at(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.update_roles_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW."updatedAt" = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$;


--
-- Name: update_states_updated_at(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.update_states_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN NEW."updatedAt" = CURRENT_TIMESTAMP; RETURN NEW; END; $$;


--
-- Name: update_task_updated_at(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.update_task_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$;


--
-- Name: update_template_reports_updated_at(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.update_template_reports_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$;


--
-- Name: update_updated_at_column(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.update_updated_at_column() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF to_jsonb(NEW) ? 'updatedAt' THEN
    NEW := jsonb_populate_record(NEW, jsonb_build_object('updatedAt', CURRENT_TIMESTAMP));
  ELSIF to_jsonb(NEW) ? 'updated_at' THEN
    NEW := jsonb_populate_record(NEW, jsonb_build_object('updated_at', CURRENT_TIMESTAMP));
  END IF;

  RETURN NEW;
END;
$$;


--
-- Name: update_users_updated_at(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.update_users_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  NEW."updatedAt" = NOW();
  RETURN NEW;
END;
$$;


--
-- Name: update_verification_types_updated_at(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.update_verification_types_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN NEW."updatedAt" = CURRENT_TIMESTAMP; RETURN NEW; END; $$;


--
-- Name: validate_device_id(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.validate_device_id() RETURNS trigger
    LANGUAGE plpgsql
    AS $_$
BEGIN
    IF NEW."deviceId" IS NOT NULL AND NEW."deviceId" !~ '^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$' THEN
        RAISE EXCEPTION 'deviceId must be a valid UUID format';
    END IF;
    RETURN NEW;
END;
$_$;


--
-- Name: validate_migration_results(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.validate_migration_results() RETURNS TABLE(validation_check text, expected_count bigint, actual_count bigint, status text)
    LANGUAGE plpgsql
    AS $$
BEGIN
    -- Check if all cases have corresponding tasks
    RETURN QUERY
    SELECT 
        'Cases with verification tasks'::TEXT,
        (SELECT COUNT(*) FROM cases WHERE "verificationTypeId" IS NOT NULL)::BIGINT,
        (SELECT COUNT(DISTINCT case_id) FROM verification_tasks)::BIGINT,
        CASE 
            WHEN (SELECT COUNT(*) FROM cases WHERE "verificationTypeId" IS NOT NULL) = 
                 (SELECT COUNT(DISTINCT case_id) FROM verification_tasks)
            THEN 'PASS'::TEXT
            ELSE 'FAIL'::TEXT
        END;
    
    -- Check commission calculations migration
    RETURN QUERY
    SELECT 
        'Commission calculations linked to tasks'::TEXT,
        (SELECT COUNT(*) FROM commission_calculations WHERE verification_task_id IS NOT NULL)::BIGINT,
        (SELECT COUNT(*) FROM task_commission_calculations)::BIGINT,
        CASE 
            WHEN (SELECT COUNT(*) FROM commission_calculations WHERE verification_task_id IS NOT NULL) >= 
                 (SELECT COUNT(*) FROM task_commission_calculations)
            THEN 'PASS'::TEXT
            ELSE 'FAIL'::TEXT
        END;
    
    -- Check case completion percentages
    RETURN QUERY
    SELECT 
        'Cases with updated completion percentages'::TEXT,
        (SELECT COUNT(*) FROM cases WHERE has_multiple_tasks IS NOT NULL)::BIGINT,
        (SELECT COUNT(*) FROM cases WHERE case_completion_percentage IS NOT NULL)::BIGINT,
        CASE 
            WHEN (SELECT COUNT(*) FROM cases WHERE has_multiple_tasks IS NOT NULL) = 
                 (SELECT COUNT(*) FROM cases WHERE case_completion_percentage IS NOT NULL)
            THEN 'PASS'::TEXT
            ELSE 'FAIL'::TEXT
        END;
    
    -- Check task assignment history
    RETURN QUERY
    SELECT 
        'Tasks with assignment history'::TEXT,
        (SELECT COUNT(*) FROM verification_tasks WHERE assigned_to IS NOT NULL)::BIGINT,
        (SELECT COUNT(DISTINCT verification_task_id) FROM task_assignment_history)::BIGINT,
        CASE 
            WHEN (SELECT COUNT(*) FROM verification_tasks WHERE assigned_to IS NOT NULL) <= 
                 (SELECT COUNT(DISTINCT verification_task_id) FROM task_assignment_history)
            THEN 'PASS'::TEXT
            ELSE 'FAIL'::TEXT
        END;
END;
$$;


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: agent_performance_daily; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.agent_performance_daily (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    agent_id uuid NOT NULL,
    date date NOT NULL,
    cases_assigned integer DEFAULT 0,
    cases_completed integer DEFAULT 0,
    cases_in_progress integer DEFAULT 0,
    forms_submitted integer DEFAULT 0,
    residence_forms integer DEFAULT 0,
    office_forms integer DEFAULT 0,
    business_forms integer DEFAULT 0,
    attachments_uploaded integer DEFAULT 0,
    avg_completion_time_hours numeric(8,2) DEFAULT NULL::numeric,
    quality_score numeric(5,2) DEFAULT NULL::numeric,
    validation_success_rate numeric(5,2) DEFAULT NULL::numeric,
    total_distance_km numeric(8,2) DEFAULT NULL::numeric,
    active_hours numeric(4,2) DEFAULT NULL::numeric,
    login_time timestamp without time zone,
    logout_time timestamp without time zone,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now(),
    CONSTRAINT agent_performance_daily_active_hours_check CHECK (((active_hours >= (0)::numeric) AND (active_hours <= (24)::numeric))),
    CONSTRAINT agent_performance_daily_attachments_uploaded_check CHECK ((attachments_uploaded >= 0)),
    CONSTRAINT agent_performance_daily_avg_completion_time_hours_check CHECK ((avg_completion_time_hours >= (0)::numeric)),
    CONSTRAINT agent_performance_daily_business_forms_check CHECK ((business_forms >= 0)),
    CONSTRAINT agent_performance_daily_cases_assigned_check CHECK ((cases_assigned >= 0)),
    CONSTRAINT agent_performance_daily_cases_completed_check CHECK ((cases_completed >= 0)),
    CONSTRAINT agent_performance_daily_cases_in_progress_check CHECK ((cases_in_progress >= 0)),
    CONSTRAINT agent_performance_daily_forms_submitted_check CHECK ((forms_submitted >= 0)),
    CONSTRAINT agent_performance_daily_office_forms_check CHECK ((office_forms >= 0)),
    CONSTRAINT agent_performance_daily_quality_score_check CHECK (((quality_score >= (0)::numeric) AND (quality_score <= (100)::numeric))),
    CONSTRAINT agent_performance_daily_residence_forms_check CHECK ((residence_forms >= 0)),
    CONSTRAINT agent_performance_daily_total_distance_km_check CHECK ((total_distance_km >= (0)::numeric)),
    CONSTRAINT agent_performance_daily_validation_success_rate_check CHECK (((validation_success_rate >= (0)::numeric) AND (validation_success_rate <= (100)::numeric)))
);


--
-- Name: ai_reports; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ai_reports (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    case_id uuid NOT NULL,
    submission_id character varying(255) NOT NULL,
    report_data jsonb NOT NULL,
    generated_by uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


--
-- Name: TABLE ai_reports; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.ai_reports IS 'Stores AI-generated verification reports for form submissions';


--
-- Name: COLUMN ai_reports.id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.ai_reports.id IS 'Unique identifier for the AI report';


--
-- Name: COLUMN ai_reports.case_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.ai_reports.case_id IS 'Reference to the case this report belongs to';


--
-- Name: COLUMN ai_reports.submission_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.ai_reports.submission_id IS 'Identifier of the form submission this report analyzes';


--
-- Name: COLUMN ai_reports.report_data; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.ai_reports.report_data IS 'JSON data containing the complete AI-generated report';


--
-- Name: COLUMN ai_reports.generated_by; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.ai_reports.generated_by IS 'User who requested the AI report generation';


--
-- Name: COLUMN ai_reports.created_at; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.ai_reports.created_at IS 'Timestamp when the report was generated';


--
-- Name: COLUMN ai_reports.updated_at; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.ai_reports.updated_at IS 'Timestamp when the report was last updated';


--
-- Name: applicants; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.applicants (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    case_id uuid NOT NULL,
    name character varying(255) NOT NULL,
    mobile character varying(20),
    role character varying(50) DEFAULT 'APPLICANT'::character varying,
    pan_number character varying(10),
    id_details jsonb DEFAULT '{}'::jsonb,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


--
-- Name: areas; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.areas (
    name character varying(255) NOT NULL,
    "createdAt" timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    id integer NOT NULL
);


--
-- Name: TABLE areas; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.areas IS 'Geographic areas within cities';


--
-- Name: areas_temp_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.areas_temp_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: areas_temp_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.areas_temp_id_seq OWNED BY public.areas.id;


--
-- Name: attachments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.attachments (
    filename character varying(255) NOT NULL,
    "originalName" character varying(255) NOT NULL,
    "filePath" character varying(500) NOT NULL,
    "fileSize" integer NOT NULL,
    "mimeType" character varying(100) NOT NULL,
    "uploadedBy" uuid NOT NULL,
    "createdAt" timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    id bigint NOT NULL,
    "caseId" integer,
    case_id uuid NOT NULL,
    verification_task_id uuid
);


--
-- Name: attachments_temp_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.attachments_temp_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: attachments_temp_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.attachments_temp_id_seq OWNED BY public.attachments.id;


--
-- Name: auditLogs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."auditLogs" (
    "userId" uuid,
    action character varying(50) NOT NULL,
    "entityType" character varying(50) NOT NULL,
    "entityId" uuid,
    "oldValues" jsonb,
    "newValues" jsonb,
    "ipAddress" inet,
    "userAgent" text,
    "createdAt" timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    id bigint NOT NULL,
    details jsonb
);


--
-- Name: auditLogs_temp_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public."auditLogs_temp_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: auditLogs_temp_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public."auditLogs_temp_id_seq" OWNED BY public."auditLogs".id;


--
-- Name: autoSaves; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."autoSaves" (
    "userId" uuid NOT NULL,
    "formData" jsonb NOT NULL,
    "createdAt" timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    id bigint NOT NULL,
    "caseId" integer,
    case_id uuid NOT NULL
);


--
-- Name: autoSaves_temp_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public."autoSaves_temp_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: autoSaves_temp_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public."autoSaves_temp_id_seq" OWNED BY public."autoSaves".id;


--
-- Name: backgroundSyncQueue; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."backgroundSyncQueue" (
    "userId" uuid NOT NULL,
    action character varying(50) NOT NULL,
    "entityType" character varying(50) NOT NULL,
    "entityData" jsonb NOT NULL,
    status character varying(20) DEFAULT 'PENDING'::character varying,
    "retryCount" integer DEFAULT 0,
    "errorMessage" text,
    "createdAt" timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    "processedAt" timestamp with time zone,
    id bigint NOT NULL,
    CONSTRAINT chk_background_sync_queue_status CHECK (((status)::text = ANY (ARRAY[('PENDING'::character varying)::text, ('PROCESSING'::character varying)::text, ('COMPLETED'::character varying)::text, ('FAILED'::character varying)::text])))
);


--
-- Name: backgroundSyncQueue_temp_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public."backgroundSyncQueue_temp_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: backgroundSyncQueue_temp_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public."backgroundSyncQueue_temp_id_seq" OWNED BY public."backgroundSyncQueue".id;


--
-- Name: builderVerificationReports; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."builderVerificationReports" (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    case_id uuid NOT NULL,
    "caseId" integer,
    form_type character varying(50) DEFAULT 'POSITIVE'::character varying NOT NULL,
    verification_outcome character varying(50) NOT NULL,
    customer_name character varying(255),
    customer_phone character varying(20),
    customer_email character varying(255),
    address_locatable character varying(50),
    address_rating character varying(50),
    full_address text,
    locality character varying(100),
    address_structure character varying(100),
    address_floor character varying(50),
    address_structure_color character varying(50),
    door_color character varying(50),
    company_nameplate_status character varying(50),
    name_on_company_board character varying(255),
    landmark1 character varying(255),
    landmark2 character varying(255),
    office_status character varying(50),
    office_existence character varying(50),
    builder_type character varying(50),
    company_nature_of_business character varying(255),
    business_period character varying(100),
    establishment_period character varying(100),
    office_approx_area integer,
    staff_strength integer,
    staff_seen integer,
    met_person_name character varying(255),
    designation character varying(100),
    builder_name character varying(255),
    builder_owner_name character varying(255),
    working_period character varying(100),
    working_status character varying(50),
    document_shown character varying(255),
    tpc_met_person1 character varying(50),
    tpc_name1 character varying(255),
    tpc_confirmation1 character varying(50),
    tpc_met_person2 character varying(50),
    tpc_name2 character varying(255),
    tpc_confirmation2 character varying(50),
    shifted_period character varying(100),
    old_office_shifted_period character varying(100),
    current_company_name character varying(255),
    current_company_period character varying(100),
    premises_status character varying(50),
    name_of_met_person character varying(255),
    met_person_type character varying(50),
    met_person_confirmation character varying(50),
    applicant_working_status character varying(50),
    contact_person character varying(255),
    call_remark character varying(50),
    political_connection character varying(100),
    dominated_area character varying(100),
    feedback_from_neighbour character varying(100),
    other_observation text,
    other_extra_remark text,
    final_status character varying(50) NOT NULL,
    hold_reason text,
    recommendation_status character varying(50),
    verification_date date DEFAULT CURRENT_DATE NOT NULL,
    verification_time time without time zone DEFAULT CURRENT_TIME NOT NULL,
    verified_by uuid NOT NULL,
    remarks text,
    total_images integer DEFAULT 0,
    total_selfies integer DEFAULT 0,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    landmark3 character varying(255),
    landmark4 character varying(255),
    applicant_designation character varying(100),
    verification_task_id uuid,
    report_sha256_hash text,
    report_server_signature text,
    report_generated_at timestamp with time zone,
    is_final boolean DEFAULT false,
    CONSTRAINT chk_builder_verification_final_status CHECK (((final_status)::text = ANY (ARRAY[('Positive'::character varying)::text, ('Negative'::character varying)::text, ('Refer'::character varying)::text, ('Fraud'::character varying)::text, ('Hold'::character varying)::text]))),
    CONSTRAINT chk_builder_verification_form_type CHECK (((form_type)::text = ANY (ARRAY[('POSITIVE'::character varying)::text, ('SHIFTED'::character varying)::text, ('NSP'::character varying)::text, ('ENTRY_RESTRICTED'::character varying)::text, ('UNTRACEABLE'::character varying)::text]))),
    CONSTRAINT chk_builder_verification_office_area CHECK (((office_approx_area IS NULL) OR ((office_approx_area >= 1) AND (office_approx_area <= 100000)))),
    CONSTRAINT chk_builder_verification_staff_seen CHECK (((staff_seen IS NULL) OR ((staff_seen >= 0) AND (staff_seen <= staff_strength)))),
    CONSTRAINT chk_builder_verification_staff_strength CHECK (((staff_strength IS NULL) OR ((staff_strength >= 1) AND (staff_strength <= 10000))))
);


--
-- Name: TABLE "builderVerificationReports"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public."builderVerificationReports" IS 'Comprehensive table for storing builder verification form data from mobile app submissions';


--
-- Name: COLUMN "builderVerificationReports".case_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."builderVerificationReports".case_id IS 'UUID reference to the case being verified';


--
-- Name: COLUMN "builderVerificationReports".form_type; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."builderVerificationReports".form_type IS 'Type of builder verification form: POSITIVE, SHIFTED, NSP, ENTRY_RESTRICTED, UNTRACEABLE';


--
-- Name: COLUMN "builderVerificationReports".verification_outcome; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."builderVerificationReports".verification_outcome IS 'Maps to verification outcome from case (Positive & Door Locked, Shifted & Door Lock, etc.)';


--
-- Name: COLUMN "builderVerificationReports".verified_by; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."builderVerificationReports".verified_by IS 'UUID of the field agent who performed the verification';


--
-- Name: COLUMN "builderVerificationReports".landmark3; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."builderVerificationReports".landmark3 IS 'Third landmark near the builder office';


--
-- Name: COLUMN "builderVerificationReports".landmark4; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."builderVerificationReports".landmark4 IS 'Fourth landmark near the builder office';


--
-- Name: COLUMN "builderVerificationReports".applicant_designation; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."builderVerificationReports".applicant_designation IS 'Designation of the applicant in the builder company';


--
-- Name: COLUMN "builderVerificationReports".verification_task_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."builderVerificationReports".verification_task_id IS 'Links builder verification report to specific verification task';


--
-- Name: COLUMN "builderVerificationReports".report_sha256_hash; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."builderVerificationReports".report_sha256_hash IS 'SHA-256 hash of generated PDF report for tamper detection.';


--
-- Name: COLUMN "builderVerificationReports".report_server_signature; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."builderVerificationReports".report_server_signature IS 'HMAC-SHA256 signature of PDF. Prevents report regeneration attacks.';


--
-- Name: COLUMN "builderVerificationReports".is_final; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."builderVerificationReports".is_final IS 'TRUE = report is finalized and cannot be regenerated. Bank audit requirement.';


--
-- Name: businessVerificationReports; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."businessVerificationReports" (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    case_id uuid NOT NULL,
    "caseId" integer,
    form_type character varying(50) DEFAULT 'POSITIVE'::character varying NOT NULL,
    verification_outcome character varying(50) NOT NULL,
    customer_name character varying(255),
    customer_phone character varying(20),
    customer_email character varying(255),
    address_locatable character varying(50),
    address_rating character varying(50),
    full_address text,
    locality character varying(100),
    address_structure character varying(100),
    address_floor character varying(50),
    address_structure_color character varying(50),
    door_color character varying(50),
    company_nameplate_status character varying(50),
    name_on_company_board character varying(255),
    landmark1 character varying(255),
    landmark2 character varying(255),
    business_status character varying(50),
    business_existence character varying(50),
    business_type character varying(50),
    ownership_type character varying(50),
    address_status character varying(50),
    company_nature_of_business character varying(255),
    business_period character varying(100),
    establishment_period character varying(100),
    business_approx_area integer,
    staff_strength integer,
    staff_seen integer,
    met_person_name character varying(255),
    designation character varying(100),
    name_of_company_owners character varying(255),
    owner_name character varying(255),
    business_owner_name character varying(255),
    document_shown character varying(255),
    tpc_met_person1 character varying(50),
    tpc_name1 character varying(255),
    tpc_confirmation1 character varying(50),
    tpc_met_person2 character varying(50),
    tpc_name2 character varying(255),
    tpc_confirmation2 character varying(50),
    shifted_period character varying(100),
    old_business_shifted_period character varying(100),
    current_company_name character varying(255),
    current_company_period character varying(100),
    premises_status character varying(50),
    name_of_met_person character varying(255),
    met_person_type character varying(50),
    met_person_confirmation character varying(50),
    applicant_working_status character varying(50),
    contact_person character varying(255),
    call_remark character varying(50),
    political_connection character varying(100),
    dominated_area character varying(100),
    feedback_from_neighbour character varying(100),
    other_observation text,
    other_extra_remark text,
    final_status character varying(50) NOT NULL,
    hold_reason text,
    recommendation_status character varying(50),
    verification_date date DEFAULT CURRENT_DATE NOT NULL,
    verification_time time without time zone DEFAULT CURRENT_TIME NOT NULL,
    verified_by uuid NOT NULL,
    remarks text,
    total_images integer DEFAULT 0,
    total_selfies integer DEFAULT 0,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    business_activity character varying(255),
    business_setup character varying(255),
    applicant_designation character varying(100),
    working_period character varying(100),
    working_status character varying(50),
    applicant_working_premises character varying(255),
    document_type character varying(100),
    name_of_tpc1 character varying(255),
    name_of_tpc2 character varying(255),
    verification_task_id uuid,
    landmark3 character varying(255),
    landmark4 character varying(255),
    report_sha256_hash text,
    report_server_signature text,
    report_generated_at timestamp with time zone,
    is_final boolean DEFAULT false,
    CONSTRAINT chk_business_verification_business_area CHECK (((business_approx_area IS NULL) OR ((business_approx_area >= 1) AND (business_approx_area <= 100000)))),
    CONSTRAINT chk_business_verification_final_status CHECK (((final_status)::text = ANY (ARRAY[('Positive'::character varying)::text, ('Negative'::character varying)::text, ('Refer'::character varying)::text, ('Fraud'::character varying)::text, ('Hold'::character varying)::text]))),
    CONSTRAINT chk_business_verification_form_type CHECK (((form_type)::text = ANY (ARRAY[('POSITIVE'::character varying)::text, ('SHIFTED'::character varying)::text, ('NSP'::character varying)::text, ('ENTRY_RESTRICTED'::character varying)::text, ('UNTRACEABLE'::character varying)::text]))),
    CONSTRAINT chk_business_verification_staff_seen CHECK (((staff_seen IS NULL) OR ((staff_seen >= 0) AND (staff_seen <= staff_strength)))),
    CONSTRAINT chk_business_verification_staff_strength CHECK (((staff_strength IS NULL) OR ((staff_strength >= 1) AND (staff_strength <= 10000))))
);


--
-- Name: TABLE "businessVerificationReports"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public."businessVerificationReports" IS 'Comprehensive table for storing business verification form data from mobile app submissions';


--
-- Name: COLUMN "businessVerificationReports".case_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."businessVerificationReports".case_id IS 'UUID reference to the case being verified';


--
-- Name: COLUMN "businessVerificationReports".form_type; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."businessVerificationReports".form_type IS 'Type of business verification form: POSITIVE, SHIFTED, NSP, ENTRY_RESTRICTED, UNTRACEABLE';


--
-- Name: COLUMN "businessVerificationReports".verification_outcome; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."businessVerificationReports".verification_outcome IS 'Maps to verification outcome from case (Positive & Door Locked, Shifted & Door Lock, etc.)';


--
-- Name: COLUMN "businessVerificationReports".verified_by; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."businessVerificationReports".verified_by IS 'UUID of the field agent who performed the verification';


--
-- Name: COLUMN "businessVerificationReports".business_activity; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."businessVerificationReports".business_activity IS 'Type of business activity conducted';


--
-- Name: COLUMN "businessVerificationReports".business_setup; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."businessVerificationReports".business_setup IS 'Business setup type or configuration';


--
-- Name: COLUMN "businessVerificationReports".applicant_designation; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."businessVerificationReports".applicant_designation IS 'Designation of the applicant in the business';


--
-- Name: COLUMN "businessVerificationReports".working_period; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."businessVerificationReports".working_period IS 'Period of working at the business location';


--
-- Name: COLUMN "businessVerificationReports".working_status; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."businessVerificationReports".working_status IS 'Current working status of the applicant';


--
-- Name: COLUMN "businessVerificationReports".applicant_working_premises; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."businessVerificationReports".applicant_working_premises IS 'Premises where the applicant is working';


--
-- Name: COLUMN "businessVerificationReports".document_type; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."businessVerificationReports".document_type IS 'Type of document shown during verification';


--
-- Name: COLUMN "businessVerificationReports".name_of_tpc1; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."businessVerificationReports".name_of_tpc1 IS 'Name of first third party contact';


--
-- Name: COLUMN "businessVerificationReports".name_of_tpc2; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."businessVerificationReports".name_of_tpc2 IS 'Name of second third party contact';


--
-- Name: COLUMN "businessVerificationReports".verification_task_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."businessVerificationReports".verification_task_id IS 'Links business verification report to specific verification task';


--
-- Name: COLUMN "businessVerificationReports".landmark3; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."businessVerificationReports".landmark3 IS 'Third landmark for location identification (used in UNTRACEABLE forms)';


--
-- Name: COLUMN "businessVerificationReports".landmark4; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."businessVerificationReports".landmark4 IS 'Fourth landmark for location identification (used in UNTRACEABLE forms)';


--
-- Name: COLUMN "businessVerificationReports".report_sha256_hash; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."businessVerificationReports".report_sha256_hash IS 'SHA-256 hash of generated PDF report for tamper detection.';


--
-- Name: COLUMN "businessVerificationReports".report_server_signature; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."businessVerificationReports".report_server_signature IS 'HMAC-SHA256 signature of PDF. Prevents report regeneration attacks.';


--
-- Name: COLUMN "businessVerificationReports".is_final; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."businessVerificationReports".is_final IS 'TRUE = report is finalized and cannot be regenerated. Bank audit requirement.';


--
-- Name: caseDeduplicationAudit; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."caseDeduplicationAudit" (
    "searchCriteria" jsonb NOT NULL,
    "duplicatesFound" jsonb,
    "userDecision" character varying(20) NOT NULL,
    rationale text,
    "performedBy" uuid NOT NULL,
    "performedAt" timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    id bigint NOT NULL,
    "caseId" integer,
    case_id uuid NOT NULL,
    CONSTRAINT chk_dedup_audit_decision CHECK ((("userDecision")::text = ANY (ARRAY[('CREATE_NEW'::character varying)::text, ('USE_EXISTING'::character varying)::text, ('MERGE_CASES'::character varying)::text])))
);


--
-- Name: TABLE "caseDeduplicationAudit"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public."caseDeduplicationAudit" IS 'Audit trail for case deduplication decisions and duplicate detection results';


--
-- Name: COLUMN "caseDeduplicationAudit"."searchCriteria"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."caseDeduplicationAudit"."searchCriteria" IS 'JSON object containing the search criteria used for duplicate detection';


--
-- Name: COLUMN "caseDeduplicationAudit"."duplicatesFound"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."caseDeduplicationAudit"."duplicatesFound" IS 'JSON array of duplicate cases found during the search';


--
-- Name: COLUMN "caseDeduplicationAudit"."userDecision"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."caseDeduplicationAudit"."userDecision" IS 'Decision made by the user: CREATE_NEW, USE_EXISTING, or MERGE_CASES';


--
-- Name: COLUMN "caseDeduplicationAudit".rationale; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."caseDeduplicationAudit".rationale IS 'User-provided rationale for their deduplication decision';


--
-- Name: COLUMN "caseDeduplicationAudit"."performedBy"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."caseDeduplicationAudit"."performedBy" IS 'User who performed the deduplication check and made the decision';


--
-- Name: caseDeduplicationAudit_temp_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public."caseDeduplicationAudit_temp_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: caseDeduplicationAudit_temp_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public."caseDeduplicationAudit_temp_id_seq" OWNED BY public."caseDeduplicationAudit".id;


--
-- Name: case_assignment_history; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.case_assignment_history (
    id integer NOT NULL,
    "previousAssignee" uuid,
    "newAssignee" uuid NOT NULL,
    reason text,
    "assignedBy" uuid NOT NULL,
    "assignedAt" timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    "createdAt" timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    "caseId" integer,
    case_id uuid NOT NULL,
    "fromUserId" uuid,
    "toUserId" uuid NOT NULL,
    "assignedById" uuid NOT NULL,
    "batchId" character varying(255),
    metadata jsonb DEFAULT '{}'::jsonb,
    "caseUUID" uuid
);


--
-- Name: TABLE case_assignment_history; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.case_assignment_history IS 'Tracks all case assignment and reassignment operations';


--
-- Name: case_assignment_queue_status; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.case_assignment_queue_status (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    "batchId" character varying(255) NOT NULL,
    "jobId" character varying(255) NOT NULL,
    "createdById" uuid NOT NULL,
    "assignedToId" uuid NOT NULL,
    status character varying(50) DEFAULT 'PENDING'::character varying NOT NULL,
    "totalCases" integer DEFAULT 0 NOT NULL,
    "processedCases" integer DEFAULT 0 NOT NULL,
    "successfulAssignments" integer DEFAULT 0 NOT NULL,
    "failedAssignments" integer DEFAULT 0 NOT NULL,
    "startedAt" timestamp with time zone,
    "completedAt" timestamp with time zone,
    "createdAt" timestamp with time zone DEFAULT now() NOT NULL,
    "updatedAt" timestamp with time zone DEFAULT now() NOT NULL,
    errors jsonb DEFAULT '[]'::jsonb,
    metadata jsonb DEFAULT '{}'::jsonb
);


--
-- Name: TABLE case_assignment_queue_status; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.case_assignment_queue_status IS 'Tracks status of bulk assignment operations';


--
-- Name: case_assignment_analytics; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.case_assignment_analytics AS
 SELECT date_trunc('day'::text, "assignedAt") AS assignment_date,
    count(*) AS total_assignments,
    count(DISTINCT COALESCE("caseUUID", case_id)) AS unique_cases,
    count(DISTINCT "toUserId") AS unique_assignees,
    count(
        CASE
            WHEN ("fromUserId" IS NOT NULL) THEN 1
            ELSE NULL::integer
        END) AS reassignments,
    count(
        CASE
            WHEN ("batchId" IS NOT NULL) THEN 1
            ELSE NULL::integer
        END) AS bulk_assignments,
    avg(
        CASE
            WHEN ("batchId" IS NOT NULL) THEN ( SELECT case_assignment_queue_status."totalCases"
               FROM public.case_assignment_queue_status
              WHERE ((case_assignment_queue_status."batchId")::text = (cah."batchId")::text)
             LIMIT 1)
            ELSE NULL::integer
        END) AS avg_bulk_size
   FROM public.case_assignment_history cah
  WHERE ("assignedAt" IS NOT NULL)
  GROUP BY (date_trunc('day'::text, "assignedAt"))
  ORDER BY (date_trunc('day'::text, "assignedAt")) DESC;


--
-- Name: VIEW case_assignment_analytics; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON VIEW public.case_assignment_analytics IS 'Analytics view for assignment operations';


--
-- Name: case_assignment_conflicts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.case_assignment_conflicts (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    "caseId" uuid NOT NULL,
    "conflictType" character varying(100) NOT NULL,
    "serverAssignedTo" uuid,
    "clientAssignedTo" uuid,
    "detectedAt" timestamp with time zone DEFAULT now() NOT NULL,
    "resolvedAt" timestamp with time zone,
    "resolvedBy" uuid,
    "resolutionStrategy" character varying(100),
    "resolutionData" jsonb DEFAULT '{}'::jsonb,
    status character varying(50) DEFAULT 'PENDING'::character varying NOT NULL,
    metadata jsonb DEFAULT '{}'::jsonb
);


--
-- Name: TABLE case_assignment_conflicts; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.case_assignment_conflicts IS 'Tracks and resolves assignment conflicts';


--
-- Name: case_assignment_history_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.case_assignment_history_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: case_assignment_history_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.case_assignment_history_id_seq OWNED BY public.case_assignment_history.id;


--
-- Name: case_configuration_errors; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.case_configuration_errors (
    id integer NOT NULL,
    case_id uuid NOT NULL,
    error_code character varying(100) NOT NULL,
    error_message text NOT NULL,
    error_details jsonb,
    created_at timestamp with time zone DEFAULT now(),
    resolved_at timestamp with time zone,
    resolved_by uuid
);


--
-- Name: TABLE case_configuration_errors; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.case_configuration_errors IS 'Stores configuration validation errors for cases in CONFIG_PENDING state. Used for bulk upload quarantine flow.';


--
-- Name: COLUMN case_configuration_errors.error_details; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.case_configuration_errors.error_details IS 'JSON object containing context like clientId, productId, verificationTypeId, pincodeId, areaId';


--
-- Name: case_configuration_errors_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.case_configuration_errors_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: case_configuration_errors_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.case_configuration_errors_id_seq OWNED BY public.case_configuration_errors.id;


--
-- Name: case_status_history; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.case_status_history (
    id character varying(255) NOT NULL,
    "caseId" integer NOT NULL,
    status character varying(50) NOT NULL,
    "transitionedAt" timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    "transitionedBy" uuid,
    "transitionReason" text,
    "createdAt" timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    case_id uuid NOT NULL
);


--
-- Name: cases; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.cases (
    "clientId" integer NOT NULL,
    "productId" integer NOT NULL,
    "verificationTypeId" integer NOT NULL,
    "cityId" integer,
    pincode character varying(10),
    status character varying(20) DEFAULT 'PENDING'::character varying,
    priority character varying(10) DEFAULT 'MEDIUM'::character varying,
    "createdAt" timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    "panNumber" character varying(10),
    "deduplicationChecked" boolean DEFAULT false,
    "deduplicationDecision" character varying(20),
    "deduplicationRationale" text,
    "applicantType" character varying(20) NOT NULL,
    "backendContactNumber" character varying(20) NOT NULL,
    trigger text NOT NULL,
    "caseId" integer NOT NULL,
    "customerName" character varying(100) NOT NULL,
    "customerCallingCode" character varying(20),
    "customerPhone" character varying(20),
    "verificationType" character varying(50),
    "createdByBackendUser" uuid,
    revokereason text,
    revokedat timestamp with time zone,
    "revokeReason" text,
    "revokedAt" timestamp with time zone,
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    form_completion_percentage numeric(5,2) DEFAULT 0,
    quality_score numeric(5,2) DEFAULT NULL::numeric,
    last_form_submitted_at timestamp without time zone,
    total_forms_required integer DEFAULT 1,
    forms_submitted_count integer DEFAULT 0,
    validation_issues_count integer DEFAULT 0,
    "verificationData" jsonb,
    "verificationOutcome" character varying(50),
    "completedAt" timestamp with time zone,
    "rateTypeId" integer,
    has_multiple_tasks boolean DEFAULT false,
    total_tasks_count integer DEFAULT 1,
    completed_tasks_count integer DEFAULT 0,
    case_completion_percentage numeric(5,2) DEFAULT 0.00,
    CONSTRAINT cases_form_completion_percentage_check CHECK (((form_completion_percentage >= (0)::numeric) AND (form_completion_percentage <= (100)::numeric))),
    CONSTRAINT cases_forms_submitted_count_check CHECK ((forms_submitted_count >= 0)),
    CONSTRAINT cases_quality_score_check CHECK (((quality_score >= (0)::numeric) AND (quality_score <= (100)::numeric))),
    CONSTRAINT cases_total_forms_required_check CHECK ((total_forms_required > 0)),
    CONSTRAINT cases_validation_issues_count_check CHECK ((validation_issues_count >= 0)),
    CONSTRAINT chk_cases_applicant_type CHECK ((("applicantType")::text = ANY (ARRAY[('APPLICANT'::character varying)::text, ('CO-APPLICANT'::character varying)::text, ('REFERENCE PERSON'::character varying)::text]))),
    CONSTRAINT chk_cases_dedup_decision CHECK ((("deduplicationDecision")::text = ANY (ARRAY[('CREATE_NEW'::character varying)::text, ('USE_EXISTING'::character varying)::text, ('MERGE_CASES'::character varying)::text, ('NO_DUPLICATES'::character varying)::text]))),
    CONSTRAINT chk_cases_priority CHECK (((priority)::text = ANY (ARRAY[('LOW'::character varying)::text, ('MEDIUM'::character varying)::text, ('HIGH'::character varying)::text, ('URGENT'::character varying)::text]))),
    CONSTRAINT chk_cases_status CHECK (((status)::text = ANY (ARRAY[('PENDING'::character varying)::text, ('ASSIGNED'::character varying)::text, ('IN_PROGRESS'::character varying)::text, ('COMPLETED'::character varying)::text, ('REVOKED'::character varying)::text])))
);


--
-- Name: TABLE cases; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.cases IS 'Main cases table with rate type assignment support for financial calculations';


--
-- Name: COLUMN cases."clientId"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.cases."clientId" IS 'Foreign key reference to clients.id (converted from UUID to INTEGER for consistency)';


--
-- Name: COLUMN cases."productId"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.cases."productId" IS 'Foreign key reference to products.id (converted from UUID to INTEGER)';


--
-- Name: COLUMN cases."verificationTypeId"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.cases."verificationTypeId" IS 'Foreign key reference to verificationTypes.id (converted from UUID to INTEGER)';


--
-- Name: COLUMN cases."cityId"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.cases."cityId" IS 'Foreign key reference to cities.id (converted from UUID to INTEGER)';


--
-- Name: COLUMN cases.status; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.cases.status IS 'Case status - can be UNASSIGNED, ASSIGNED, IN_PROGRESS, or COMPLETED';


--
-- Name: COLUMN cases."panNumber"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.cases."panNumber" IS 'PAN card number for deduplication matching';


--
-- Name: COLUMN cases."deduplicationChecked"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.cases."deduplicationChecked" IS 'Whether deduplication check was performed';


--
-- Name: COLUMN cases."deduplicationDecision"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.cases."deduplicationDecision" IS 'User decision after deduplication check';


--
-- Name: COLUMN cases."deduplicationRationale"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.cases."deduplicationRationale" IS 'Reason for deduplication decision';


--
-- Name: COLUMN cases."applicantType"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.cases."applicantType" IS 'Type of applicant: APPLICANT, CO-APPLICANT, or REFERENCE PERSON';


--
-- Name: COLUMN cases."backendContactNumber"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.cases."backendContactNumber" IS 'Contact number of the backend user who created the case';


--
-- Name: COLUMN cases.trigger; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.cases.trigger IS 'TRIGGER field - additional information or special instructions';


--
-- Name: COLUMN cases."caseId"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.cases."caseId" IS 'Business identifier - Case number for display and external references';


--
-- Name: COLUMN cases."customerName"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.cases."customerName" IS 'Customer name as entered in case creation form';


--
-- Name: COLUMN cases."customerCallingCode"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.cases."customerCallingCode" IS 'Customer calling code (auto-generated: CC-timestamp+random)';


--
-- Name: COLUMN cases."customerPhone"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.cases."customerPhone" IS 'Customer phone number';


--
-- Name: COLUMN cases."verificationType"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.cases."verificationType" IS 'Verification type name (e.g., Residence, Office, Business)';


--
-- Name: COLUMN cases.id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.cases.id IS 'Primary key - UUID identifier for internal references';


--
-- Name: COLUMN cases."rateTypeId"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.cases."rateTypeId" IS 'Foreign key to rateTypes table for rate calculation and assignment';


--
-- Name: task_commission_calculations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.task_commission_calculations (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    verification_task_id uuid NOT NULL,
    case_id uuid NOT NULL,
    task_number character varying(20) NOT NULL,
    user_id uuid NOT NULL,
    client_id integer NOT NULL,
    rate_type_id integer NOT NULL,
    base_amount numeric(10,2) NOT NULL,
    commission_amount numeric(10,2) NOT NULL,
    calculated_commission numeric(10,2) NOT NULL,
    currency character varying(3) DEFAULT 'INR'::character varying,
    calculation_method character varying(20) DEFAULT 'FIXED_AMOUNT'::character varying,
    calculation_date timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    status character varying(20) DEFAULT 'PENDING'::character varying,
    approved_by uuid,
    approved_at timestamp without time zone,
    paid_by uuid,
    paid_at timestamp without time zone,
    payment_method character varying(50),
    transaction_id character varying(100),
    rejection_reason text,
    task_completed_at timestamp without time zone NOT NULL,
    verification_outcome character varying(50),
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    created_by uuid,
    notes text,
    CONSTRAINT check_calculation_method CHECK (((calculation_method)::text = ANY (ARRAY[('FIXED_AMOUNT'::character varying)::text, ('PERCENTAGE'::character varying)::text]))),
    CONSTRAINT check_commission_status CHECK (((status)::text = ANY (ARRAY[('PENDING'::character varying)::text, ('CALCULATED'::character varying)::text, ('APPROVED'::character varying)::text, ('PAID'::character varying)::text, ('REJECTED'::character varying)::text])))
);


--
-- Name: verification_tasks; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.verification_tasks (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    task_number character varying(20) NOT NULL,
    case_id uuid NOT NULL,
    verification_type_id integer NOT NULL,
    task_title character varying(255) NOT NULL,
    task_description text,
    priority character varying(10) DEFAULT 'MEDIUM'::character varying,
    assigned_to uuid,
    assigned_by uuid,
    assigned_at timestamp without time zone,
    status character varying(20) DEFAULT 'PENDING'::character varying,
    verification_outcome character varying(50),
    rate_type_id integer,
    estimated_amount numeric(10,2),
    actual_amount numeric(10,2),
    address text,
    pincode character varying(10),
    latitude numeric(10,8),
    longitude numeric(11,8),
    document_type character varying(100),
    document_number character varying(100),
    document_details jsonb,
    estimated_completion_date date,
    started_at timestamp without time zone,
    completed_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    created_by uuid,
    trigger text,
    applicant_type character varying(20),
    revoked_at timestamp with time zone,
    revoked_by uuid,
    revocation_reason text,
    cancelled_at timestamp with time zone,
    cancelled_by uuid,
    cancellation_reason text,
    task_type public.task_type_enum DEFAULT 'NORMAL'::public.task_type_enum NOT NULL,
    parent_task_id uuid,
    saved_at timestamp with time zone,
    is_saved boolean DEFAULT false NOT NULL,
    first_assigned_at timestamp with time zone,
    current_assigned_at timestamp with time zone,
    service_zone_id integer,
    forensic_version smallint DEFAULT 1,
    device_id text,
    app_version text,
    submitted_at timestamp with time zone,
    reviewer_id uuid,
    reviewed_at timestamp with time zone,
    review_notes text,
    area_id integer,
    CONSTRAINT check_priority CHECK (((priority)::text = ANY (ARRAY[('LOW'::character varying)::text, ('MEDIUM'::character varying)::text, ('HIGH'::character varying)::text, ('URGENT'::character varying)::text]))),
    CONSTRAINT check_status_unified CHECK (((status)::text = ANY (ARRAY[('PENDING'::character varying)::text, ('ASSIGNED'::character varying)::text, ('IN_PROGRESS'::character varying)::text, ('COMPLETED'::character varying)::text, ('REVOKED'::character varying)::text, ('SAVED'::character varying)::text, ('ON_HOLD'::character varying)::text]))),
    CONSTRAINT chk_verification_tasks_applicant_type CHECK (((applicant_type IS NULL) OR ((applicant_type)::text = ANY (ARRAY[('APPLICANT'::character varying)::text, ('CO-APPLICANT'::character varying)::text, ('REFERENCE PERSON'::character varying)::text]))))
);


--
-- Name: COLUMN verification_tasks.trigger; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.verification_tasks.trigger IS 'Trigger information for the verification task';


--
-- Name: COLUMN verification_tasks.applicant_type; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.verification_tasks.applicant_type IS 'Type of applicant: APPLICANT, CO-APPLICANT, or REFERENCE PERSON';


--
-- Name: COLUMN verification_tasks.revoked_at; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.verification_tasks.revoked_at IS 'Timestamp when the task was revoked by field agent';


--
-- Name: COLUMN verification_tasks.revoked_by; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.verification_tasks.revoked_by IS 'User ID of the field agent who revoked the task';


--
-- Name: COLUMN verification_tasks.revocation_reason; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.verification_tasks.revocation_reason IS 'Reason provided by field agent for revoking the task';


--
-- Name: COLUMN verification_tasks.cancelled_at; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.verification_tasks.cancelled_at IS 'Timestamp when the task was cancelled by backend user';


--
-- Name: COLUMN verification_tasks.cancelled_by; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.verification_tasks.cancelled_by IS 'User ID of the backend user who cancelled the task';


--
-- Name: COLUMN verification_tasks.cancellation_reason; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.verification_tasks.cancellation_reason IS 'Reason provided by backend user for cancelling the task';


--
-- Name: COLUMN verification_tasks.task_type; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.verification_tasks.task_type IS 'Type of the task: NORMAL or REVISIT';


--
-- Name: COLUMN verification_tasks.parent_task_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.verification_tasks.parent_task_id IS 'ID of the original task if this is a revisit task';


--
-- Name: COLUMN verification_tasks.saved_at; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.verification_tasks.saved_at IS 'Timestamp when the task was saved by field agent';


--
-- Name: COLUMN verification_tasks.is_saved; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.verification_tasks.is_saved IS 'Boolean flag indicating if task is in saved state';


--
-- Name: COLUMN verification_tasks.first_assigned_at; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.verification_tasks.first_assigned_at IS 'When the task was first assigned for Bank SLA tracking';


--
-- Name: COLUMN verification_tasks.current_assigned_at; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.verification_tasks.current_assigned_at IS 'When the task was last assigned/reassigned for Agent Performance tracking';


--
-- Name: COLUMN verification_tasks.forensic_version; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.verification_tasks.forensic_version IS 'Forensic enforcement version: 1 = legacy verification (no forensic enforcement), 2 = forensic-protected verification. Allows backward compatibility for old cases.';


--
-- Name: COLUMN verification_tasks.device_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.verification_tasks.device_id IS 'Device used for entire verification task. Must match photo device_ids.';


--
-- Name: COLUMN verification_tasks.app_version; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.verification_tasks.app_version IS 'Mobile app version used for this task.';


--
-- Name: COLUMN verification_tasks.submitted_at; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.verification_tasks.submitted_at IS 'When field agent submitted task (status → SUBMITTED). Distinct from completed_at.';


--
-- Name: COLUMN verification_tasks.reviewer_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.verification_tasks.reviewer_id IS 'Backend user who reviewed and approved/rejected this task.';


--
-- Name: COLUMN verification_tasks.reviewed_at; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.verification_tasks.reviewed_at IS 'When reviewer made approval/rejection decision.';


--
-- Name: COLUMN verification_tasks.review_notes; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.verification_tasks.review_notes IS 'Reviewer comments or rejection reason.';


--
-- Name: case_task_summary; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.case_task_summary AS
 SELECT c.id AS case_id,
    c."caseId" AS case_number,
    c."customerName",
    c.status AS case_status,
    c."createdAt" AS case_created_at,
    c.has_multiple_tasks,
    c.total_tasks_count,
    c.completed_tasks_count,
    c.case_completion_percentage,
    count(vt.id) AS actual_tasks_count,
    count(
        CASE
            WHEN ((vt.status)::text = 'COMPLETED'::text) THEN 1
            ELSE NULL::integer
        END) AS completed_tasks,
    count(
        CASE
            WHEN ((vt.status)::text = 'IN_PROGRESS'::text) THEN 1
            ELSE NULL::integer
        END) AS in_progress_tasks,
    count(
        CASE
            WHEN ((vt.status)::text = 'PENDING'::text) THEN 1
            ELSE NULL::integer
        END) AS pending_tasks,
    count(
        CASE
            WHEN ((vt.status)::text = 'ASSIGNED'::text) THEN 1
            ELSE NULL::integer
        END) AS assigned_tasks,
    count(
        CASE
            WHEN ((vt.status)::text = 'CANCELLED'::text) THEN 1
            ELSE NULL::integer
        END) AS cancelled_tasks,
    COALESCE(sum(vt.estimated_amount), (0)::numeric) AS total_estimated_amount,
    COALESCE(sum(vt.actual_amount), (0)::numeric) AS total_actual_amount,
    COALESCE(sum(
        CASE
            WHEN ((vt.status)::text = 'COMPLETED'::text) THEN vt.actual_amount
            ELSE (0)::numeric
        END), (0)::numeric) AS completed_amount,
    COALESCE(sum(tcc.calculated_commission), (0)::numeric) AS total_commission,
    COALESCE(sum(
        CASE
            WHEN ((tcc.status)::text = 'PAID'::text) THEN tcc.calculated_commission
            ELSE (0)::numeric
        END), (0)::numeric) AS paid_commission,
    min(vt.assigned_at) AS first_task_assigned,
    max(vt.completed_at) AS last_task_completed
   FROM ((public.cases c
     LEFT JOIN public.verification_tasks vt ON ((c.id = vt.case_id)))
     LEFT JOIN public.task_commission_calculations tcc ON ((vt.id = tcc.verification_task_id)))
  GROUP BY c.id, c."caseId", c."customerName", c.status, c."createdAt", c.has_multiple_tasks, c.total_tasks_count, c.completed_tasks_count, c.case_completion_percentage;


--
-- Name: case_timeline_events; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.case_timeline_events (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    case_id uuid NOT NULL,
    event_type character varying(50) NOT NULL,
    event_category character varying(30) DEFAULT 'GENERAL'::character varying NOT NULL,
    performed_by uuid,
    event_data jsonb DEFAULT '{}'::jsonb,
    previous_value text,
    new_value text,
    event_description text,
    is_system_generated boolean DEFAULT false,
    event_timestamp timestamp without time zone DEFAULT now() NOT NULL,
    created_at timestamp without time zone DEFAULT now(),
    CONSTRAINT case_timeline_events_event_category_check CHECK (((event_category)::text = ANY (ARRAY[('ASSIGNMENT'::character varying)::text, ('STATUS_CHANGE'::character varying)::text, ('FORM_SUBMISSION'::character varying)::text, ('VALIDATION'::character varying)::text, ('COMMUNICATION'::character varying)::text, ('GENERAL'::character varying)::text])))
);


--
-- Name: cases_caseId_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public."cases_caseId_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: cases_caseId_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public."cases_caseId_seq" OWNED BY public.cases."caseId";


--
-- Name: cities; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.cities (
    name character varying(100) NOT NULL,
    "createdAt" timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    id integer NOT NULL,
    "stateId" integer,
    "countryId" integer
);


--
-- Name: cities_temp_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.cities_temp_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: cities_temp_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.cities_temp_id_seq OWNED BY public.cities.id;


--
-- Name: clientDocumentTypes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."clientDocumentTypes" (
    id integer NOT NULL,
    "clientId" integer NOT NULL,
    "documentTypeId" integer NOT NULL,
    is_mandatory boolean DEFAULT false,
    is_active boolean DEFAULT true,
    display_order integer DEFAULT 0,
    created_by uuid,
    updated_by uuid,
    "createdAt" timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: TABLE "clientDocumentTypes"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public."clientDocumentTypes" IS 'Junction table mapping document types to clients';


--
-- Name: clientDocumentTypes_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public."clientDocumentTypes_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: clientDocumentTypes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public."clientDocumentTypes_id_seq" OWNED BY public."clientDocumentTypes".id;


--
-- Name: clientProducts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."clientProducts" (
    "isActive" boolean DEFAULT true,
    "createdAt" timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    id integer NOT NULL,
    "clientId" integer,
    "productId" integer
);


--
-- Name: TABLE "clientProducts"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public."clientProducts" IS 'Products available to each client';


--
-- Name: clientProducts_temp_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public."clientProducts_temp_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: clientProducts_temp_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public."clientProducts_temp_id_seq" OWNED BY public."clientProducts".id;


--
-- Name: clients; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.clients (
    name character varying(100) NOT NULL,
    code character varying(20) NOT NULL,
    email character varying(100),
    phone character varying(20),
    address text,
    "isActive" boolean DEFAULT true,
    "createdAt" timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    id integer NOT NULL
);


--
-- Name: client_task_analytics; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.client_task_analytics AS
 SELECT c."clientId",
    cl.name AS client_name,
    count(DISTINCT c.id) AS total_cases,
    count(DISTINCT
        CASE
            WHEN c.has_multiple_tasks THEN c.id
            ELSE NULL::uuid
        END) AS multi_task_cases,
    count(vt.id) AS total_tasks,
    count(
        CASE
            WHEN ((vt.status)::text = 'COMPLETED'::text) THEN 1
            ELSE NULL::integer
        END) AS completed_tasks,
    count(
        CASE
            WHEN ((vt.status)::text = 'IN_PROGRESS'::text) THEN 1
            ELSE NULL::integer
        END) AS in_progress_tasks,
    count(
        CASE
            WHEN (((vt.status)::text = 'PENDING'::text) OR ((vt.status)::text = 'ASSIGNED'::text)) THEN 1
            ELSE NULL::integer
        END) AS pending_tasks,
    COALESCE(sum(vt.estimated_amount), (0)::numeric) AS total_estimated_amount,
    COALESCE(sum(vt.actual_amount), (0)::numeric) AS total_actual_amount,
    COALESCE(sum(
        CASE
            WHEN ((vt.status)::text = 'COMPLETED'::text) THEN vt.actual_amount
            ELSE (0)::numeric
        END), (0)::numeric) AS completed_amount,
    round(
        CASE
            WHEN (count(vt.id) = 0) THEN (0)::numeric
            ELSE (((count(
            CASE
                WHEN ((vt.status)::text = 'COMPLETED'::text) THEN 1
                ELSE NULL::integer
            END))::numeric / (count(vt.id))::numeric) * (100)::numeric)
        END, 2) AS task_completion_rate,
    round(
        CASE
            WHEN (count(DISTINCT c.id) = 0) THEN (0)::numeric
            ELSE (((count(DISTINCT
            CASE
                WHEN ((c.status)::text = 'COMPLETED'::text) THEN c.id
                ELSE NULL::uuid
            END))::numeric / (count(DISTINCT c.id))::numeric) * (100)::numeric)
        END, 2) AS case_completion_rate,
    round(avg(
        CASE
            WHEN (((c.status)::text = 'COMPLETED'::text) AND (c."completedAt" IS NOT NULL)) THEN (EXTRACT(epoch FROM (c."completedAt" - c."createdAt")) / (86400)::numeric)
            ELSE NULL::numeric
        END), 2) AS avg_case_completion_days
   FROM ((public.cases c
     LEFT JOIN public.verification_tasks vt ON ((c.id = vt.case_id)))
     LEFT JOIN public.clients cl ON ((c."clientId" = cl.id)))
  GROUP BY c."clientId", cl.name;


--
-- Name: clients_temp_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.clients_temp_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: clients_temp_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.clients_temp_id_seq OWNED BY public.clients.id;


--
-- Name: commission_analytics; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.commission_analytics AS
 SELECT date(calculation_date) AS calculation_date,
    count(*) AS total_commissions,
    count(
        CASE
            WHEN ((status)::text = 'PAID'::text) THEN 1
            ELSE NULL::integer
        END) AS paid_commissions,
    count(
        CASE
            WHEN (((status)::text = 'PENDING'::text) OR ((status)::text = 'CALCULATED'::text)) THEN 1
            ELSE NULL::integer
        END) AS pending_commissions,
    COALESCE(sum(calculated_commission), (0)::numeric) AS total_commission_amount,
    COALESCE(sum(
        CASE
            WHEN ((status)::text = 'PAID'::text) THEN calculated_commission
            ELSE (0)::numeric
        END), (0)::numeric) AS paid_commission_amount,
    COALESCE(sum(
        CASE
            WHEN (((status)::text = 'PENDING'::text) OR ((status)::text = 'CALCULATED'::text)) THEN calculated_commission
            ELSE (0)::numeric
        END), (0)::numeric) AS pending_commission_amount,
    round(avg(calculated_commission), 2) AS avg_commission_amount,
    round(avg(base_amount), 2) AS avg_base_amount,
    count(DISTINCT user_id) AS unique_users,
    count(DISTINCT case_id) AS unique_cases
   FROM public.task_commission_calculations tcc
  WHERE (calculation_date >= (CURRENT_DATE - '90 days'::interval))
  GROUP BY (date(calculation_date))
  ORDER BY (date(calculation_date)) DESC;


--
-- Name: commission_batch_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.commission_batch_items (
    id bigint NOT NULL,
    batch_id bigint NOT NULL,
    commission_id bigint NOT NULL,
    amount numeric(10,2) NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT commission_batch_items_amount_check CHECK ((amount >= (0)::numeric))
);


--
-- Name: TABLE commission_batch_items; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.commission_batch_items IS 'Individual commission items within payment batches';


--
-- Name: commission_batch_items_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.commission_batch_items_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: commission_batch_items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.commission_batch_items_id_seq OWNED BY public.commission_batch_items.id;


--
-- Name: commission_calculations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.commission_calculations (
    id bigint NOT NULL,
    case_id uuid NOT NULL,
    case_number integer NOT NULL,
    user_id uuid NOT NULL,
    client_id integer NOT NULL,
    rate_type_id integer NOT NULL,
    base_amount numeric(10,2) NOT NULL,
    commission_amount numeric(10,2) NOT NULL,
    calculated_commission numeric(10,2) NOT NULL,
    currency character varying(3) DEFAULT 'INR'::character varying,
    calculation_method character varying(20) DEFAULT 'FIXED_AMOUNT'::character varying NOT NULL,
    status character varying(20) DEFAULT 'PENDING'::character varying,
    case_completed_at timestamp with time zone NOT NULL,
    approved_by uuid,
    approved_at timestamp with time zone,
    paid_by uuid,
    paid_at timestamp with time zone,
    payment_method character varying(50),
    transaction_id character varying(100),
    rejection_reason text,
    notes text,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    verification_task_id uuid,
    CONSTRAINT chk_commission_calculations_amount_positive CHECK ((commission_amount > (0)::numeric)),
    CONSTRAINT commission_calculations_base_amount_check CHECK ((base_amount >= (0)::numeric)),
    CONSTRAINT commission_calculations_calculated_commission_check CHECK ((calculated_commission >= (0)::numeric)),
    CONSTRAINT commission_calculations_calculation_method_check CHECK (((calculation_method)::text = 'FIXED_AMOUNT'::text)),
    CONSTRAINT commission_calculations_commission_amount_check CHECK ((commission_amount >= (0)::numeric)),
    CONSTRAINT commission_calculations_status_check CHECK (((status)::text = ANY (ARRAY[('PENDING'::character varying)::text, ('APPROVED'::character varying)::text, ('PAID'::character varying)::text, ('REJECTED'::character varying)::text])))
);


--
-- Name: TABLE commission_calculations; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.commission_calculations IS 'Calculated commissions for completed cases';


--
-- Name: COLUMN commission_calculations.base_amount; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.commission_calculations.base_amount IS 'Original rate amount from rates table';


--
-- Name: COLUMN commission_calculations.commission_amount; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.commission_calculations.commission_amount IS 'Fixed commission amount used for calculation';


--
-- Name: COLUMN commission_calculations.calculated_commission; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.commission_calculations.calculated_commission IS 'Final commission amount to be paid';


--
-- Name: COLUMN commission_calculations.calculation_method; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.commission_calculations.calculation_method IS 'Always FIXED_AMOUNT - percentage support removed';


--
-- Name: commission_calculations_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.commission_calculations_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: commission_calculations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.commission_calculations_id_seq OWNED BY public.commission_calculations.id;


--
-- Name: commission_payment_batches; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.commission_payment_batches (
    id bigint NOT NULL,
    batch_number character varying(50) NOT NULL,
    total_amount numeric(12,2) NOT NULL,
    total_commissions integer NOT NULL,
    currency character varying(3) DEFAULT 'INR'::character varying,
    payment_method character varying(50) NOT NULL,
    payment_date timestamp with time zone,
    status character varying(20) DEFAULT 'PENDING'::character varying,
    created_by uuid NOT NULL,
    processed_by uuid,
    notes text,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT commission_payment_batches_status_check CHECK (((status)::text = ANY (ARRAY[('PENDING'::character varying)::text, ('PROCESSING'::character varying)::text, ('COMPLETED'::character varying)::text, ('FAILED'::character varying)::text]))),
    CONSTRAINT commission_payment_batches_total_amount_check CHECK ((total_amount >= (0)::numeric)),
    CONSTRAINT commission_payment_batches_total_commissions_check CHECK ((total_commissions >= 0))
);


--
-- Name: TABLE commission_payment_batches; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.commission_payment_batches IS 'Batched commission payments for easier processing';


--
-- Name: commission_payment_batches_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.commission_payment_batches_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: commission_payment_batches_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.commission_payment_batches_id_seq OWNED BY public.commission_payment_batches.id;


--
-- Name: commission_rate_types; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.commission_rate_types (
    id bigint NOT NULL,
    rate_type_id integer NOT NULL,
    commission_amount numeric(10,2) NOT NULL,
    currency character varying(3) DEFAULT 'INR'::character varying,
    is_active boolean DEFAULT true,
    created_by uuid,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT chk_commission_rate_types_amount_positive CHECK ((commission_amount > (0)::numeric)),
    CONSTRAINT commission_rate_types_commission_amount_check CHECK ((commission_amount >= (0)::numeric))
);


--
-- Name: TABLE commission_rate_types; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.commission_rate_types IS 'Commission rate templates with fixed amounts only';


--
-- Name: COLUMN commission_rate_types.commission_amount; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.commission_rate_types.commission_amount IS 'Fixed commission amount in specified currency';


--
-- Name: commission_rate_types_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.commission_rate_types_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: commission_rate_types_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.commission_rate_types_id_seq OWNED BY public.commission_rate_types.id;


--
-- Name: countries; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.countries (
    name character varying(100) NOT NULL,
    code character varying(3) NOT NULL,
    continent character varying(50) NOT NULL,
    "createdAt" timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    id integer NOT NULL
);


--
-- Name: countries_temp_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.countries_temp_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: countries_temp_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.countries_temp_id_seq OWNED BY public.countries.id;


--
-- Name: verification_task_types; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.verification_task_types (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    code character varying(20) NOT NULL,
    description text,
    category character varying(50),
    default_priority character varying(10) DEFAULT 'MEDIUM'::character varying,
    estimated_duration_hours integer DEFAULT 24,
    requires_location boolean DEFAULT false,
    requires_documents boolean DEFAULT false,
    required_form_type character varying(50),
    validation_rules jsonb,
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    created_by uuid,
    CONSTRAINT check_task_type_category CHECK (((category)::text = ANY (ARRAY[('DOCUMENT'::character varying)::text, ('ADDRESS'::character varying)::text, ('BUSINESS'::character varying)::text, ('IDENTITY'::character varying)::text, ('FINANCIAL'::character varying)::text, ('EMPLOYMENT'::character varying)::text]))),
    CONSTRAINT check_task_type_priority CHECK (((default_priority)::text = ANY (ARRAY[('LOW'::character varying)::text, ('MEDIUM'::character varying)::text, ('HIGH'::character varying)::text, ('URGENT'::character varying)::text])))
);


--
-- Name: daily_task_performance; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.daily_task_performance AS
 SELECT date(vt.created_at) AS task_date,
    count(*) AS tasks_created,
    count(
        CASE
            WHEN ((vt.status)::text = 'COMPLETED'::text) THEN 1
            ELSE NULL::integer
        END) AS tasks_completed,
    count(
        CASE
            WHEN (vt.assigned_to IS NOT NULL) THEN 1
            ELSE NULL::integer
        END) AS tasks_assigned,
    round(
        CASE
            WHEN (count(*) = 0) THEN (0)::numeric
            ELSE (((count(
            CASE
                WHEN ((vt.status)::text = 'COMPLETED'::text) THEN 1
                ELSE NULL::integer
            END))::numeric / (count(*))::numeric) * (100)::numeric)
        END, 2) AS completion_rate,
    COALESCE(sum(vt.estimated_amount), (0)::numeric) AS total_estimated_value,
    COALESCE(sum(
        CASE
            WHEN ((vt.status)::text = 'COMPLETED'::text) THEN vt.actual_amount
            ELSE (0)::numeric
        END), (0)::numeric) AS total_completed_value,
    round(avg(
        CASE
            WHEN (((vt.status)::text = 'COMPLETED'::text) AND (vt.started_at IS NOT NULL)) THEN (EXTRACT(epoch FROM (vt.completed_at - vt.started_at)) / (3600)::numeric)
            ELSE NULL::numeric
        END), 2) AS avg_completion_hours,
    count(
        CASE
            WHEN ((vtt.category)::text = 'ADDRESS'::text) THEN 1
            ELSE NULL::integer
        END) AS address_tasks,
    count(
        CASE
            WHEN ((vtt.category)::text = 'DOCUMENT'::text) THEN 1
            ELSE NULL::integer
        END) AS document_tasks,
    count(
        CASE
            WHEN ((vtt.category)::text = 'BUSINESS'::text) THEN 1
            ELSE NULL::integer
        END) AS business_tasks,
    count(
        CASE
            WHEN ((vtt.category)::text = 'IDENTITY'::text) THEN 1
            ELSE NULL::integer
        END) AS identity_tasks
   FROM (public.verification_tasks vt
     LEFT JOIN public.verification_task_types vtt ON ((vt.verification_type_id = vtt.id)))
  WHERE (vt.created_at >= (CURRENT_DATE - '90 days'::interval))
  GROUP BY (date(vt.created_at))
  ORDER BY (date(vt.created_at)) DESC;


--
-- Name: departments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.departments (
    name character varying(100) NOT NULL,
    description text,
    "departmentHeadId" uuid,
    "isActive" boolean DEFAULT true NOT NULL,
    "createdAt" timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    "createdBy" uuid,
    "updatedBy" uuid,
    id integer NOT NULL,
    "parentDepartmentId" integer
);


--
-- Name: departments_temp_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.departments_temp_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: departments_temp_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.departments_temp_id_seq OWNED BY public.departments.id;


--
-- Name: designations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.designations (
    name character varying(100) NOT NULL,
    description text,
    "isActive" boolean DEFAULT true,
    "createdAt" timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    "createdBy" uuid,
    "updatedBy" uuid,
    id integer NOT NULL,
    "departmentId" integer
);


--
-- Name: designations_temp_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.designations_temp_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: designations_temp_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.designations_temp_id_seq OWNED BY public.designations.id;


--
-- Name: documentTypeRates; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."documentTypeRates" (
    id bigint NOT NULL,
    "clientId" integer NOT NULL,
    "productId" integer NOT NULL,
    "documentTypeId" integer NOT NULL,
    amount numeric(10,2) NOT NULL,
    currency character varying(3) DEFAULT 'INR'::character varying,
    "isActive" boolean DEFAULT true,
    "effectiveFrom" timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    "effectiveTo" timestamp without time zone,
    "createdBy" uuid,
    "createdAt" timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT "documentTypeRates_amount_check" CHECK ((amount >= (0)::numeric))
);


--
-- Name: TABLE "documentTypeRates"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public."documentTypeRates" IS 'Stores pricing for document verification services by client, product, and document type';


--
-- Name: COLUMN "documentTypeRates"."clientId"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."documentTypeRates"."clientId" IS 'Reference to the client requesting document verification';


--
-- Name: COLUMN "documentTypeRates"."productId"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."documentTypeRates"."productId" IS 'Reference to the product/service for which document is required';


--
-- Name: COLUMN "documentTypeRates"."documentTypeId"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."documentTypeRates"."documentTypeId" IS 'Reference to the type of document (Aadhaar, PAN, Passport, etc.)';


--
-- Name: COLUMN "documentTypeRates".amount; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."documentTypeRates".amount IS 'Rate amount for this document type verification';


--
-- Name: COLUMN "documentTypeRates".currency; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."documentTypeRates".currency IS 'Currency code (default: INR)';


--
-- Name: COLUMN "documentTypeRates"."isActive"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."documentTypeRates"."isActive" IS 'Whether this rate is currently active';


--
-- Name: COLUMN "documentTypeRates"."effectiveFrom"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."documentTypeRates"."effectiveFrom" IS 'Date from which this rate is effective';


--
-- Name: COLUMN "documentTypeRates"."effectiveTo"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."documentTypeRates"."effectiveTo" IS 'Date until which this rate is effective (NULL for indefinite)';


--
-- Name: documentTypes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."documentTypes" (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    code character varying(50) NOT NULL,
    created_by uuid,
    updated_by uuid,
    "createdAt" timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: TABLE "documentTypes"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public."documentTypes" IS 'Master table for document types used in verification processes';


--
-- Name: COLUMN "documentTypes".code; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."documentTypes".code IS 'Unique code for the document type (e.g., AADHAAR, PAN, PASSPORT)';


--
-- Name: products; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.products (
    name character varying(255) NOT NULL,
    code character varying(50) NOT NULL,
    description text,
    "createdAt" timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    "isActive" boolean DEFAULT true,
    id integer NOT NULL
);


--
-- Name: TABLE products; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.products IS 'Core business products offered by the organization';


--
-- Name: COLUMN products."isActive"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.products."isActive" IS 'Indicates whether the product is active and available for use';


--
-- Name: documentTypeRatesView; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public."documentTypeRatesView" AS
 SELECT dtr.id,
    dtr."clientId",
    dtr."productId",
    dtr."documentTypeId",
    dtr.amount,
    dtr.currency,
    dtr."isActive",
    dtr."effectiveFrom",
    dtr."effectiveTo",
    dtr."createdBy",
    dtr."createdAt",
    dtr."updatedAt",
    c.name AS "clientName",
    c.code AS "clientCode",
    p.name AS "productName",
    p.code AS "productCode",
    dt.name AS "documentTypeName",
    dt.code AS "documentTypeCode"
   FROM (((public."documentTypeRates" dtr
     JOIN public.clients c ON ((dtr."clientId" = c.id)))
     JOIN public.products p ON ((dtr."productId" = p.id)))
     JOIN public."documentTypes" dt ON ((dtr."documentTypeId" = dt.id)));


--
-- Name: documentTypeRates_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public."documentTypeRates_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: documentTypeRates_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public."documentTypeRates_id_seq" OWNED BY public."documentTypeRates".id;


--
-- Name: documentTypes_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public."documentTypes_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: documentTypes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public."documentTypes_id_seq" OWNED BY public."documentTypes".id;


--
-- Name: dsaConnectorVerificationReports; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."dsaConnectorVerificationReports" (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    case_id uuid NOT NULL,
    "caseId" integer,
    form_type character varying(50) DEFAULT 'POSITIVE'::character varying NOT NULL,
    verification_outcome character varying(50) NOT NULL,
    customer_name character varying(255),
    customer_phone character varying(20),
    customer_email character varying(255),
    address_locatable character varying(50),
    address_rating character varying(50),
    full_address text,
    locality character varying(100),
    address_structure character varying(100),
    address_floor character varying(50),
    address_structure_color character varying(50),
    door_color character varying(50),
    landmark1 character varying(255),
    landmark2 character varying(255),
    landmark3 character varying(255),
    landmark4 character varying(255),
    connector_type character varying(50),
    connector_code character varying(100),
    connector_name character varying(255),
    connector_designation character varying(100),
    connector_experience integer,
    connector_status character varying(50),
    business_name character varying(255),
    business_type character varying(100),
    business_registration_number character varying(100),
    business_establishment_year integer,
    office_type character varying(100),
    office_area numeric(10,2),
    office_rent numeric(10,2),
    total_staff integer,
    sales_staff integer,
    support_staff integer,
    team_size integer,
    monthly_business_volume numeric(15,2),
    average_monthly_sales numeric(15,2),
    annual_turnover numeric(15,2),
    monthly_income numeric(12,2),
    commission_structure character varying(255),
    payment_terms character varying(255),
    bank_account_details character varying(255),
    computer_systems integer,
    internet_connection character varying(50),
    software_systems character varying(255),
    pos_terminals integer,
    printer_scanner character varying(50),
    license_status character varying(50),
    license_number character varying(100),
    license_expiry_date date,
    compliance_status character varying(50),
    audit_status character varying(50),
    training_status character varying(50),
    met_person_name character varying(255),
    met_person_designation character varying(100),
    met_person_relation character varying(100),
    met_person_contact character varying(20),
    business_operational character varying(50),
    customer_footfall character varying(100),
    business_hours character varying(100),
    weekend_operations character varying(50),
    tpc_met_person1 character varying(50),
    tpc_name1 character varying(255),
    tpc_confirmation1 character varying(50),
    tpc_met_person2 character varying(50),
    tpc_name2 character varying(255),
    tpc_confirmation2 character varying(50),
    shifted_period character varying(100),
    current_location character varying(255),
    premises_status character varying(50),
    previous_business_name character varying(255),
    entry_restriction_reason character varying(255),
    security_person_name character varying(255),
    security_confirmation character varying(50),
    contact_person character varying(255),
    call_remark character varying(50),
    market_presence character varying(100),
    competitor_analysis character varying(255),
    market_reputation character varying(100),
    customer_feedback character varying(100),
    political_connection character varying(100),
    dominated_area character varying(100),
    feedback_from_neighbour character varying(100),
    infrastructure_status character varying(100),
    commercial_viability character varying(100),
    other_observation text,
    business_concerns text,
    operational_challenges text,
    growth_potential text,
    final_status character varying(50) NOT NULL,
    hold_reason text,
    recommendation_status character varying(50),
    risk_assessment character varying(50),
    verification_date date DEFAULT CURRENT_DATE NOT NULL,
    verification_time time without time zone DEFAULT CURRENT_TIME NOT NULL,
    verified_by uuid NOT NULL,
    remarks text,
    total_images integer DEFAULT 0,
    total_selfies integer DEFAULT 0,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    verification_task_id uuid,
    report_sha256_hash text,
    report_server_signature text,
    report_generated_at timestamp with time zone,
    is_final boolean DEFAULT false,
    CONSTRAINT chk_dsa_connector_verification_connector_experience CHECK (((connector_experience IS NULL) OR ((connector_experience >= 0) AND (connector_experience <= 50)))),
    CONSTRAINT chk_dsa_connector_verification_establishment_year CHECK (((business_establishment_year IS NULL) OR ((business_establishment_year >= 1900) AND ((business_establishment_year)::numeric <= EXTRACT(year FROM CURRENT_DATE))))),
    CONSTRAINT chk_dsa_connector_verification_final_status CHECK (((final_status)::text = ANY (ARRAY[('Positive'::character varying)::text, ('Negative'::character varying)::text, ('Refer'::character varying)::text, ('Fraud'::character varying)::text, ('Hold'::character varying)::text]))),
    CONSTRAINT chk_dsa_connector_verification_form_type CHECK (((form_type)::text = ANY (ARRAY[('POSITIVE'::character varying)::text, ('SHIFTED'::character varying)::text, ('NSP'::character varying)::text, ('ENTRY_RESTRICTED'::character varying)::text, ('UNTRACEABLE'::character varying)::text]))),
    CONSTRAINT chk_dsa_connector_verification_staff_consistency CHECK (((total_staff IS NULL) OR ((sales_staff + support_staff) <= total_staff))),
    CONSTRAINT chk_dsa_connector_verification_total_staff CHECK (((total_staff IS NULL) OR ((total_staff >= 1) AND (total_staff <= 1000))))
);


--
-- Name: TABLE "dsaConnectorVerificationReports"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public."dsaConnectorVerificationReports" IS 'Comprehensive table for storing DSA/DST Connector verification form data from mobile app submissions';


--
-- Name: COLUMN "dsaConnectorVerificationReports".case_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."dsaConnectorVerificationReports".case_id IS 'UUID reference to the case being verified';


--
-- Name: COLUMN "dsaConnectorVerificationReports".form_type; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."dsaConnectorVerificationReports".form_type IS 'Type of DSA/DST Connector verification form: POSITIVE, SHIFTED, NSP, ENTRY_RESTRICTED, UNTRACEABLE';


--
-- Name: COLUMN "dsaConnectorVerificationReports".verification_outcome; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."dsaConnectorVerificationReports".verification_outcome IS 'Maps to verification outcome from case (Positive & Door Locked, Shifted & Door Lock, etc.)';


--
-- Name: COLUMN "dsaConnectorVerificationReports".verified_by; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."dsaConnectorVerificationReports".verified_by IS 'UUID of the field agent who performed the verification';


--
-- Name: COLUMN "dsaConnectorVerificationReports".verification_task_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."dsaConnectorVerificationReports".verification_task_id IS 'Links DSA connector verification report to specific verification task';


--
-- Name: COLUMN "dsaConnectorVerificationReports".report_sha256_hash; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."dsaConnectorVerificationReports".report_sha256_hash IS 'SHA-256 hash of generated PDF report for tamper detection.';


--
-- Name: COLUMN "dsaConnectorVerificationReports".report_server_signature; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."dsaConnectorVerificationReports".report_server_signature IS 'HMAC-SHA256 signature of PDF. Prevents report regeneration attacks.';


--
-- Name: COLUMN "dsaConnectorVerificationReports".is_final; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."dsaConnectorVerificationReports".is_final IS 'TRUE = report is finalized and cannot be regenerated. Bank audit requirement.';


--
-- Name: error_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.error_logs (
    id bigint NOT NULL,
    error_type character varying(100) NOT NULL,
    error_message text NOT NULL,
    stack_trace text,
    request_id character varying(255),
    user_id uuid,
    url text,
    additional_data jsonb,
    "timestamp" timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: TABLE error_logs; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.error_logs IS 'Centralized error logging for application monitoring';


--
-- Name: error_frequency; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.error_frequency AS
 SELECT error_type,
    count(*) AS error_count,
    max("timestamp") AS last_occurrence,
    count(DISTINCT user_id) AS affected_users
   FROM public.error_logs
  WHERE ("timestamp" > (now() - '24:00:00'::interval))
  GROUP BY error_type
  ORDER BY (count(*)) DESC;


--
-- Name: error_logs_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.error_logs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: error_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.error_logs_id_seq OWNED BY public.error_logs.id;


--
-- Name: pincodes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.pincodes (
    code character varying(10) NOT NULL,
    "createdAt" timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    id integer NOT NULL,
    "cityId" integer
);


--
-- Name: TABLE pincodes; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.pincodes IS 'Postal codes linked to cities';


--
-- Name: states; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.states (
    name character varying(100) NOT NULL,
    code character varying(10) NOT NULL,
    "createdAt" timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    id integer NOT NULL,
    "countryId" integer
);


--
-- Name: userAreaAssignments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."userAreaAssignments" (
    id integer NOT NULL,
    "userId" uuid NOT NULL,
    "pincodeId" integer NOT NULL,
    "areaId" integer NOT NULL,
    "userPincodeAssignmentId" integer NOT NULL,
    "assignedBy" uuid NOT NULL,
    "assignedAt" timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    "isActive" boolean DEFAULT true,
    "createdAt" timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: TABLE "userAreaAssignments"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public."userAreaAssignments" IS 'Junction table for assigning field agents to specific areas within pincodes';


--
-- Name: COLUMN "userAreaAssignments"."userId"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."userAreaAssignments"."userId" IS 'Reference to the field agent user being assigned to areas';


--
-- Name: COLUMN "userAreaAssignments"."pincodeId"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."userAreaAssignments"."pincodeId" IS 'Reference to the pincode containing the area';


--
-- Name: COLUMN "userAreaAssignments"."areaId"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."userAreaAssignments"."areaId" IS 'Reference to the specific area within the pincode';


--
-- Name: COLUMN "userAreaAssignments"."userPincodeAssignmentId"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."userAreaAssignments"."userPincodeAssignmentId" IS 'Reference to the parent pincode assignment';


--
-- Name: COLUMN "userAreaAssignments"."isActive"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."userAreaAssignments"."isActive" IS 'Whether this area assignment is currently active';


--
-- Name: userPincodeAssignments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."userPincodeAssignments" (
    id integer NOT NULL,
    "userId" uuid NOT NULL,
    "pincodeId" integer NOT NULL,
    "assignedBy" uuid NOT NULL,
    "assignedAt" timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    "isActive" boolean DEFAULT true,
    "createdAt" timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: TABLE "userPincodeAssignments"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public."userPincodeAssignments" IS 'Junction table for assigning field agents to specific pincodes for territorial coverage';


--
-- Name: COLUMN "userPincodeAssignments"."userId"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."userPincodeAssignments"."userId" IS 'Reference to the field agent user being assigned to pincodes';


--
-- Name: COLUMN "userPincodeAssignments"."pincodeId"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."userPincodeAssignments"."pincodeId" IS 'Reference to the pincode the field agent is assigned to';


--
-- Name: COLUMN "userPincodeAssignments"."assignedBy"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."userPincodeAssignments"."assignedBy" IS 'User who performed the assignment (ADMIN/SUPER_ADMIN)';


--
-- Name: COLUMN "userPincodeAssignments"."isActive"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."userPincodeAssignments"."isActive" IS 'Whether this assignment is currently active';


--
-- Name: users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name character varying(100) NOT NULL,
    username character varying(50) NOT NULL,
    password character varying(255) NOT NULL,
    "passwordHash" character varying(255) NOT NULL,
    role character varying(20) DEFAULT 'USER'::character varying NOT NULL,
    email character varying(100),
    phone character varying(20),
    "isActive" boolean DEFAULT true,
    "lastLogin" timestamp with time zone,
    "createdAt" timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    "employeeId" character varying(50),
    designation character varying(100),
    department character varying(100),
    "profilePhotoUrl" character varying(500),
    "departmentId" integer,
    "designationId" integer,
    performance_rating numeric(3,2) DEFAULT NULL::numeric,
    total_cases_handled integer DEFAULT 0,
    avg_case_completion_days numeric(6,2) DEFAULT NULL::numeric,
    last_active_at timestamp without time zone,
    preferred_form_types character varying(100) DEFAULT NULL::character varying,
    "deletedAt" timestamp with time zone,
    team_leader_id uuid,
    manager_id uuid,
    CONSTRAINT chk_users_role CHECK (((role)::text = ANY (ARRAY[('SUPER_ADMIN'::character varying)::text, ('ADMIN'::character varying)::text, ('BACKEND_USER'::character varying)::text, ('FIELD_AGENT'::character varying)::text, ('MANAGER'::character varying)::text, ('REPORT_PERSON'::character varying)::text]))),
    CONSTRAINT users_avg_case_completion_days_check CHECK ((avg_case_completion_days >= (0)::numeric)),
    CONSTRAINT users_performance_rating_check CHECK (((performance_rating >= (0)::numeric) AND (performance_rating <= (5)::numeric))),
    CONSTRAINT users_total_cases_handled_check CHECK ((total_cases_handled >= 0))
);


--
-- Name: fieldAgentTerritories; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public."fieldAgentTerritories" AS
 SELECT u.id AS "userId",
    u.name AS "userName",
    u.username,
    u."employeeId",
    upa.id AS "pincodeAssignmentId",
    p.id AS "pincodeId",
    p.code AS "pincodeCode",
    c.name AS "cityName",
    s.name AS "stateName",
    co.name AS "countryName",
    COALESCE(json_agg(json_build_object('areaAssignmentId', uaa.id, 'areaId', a.id, 'areaName', a.name, 'assignedAt', uaa."assignedAt") ORDER BY a.name) FILTER (WHERE (a.id IS NOT NULL)), '[]'::json) AS "assignedAreas",
    upa."assignedAt" AS "pincodeAssignedAt",
    upa."assignedBy",
    upa."isActive"
   FROM (((((((public.users u
     JOIN public."userPincodeAssignments" upa ON ((u.id = upa."userId")))
     JOIN public.pincodes p ON ((upa."pincodeId" = p.id)))
     JOIN public.cities c ON ((p."cityId" = c.id)))
     JOIN public.states s ON ((c."stateId" = s.id)))
     JOIN public.countries co ON ((c."countryId" = co.id)))
     LEFT JOIN public."userAreaAssignments" uaa ON (((upa.id = uaa."userPincodeAssignmentId") AND (uaa."isActive" = true))))
     LEFT JOIN public.areas a ON ((uaa."areaId" = a.id)))
  WHERE (upa."isActive" = true)
  GROUP BY u.id, u.name, u.username, u."employeeId", upa.id, p.id, p.code, c.name, s.name, co.name, upa."assignedAt", upa."assignedBy", upa."isActive";


--
-- Name: VIEW "fieldAgentTerritories"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON VIEW public."fieldAgentTerritories" IS 'Comprehensive view of field agent territory assignments with pincode and area details';


--
-- Name: field_user_commission_assignments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.field_user_commission_assignments (
    id bigint NOT NULL,
    user_id uuid NOT NULL,
    rate_type_id integer NOT NULL,
    commission_amount numeric(10,2) NOT NULL,
    currency character varying(3) DEFAULT 'INR'::character varying,
    client_id integer,
    is_active boolean DEFAULT true,
    effective_from timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    effective_to timestamp with time zone,
    created_by uuid,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT chk_field_user_commission_amount_positive CHECK ((commission_amount > (0)::numeric)),
    CONSTRAINT field_user_commission_assignments_commission_amount_check CHECK ((commission_amount >= (0)::numeric))
);


--
-- Name: TABLE field_user_commission_assignments; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.field_user_commission_assignments IS 'Field user commission assignments with fixed amounts only';


--
-- Name: COLUMN field_user_commission_assignments.commission_amount; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.field_user_commission_assignments.commission_amount IS 'Fixed commission amount for this user assignment';


--
-- Name: COLUMN field_user_commission_assignments.client_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.field_user_commission_assignments.client_id IS 'NULL for global assignments, specific client_id for institute-specific rates';


--
-- Name: field_user_commission_assignments_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.field_user_commission_assignments_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: field_user_commission_assignments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.field_user_commission_assignments_id_seq OWNED BY public.field_user_commission_assignments.id;


--
-- Name: field_user_task_workload; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.field_user_task_workload AS
 SELECT u.id AS user_id,
    u.name AS user_name,
    u."employeeId",
    count(vt.id) AS total_assigned_tasks,
    count(
        CASE
            WHEN (((vt.status)::text = 'PENDING'::text) OR ((vt.status)::text = 'ASSIGNED'::text)) THEN 1
            ELSE NULL::integer
        END) AS pending_tasks,
    count(
        CASE
            WHEN ((vt.status)::text = 'IN_PROGRESS'::text) THEN 1
            ELSE NULL::integer
        END) AS in_progress_tasks,
    count(
        CASE
            WHEN ((vt.status)::text = 'COMPLETED'::text) THEN 1
            ELSE NULL::integer
        END) AS completed_tasks,
    count(
        CASE
            WHEN ((vt.status)::text = 'CANCELLED'::text) THEN 1
            ELSE NULL::integer
        END) AS cancelled_tasks,
    round(
        CASE
            WHEN (count(vt.id) = 0) THEN (0)::numeric
            ELSE (((count(
            CASE
                WHEN ((vt.status)::text = 'COMPLETED'::text) THEN 1
                ELSE NULL::integer
            END))::numeric / (count(vt.id))::numeric) * (100)::numeric)
        END, 2) AS completion_rate_percentage,
    COALESCE(sum(
        CASE
            WHEN ((vt.status)::text = 'COMPLETED'::text) THEN vt.actual_amount
            ELSE (0)::numeric
        END), (0)::numeric) AS total_completed_amount,
    COALESCE(sum(tcc.calculated_commission), (0)::numeric) AS total_commission_earned,
    COALESCE(sum(
        CASE
            WHEN ((tcc.status)::text = 'PAID'::text) THEN tcc.calculated_commission
            ELSE (0)::numeric
        END), (0)::numeric) AS paid_commission,
    round(avg(
        CASE
            WHEN (((vt.status)::text = 'COMPLETED'::text) AND (vt.started_at IS NOT NULL)) THEN (EXTRACT(epoch FROM (vt.completed_at - vt.started_at)) / (3600)::numeric)
            ELSE NULL::numeric
        END), 2) AS avg_completion_time_hours,
    max(vt.completed_at) AS last_task_completed,
    count(
        CASE
            WHEN (((vt.status)::text = 'COMPLETED'::text) AND (date(vt.completed_at) = CURRENT_DATE)) THEN 1
            ELSE NULL::integer
        END) AS completed_today
   FROM ((public.users u
     LEFT JOIN public.verification_tasks vt ON ((u.id = vt.assigned_to)))
     LEFT JOIN public.task_commission_calculations tcc ON ((vt.id = tcc.verification_task_id)))
  WHERE ((u.role)::text = 'FIELD_USER'::text)
  GROUP BY u.id, u.name, u."employeeId";


--
-- Name: form_quality_metrics; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.form_quality_metrics (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    form_submission_id uuid NOT NULL,
    overall_quality_score numeric(5,2),
    completeness_score numeric(5,2),
    accuracy_score numeric(5,2),
    photo_quality_score numeric(5,2),
    timeliness_score numeric(5,2),
    consistency_score numeric(5,2),
    calculated_at timestamp without time zone DEFAULT now(),
    calculated_by character varying(50),
    notes text,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now(),
    CONSTRAINT form_quality_metrics_accuracy_score_check CHECK (((accuracy_score >= (0)::numeric) AND (accuracy_score <= (100)::numeric))),
    CONSTRAINT form_quality_metrics_completeness_score_check CHECK (((completeness_score >= (0)::numeric) AND (completeness_score <= (100)::numeric))),
    CONSTRAINT form_quality_metrics_consistency_score_check CHECK (((consistency_score >= (0)::numeric) AND (consistency_score <= (100)::numeric))),
    CONSTRAINT form_quality_metrics_overall_quality_score_check CHECK (((overall_quality_score >= (0)::numeric) AND (overall_quality_score <= (100)::numeric))),
    CONSTRAINT form_quality_metrics_photo_quality_score_check CHECK (((photo_quality_score >= (0)::numeric) AND (photo_quality_score <= (100)::numeric))),
    CONSTRAINT form_quality_metrics_timeliness_score_check CHECK (((timeliness_score >= (0)::numeric) AND (timeliness_score <= (100)::numeric)))
);


--
-- Name: TABLE form_quality_metrics; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.form_quality_metrics IS 'Quality metrics for form submissions';


--
-- Name: form_submissions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.form_submissions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    case_id uuid NOT NULL,
    verification_task_id uuid,
    verification_type_id integer,
    form_type character varying(50) NOT NULL,
    submitted_by uuid NOT NULL,
    submission_data jsonb DEFAULT '{}'::jsonb NOT NULL,
    validation_status character varying(20) DEFAULT 'PENDING'::character varying NOT NULL,
    validation_errors jsonb DEFAULT '[]'::jsonb,
    photos_count integer DEFAULT 0,
    attachments_count integer DEFAULT 0,
    geo_location jsonb,
    submission_score numeric(5,2),
    time_spent_minutes integer,
    device_info jsonb DEFAULT '{}'::jsonb,
    network_quality character varying(20),
    submitted_at timestamp without time zone DEFAULT now() NOT NULL,
    validated_at timestamp without time zone,
    validated_by uuid,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now(),
    CONSTRAINT form_submissions_attachments_count_check CHECK ((attachments_count >= 0)),
    CONSTRAINT form_submissions_form_type_check CHECK (((form_type)::text = ANY (ARRAY[('RESIDENCE'::character varying)::text, ('OFFICE'::character varying)::text, ('BUSINESS'::character varying)::text, ('BUILDER'::character varying)::text, ('RESIDENCE_CUM_OFFICE'::character varying)::text, ('DSA_CONNECTOR'::character varying)::text, ('PROPERTY_APF'::character varying)::text, ('PROPERTY_INDIVIDUAL'::character varying)::text, ('NOC'::character varying)::text]))),
    CONSTRAINT form_submissions_photos_count_check CHECK ((photos_count >= 0)),
    CONSTRAINT form_submissions_submission_score_check CHECK (((submission_score >= (0)::numeric) AND (submission_score <= (100)::numeric))),
    CONSTRAINT form_submissions_time_spent_minutes_check CHECK ((time_spent_minutes >= 0)),
    CONSTRAINT form_submissions_validation_status_check CHECK (((validation_status)::text = ANY (ARRAY[('PENDING'::character varying)::text, ('VALID'::character varying)::text, ('INVALID'::character varying)::text, ('REQUIRES_REVIEW'::character varying)::text])))
);


--
-- Name: TABLE form_submissions; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.form_submissions IS 'Generic form submissions table for analytics and reporting';


--
-- Name: COLUMN form_submissions.verification_task_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.form_submissions.verification_task_id IS 'Links form submission to specific verification task (multi-task support)';


--
-- Name: COLUMN form_submissions.verification_type_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.form_submissions.verification_type_id IS 'Verification type ID from the task (not case) for proper report generation';


--
-- Name: verificationTypes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."verificationTypes" (
    name character varying(255) NOT NULL,
    code character varying(50) NOT NULL,
    description text,
    "createdAt" timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    "isActive" boolean DEFAULT true,
    id integer NOT NULL
);


--
-- Name: TABLE "verificationTypes"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public."verificationTypes" IS 'Types of verification services available';


--
-- Name: COLUMN "verificationTypes"."isActive"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."verificationTypes"."isActive" IS 'Indicates whether the verification type is active and available for use';


--
-- Name: form_submission_analytics; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.form_submission_analytics AS
 SELECT fs.id,
    fs.case_id,
    fs.verification_task_id,
    fs.form_type,
    fs.submitted_by,
    fs.submitted_at,
    fs.validation_status,
    fs.submission_score,
    fs.photos_count,
    fs.attachments_count,
    fqm.overall_quality_score,
    fqm.completeness_score,
    fqm.accuracy_score,
    fqm.photo_quality_score,
    fqm.timeliness_score,
    c."customerName",
    c."caseId" AS case_number,
    u.name AS submitted_by_name,
    u."employeeId" AS submitted_by_employee_id,
    vt.task_number,
    vtype.name AS verification_type_name
   FROM (((((public.form_submissions fs
     LEFT JOIN public.form_quality_metrics fqm ON ((fs.id = fqm.form_submission_id)))
     LEFT JOIN public.cases c ON ((fs.case_id = c.id)))
     LEFT JOIN public.users u ON ((fs.submitted_by = u.id)))
     LEFT JOIN public.verification_tasks vt ON ((fs.verification_task_id = vt.id)))
     LEFT JOIN public."verificationTypes" vtype ON ((fs.verification_type_id = vtype.id)));


--
-- Name: VIEW form_submission_analytics; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON VIEW public.form_submission_analytics IS 'Analytics view combining form submissions with quality metrics and case data';


--
-- Name: form_validation_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.form_validation_logs (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    form_submission_id uuid NOT NULL,
    field_name character varying(100) NOT NULL,
    field_value text,
    is_valid boolean NOT NULL,
    error_message text,
    validation_rule character varying(100),
    validated_at timestamp without time zone DEFAULT now(),
    validated_by character varying(50),
    created_at timestamp without time zone DEFAULT now()
);


--
-- Name: TABLE form_validation_logs; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.form_validation_logs IS 'Validation logs for form submission fields';


--
-- Name: invoice_item_tasks; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.invoice_item_tasks (
    id bigint NOT NULL,
    invoice_item_id bigint NOT NULL,
    verification_task_id uuid NOT NULL,
    case_id uuid NOT NULL,
    client_id integer NOT NULL,
    billed_amount numeric(12,2) DEFAULT 0 NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: invoice_item_tasks_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.invoice_item_tasks_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: invoice_item_tasks_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.invoice_item_tasks_id_seq OWNED BY public.invoice_item_tasks.id;


--
-- Name: invoice_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.invoice_items (
    id bigint NOT NULL,
    invoice_id bigint NOT NULL,
    client_id integer NOT NULL,
    product_id integer,
    verification_type_id integer,
    rate_type_id integer,
    description character varying(500) NOT NULL,
    quantity integer DEFAULT 1 NOT NULL,
    unit_price numeric(12,2) DEFAULT 0 NOT NULL,
    amount numeric(12,2) DEFAULT 0 NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: invoice_items_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.invoice_items_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: invoice_items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.invoice_items_id_seq OWNED BY public.invoice_items.id;


--
-- Name: invoice_status_history; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.invoice_status_history (
    id bigint NOT NULL,
    invoice_id bigint NOT NULL,
    from_status character varying(50),
    to_status character varying(50) NOT NULL,
    changed_by uuid,
    notes text,
    changed_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: invoice_status_history_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.invoice_status_history_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: invoice_status_history_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.invoice_status_history_id_seq OWNED BY public.invoice_status_history.id;


--
-- Name: invoices; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.invoices (
    id bigint NOT NULL,
    invoice_number character varying(100) NOT NULL,
    client_id integer NOT NULL,
    product_id integer,
    client_name character varying(200) NOT NULL,
    amount numeric(12,2) DEFAULT 0 NOT NULL,
    subtotal_amount numeric(12,2) DEFAULT 0 NOT NULL,
    tax_amount numeric(12,2) DEFAULT 0 NOT NULL,
    total_amount numeric(12,2) DEFAULT 0 NOT NULL,
    currency character varying(10) DEFAULT 'INR'::character varying NOT NULL,
    status character varying(50) DEFAULT 'DRAFT'::character varying NOT NULL,
    billing_period_from timestamp with time zone,
    billing_period_to timestamp with time zone,
    issue_date timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    due_date timestamp with time zone NOT NULL,
    approved_by uuid,
    approved_at timestamp with time zone,
    sent_at timestamp with time zone,
    paid_date timestamp with time zone,
    payment_method character varying(50),
    transaction_id character varying(100),
    notes text,
    created_by uuid,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: invoices_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.invoices_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: invoices_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.invoices_id_seq OWNED BY public.invoices.id;


--
-- Name: locations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.locations (
    latitude numeric(10,8) NOT NULL,
    longitude numeric(11,8) NOT NULL,
    accuracy numeric(8,2),
    "recordedBy" uuid NOT NULL,
    "recordedAt" timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    id bigint NOT NULL,
    "caseId" integer,
    case_id uuid NOT NULL,
    verification_task_id uuid
);


--
-- Name: COLUMN locations.verification_task_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.locations.verification_task_id IS 'Stage-1: Links GPS capture to a specific verification task. NULL for legacy records.';


--
-- Name: locations_temp_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.locations_temp_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: locations_temp_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.locations_temp_id_seq OWNED BY public.locations.id;


--
-- Name: migrations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.migrations (
    id character varying(255) NOT NULL,
    filename character varying(255) NOT NULL,
    "executedAt" timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: mobile_device_sync; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.mobile_device_sync (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    "userId" uuid NOT NULL,
    "deviceId" character varying(255) NOT NULL,
    "lastSyncAt" timestamp with time zone NOT NULL,
    "appVersion" character varying(50) NOT NULL,
    platform character varying(20) NOT NULL,
    "syncCount" integer DEFAULT 0 NOT NULL,
    "createdAt" timestamp with time zone DEFAULT now() NOT NULL,
    "updatedAt" timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT mobile_device_sync_platform_check CHECK (((platform)::text = ANY (ARRAY[('iOS'::character varying)::text, ('Android'::character varying)::text])))
);


--
-- Name: TABLE mobile_device_sync; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.mobile_device_sync IS 'Tracks mobile device synchronization for enterprise scale monitoring';


--
-- Name: mobile_notification_audit; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.mobile_notification_audit (
    id bigint NOT NULL,
    "notificationId" character varying(255) NOT NULL,
    "userId" uuid,
    "caseId" integer,
    "notificationType" character varying(100) NOT NULL,
    "notificationData" text NOT NULL,
    "sentAt" timestamp with time zone NOT NULL,
    "deliveryStatus" character varying(50) DEFAULT 'SENT'::character varying NOT NULL,
    "acknowledgedAt" timestamp with time zone,
    metadata text,
    "createdAt" timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    case_id uuid NOT NULL
);


--
-- Name: TABLE mobile_notification_audit; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.mobile_notification_audit IS 'Audit log for WebSocket notifications sent to mobile applications';


--
-- Name: COLUMN mobile_notification_audit."notificationId"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.mobile_notification_audit."notificationId" IS 'Unique identifier for the notification';


--
-- Name: COLUMN mobile_notification_audit."userId"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.mobile_notification_audit."userId" IS 'ID of the user who received the notification';


--
-- Name: COLUMN mobile_notification_audit."caseId"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.mobile_notification_audit."caseId" IS 'ID of the case related to the notification';


--
-- Name: COLUMN mobile_notification_audit."notificationType"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.mobile_notification_audit."notificationType" IS 'Type of notification (CASE_ASSIGNED, CASE_STATUS_CHANGED, etc.)';


--
-- Name: COLUMN mobile_notification_audit."notificationData"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.mobile_notification_audit."notificationData" IS 'JSON data of the notification payload';


--
-- Name: COLUMN mobile_notification_audit."sentAt"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.mobile_notification_audit."sentAt" IS 'Timestamp when notification was sent';


--
-- Name: COLUMN mobile_notification_audit."deliveryStatus"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.mobile_notification_audit."deliveryStatus" IS 'Status of notification delivery (SENT, DELIVERED, ACKNOWLEDGED, FAILED)';


--
-- Name: COLUMN mobile_notification_audit."acknowledgedAt"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.mobile_notification_audit."acknowledgedAt" IS 'Timestamp when notification was acknowledged by mobile app';


--
-- Name: COLUMN mobile_notification_audit.metadata; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.mobile_notification_audit.metadata IS 'Additional metadata about the notification';


--
-- Name: mobile_notification_audit_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.mobile_notification_audit_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: mobile_notification_audit_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.mobile_notification_audit_id_seq OWNED BY public.mobile_notification_audit.id;


--
-- Name: mobile_notification_queue; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.mobile_notification_queue (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    "userId" uuid NOT NULL,
    "notificationType" character varying(100) NOT NULL,
    title character varying(255) NOT NULL,
    message text NOT NULL,
    data jsonb DEFAULT '{}'::jsonb,
    status character varying(50) DEFAULT 'PENDING'::character varying NOT NULL,
    "scheduledAt" timestamp with time zone DEFAULT now() NOT NULL,
    "sentAt" timestamp with time zone,
    "failedAt" timestamp with time zone,
    "retryCount" integer DEFAULT 0 NOT NULL,
    "maxRetries" integer DEFAULT 3 NOT NULL,
    error text,
    "createdAt" timestamp with time zone DEFAULT now() NOT NULL,
    "updatedAt" timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: TABLE mobile_notification_queue; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.mobile_notification_queue IS 'Queue for mobile push notifications';


--
-- Name: mobile_sync_analytics; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.mobile_sync_analytics AS
 SELECT date_trunc('hour'::text, "lastSyncAt") AS sync_hour,
    count(*) AS total_syncs,
    count(DISTINCT "userId") AS unique_users,
    count(DISTINCT "deviceId") AS unique_devices,
    avg("syncCount") AS avg_sync_count,
    count(
        CASE
            WHEN ((platform)::text = 'iOS'::text) THEN 1
            ELSE NULL::integer
        END) AS ios_syncs,
    count(
        CASE
            WHEN ((platform)::text = 'Android'::text) THEN 1
            ELSE NULL::integer
        END) AS android_syncs
   FROM public.mobile_device_sync mds
  WHERE ("lastSyncAt" >= (now() - '24:00:00'::interval))
  GROUP BY (date_trunc('hour'::text, "lastSyncAt"))
  ORDER BY (date_trunc('hour'::text, "lastSyncAt")) DESC;


--
-- Name: VIEW mobile_sync_analytics; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON VIEW public.mobile_sync_analytics IS 'Analytics view for mobile sync operations';


--
-- Name: nocVerificationReports; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."nocVerificationReports" (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    case_id uuid NOT NULL,
    "caseId" integer,
    form_type character varying(50) DEFAULT 'POSITIVE'::character varying NOT NULL,
    verification_outcome character varying(50) NOT NULL,
    customer_name character varying(255),
    customer_phone character varying(20),
    customer_email character varying(255),
    address_locatable character varying(50),
    address_rating character varying(50),
    full_address text,
    locality character varying(100),
    address_structure character varying(100),
    address_floor character varying(50),
    address_structure_color character varying(50),
    door_color character varying(50),
    landmark1 character varying(255),
    landmark2 character varying(255),
    landmark3 character varying(255),
    landmark4 character varying(255),
    noc_status character varying(50),
    noc_type character varying(100),
    noc_number character varying(100),
    noc_issue_date date,
    noc_expiry_date date,
    noc_issuing_authority character varying(255),
    noc_validity_status character varying(50),
    property_type character varying(100),
    project_name character varying(255),
    project_status character varying(50),
    construction_status character varying(50),
    project_approval_status character varying(50),
    total_units integer,
    completed_units integer,
    sold_units integer,
    possession_status character varying(50),
    builder_name character varying(255),
    builder_contact character varying(20),
    developer_name character varying(255),
    developer_contact character varying(20),
    builder_registration_number character varying(100),
    met_person_name character varying(255),
    met_person_designation character varying(100),
    met_person_relation character varying(100),
    met_person_contact character varying(20),
    document_shown_status character varying(50),
    document_type character varying(255),
    document_verification_status character varying(50),
    tpc_met_person1 character varying(50),
    tpc_name1 character varying(255),
    tpc_confirmation1 character varying(50),
    tpc_met_person2 character varying(50),
    tpc_name2 character varying(255),
    tpc_confirmation2 character varying(50),
    shifted_period character varying(100),
    current_location character varying(255),
    premises_status character varying(50),
    entry_restriction_reason character varying(255),
    security_person_name character varying(255),
    security_confirmation character varying(50),
    contact_person character varying(255),
    call_remark character varying(50),
    environmental_clearance character varying(50),
    fire_safety_clearance character varying(50),
    pollution_clearance character varying(50),
    water_connection_status character varying(50),
    electricity_connection_status character varying(50),
    political_connection character varying(100),
    dominated_area character varying(100),
    feedback_from_neighbour character varying(100),
    infrastructure_status character varying(100),
    road_connectivity character varying(100),
    other_observation text,
    compliance_issues text,
    regulatory_concerns text,
    final_status character varying(50) NOT NULL,
    hold_reason text,
    recommendation_status character varying(50),
    verification_date date DEFAULT CURRENT_DATE NOT NULL,
    verification_time time without time zone DEFAULT CURRENT_TIME NOT NULL,
    verified_by uuid NOT NULL,
    remarks text,
    total_images integer DEFAULT 0,
    total_selfies integer DEFAULT 0,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    verification_task_id uuid,
    report_sha256_hash text,
    report_server_signature text,
    report_generated_at timestamp with time zone,
    is_final boolean DEFAULT false,
    CONSTRAINT chk_noc_verification_completed_units CHECK (((completed_units IS NULL) OR ((completed_units >= 0) AND (completed_units <= total_units)))),
    CONSTRAINT chk_noc_verification_final_status CHECK (((final_status)::text = ANY (ARRAY[('Positive'::character varying)::text, ('Negative'::character varying)::text, ('Refer'::character varying)::text, ('Fraud'::character varying)::text, ('Hold'::character varying)::text]))),
    CONSTRAINT chk_noc_verification_form_type CHECK (((form_type)::text = ANY (ARRAY[('POSITIVE'::character varying)::text, ('SHIFTED'::character varying)::text, ('NSP'::character varying)::text, ('ENTRY_RESTRICTED'::character varying)::text, ('UNTRACEABLE'::character varying)::text]))),
    CONSTRAINT chk_noc_verification_sold_units CHECK (((sold_units IS NULL) OR ((sold_units >= 0) AND (sold_units <= total_units)))),
    CONSTRAINT chk_noc_verification_total_units CHECK (((total_units IS NULL) OR ((total_units >= 1) AND (total_units <= 10000))))
);


--
-- Name: TABLE "nocVerificationReports"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public."nocVerificationReports" IS 'Comprehensive table for storing NOC verification form data from mobile app submissions';


--
-- Name: COLUMN "nocVerificationReports".case_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."nocVerificationReports".case_id IS 'UUID reference to the case being verified';


--
-- Name: COLUMN "nocVerificationReports".form_type; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."nocVerificationReports".form_type IS 'Type of NOC verification form: POSITIVE, SHIFTED, NSP, ENTRY_RESTRICTED, UNTRACEABLE';


--
-- Name: COLUMN "nocVerificationReports".verification_outcome; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."nocVerificationReports".verification_outcome IS 'Maps to verification outcome from case (Positive & Door Locked, Shifted & Door Lock, etc.)';


--
-- Name: COLUMN "nocVerificationReports".verified_by; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."nocVerificationReports".verified_by IS 'UUID of the field agent who performed the verification';


--
-- Name: COLUMN "nocVerificationReports".verification_task_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."nocVerificationReports".verification_task_id IS 'Links NOC verification report to specific verification task';


--
-- Name: COLUMN "nocVerificationReports".report_sha256_hash; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."nocVerificationReports".report_sha256_hash IS 'SHA-256 hash of generated PDF report for tamper detection.';


--
-- Name: COLUMN "nocVerificationReports".report_server_signature; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."nocVerificationReports".report_server_signature IS 'HMAC-SHA256 signature of PDF. Prevents report regeneration attacks.';


--
-- Name: COLUMN "nocVerificationReports".is_final; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."nocVerificationReports".is_final IS 'TRUE = report is finalized and cannot be regenerated. Bank audit requirement.';


--
-- Name: notificationTokens; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."notificationTokens" (
    "userId" uuid NOT NULL,
    token character varying(500) NOT NULL,
    platform character varying(20) NOT NULL,
    "isActive" boolean DEFAULT true,
    "createdAt" timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    id bigint NOT NULL,
    CONSTRAINT chk_notification_tokens_platform CHECK (((platform)::text = ANY (ARRAY[('IOS'::character varying)::text, ('ANDROID'::character varying)::text, ('WEB'::character varying)::text])))
);


--
-- Name: notificationTokens_temp_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public."notificationTokens_temp_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: notificationTokens_temp_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public."notificationTokens_temp_id_seq" OWNED BY public."notificationTokens".id;


--
-- Name: notification_batches; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.notification_batches (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    batch_name character varying(255),
    batch_type character varying(50) NOT NULL,
    target_user_ids uuid[] DEFAULT '{}'::uuid[],
    target_roles character varying(50)[] DEFAULT '{}'::character varying[],
    status character varying(20) DEFAULT 'PENDING'::character varying,
    total_notifications integer DEFAULT 0,
    sent_notifications integer DEFAULT 0,
    failed_notifications integer DEFAULT 0,
    scheduled_at timestamp with time zone,
    started_at timestamp with time zone,
    completed_at timestamp with time zone,
    created_by uuid,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    CONSTRAINT notification_batches_batch_type_check CHECK (((batch_type)::text = ANY (ARRAY[('BULK_ASSIGNMENT'::character varying)::text, ('SYSTEM_ANNOUNCEMENT'::character varying)::text, ('EMERGENCY_ALERT'::character varying)::text, ('MAINTENANCE_NOTICE'::character varying)::text]))),
    CONSTRAINT notification_batches_status_check CHECK (((status)::text = ANY (ARRAY[('PENDING'::character varying)::text, ('PROCESSING'::character varying)::text, ('COMPLETED'::character varying)::text, ('FAILED'::character varying)::text, ('CANCELLED'::character varying)::text])))
);


--
-- Name: notification_delivery_log; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.notification_delivery_log (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    notification_id uuid NOT NULL,
    delivery_method character varying(20) NOT NULL,
    attempt_number integer DEFAULT 1,
    delivery_status character varying(20) NOT NULL,
    error_code character varying(50),
    error_message text,
    device_id character varying(255),
    platform character varying(20),
    push_token_used text,
    attempted_at timestamp with time zone DEFAULT now(),
    completed_at timestamp with time zone,
    response_data jsonb DEFAULT '{}'::jsonb,
    CONSTRAINT notification_delivery_log_delivery_method_check CHECK (((delivery_method)::text = ANY (ARRAY[('PUSH'::character varying)::text, ('WEBSOCKET'::character varying)::text, ('EMAIL'::character varying)::text]))),
    CONSTRAINT notification_delivery_log_delivery_status_check CHECK (((delivery_status)::text = ANY (ARRAY[('PENDING'::character varying)::text, ('SENT'::character varying)::text, ('DELIVERED'::character varying)::text, ('FAILED'::character varying)::text, ('RETRY'::character varying)::text])))
);


--
-- Name: notification_preferences; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.notification_preferences (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    case_assignment_enabled boolean DEFAULT true,
    case_assignment_push boolean DEFAULT true,
    case_assignment_websocket boolean DEFAULT true,
    case_reassignment_enabled boolean DEFAULT true,
    case_reassignment_push boolean DEFAULT true,
    case_reassignment_websocket boolean DEFAULT true,
    case_completion_enabled boolean DEFAULT true,
    case_completion_push boolean DEFAULT false,
    case_completion_websocket boolean DEFAULT true,
    case_revocation_enabled boolean DEFAULT true,
    case_revocation_push boolean DEFAULT false,
    case_revocation_websocket boolean DEFAULT true,
    system_notifications_enabled boolean DEFAULT true,
    system_notifications_push boolean DEFAULT true,
    system_notifications_websocket boolean DEFAULT true,
    quiet_hours_enabled boolean DEFAULT false,
    quiet_hours_start time without time zone DEFAULT '22:00:00'::time without time zone,
    quiet_hours_end time without time zone DEFAULT '08:00:00'::time without time zone,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


--
-- Name: notification_tokens; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.notification_tokens (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    device_id character varying(255) NOT NULL,
    platform character varying(20) NOT NULL,
    push_token text NOT NULL,
    is_active boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    last_used_at timestamp with time zone DEFAULT now(),
    CONSTRAINT notification_tokens_platform_check CHECK (((platform)::text = ANY (ARRAY[('ios'::character varying)::text, ('android'::character varying)::text, ('web'::character varying)::text, ('IOS'::character varying)::text, ('ANDROID'::character varying)::text, ('WEB'::character varying)::text])))
);


--
-- Name: notifications; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.notifications (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    title character varying(255) NOT NULL,
    message text NOT NULL,
    type character varying(50) NOT NULL,
    case_id uuid,
    case_number character varying(50),
    data jsonb DEFAULT '{}'::jsonb,
    action_url character varying(500),
    action_type character varying(50) DEFAULT 'NAVIGATE'::character varying,
    is_read boolean DEFAULT false,
    read_at timestamp with time zone,
    delivery_status character varying(20) DEFAULT 'PENDING'::character varying,
    sent_at timestamp with time zone,
    delivered_at timestamp with time zone,
    acknowledged_at timestamp with time zone,
    priority character varying(20) DEFAULT 'MEDIUM'::character varying,
    expires_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    task_id uuid,
    task_number character varying(20),
    CONSTRAINT notifications_delivery_status_check CHECK (((delivery_status)::text = ANY (ARRAY[('PENDING'::character varying)::text, ('SENT'::character varying)::text, ('DELIVERED'::character varying)::text, ('FAILED'::character varying)::text, ('ACKNOWLEDGED'::character varying)::text]))),
    CONSTRAINT notifications_priority_check CHECK (((priority)::text = ANY (ARRAY[('LOW'::character varying)::text, ('MEDIUM'::character varying)::text, ('HIGH'::character varying)::text, ('URGENT'::character varying)::text]))),
    CONSTRAINT notifications_type_check CHECK (((type)::text = ANY (ARRAY[('CASE_ASSIGNED'::character varying)::text, ('CASE_REASSIGNED'::character varying)::text, ('CASE_REMOVED'::character varying)::text, ('CASE_COMPLETED'::character varying)::text, ('CASE_REVOKED'::character varying)::text, ('TASK_REVOKED'::character varying)::text, ('TASK_COMPLETED'::character varying)::text, ('CASE_APPROVED'::character varying)::text, ('CASE_REJECTED'::character varying)::text, ('SYSTEM_MAINTENANCE'::character varying)::text, ('APP_UPDATE'::character varying)::text, ('EMERGENCY_ALERT'::character varying)::text, ('TEST'::character varying)::text])))
);


--
-- Name: COLUMN notifications.task_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.notifications.task_id IS 'Reference to specific verification task (for task-level notifications)';


--
-- Name: COLUMN notifications.task_number; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.notifications.task_number IS 'Human-readable task number for display in notifications';


--
-- Name: officeVerificationReports; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."officeVerificationReports" (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    case_id uuid NOT NULL,
    "caseId" integer,
    form_type character varying(50) DEFAULT 'POSITIVE'::character varying NOT NULL,
    verification_outcome character varying(50) NOT NULL,
    customer_name character varying(255),
    customer_phone character varying(20),
    customer_email character varying(255),
    address_locatable character varying(50),
    address_rating character varying(50),
    full_address text,
    locality character varying(100),
    address_structure character varying(100),
    address_floor character varying(50),
    address_structure_color character varying(50),
    door_color character varying(50),
    company_nameplate_status character varying(50),
    name_on_company_board character varying(255),
    landmark1 character varying(255),
    landmark2 character varying(255),
    office_status character varying(50),
    office_existence character varying(50),
    office_type character varying(50),
    company_nature_of_business character varying(255),
    business_period character varying(100),
    establishment_period character varying(100),
    office_approx_area integer,
    staff_strength integer,
    staff_seen integer,
    met_person_name character varying(255),
    designation character varying(100),
    applicant_designation character varying(100),
    working_period character varying(100),
    working_status character varying(50),
    applicant_working_premises character varying(50),
    sitting_location character varying(255),
    current_company_name character varying(255),
    document_shown character varying(255),
    tpc_met_person1 character varying(50),
    tpc_name1 character varying(255),
    tpc_confirmation1 character varying(50),
    tpc_met_person2 character varying(50),
    tpc_name2 character varying(255),
    tpc_confirmation2 character varying(50),
    shifted_period character varying(100),
    old_office_shifted_period character varying(100),
    current_company_period character varying(100),
    premises_status character varying(50),
    name_of_met_person character varying(255),
    met_person_type character varying(50),
    met_person_confirmation character varying(50),
    applicant_working_status character varying(50),
    contact_person character varying(255),
    call_remark character varying(50),
    political_connection character varying(100),
    dominated_area character varying(100),
    feedback_from_neighbour character varying(100),
    other_observation text,
    other_extra_remark text,
    final_status character varying(50) NOT NULL,
    hold_reason text,
    recommendation_status character varying(50),
    verification_date date DEFAULT CURRENT_DATE NOT NULL,
    verification_time time without time zone DEFAULT CURRENT_TIME NOT NULL,
    verified_by uuid NOT NULL,
    remarks text,
    total_images integer DEFAULT 0,
    total_selfies integer DEFAULT 0,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    landmark3 text,
    landmark4 text,
    document_type text,
    name_of_tpc1 text,
    name_of_tpc2 text,
    verification_task_id uuid,
    report_sha256_hash text,
    report_server_signature text,
    report_generated_at timestamp with time zone,
    is_final boolean DEFAULT false,
    CONSTRAINT chk_office_verification_final_status CHECK (((final_status)::text = ANY (ARRAY[('Positive'::character varying)::text, ('Negative'::character varying)::text, ('Refer'::character varying)::text, ('Fraud'::character varying)::text, ('Hold'::character varying)::text]))),
    CONSTRAINT chk_office_verification_form_type CHECK (((form_type)::text = ANY (ARRAY[('POSITIVE'::character varying)::text, ('SHIFTED'::character varying)::text, ('NSP'::character varying)::text, ('ENTRY_RESTRICTED'::character varying)::text, ('UNTRACEABLE'::character varying)::text]))),
    CONSTRAINT chk_office_verification_office_area CHECK (((office_approx_area IS NULL) OR ((office_approx_area >= 1) AND (office_approx_area <= 100000)))),
    CONSTRAINT chk_office_verification_staff_seen CHECK (((staff_seen IS NULL) OR ((staff_seen >= 0) AND (staff_seen <= staff_strength)))),
    CONSTRAINT chk_office_verification_staff_strength CHECK (((staff_strength IS NULL) OR ((staff_strength >= 1) AND (staff_strength <= 10000))))
);


--
-- Name: TABLE "officeVerificationReports"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public."officeVerificationReports" IS 'Comprehensive table for storing office verification form data from mobile app submissions';


--
-- Name: COLUMN "officeVerificationReports".case_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."officeVerificationReports".case_id IS 'UUID reference to the case being verified';


--
-- Name: COLUMN "officeVerificationReports".form_type; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."officeVerificationReports".form_type IS 'Type of office verification form: POSITIVE, SHIFTED, NSP, ENTRY_RESTRICTED, UNTRACEABLE';


--
-- Name: COLUMN "officeVerificationReports".verification_outcome; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."officeVerificationReports".verification_outcome IS 'Maps to verification outcome from case (Positive & Door Locked, Shifted & Door Lock, etc.)';


--
-- Name: COLUMN "officeVerificationReports".verified_by; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."officeVerificationReports".verified_by IS 'UUID of the field agent who performed the verification';


--
-- Name: COLUMN "officeVerificationReports".verification_task_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."officeVerificationReports".verification_task_id IS 'Links office verification report to specific verification task';


--
-- Name: COLUMN "officeVerificationReports".report_sha256_hash; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."officeVerificationReports".report_sha256_hash IS 'SHA-256 hash of generated PDF report for tamper detection.';


--
-- Name: COLUMN "officeVerificationReports".report_server_signature; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."officeVerificationReports".report_server_signature IS 'HMAC-SHA256 signature of PDF. Prevents report regeneration attacks.';


--
-- Name: COLUMN "officeVerificationReports".is_final; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."officeVerificationReports".is_final IS 'TRUE = report is finalized and cannot be regenerated. Bank audit requirement.';


--
-- Name: performance_metrics; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.performance_metrics (
    id bigint NOT NULL,
    request_id character varying(255) NOT NULL,
    method character varying(10) NOT NULL,
    url text NOT NULL,
    status_code integer NOT NULL,
    response_time numeric(10,2) NOT NULL,
    memory_usage jsonb,
    user_id uuid,
    "timestamp" timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: TABLE performance_metrics; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.performance_metrics IS 'Stores HTTP request performance metrics for monitoring';


--
-- Name: performance_metrics_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.performance_metrics_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: performance_metrics_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.performance_metrics_id_seq OWNED BY public.performance_metrics.id;


--
-- Name: performance_trends; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.performance_trends AS
 SELECT date_trunc('hour'::text, "timestamp") AS hour,
    avg(response_time) AS avg_response_time,
    max(response_time) AS max_response_time,
    count(*) AS request_count,
    count(
        CASE
            WHEN (status_code >= 400) THEN 1
            ELSE NULL::integer
        END) AS error_count
   FROM public.performance_metrics
  WHERE ("timestamp" > (now() - '24:00:00'::interval))
  GROUP BY (date_trunc('hour'::text, "timestamp"))
  ORDER BY (date_trunc('hour'::text, "timestamp"));


--
-- Name: permissions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.permissions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    code character varying(100) NOT NULL,
    module character varying(50) NOT NULL,
    description text
);


--
-- Name: pincodeAreas; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."pincodeAreas" (
    "displayOrder" integer DEFAULT 1,
    "createdAt" timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    id integer NOT NULL,
    "pincodeId" integer,
    "areaId" integer,
    CONSTRAINT chk_pincode_areas_display_order CHECK ((("displayOrder" >= 1) AND ("displayOrder" <= 50)))
);


--
-- Name: TABLE "pincodeAreas"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public."pincodeAreas" IS 'Junction table linking pincodes with specific areas for granular rate configuration';


--
-- Name: COLUMN "pincodeAreas"."displayOrder"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."pincodeAreas"."displayOrder" IS 'Order for displaying areas (1-50)';


--
-- Name: pincodeAreas_temp_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public."pincodeAreas_temp_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: pincodeAreas_temp_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public."pincodeAreas_temp_id_seq" OWNED BY public."pincodeAreas".id;


--
-- Name: pincodes_temp_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.pincodes_temp_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: pincodes_temp_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.pincodes_temp_id_seq OWNED BY public.pincodes.id;


--
-- Name: productDocumentTypes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."productDocumentTypes" (
    id integer NOT NULL,
    "productId" integer NOT NULL,
    "documentTypeId" integer NOT NULL,
    is_mandatory boolean DEFAULT false,
    is_active boolean DEFAULT true,
    display_order integer DEFAULT 0,
    created_by uuid,
    updated_by uuid,
    "createdAt" timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: TABLE "productDocumentTypes"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public."productDocumentTypes" IS 'Junction table mapping document types to products';


--
-- Name: productDocumentTypes_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public."productDocumentTypes_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: productDocumentTypes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public."productDocumentTypes_id_seq" OWNED BY public."productDocumentTypes".id;


--
-- Name: productVerificationTypes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."productVerificationTypes" (
    "isActive" boolean DEFAULT true,
    "createdAt" timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    id integer NOT NULL,
    "productId" integer,
    "verificationTypeId" integer
);


--
-- Name: TABLE "productVerificationTypes"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public."productVerificationTypes" IS 'Junction table linking products with their available verification types';


--
-- Name: productVerificationTypes_temp_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public."productVerificationTypes_temp_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: productVerificationTypes_temp_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public."productVerificationTypes_temp_id_seq" OWNED BY public."productVerificationTypes".id;


--
-- Name: products_temp_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.products_temp_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: products_temp_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.products_temp_id_seq OWNED BY public.products.id;


--
-- Name: propertyApfVerificationReports; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."propertyApfVerificationReports" (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    case_id uuid NOT NULL,
    "caseId" integer,
    form_type character varying(50) DEFAULT 'POSITIVE'::character varying NOT NULL,
    verification_outcome character varying(50) NOT NULL,
    customer_name character varying(255),
    customer_phone character varying(20),
    customer_email character varying(255),
    address_locatable character varying(50),
    address_rating character varying(50),
    full_address text,
    locality character varying(100),
    address_structure character varying(100),
    address_floor character varying(50),
    address_structure_color character varying(50),
    door_color character varying(50),
    landmark1 character varying(255),
    landmark2 character varying(255),
    landmark3 character varying(255),
    landmark4 character varying(255),
    property_type character varying(100),
    property_status character varying(50),
    property_ownership character varying(50),
    property_age integer,
    property_condition character varying(50),
    property_area numeric(10,2),
    property_value numeric(15,2),
    market_value numeric(15,2),
    apf_status character varying(50),
    apf_number character varying(100),
    apf_issue_date date,
    apf_expiry_date date,
    apf_issuing_authority character varying(255),
    apf_validity_status character varying(50),
    apf_amount numeric(15,2),
    apf_utilized_amount numeric(15,2),
    apf_balance_amount numeric(15,2),
    project_name character varying(255),
    project_status character varying(50),
    project_approval_status character varying(50),
    project_completion_percentage integer,
    total_units integer,
    completed_units integer,
    sold_units integer,
    available_units integer,
    possession_status character varying(50),
    builder_name character varying(255),
    builder_contact character varying(20),
    developer_name character varying(255),
    developer_contact character varying(20),
    builder_registration_number character varying(100),
    rera_registration_number character varying(100),
    loan_amount numeric(15,2),
    loan_purpose character varying(255),
    loan_status character varying(50),
    bank_name character varying(255),
    loan_account_number character varying(50),
    emi_amount numeric(10,2),
    met_person_name character varying(255),
    met_person_designation character varying(100),
    met_person_relation character varying(100),
    met_person_contact character varying(20),
    document_shown_status character varying(50),
    document_type character varying(255),
    document_verification_status character varying(50),
    tpc_met_person1 character varying(50),
    tpc_name1 character varying(255),
    tpc_confirmation1 character varying(50),
    tpc_met_person2 character varying(50),
    tpc_name2 character varying(255),
    tpc_confirmation2 character varying(50),
    shifted_period character varying(100),
    current_location character varying(255),
    premises_status character varying(50),
    entry_restriction_reason character varying(255),
    security_person_name character varying(255),
    security_confirmation character varying(50),
    contact_person character varying(255),
    call_remark character varying(50),
    legal_clearance character varying(50),
    title_clearance character varying(50),
    encumbrance_status character varying(50),
    litigation_status character varying(50),
    political_connection character varying(100),
    dominated_area character varying(100),
    feedback_from_neighbour character varying(100),
    infrastructure_status character varying(100),
    road_connectivity character varying(100),
    other_observation text,
    property_concerns text,
    financial_concerns text,
    final_status character varying(50) NOT NULL,
    hold_reason text,
    recommendation_status character varying(50),
    verification_date date DEFAULT CURRENT_DATE NOT NULL,
    verification_time time without time zone DEFAULT CURRENT_TIME NOT NULL,
    verified_by uuid NOT NULL,
    remarks text,
    total_images integer DEFAULT 0,
    total_selfies integer DEFAULT 0,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    building_status character varying(50),
    name_of_met_person character varying(255),
    met_person_confirmation character varying(50),
    construction_activity character varying(50),
    designation character varying(100),
    activity_stop_reason text,
    project_started_date date,
    project_completion_date date,
    total_wing integer,
    total_flats integer,
    staff_strength integer,
    staff_seen integer,
    company_name_board character varying(50),
    name_on_board character varying(255),
    total_buildings_in_project integer,
    total_flats_in_building integer,
    project_start_date date,
    project_end_date date,
    verification_task_id uuid,
    report_sha256_hash text,
    report_server_signature text,
    report_generated_at timestamp with time zone,
    is_final boolean DEFAULT false,
    CONSTRAINT chk_property_apf_verification_completed_units CHECK (((completed_units IS NULL) OR ((completed_units >= 0) AND (completed_units <= total_units)))),
    CONSTRAINT chk_property_apf_verification_completion_percentage CHECK (((project_completion_percentage IS NULL) OR ((project_completion_percentage >= 0) AND (project_completion_percentage <= 100)))),
    CONSTRAINT chk_property_apf_verification_final_status CHECK (((final_status)::text = ANY (ARRAY[('Positive'::character varying)::text, ('Negative'::character varying)::text, ('Refer'::character varying)::text, ('Fraud'::character varying)::text, ('Hold'::character varying)::text]))),
    CONSTRAINT chk_property_apf_verification_form_type CHECK (((form_type)::text = ANY (ARRAY[('POSITIVE'::character varying)::text, ('SHIFTED'::character varying)::text, ('NSP'::character varying)::text, ('ENTRY_RESTRICTED'::character varying)::text, ('UNTRACEABLE'::character varying)::text]))),
    CONSTRAINT chk_property_apf_verification_property_age CHECK (((property_age IS NULL) OR ((property_age >= 0) AND (property_age <= 100)))),
    CONSTRAINT chk_property_apf_verification_total_units CHECK (((total_units IS NULL) OR ((total_units >= 1) AND (total_units <= 10000))))
);


--
-- Name: TABLE "propertyApfVerificationReports"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public."propertyApfVerificationReports" IS 'Comprehensive table for storing Property APF verification form data from mobile app submissions';


--
-- Name: COLUMN "propertyApfVerificationReports".case_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."propertyApfVerificationReports".case_id IS 'UUID reference to the case being verified';


--
-- Name: COLUMN "propertyApfVerificationReports".form_type; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."propertyApfVerificationReports".form_type IS 'Type of Property APF verification form: POSITIVE, SHIFTED, NSP, ENTRY_RESTRICTED, UNTRACEABLE';


--
-- Name: COLUMN "propertyApfVerificationReports".verification_outcome; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."propertyApfVerificationReports".verification_outcome IS 'Maps to verification outcome from case (Positive & Door Locked, Shifted & Door Lock, etc.)';


--
-- Name: COLUMN "propertyApfVerificationReports".verified_by; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."propertyApfVerificationReports".verified_by IS 'UUID of the field agent who performed the verification';


--
-- Name: COLUMN "propertyApfVerificationReports".verification_task_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."propertyApfVerificationReports".verification_task_id IS 'Links property APF verification report to specific verification task';


--
-- Name: COLUMN "propertyApfVerificationReports".report_sha256_hash; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."propertyApfVerificationReports".report_sha256_hash IS 'SHA-256 hash of generated PDF report for tamper detection.';


--
-- Name: COLUMN "propertyApfVerificationReports".report_server_signature; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."propertyApfVerificationReports".report_server_signature IS 'HMAC-SHA256 signature of PDF. Prevents report regeneration attacks.';


--
-- Name: COLUMN "propertyApfVerificationReports".is_final; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."propertyApfVerificationReports".is_final IS 'TRUE = report is finalized and cannot be regenerated. Bank audit requirement.';


--
-- Name: propertyIndividualVerificationReports; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."propertyIndividualVerificationReports" (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    case_id uuid NOT NULL,
    "caseId" integer,
    form_type character varying(50) DEFAULT 'POSITIVE'::character varying NOT NULL,
    verification_outcome character varying(50) NOT NULL,
    customer_name character varying(255),
    customer_phone character varying(20),
    customer_email character varying(255),
    address_locatable character varying(50),
    address_rating character varying(50),
    full_address text,
    locality character varying(100),
    address_structure character varying(100),
    address_floor character varying(50),
    address_structure_color character varying(50),
    door_color character varying(50),
    landmark1 character varying(255),
    landmark2 character varying(255),
    landmark3 character varying(255),
    landmark4 character varying(255),
    property_type character varying(100),
    property_status character varying(50),
    property_ownership character varying(50),
    property_age integer,
    property_condition character varying(50),
    property_area numeric(10,2),
    property_value numeric(15,2),
    market_value numeric(15,2),
    construction_type character varying(100),
    owner_name character varying(255),
    owner_relation character varying(100),
    owner_age integer,
    owner_occupation character varying(255),
    owner_income numeric(12,2),
    years_of_residence integer,
    family_members integer,
    earning_members integer,
    property_documents character varying(255),
    document_verification_status character varying(50),
    title_clear_status character varying(50),
    mutation_status character varying(50),
    tax_payment_status character varying(50),
    met_person_name character varying(255),
    met_person_designation character varying(100),
    met_person_relation character varying(100),
    met_person_contact character varying(20),
    neighbor1_name character varying(255),
    neighbor1_confirmation character varying(50),
    neighbor2_name character varying(255),
    neighbor2_confirmation character varying(50),
    locality_reputation character varying(100),
    tpc_met_person1 character varying(50),
    tpc_name1 character varying(255),
    tpc_confirmation1 character varying(50),
    tpc_met_person2 character varying(50),
    tpc_name2 character varying(255),
    tpc_confirmation2 character varying(50),
    shifted_period character varying(100),
    current_location character varying(255),
    premises_status character varying(50),
    previous_owner_name character varying(255),
    entry_restriction_reason character varying(255),
    security_person_name character varying(255),
    security_confirmation character varying(50),
    contact_person character varying(255),
    call_remark character varying(50),
    legal_issues character varying(50),
    loan_against_property character varying(50),
    bank_name character varying(255),
    loan_amount numeric(15,2),
    emi_amount numeric(10,2),
    electricity_connection character varying(50),
    water_connection character varying(50),
    gas_connection character varying(50),
    internet_connection character varying(50),
    road_connectivity character varying(100),
    public_transport character varying(100),
    political_connection character varying(100),
    dominated_area character varying(100),
    feedback_from_neighbour character varying(100),
    infrastructure_status character varying(100),
    safety_security character varying(100),
    other_observation text,
    property_concerns text,
    verification_challenges text,
    final_status character varying(50) NOT NULL,
    hold_reason text,
    recommendation_status character varying(50),
    verification_date date DEFAULT CURRENT_DATE NOT NULL,
    verification_time time without time zone DEFAULT CURRENT_TIME NOT NULL,
    verified_by uuid NOT NULL,
    remarks text,
    total_images integer DEFAULT 0,
    total_selfies integer DEFAULT 0,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    property_location character varying(255),
    property_description text,
    construction_year integer,
    renovation_year integer,
    property_amenities text,
    individual_name character varying(255),
    individual_age integer,
    individual_occupation character varying(100),
    individual_income numeric(15,2),
    individual_education character varying(100),
    individual_marital_status character varying(50),
    individual_experience integer,
    employment_type character varying(100),
    employer_name character varying(255),
    employment_duration integer,
    monthly_income numeric(15,2),
    annual_income numeric(15,2),
    income_source character varying(100),
    business_name character varying(255),
    business_type character varying(100),
    business_experience integer,
    business_income numeric(15,2),
    verification_task_id uuid,
    report_sha256_hash text,
    report_server_signature text,
    report_generated_at timestamp with time zone,
    is_final boolean DEFAULT false,
    CONSTRAINT chk_property_individual_verification_earning_members CHECK (((earning_members IS NULL) OR ((earning_members >= 0) AND (earning_members <= family_members)))),
    CONSTRAINT chk_property_individual_verification_family_members CHECK (((family_members IS NULL) OR ((family_members >= 1) AND (family_members <= 50)))),
    CONSTRAINT chk_property_individual_verification_final_status CHECK (((final_status)::text = ANY (ARRAY[('Positive'::character varying)::text, ('Negative'::character varying)::text, ('Refer'::character varying)::text, ('Fraud'::character varying)::text, ('Hold'::character varying)::text]))),
    CONSTRAINT chk_property_individual_verification_form_type CHECK (((form_type)::text = ANY (ARRAY[('POSITIVE'::character varying)::text, ('SHIFTED'::character varying)::text, ('NSP'::character varying)::text, ('ENTRY_RESTRICTED'::character varying)::text, ('UNTRACEABLE'::character varying)::text]))),
    CONSTRAINT chk_property_individual_verification_owner_age CHECK (((owner_age IS NULL) OR ((owner_age >= 18) AND (owner_age <= 120)))),
    CONSTRAINT chk_property_individual_verification_property_age CHECK (((property_age IS NULL) OR ((property_age >= 0) AND (property_age <= 200))))
);


--
-- Name: TABLE "propertyIndividualVerificationReports"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public."propertyIndividualVerificationReports" IS 'Comprehensive table for storing Property Individual verification form data from mobile app submissions';


--
-- Name: COLUMN "propertyIndividualVerificationReports".case_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."propertyIndividualVerificationReports".case_id IS 'UUID reference to the case being verified';


--
-- Name: COLUMN "propertyIndividualVerificationReports".form_type; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."propertyIndividualVerificationReports".form_type IS 'Type of Property Individual verification form: POSITIVE, SHIFTED, NSP, ENTRY_RESTRICTED, UNTRACEABLE';


--
-- Name: COLUMN "propertyIndividualVerificationReports".verification_outcome; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."propertyIndividualVerificationReports".verification_outcome IS 'Maps to verification outcome from case (Positive & Door Locked, Shifted & Door Lock, etc.)';


--
-- Name: COLUMN "propertyIndividualVerificationReports".verified_by; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."propertyIndividualVerificationReports".verified_by IS 'UUID of the field agent who performed the verification';


--
-- Name: COLUMN "propertyIndividualVerificationReports".verification_task_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."propertyIndividualVerificationReports".verification_task_id IS 'Links property individual verification report to specific verification task';


--
-- Name: COLUMN "propertyIndividualVerificationReports".report_sha256_hash; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."propertyIndividualVerificationReports".report_sha256_hash IS 'SHA-256 hash of generated PDF report for tamper detection.';


--
-- Name: COLUMN "propertyIndividualVerificationReports".report_server_signature; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."propertyIndividualVerificationReports".report_server_signature IS 'HMAC-SHA256 signature of PDF. Prevents report regeneration attacks.';


--
-- Name: COLUMN "propertyIndividualVerificationReports".is_final; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."propertyIndividualVerificationReports".is_final IS 'TRUE = report is finalized and cannot be regenerated. Bank audit requirement.';


--
-- Name: query_performance; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.query_performance (
    id bigint NOT NULL,
    query_hash character varying(64) NOT NULL,
    query_text text NOT NULL,
    execution_time numeric(10,2) NOT NULL,
    rows_returned integer,
    rows_examined integer,
    query_plan jsonb,
    "timestamp" timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: TABLE query_performance; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.query_performance IS 'Stores database query performance data for optimization';


--
-- Name: query_performance_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.query_performance_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: query_performance_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.query_performance_id_seq OWNED BY public.query_performance.id;


--
-- Name: rateHistory; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."rateHistory" (
    "oldAmount" numeric(10,2),
    "newAmount" numeric(10,2) NOT NULL,
    "changeReason" text,
    "changedBy" uuid,
    "changedAt" timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    id bigint NOT NULL,
    "rateId" bigint
);


--
-- Name: TABLE "rateHistory"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public."rateHistory" IS 'Audit trail for rate changes';


--
-- Name: rateHistory_temp_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public."rateHistory_temp_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: rateHistory_temp_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public."rateHistory_temp_id_seq" OWNED BY public."rateHistory".id;


--
-- Name: rateTypes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."rateTypes" (
    name character varying(100) NOT NULL,
    description text,
    "isActive" boolean DEFAULT true,
    "createdAt" timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    id integer NOT NULL
);


--
-- Name: TABLE "rateTypes"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public."rateTypes" IS 'Rate types for verification services (Local, Local1, Local2, OGL, OGL1, OGL2, Outstation)';


--
-- Name: rates; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.rates (
    amount numeric(10,2) NOT NULL,
    currency character varying(3) DEFAULT 'INR'::character varying,
    "isActive" boolean DEFAULT true,
    "effectiveFrom" timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    "effectiveTo" timestamp with time zone,
    "createdBy" uuid,
    "createdAt" timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    id bigint NOT NULL,
    "clientId" integer,
    "productId" integer,
    "verificationTypeId" integer,
    "rateTypeId" integer,
    CONSTRAINT rates_amount_check CHECK ((amount >= (0)::numeric))
);


--
-- Name: TABLE rates; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.rates IS 'Actual rate amounts for assigned rate types';


--
-- Name: rateManagementView; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public."rateManagementView" AS
 SELECT r.id,
    r."clientId",
    c.name AS "clientName",
    c.code AS "clientCode",
    r."productId",
    p.name AS "productName",
    p.code AS "productCode",
    r."verificationTypeId",
    vt.name AS "verificationTypeName",
    vt.code AS "verificationTypeCode",
    r."rateTypeId",
    rt.name AS "rateTypeName",
    r.amount,
    r.currency,
    r."isActive",
    r."effectiveFrom",
    r."effectiveTo",
    r."createdAt",
    r."updatedAt"
   FROM ((((public.rates r
     JOIN public.clients c ON ((r."clientId" = c.id)))
     JOIN public.products p ON ((r."productId" = p.id)))
     JOIN public."verificationTypes" vt ON ((r."verificationTypeId" = vt.id)))
     JOIN public."rateTypes" rt ON ((r."rateTypeId" = rt.id)));


--
-- Name: rateTypeAssignments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."rateTypeAssignments" (
    "isActive" boolean DEFAULT true,
    "createdAt" timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    id bigint NOT NULL,
    "clientId" integer,
    "productId" integer,
    "verificationTypeId" integer,
    "rateTypeId" integer
);


--
-- Name: TABLE "rateTypeAssignments"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public."rateTypeAssignments" IS 'Assignment of rate types to client-product-verification type combinations';


--
-- Name: rateTypeAssignmentView; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public."rateTypeAssignmentView" AS
 SELECT rta.id,
    rta."clientId",
    c.name AS "clientName",
    c.code AS "clientCode",
    rta."productId",
    p.name AS "productName",
    p.code AS "productCode",
    rta."verificationTypeId",
    vt.name AS "verificationTypeName",
    vt.code AS "verificationTypeCode",
    rta."rateTypeId",
    rt.name AS "rateTypeName",
    rta."isActive",
    rta."createdAt",
    rta."updatedAt"
   FROM ((((public."rateTypeAssignments" rta
     JOIN public.clients c ON ((rta."clientId" = c.id)))
     JOIN public.products p ON ((rta."productId" = p.id)))
     JOIN public."verificationTypes" vt ON ((rta."verificationTypeId" = vt.id)))
     JOIN public."rateTypes" rt ON ((rta."rateTypeId" = rt.id)));


--
-- Name: rateTypeAssignments_temp_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public."rateTypeAssignments_temp_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: rateTypeAssignments_temp_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public."rateTypeAssignments_temp_id_seq" OWNED BY public."rateTypeAssignments".id;


--
-- Name: rateTypes_temp_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public."rateTypes_temp_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: rateTypes_temp_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public."rateTypes_temp_id_seq" OWNED BY public."rateTypes".id;


--
-- Name: rates_temp_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.rates_temp_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: rates_temp_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.rates_temp_id_seq OWNED BY public.rates.id;


--
-- Name: refreshTokens; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."refreshTokens" (
    "userId" uuid NOT NULL,
    token character varying(500) NOT NULL,
    "expiresAt" timestamp with time zone NOT NULL,
    "createdAt" timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    id bigint NOT NULL,
    "ipAddress" character varying(50),
    "userAgent" text
);


--
-- Name: refreshTokens_temp_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public."refreshTokens_temp_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: refreshTokens_temp_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public."refreshTokens_temp_id_seq" OWNED BY public."refreshTokens".id;


--
-- Name: residenceCumOfficeVerificationReports; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."residenceCumOfficeVerificationReports" (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    case_id uuid NOT NULL,
    "caseId" integer,
    form_type character varying(50) DEFAULT 'POSITIVE'::character varying NOT NULL,
    verification_outcome character varying(50) NOT NULL,
    customer_name character varying(255),
    customer_phone character varying(20),
    customer_email character varying(255),
    address_locatable character varying(50),
    address_rating character varying(50),
    full_address text,
    locality character varying(100),
    address_structure character varying(100),
    address_floor character varying(50),
    address_structure_color character varying(50),
    door_color character varying(50),
    company_nameplate_status character varying(50),
    name_on_company_board character varying(255),
    door_nameplate_status character varying(50),
    name_on_door_plate character varying(255),
    society_nameplate_status character varying(50),
    name_on_society_board character varying(255),
    landmark1 character varying(255),
    landmark2 character varying(255),
    landmark3 character varying(255),
    landmark4 character varying(255),
    house_status character varying(50),
    met_person_name character varying(255),
    met_person_relation character varying(100),
    total_family_members integer,
    total_earning integer,
    applicant_dob date,
    applicant_age integer,
    staying_period character varying(100),
    staying_status character varying(50),
    approx_area integer,
    document_shown_status character varying(50),
    document_type character varying(255),
    office_status character varying(50),
    office_existence character varying(50),
    office_type character varying(50),
    designation character varying(100),
    applicant_designation character varying(100),
    working_period character varying(100),
    working_status character varying(50),
    applicant_working_premises character varying(50),
    sitting_location character varying(255),
    current_company_name character varying(255),
    company_nature_of_business character varying(255),
    business_period character varying(100),
    establishment_period character varying(100),
    staff_strength integer,
    staff_seen integer,
    tpc_met_person1 character varying(50),
    tpc_name1 character varying(255),
    tpc_confirmation1 character varying(50),
    tpc_met_person2 character varying(50),
    tpc_name2 character varying(255),
    tpc_confirmation2 character varying(50),
    shifted_period character varying(100),
    old_office_shifted_period character varying(100),
    current_company_period character varying(100),
    premises_status character varying(50),
    name_of_met_person character varying(255),
    met_person_type character varying(50),
    met_person_confirmation character varying(50),
    applicant_working_status character varying(50),
    applicant_staying_status character varying(50),
    contact_person character varying(255),
    call_remark character varying(50),
    political_connection character varying(100),
    dominated_area character varying(100),
    feedback_from_neighbour character varying(100),
    other_observation text,
    other_extra_remark text,
    final_status character varying(50) NOT NULL,
    hold_reason text,
    recommendation_status character varying(50),
    verification_date date DEFAULT CURRENT_DATE NOT NULL,
    verification_time time without time zone DEFAULT CURRENT_TIME NOT NULL,
    verified_by uuid NOT NULL,
    remarks text,
    total_images integer DEFAULT 0,
    total_selfies integer DEFAULT 0,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    staying_person_name character varying(255),
    verification_task_id uuid,
    report_sha256_hash text,
    report_server_signature text,
    report_generated_at timestamp with time zone,
    is_final boolean DEFAULT false,
    CONSTRAINT chk_res_cum_office_verification_approx_area CHECK (((approx_area IS NULL) OR ((approx_area >= 1) AND (approx_area <= 100000)))),
    CONSTRAINT chk_res_cum_office_verification_family_members CHECK (((total_family_members IS NULL) OR ((total_family_members >= 1) AND (total_family_members <= 50)))),
    CONSTRAINT chk_res_cum_office_verification_final_status CHECK (((final_status)::text = ANY (ARRAY[('Positive'::character varying)::text, ('Negative'::character varying)::text, ('Refer'::character varying)::text, ('Fraud'::character varying)::text, ('Hold'::character varying)::text]))),
    CONSTRAINT chk_res_cum_office_verification_form_type CHECK (((form_type)::text = ANY (ARRAY[('POSITIVE'::character varying)::text, ('SHIFTED'::character varying)::text, ('NSP'::character varying)::text, ('ENTRY_RESTRICTED'::character varying)::text, ('UNTRACEABLE'::character varying)::text]))),
    CONSTRAINT chk_res_cum_office_verification_staff_seen CHECK (((staff_seen IS NULL) OR ((staff_seen >= 0) AND (staff_seen <= staff_strength)))),
    CONSTRAINT chk_res_cum_office_verification_staff_strength CHECK (((staff_strength IS NULL) OR ((staff_strength >= 1) AND (staff_strength <= 10000))))
);


--
-- Name: TABLE "residenceCumOfficeVerificationReports"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public."residenceCumOfficeVerificationReports" IS 'Comprehensive table for storing residence-cum-office verification form data from mobile app submissions';


--
-- Name: COLUMN "residenceCumOfficeVerificationReports".case_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."residenceCumOfficeVerificationReports".case_id IS 'UUID reference to the case being verified';


--
-- Name: COLUMN "residenceCumOfficeVerificationReports".form_type; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."residenceCumOfficeVerificationReports".form_type IS 'Type of residence-cum-office verification form: POSITIVE, SHIFTED, NSP, ENTRY_RESTRICTED, UNTRACEABLE';


--
-- Name: COLUMN "residenceCumOfficeVerificationReports".verification_outcome; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."residenceCumOfficeVerificationReports".verification_outcome IS 'Maps to verification outcome from case (Positive & Door Locked, Shifted & Door Lock, etc.)';


--
-- Name: COLUMN "residenceCumOfficeVerificationReports".verified_by; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."residenceCumOfficeVerificationReports".verified_by IS 'UUID of the field agent who performed the verification';


--
-- Name: COLUMN "residenceCumOfficeVerificationReports".staying_person_name; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."residenceCumOfficeVerificationReports".staying_person_name IS 'Name of the person staying at the residence (different from met_person_name)';


--
-- Name: COLUMN "residenceCumOfficeVerificationReports".verification_task_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."residenceCumOfficeVerificationReports".verification_task_id IS 'Links residence-cum-office verification report to specific verification task';


--
-- Name: COLUMN "residenceCumOfficeVerificationReports".report_sha256_hash; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."residenceCumOfficeVerificationReports".report_sha256_hash IS 'SHA-256 hash of generated PDF report for tamper detection.';


--
-- Name: COLUMN "residenceCumOfficeVerificationReports".report_server_signature; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."residenceCumOfficeVerificationReports".report_server_signature IS 'HMAC-SHA256 signature of PDF. Prevents report regeneration attacks.';


--
-- Name: COLUMN "residenceCumOfficeVerificationReports".is_final; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."residenceCumOfficeVerificationReports".is_final IS 'TRUE = report is finalized and cannot be regenerated. Bank audit requirement.';


--
-- Name: residenceVerificationReports; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."residenceVerificationReports" (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    case_id uuid NOT NULL,
    "caseId" integer,
    form_type character varying(50) DEFAULT 'POSITIVE'::character varying NOT NULL,
    verification_outcome character varying(50) NOT NULL,
    customer_name character varying(255),
    customer_phone character varying(20),
    customer_email character varying(255),
    address_locatable character varying(50),
    address_rating character varying(50),
    full_address text,
    locality character varying(100),
    address_structure character varying(100),
    address_floor character varying(50),
    address_structure_color character varying(50),
    door_color character varying(50),
    door_nameplate_status character varying(50),
    name_on_door_plate character varying(255),
    society_nameplate_status character varying(50),
    name_on_society_board character varying(255),
    company_nameplate_status character varying(50),
    name_on_company_board character varying(255),
    landmark1 character varying(255),
    landmark2 character varying(255),
    landmark3 character varying(255),
    landmark4 character varying(255),
    house_status character varying(50),
    room_status character varying(50),
    met_person_name character varying(255),
    met_person_relation character varying(50),
    met_person_status character varying(50),
    staying_person_name character varying(255),
    total_family_members integer,
    total_earning numeric(15,2),
    applicant_dob date,
    applicant_age integer,
    working_status character varying(50),
    company_name character varying(255),
    staying_period character varying(100),
    staying_status character varying(50),
    approx_area integer,
    document_shown_status character varying(50),
    document_type character varying(50),
    tpc_met_person1 character varying(50),
    tpc_name1 character varying(255),
    tpc_confirmation1 character varying(50),
    tpc_met_person2 character varying(50),
    tpc_name2 character varying(255),
    tpc_confirmation2 character varying(50),
    shifted_period character varying(100),
    premises_status character varying(50),
    name_of_met_person character varying(255),
    met_person_type character varying(50),
    met_person_confirmation character varying(50),
    applicant_staying_status character varying(50),
    call_remark character varying(50),
    political_connection character varying(100),
    dominated_area character varying(100),
    feedback_from_neighbour character varying(100),
    other_observation text,
    final_status character varying(50) NOT NULL,
    hold_reason text,
    recommendation_status character varying(50),
    verification_date date DEFAULT CURRENT_DATE NOT NULL,
    verification_time time without time zone DEFAULT CURRENT_TIME NOT NULL,
    verified_by uuid NOT NULL,
    remarks text,
    total_images integer DEFAULT 0,
    total_selfies integer DEFAULT 0,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    verification_task_id uuid,
    report_sha256_hash text,
    report_server_signature text,
    report_generated_at timestamp with time zone,
    is_final boolean DEFAULT false,
    CONSTRAINT chk_residence_verification_age CHECK (((applicant_age IS NULL) OR ((applicant_age >= 0) AND (applicant_age <= 120)))),
    CONSTRAINT chk_residence_verification_family_members CHECK (((total_family_members IS NULL) OR ((total_family_members >= 1) AND (total_family_members <= 50)))),
    CONSTRAINT chk_residence_verification_final_status CHECK (((final_status)::text = ANY (ARRAY[('Positive'::character varying)::text, ('Negative'::character varying)::text, ('Refer'::character varying)::text, ('Fraud'::character varying)::text, ('Hold'::character varying)::text]))),
    CONSTRAINT chk_residence_verification_form_type CHECK (((form_type)::text = ANY (ARRAY[('POSITIVE'::character varying)::text, ('SHIFTED'::character varying)::text, ('NSP'::character varying)::text, ('ENTRY_RESTRICTED'::character varying)::text, ('UNTRACEABLE'::character varying)::text])))
);


--
-- Name: TABLE "residenceVerificationReports"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public."residenceVerificationReports" IS 'Comprehensive table for all residence verification form types (Positive, Shifted, NSP, Entry Restricted, Untraceable)';


--
-- Name: COLUMN "residenceVerificationReports".case_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."residenceVerificationReports".case_id IS 'UUID reference to the case being verified';


--
-- Name: COLUMN "residenceVerificationReports"."caseId"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."residenceVerificationReports"."caseId" IS 'Legacy integer case ID for backward compatibility';


--
-- Name: COLUMN "residenceVerificationReports".form_type; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."residenceVerificationReports".form_type IS 'Type of residence verification form: POSITIVE, SHIFTED, NSP, ENTRY_RESTRICTED, UNTRACEABLE';


--
-- Name: COLUMN "residenceVerificationReports".verification_outcome; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."residenceVerificationReports".verification_outcome IS 'Maps to verification outcome from case (Positive & Door Locked, Shifted & Door Lock, etc.)';


--
-- Name: COLUMN "residenceVerificationReports".address_structure; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."residenceVerificationReports".address_structure IS 'Type of address structure (Independent House, Apartment, etc.) - increased from 10 to 100 chars';


--
-- Name: COLUMN "residenceVerificationReports".address_floor; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."residenceVerificationReports".address_floor IS 'Floor information (Ground Floor, 1st Floor, etc.) - increased from 10 to 50 chars';


--
-- Name: COLUMN "residenceVerificationReports".verified_by; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."residenceVerificationReports".verified_by IS 'UUID of the field agent who performed the verification';


--
-- Name: COLUMN "residenceVerificationReports".total_images; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."residenceVerificationReports".total_images IS 'Count of verification images (stored in verification_attachments table)';


--
-- Name: COLUMN "residenceVerificationReports".total_selfies; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."residenceVerificationReports".total_selfies IS 'Count of selfie images (stored in verification_attachments table)';


--
-- Name: COLUMN "residenceVerificationReports".verification_task_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."residenceVerificationReports".verification_task_id IS 'Links residence verification report to specific verification task';


--
-- Name: COLUMN "residenceVerificationReports".report_sha256_hash; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."residenceVerificationReports".report_sha256_hash IS 'SHA-256 hash of generated PDF report for tamper detection.';


--
-- Name: COLUMN "residenceVerificationReports".report_server_signature; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."residenceVerificationReports".report_server_signature IS 'HMAC-SHA256 signature of PDF. Prevents report regeneration attacks.';


--
-- Name: COLUMN "residenceVerificationReports".is_final; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."residenceVerificationReports".is_final IS 'TRUE = report is finalized and cannot be regenerated. Bank audit requirement.';


--
-- Name: role_permissions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.role_permissions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    role_id uuid NOT NULL,
    permission_id uuid NOT NULL,
    allowed boolean DEFAULT true NOT NULL
);


--
-- Name: role_routes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.role_routes (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    role_id uuid NOT NULL,
    route_key character varying(100) NOT NULL,
    allowed boolean DEFAULT true NOT NULL
);


--
-- Name: roles_v2; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.roles_v2 (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name character varying(100) NOT NULL,
    description text,
    parent_role_id uuid,
    is_system boolean DEFAULT false NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: scheduled_reports; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.scheduled_reports (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name character varying(255) NOT NULL,
    report_type character varying(50) NOT NULL,
    format character varying(20) NOT NULL,
    frequency character varying(20) NOT NULL,
    recipients jsonb DEFAULT '[]'::jsonb NOT NULL,
    filters jsonb DEFAULT '{}'::jsonb,
    options jsonb DEFAULT '{}'::jsonb,
    is_active boolean DEFAULT true,
    created_by uuid NOT NULL,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now(),
    last_run timestamp without time zone,
    next_run timestamp without time zone
);


--
-- Name: schema_migrations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.schema_migrations (
    id character varying(255) NOT NULL,
    filename character varying(255) NOT NULL,
    executed_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    checksum character varying(64) NOT NULL,
    execution_time_ms integer,
    success boolean DEFAULT true
);


--
-- Name: schema_migrations_legacy_archive; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.schema_migrations_legacy_archive (
    id character varying(255) NOT NULL,
    filename character varying(255) NOT NULL,
    executed_at timestamp without time zone,
    checksum character varying(64) NOT NULL,
    execution_time_ms integer,
    success boolean DEFAULT true,
    archived_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: security_audit_events; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.security_audit_events (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    event_type character varying(50) NOT NULL,
    severity character varying(20) NOT NULL,
    user_id uuid,
    entity_type character varying(50),
    entity_id text,
    details jsonb,
    ip_address inet,
    user_agent text,
    created_at timestamp with time zone DEFAULT now(),
    CONSTRAINT security_audit_events_severity_check CHECK (((severity)::text = ANY (ARRAY[('CRITICAL'::character varying)::text, ('HIGH'::character varying)::text, ('MEDIUM'::character varying)::text, ('LOW'::character varying)::text, ('INFO'::character varying)::text])))
);


--
-- Name: TABLE security_audit_events; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.security_audit_events IS 'Security event log with SIEM-compatible severity levels. Captures tampering attempts, hash mismatches, etc.';


--
-- Name: COLUMN security_audit_events.event_type; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.security_audit_events.event_type IS 'Event type: HASH_MISMATCH, GPS_MISMATCH, UPLOAD_TAMPERING, DEVICE_BLOCKED, etc.';


--
-- Name: COLUMN security_audit_events.severity; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.security_audit_events.severity IS 'SIEM severity: CRITICAL (tampering), HIGH (hash fail), MEDIUM (GPS mismatch), LOW (warnings), INFO (normal).';


--
-- Name: service_zone_rules; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.service_zone_rules (
    id integer NOT NULL,
    client_id integer,
    product_id integer,
    pincode_id integer NOT NULL,
    area_id integer,
    service_zone_id integer NOT NULL,
    is_active boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


--
-- Name: service_zone_rules_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.service_zone_rules_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: service_zone_rules_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.service_zone_rules_id_seq OWNED BY public.service_zone_rules.id;


--
-- Name: service_zones; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.service_zones (
    id integer NOT NULL,
    name character varying(50) NOT NULL,
    sla_hours integer DEFAULT 48 NOT NULL,
    is_active boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


--
-- Name: service_zones_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.service_zones_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: service_zones_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.service_zones_id_seq OWNED BY public.service_zones.id;


--
-- Name: slow_queries; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.slow_queries AS
 SELECT query_hash,
    query_text,
    avg(execution_time) AS avg_execution_time,
    max(execution_time) AS max_execution_time,
    count(*) AS execution_count,
    max("timestamp") AS last_execution
   FROM public.query_performance
  WHERE (execution_time > (100)::numeric)
  GROUP BY query_hash, query_text
  ORDER BY (avg(execution_time)) DESC;


--
-- Name: states_temp_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.states_temp_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: states_temp_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.states_temp_id_seq OWNED BY public.states.id;


--
-- Name: system_health_metrics; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.system_health_metrics (
    id bigint NOT NULL,
    metric_name character varying(100) NOT NULL,
    metric_value numeric(15,4) NOT NULL,
    metric_unit character varying(20),
    tags jsonb,
    "timestamp" timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: TABLE system_health_metrics; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.system_health_metrics IS 'System-level health and performance metrics';


--
-- Name: system_health_metrics_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.system_health_metrics_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: system_health_metrics_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.system_health_metrics_id_seq OWNED BY public.system_health_metrics.id;


--
-- Name: task_assignment_history; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.task_assignment_history (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    verification_task_id uuid NOT NULL,
    case_id uuid NOT NULL,
    assigned_from uuid,
    assigned_to uuid NOT NULL,
    assigned_by uuid NOT NULL,
    assignment_reason text,
    assigned_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    task_status_before character varying(20),
    task_status_after character varying(20),
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: task_form_submissions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.task_form_submissions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    verification_task_id uuid NOT NULL,
    case_id uuid NOT NULL,
    form_submission_id uuid NOT NULL,
    form_type character varying(50) NOT NULL,
    submitted_by uuid NOT NULL,
    submitted_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    validation_status character varying(20) DEFAULT 'PENDING'::character varying,
    validated_by uuid,
    validated_at timestamp without time zone,
    validation_notes text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT check_validation_status CHECK (((validation_status)::text = ANY (ARRAY[('PENDING'::character varying)::text, ('VALID'::character varying)::text, ('INVALID'::character varying)::text])))
);


--
-- Name: task_revocations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.task_revocations (
    id bigint NOT NULL,
    task_id uuid NOT NULL,
    revoked_by_user_id uuid NOT NULL,
    revoked_by_role character varying(16) NOT NULL,
    revoked_from_user_id uuid,
    revoke_reason text NOT NULL,
    previous_status character varying(64) NOT NULL,
    revoked_at timestamp with time zone DEFAULT now() NOT NULL,
    reassigned boolean DEFAULT false NOT NULL,
    reassigned_to_user_id uuid,
    reassigned_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: task_revocations_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.task_revocations_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: task_revocations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.task_revocations_id_seq OWNED BY public.task_revocations.id;


--
-- Name: task_type_analytics; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.task_type_analytics AS
 SELECT vtt.name AS task_type_name,
    vtt.code AS task_type_code,
    vtt.category,
    count(vt.id) AS total_tasks,
    count(
        CASE
            WHEN ((vt.status)::text = 'COMPLETED'::text) THEN 1
            ELSE NULL::integer
        END) AS completed_tasks,
    count(
        CASE
            WHEN ((vt.status)::text = 'IN_PROGRESS'::text) THEN 1
            ELSE NULL::integer
        END) AS in_progress_tasks,
    count(
        CASE
            WHEN (((vt.status)::text = 'PENDING'::text) OR ((vt.status)::text = 'ASSIGNED'::text)) THEN 1
            ELSE NULL::integer
        END) AS pending_tasks,
    count(
        CASE
            WHEN ((vt.status)::text = 'CANCELLED'::text) THEN 1
            ELSE NULL::integer
        END) AS cancelled_tasks,
    round(
        CASE
            WHEN (count(vt.id) = 0) THEN (0)::numeric
            ELSE (((count(
            CASE
                WHEN ((vt.status)::text = 'COMPLETED'::text) THEN 1
                ELSE NULL::integer
            END))::numeric / (count(vt.id))::numeric) * (100)::numeric)
        END, 2) AS completion_rate_percentage,
    round(avg(vt.estimated_amount), 2) AS avg_estimated_amount,
    round(avg(vt.actual_amount), 2) AS avg_actual_amount,
    COALESCE(sum(vt.actual_amount), (0)::numeric) AS total_revenue,
    round(avg(
        CASE
            WHEN (((vt.status)::text = 'COMPLETED'::text) AND (vt.started_at IS NOT NULL)) THEN (EXTRACT(epoch FROM (vt.completed_at - vt.started_at)) / (3600)::numeric)
            ELSE NULL::numeric
        END), 2) AS avg_completion_time_hours,
    count(
        CASE
            WHEN (vt.created_at >= (CURRENT_DATE - '7 days'::interval)) THEN 1
            ELSE NULL::integer
        END) AS tasks_last_7_days,
    count(
        CASE
            WHEN (vt.created_at >= (CURRENT_DATE - '30 days'::interval)) THEN 1
            ELSE NULL::integer
        END) AS tasks_last_30_days
   FROM (public.verification_task_types vtt
     LEFT JOIN public.verification_tasks vt ON ((vtt.id = vt.verification_type_id)))
  GROUP BY vtt.id, vtt.name, vtt.code, vtt.category;


--
-- Name: template_reports; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.template_reports (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    case_id uuid NOT NULL,
    submission_id character varying(255) NOT NULL,
    verification_type character varying(100) NOT NULL,
    outcome character varying(255) NOT NULL,
    report_content text NOT NULL,
    metadata jsonb,
    created_by uuid,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


--
-- Name: TABLE template_reports; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.template_reports IS 'Stores template-based verification reports generated from form submissions';


--
-- Name: COLUMN template_reports.id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.template_reports.id IS 'Unique identifier for the template report';


--
-- Name: COLUMN template_reports.case_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.template_reports.case_id IS 'Reference to the case this report belongs to';


--
-- Name: COLUMN template_reports.submission_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.template_reports.submission_id IS 'Mobile app submission ID that this report was generated from';


--
-- Name: COLUMN template_reports.verification_type; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.template_reports.verification_type IS 'Type of verification (RESIDENCE, BUSINESS, etc.)';


--
-- Name: COLUMN template_reports.outcome; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.template_reports.outcome IS 'Verification outcome (Positive, Negative, etc.)';


--
-- Name: COLUMN template_reports.report_content; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.template_reports.report_content IS 'Generated template-based report content';


--
-- Name: COLUMN template_reports.metadata; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.template_reports.metadata IS 'Additional metadata about the report generation';


--
-- Name: COLUMN template_reports.created_by; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.template_reports.created_by IS 'User who generated the report';


--
-- Name: COLUMN template_reports.created_at; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.template_reports.created_at IS 'Timestamp when the report was created';


--
-- Name: COLUMN template_reports.updated_at; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.template_reports.updated_at IS 'Timestamp when the report was last updated';


--
-- Name: territoryAssignmentAudit; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."territoryAssignmentAudit" (
    id bigint NOT NULL,
    "userId" uuid NOT NULL,
    "assignmentType" character varying(20) NOT NULL,
    "assignmentId" integer NOT NULL,
    action character varying(20) NOT NULL,
    "previousData" jsonb,
    "newData" jsonb NOT NULL,
    "performedBy" uuid NOT NULL,
    "performedAt" timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    reason text,
    CONSTRAINT "territoryAssignmentAudit_action_check" CHECK (((action)::text = ANY (ARRAY[('ASSIGNED'::character varying)::text, ('UNASSIGNED'::character varying)::text, ('MODIFIED'::character varying)::text]))),
    CONSTRAINT "territoryAssignmentAudit_assignmentType_check" CHECK ((("assignmentType")::text = ANY (ARRAY[('PINCODE'::character varying)::text, ('AREA'::character varying)::text])))
);


--
-- Name: TABLE "territoryAssignmentAudit"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public."territoryAssignmentAudit" IS 'Audit trail for all territory assignment changes and decisions';


--
-- Name: COLUMN "territoryAssignmentAudit"."assignmentType"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."territoryAssignmentAudit"."assignmentType" IS 'Type of assignment: PINCODE or AREA';


--
-- Name: COLUMN "territoryAssignmentAudit"."assignmentId"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."territoryAssignmentAudit"."assignmentId" IS 'ID of the assignment record (userPincodeAssignments.id or userAreaAssignments.id)';


--
-- Name: COLUMN "territoryAssignmentAudit".action; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."territoryAssignmentAudit".action IS 'Action performed: ASSIGNED, UNASSIGNED, or MODIFIED';


--
-- Name: COLUMN "territoryAssignmentAudit"."previousData"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."territoryAssignmentAudit"."previousData" IS 'JSON object containing the previous assignment data';


--
-- Name: COLUMN "territoryAssignmentAudit"."newData"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."territoryAssignmentAudit"."newData" IS 'JSON object containing the new assignment data';


--
-- Name: COLUMN "territoryAssignmentAudit".reason; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."territoryAssignmentAudit".reason IS 'Optional reason for the assignment change';


--
-- Name: territoryAssignmentAudit_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public."territoryAssignmentAudit_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: territoryAssignmentAudit_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public."territoryAssignmentAudit_id_seq" OWNED BY public."territoryAssignmentAudit".id;


--
-- Name: trusted_devices; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.trusted_devices (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid,
    device_id text NOT NULL,
    device_model text,
    os_version text,
    first_seen_at timestamp with time zone DEFAULT now(),
    last_seen_at timestamp with time zone DEFAULT now(),
    is_blocked boolean DEFAULT false,
    created_at timestamp with time zone DEFAULT now()
);


--
-- Name: TABLE trusted_devices; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.trusted_devices IS 'Tracks devices used by field agents. New devices require admin approval. User history retained even after account deletion.';


--
-- Name: COLUMN trusted_devices.user_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.trusted_devices.user_id IS 'Owner of device. NULL if user account deleted but device history must be retained.';


--
-- Name: COLUMN trusted_devices.device_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.trusted_devices.device_id IS 'Unique device identifier from Capacitor Device plugin.';


--
-- Name: COLUMN trusted_devices.is_blocked; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.trusted_devices.is_blocked IS 'Admin can block compromised/lost devices to prevent unauthorized access.';


--
-- Name: userAreaAssignments_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public."userAreaAssignments_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: userAreaAssignments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public."userAreaAssignments_id_seq" OWNED BY public."userAreaAssignments".id;


--
-- Name: userClientAssignments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."userClientAssignments" (
    id integer NOT NULL,
    "userId" uuid NOT NULL,
    "clientId" integer NOT NULL,
    "createdAt" timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    "assignedAt" timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    "assignedBy" uuid
);


--
-- Name: TABLE "userClientAssignments"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public."userClientAssignments" IS 'Junction table for assigning BACKEND users to specific clients for access control';


--
-- Name: COLUMN "userClientAssignments"."userId"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."userClientAssignments"."userId" IS 'Reference to the user being assigned to clients';


--
-- Name: COLUMN "userClientAssignments"."clientId"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."userClientAssignments"."clientId" IS 'Reference to the client the user has access to';


--
-- Name: COLUMN "userClientAssignments"."assignedAt"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."userClientAssignments"."assignedAt" IS 'Timestamp when the assignment was made';


--
-- Name: COLUMN "userClientAssignments"."assignedBy"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."userClientAssignments"."assignedBy" IS 'User who made the assignment';


--
-- Name: userClientAssignments_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public."userClientAssignments_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: userClientAssignments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public."userClientAssignments_id_seq" OWNED BY public."userClientAssignments".id;


--
-- Name: userPincodeAssignments_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public."userPincodeAssignments_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: userPincodeAssignments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public."userPincodeAssignments_id_seq" OWNED BY public."userPincodeAssignments".id;


--
-- Name: userProductAssignments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."userProductAssignments" (
    id integer NOT NULL,
    "userId" uuid NOT NULL,
    "productId" integer NOT NULL,
    "assignedAt" timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    "assignedBy" uuid,
    "createdAt" timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: TABLE "userProductAssignments"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public."userProductAssignments" IS 'Junction table for assigning BACKEND users to specific products for access control';


--
-- Name: COLUMN "userProductAssignments"."userId"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."userProductAssignments"."userId" IS 'Reference to the user being assigned to products';


--
-- Name: COLUMN "userProductAssignments"."productId"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."userProductAssignments"."productId" IS 'Reference to the product the user has access to';


--
-- Name: COLUMN "userProductAssignments"."assignedAt"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."userProductAssignments"."assignedAt" IS 'Timestamp when the assignment was made';


--
-- Name: COLUMN "userProductAssignments"."assignedBy"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."userProductAssignments"."assignedBy" IS 'User who made the assignment';


--
-- Name: userProductAssignments_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public."userProductAssignments_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: userProductAssignments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public."userProductAssignments_id_seq" OWNED BY public."userProductAssignments".id;


--
-- Name: user_roles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_roles (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    role_id uuid NOT NULL
);


--
-- Name: verificationTypes_temp_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public."verificationTypes_temp_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: verificationTypes_temp_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public."verificationTypes_temp_id_seq" OWNED BY public."verificationTypes".id;


--
-- Name: verification_attachments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.verification_attachments (
    id integer NOT NULL,
    case_id uuid NOT NULL,
    "caseId" integer,
    verification_type character varying(50) NOT NULL,
    filename character varying(255) NOT NULL,
    "originalName" character varying(255) NOT NULL,
    "mimeType" character varying(100) NOT NULL,
    "fileSize" integer NOT NULL,
    "filePath" character varying(500) NOT NULL,
    "thumbnailPath" character varying(500),
    "uploadedBy" uuid NOT NULL,
    "geoLocation" jsonb,
    "photoType" character varying(50) DEFAULT 'verification'::character varying,
    "submissionId" character varying(100),
    "createdAt" timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    verification_task_id uuid,
    sha256_hash text,
    server_sha256_hash text,
    hash_verified boolean DEFAULT false,
    server_signature text,
    file_size_bytes bigint,
    capture_time timestamp with time zone,
    gps_latitude numeric(10,8),
    gps_longitude numeric(11,8),
    gps_validation_status character varying(20),
    gps_distance_meters numeric(10,2),
    device_id text,
    app_version text,
    exif_json jsonb,
    deleted_at timestamp with time zone,
    deleted_by uuid,
    deletion_reason text
);


--
-- Name: TABLE verification_attachments; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.verification_attachments IS 'Stores verification images captured during mobile form submissions, separate from regular case attachments';


--
-- Name: COLUMN verification_attachments.verification_type; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.verification_attachments.verification_type IS 'Type of verification: RESIDENCE, OFFICE, BUSINESS, etc.';


--
-- Name: COLUMN verification_attachments."geoLocation"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.verification_attachments."geoLocation" IS 'GPS coordinates where photo was taken';


--
-- Name: COLUMN verification_attachments."photoType"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.verification_attachments."photoType" IS 'Type of photo: verification, selfie';


--
-- Name: COLUMN verification_attachments."submissionId"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.verification_attachments."submissionId" IS 'Links to specific verification form submission';


--
-- Name: COLUMN verification_attachments.verification_task_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.verification_attachments.verification_task_id IS 'Links verification image/attachment to specific verification task';


--
-- Name: COLUMN verification_attachments.sha256_hash; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.verification_attachments.sha256_hash IS 'Client-provided SHA-256 hash computed before upload. Used for transit verification.';


--
-- Name: COLUMN verification_attachments.server_sha256_hash; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.verification_attachments.server_sha256_hash IS 'Server-recalculated SHA-256 hash after upload. Primary evidence hash.';


--
-- Name: COLUMN verification_attachments.hash_verified; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.verification_attachments.hash_verified IS 'TRUE if client hash matches server hash. Upload rejected if FALSE.';


--
-- Name: COLUMN verification_attachments.server_signature; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.verification_attachments.server_signature IS 'HMAC-SHA256 signature: HMAC(secret, server_sha256_hash + file_size_bytes + capture_time + device_id + verification_task_id). Tamper-proof seal.';


--
-- Name: COLUMN verification_attachments.file_size_bytes; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.verification_attachments.file_size_bytes IS 'Physical file size in bytes. Required for forensic fingerprint.';


--
-- Name: COLUMN verification_attachments.capture_time; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.verification_attachments.capture_time IS 'Photo capture timestamp from EXIF or device. Distinct from upload time.';


--
-- Name: COLUMN verification_attachments.gps_latitude; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.verification_attachments.gps_latitude IS 'GPS latitude from EXIF metadata. Weak evidence - cross-validate with device GPS.';


--
-- Name: COLUMN verification_attachments.gps_longitude; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.verification_attachments.gps_longitude IS 'GPS longitude from EXIF metadata. Weak evidence - cross-validate with device GPS.';


--
-- Name: COLUMN verification_attachments.gps_validation_status; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.verification_attachments.gps_validation_status IS 'GPS consistency check result: MATCH (< 100m), MISMATCH (> 100m), NO_EXIF_GPS.';


--
-- Name: COLUMN verification_attachments.gps_distance_meters; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.verification_attachments.gps_distance_meters IS 'Distance in meters between device GPS (geoLocation) and EXIF GPS.';


--
-- Name: COLUMN verification_attachments.device_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.verification_attachments.device_id IS 'Unique device identifier that captured this photo.';


--
-- Name: COLUMN verification_attachments.app_version; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.verification_attachments.app_version IS 'Mobile app version used to capture photo (e.g., "4.0.1").';


--
-- Name: COLUMN verification_attachments.exif_json; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.verification_attachments.exif_json IS 'Full EXIF metadata dump for forensic analysis.';


--
-- Name: COLUMN verification_attachments.deleted_at; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.verification_attachments.deleted_at IS 'Soft-delete timestamp. Forensic evidence should never be physically deleted.';


--
-- Name: COLUMN verification_attachments.deleted_by; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.verification_attachments.deleted_by IS 'User who soft-deleted this attachment.';


--
-- Name: COLUMN verification_attachments.deletion_reason; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.verification_attachments.deletion_reason IS 'Reason for soft-deletion (e.g., "duplicate", "wrong photo", "quality issue").';


--
-- Name: verification_attachments_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.verification_attachments_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: verification_attachments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.verification_attachments_id_seq OWNED BY public.verification_attachments.id;


--
-- Name: verification_task_number_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.verification_task_number_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: verification_task_templates; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.verification_task_templates (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    description text,
    category character varying(50),
    tasks jsonb NOT NULL,
    estimated_total_cost numeric(10,2),
    estimated_duration_days integer,
    usage_count integer DEFAULT 0,
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    created_by uuid,
    CONSTRAINT check_template_category CHECK (((category)::text = ANY (ARRAY[('INDIVIDUAL'::character varying)::text, ('BUSINESS'::character varying)::text, ('PROPERTY'::character varying)::text, ('FINANCIAL'::character varying)::text])))
);


--
-- Name: verification_task_templates_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.verification_task_templates_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: verification_task_templates_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.verification_task_templates_id_seq OWNED BY public.verification_task_templates.id;


--
-- Name: verification_task_types_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.verification_task_types_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: verification_task_types_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.verification_task_types_id_seq OWNED BY public.verification_task_types.id;


--
-- Name: verifications; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.verifications (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    applicant_id uuid NOT NULL,
    verification_type_id integer NOT NULL,
    address text NOT NULL,
    pincode_id integer,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


--
-- Name: visits; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.visits (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    verification_id uuid NOT NULL,
    visit_number integer DEFAULT 1,
    assigned_to uuid,
    status character varying(50) DEFAULT 'PENDING'::character varying,
    assigned_at timestamp without time zone,
    started_at timestamp without time zone,
    completed_at timestamp without time zone,
    revoked_at timestamp without time zone,
    sla_deadline timestamp without time zone,
    geo_evidence jsonb DEFAULT '{}'::jsonb,
    photos jsonb DEFAULT '[]'::jsonb,
    form_data jsonb DEFAULT '{}'::jsonb,
    review_notes text,
    report_url text,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


--
-- Name: zone_rate_type_mapping; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.zone_rate_type_mapping (
    id integer NOT NULL,
    client_id integer NOT NULL,
    product_id integer NOT NULL,
    verification_type_id integer NOT NULL,
    service_zone_id integer NOT NULL,
    rate_type_id integer NOT NULL,
    is_active boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


--
-- Name: TABLE zone_rate_type_mapping; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.zone_rate_type_mapping IS 'Deterministic mapping from Service Zone to Rate Type for billing. Ensures that for a given Client+Product+VerificationType+Zone, exactly one Rate Type is used for financial calculations.';


--
-- Name: zone_rate_type_mapping_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.zone_rate_type_mapping_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: zone_rate_type_mapping_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.zone_rate_type_mapping_id_seq OWNED BY public.zone_rate_type_mapping.id;


--
-- Name: areas id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.areas ALTER COLUMN id SET DEFAULT nextval('public.areas_temp_id_seq'::regclass);


--
-- Name: attachments id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.attachments ALTER COLUMN id SET DEFAULT nextval('public.attachments_temp_id_seq'::regclass);


--
-- Name: auditLogs id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."auditLogs" ALTER COLUMN id SET DEFAULT nextval('public."auditLogs_temp_id_seq"'::regclass);


--
-- Name: autoSaves id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."autoSaves" ALTER COLUMN id SET DEFAULT nextval('public."autoSaves_temp_id_seq"'::regclass);


--
-- Name: backgroundSyncQueue id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."backgroundSyncQueue" ALTER COLUMN id SET DEFAULT nextval('public."backgroundSyncQueue_temp_id_seq"'::regclass);


--
-- Name: caseDeduplicationAudit id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."caseDeduplicationAudit" ALTER COLUMN id SET DEFAULT nextval('public."caseDeduplicationAudit_temp_id_seq"'::regclass);


--
-- Name: case_assignment_history id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.case_assignment_history ALTER COLUMN id SET DEFAULT nextval('public.case_assignment_history_id_seq'::regclass);


--
-- Name: case_configuration_errors id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.case_configuration_errors ALTER COLUMN id SET DEFAULT nextval('public.case_configuration_errors_id_seq'::regclass);


--
-- Name: cases caseId; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cases ALTER COLUMN "caseId" SET DEFAULT nextval('public."cases_caseId_seq"'::regclass);


--
-- Name: cities id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cities ALTER COLUMN id SET DEFAULT nextval('public.cities_temp_id_seq'::regclass);


--
-- Name: clientDocumentTypes id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."clientDocumentTypes" ALTER COLUMN id SET DEFAULT nextval('public."clientDocumentTypes_id_seq"'::regclass);


--
-- Name: clientProducts id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."clientProducts" ALTER COLUMN id SET DEFAULT nextval('public."clientProducts_temp_id_seq"'::regclass);


--
-- Name: clients id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.clients ALTER COLUMN id SET DEFAULT nextval('public.clients_temp_id_seq'::regclass);


--
-- Name: commission_batch_items id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.commission_batch_items ALTER COLUMN id SET DEFAULT nextval('public.commission_batch_items_id_seq'::regclass);


--
-- Name: commission_calculations id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.commission_calculations ALTER COLUMN id SET DEFAULT nextval('public.commission_calculations_id_seq'::regclass);


--
-- Name: commission_payment_batches id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.commission_payment_batches ALTER COLUMN id SET DEFAULT nextval('public.commission_payment_batches_id_seq'::regclass);


--
-- Name: commission_rate_types id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.commission_rate_types ALTER COLUMN id SET DEFAULT nextval('public.commission_rate_types_id_seq'::regclass);


--
-- Name: countries id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.countries ALTER COLUMN id SET DEFAULT nextval('public.countries_temp_id_seq'::regclass);


--
-- Name: departments id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.departments ALTER COLUMN id SET DEFAULT nextval('public.departments_temp_id_seq'::regclass);


--
-- Name: designations id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.designations ALTER COLUMN id SET DEFAULT nextval('public.designations_temp_id_seq'::regclass);


--
-- Name: documentTypeRates id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."documentTypeRates" ALTER COLUMN id SET DEFAULT nextval('public."documentTypeRates_id_seq"'::regclass);


--
-- Name: documentTypes id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."documentTypes" ALTER COLUMN id SET DEFAULT nextval('public."documentTypes_id_seq"'::regclass);


--
-- Name: error_logs id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.error_logs ALTER COLUMN id SET DEFAULT nextval('public.error_logs_id_seq'::regclass);


--
-- Name: field_user_commission_assignments id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.field_user_commission_assignments ALTER COLUMN id SET DEFAULT nextval('public.field_user_commission_assignments_id_seq'::regclass);


--
-- Name: invoice_item_tasks id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invoice_item_tasks ALTER COLUMN id SET DEFAULT nextval('public.invoice_item_tasks_id_seq'::regclass);


--
-- Name: invoice_items id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invoice_items ALTER COLUMN id SET DEFAULT nextval('public.invoice_items_id_seq'::regclass);


--
-- Name: invoice_status_history id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invoice_status_history ALTER COLUMN id SET DEFAULT nextval('public.invoice_status_history_id_seq'::regclass);


--
-- Name: invoices id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invoices ALTER COLUMN id SET DEFAULT nextval('public.invoices_id_seq'::regclass);


--
-- Name: locations id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.locations ALTER COLUMN id SET DEFAULT nextval('public.locations_temp_id_seq'::regclass);


--
-- Name: mobile_notification_audit id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mobile_notification_audit ALTER COLUMN id SET DEFAULT nextval('public.mobile_notification_audit_id_seq'::regclass);


--
-- Name: notificationTokens id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."notificationTokens" ALTER COLUMN id SET DEFAULT nextval('public."notificationTokens_temp_id_seq"'::regclass);


--
-- Name: performance_metrics id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.performance_metrics ALTER COLUMN id SET DEFAULT nextval('public.performance_metrics_id_seq'::regclass);


--
-- Name: pincodeAreas id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."pincodeAreas" ALTER COLUMN id SET DEFAULT nextval('public."pincodeAreas_temp_id_seq"'::regclass);


--
-- Name: pincodes id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pincodes ALTER COLUMN id SET DEFAULT nextval('public.pincodes_temp_id_seq'::regclass);


--
-- Name: productDocumentTypes id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."productDocumentTypes" ALTER COLUMN id SET DEFAULT nextval('public."productDocumentTypes_id_seq"'::regclass);


--
-- Name: productVerificationTypes id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."productVerificationTypes" ALTER COLUMN id SET DEFAULT nextval('public."productVerificationTypes_temp_id_seq"'::regclass);


--
-- Name: products id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.products ALTER COLUMN id SET DEFAULT nextval('public.products_temp_id_seq'::regclass);


--
-- Name: query_performance id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.query_performance ALTER COLUMN id SET DEFAULT nextval('public.query_performance_id_seq'::regclass);


--
-- Name: rateHistory id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."rateHistory" ALTER COLUMN id SET DEFAULT nextval('public."rateHistory_temp_id_seq"'::regclass);


--
-- Name: rateTypeAssignments id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."rateTypeAssignments" ALTER COLUMN id SET DEFAULT nextval('public."rateTypeAssignments_temp_id_seq"'::regclass);


--
-- Name: rateTypes id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."rateTypes" ALTER COLUMN id SET DEFAULT nextval('public."rateTypes_temp_id_seq"'::regclass);


--
-- Name: rates id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rates ALTER COLUMN id SET DEFAULT nextval('public.rates_temp_id_seq'::regclass);


--
-- Name: refreshTokens id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."refreshTokens" ALTER COLUMN id SET DEFAULT nextval('public."refreshTokens_temp_id_seq"'::regclass);


--
-- Name: service_zone_rules id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.service_zone_rules ALTER COLUMN id SET DEFAULT nextval('public.service_zone_rules_id_seq'::regclass);


--
-- Name: service_zones id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.service_zones ALTER COLUMN id SET DEFAULT nextval('public.service_zones_id_seq'::regclass);


--
-- Name: states id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.states ALTER COLUMN id SET DEFAULT nextval('public.states_temp_id_seq'::regclass);


--
-- Name: system_health_metrics id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.system_health_metrics ALTER COLUMN id SET DEFAULT nextval('public.system_health_metrics_id_seq'::regclass);


--
-- Name: task_revocations id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.task_revocations ALTER COLUMN id SET DEFAULT nextval('public.task_revocations_id_seq'::regclass);


--
-- Name: territoryAssignmentAudit id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."territoryAssignmentAudit" ALTER COLUMN id SET DEFAULT nextval('public."territoryAssignmentAudit_id_seq"'::regclass);


--
-- Name: userAreaAssignments id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."userAreaAssignments" ALTER COLUMN id SET DEFAULT nextval('public."userAreaAssignments_id_seq"'::regclass);


--
-- Name: userClientAssignments id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."userClientAssignments" ALTER COLUMN id SET DEFAULT nextval('public."userClientAssignments_id_seq"'::regclass);


--
-- Name: userPincodeAssignments id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."userPincodeAssignments" ALTER COLUMN id SET DEFAULT nextval('public."userPincodeAssignments_id_seq"'::regclass);


--
-- Name: userProductAssignments id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."userProductAssignments" ALTER COLUMN id SET DEFAULT nextval('public."userProductAssignments_id_seq"'::regclass);


--
-- Name: verificationTypes id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."verificationTypes" ALTER COLUMN id SET DEFAULT nextval('public."verificationTypes_temp_id_seq"'::regclass);


--
-- Name: verification_attachments id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.verification_attachments ALTER COLUMN id SET DEFAULT nextval('public.verification_attachments_id_seq'::regclass);


--
-- Name: verification_task_templates id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.verification_task_templates ALTER COLUMN id SET DEFAULT nextval('public.verification_task_templates_id_seq'::regclass);


--
-- Name: verification_task_types id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.verification_task_types ALTER COLUMN id SET DEFAULT nextval('public.verification_task_types_id_seq'::regclass);


--
-- Name: zone_rate_type_mapping id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.zone_rate_type_mapping ALTER COLUMN id SET DEFAULT nextval('public.zone_rate_type_mapping_id_seq'::regclass);


--
-- Data for Name: agent_performance_daily; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.agent_performance_daily (id, agent_id, date, cases_assigned, cases_completed, cases_in_progress, forms_submitted, residence_forms, office_forms, business_forms, attachments_uploaded, avg_completion_time_hours, quality_score, validation_success_rate, total_distance_km, active_hours, login_time, logout_time, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: ai_reports; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.ai_reports (id, case_id, submission_id, report_data, generated_by, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: applicants; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.applicants (id, case_id, name, mobile, role, pan_number, id_details, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: areas; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.areas (name, "createdAt", "updatedAt", id) FROM stdin;
Shirdhon B.O	2025-10-31 11:04:09.137455+05:30	2025-10-31 11:04:09.137455+05:30	813
Shirki B.O	2025-10-31 11:04:09.140136+05:30	2025-10-31 11:04:09.140136+05:30	814
Somatane B.O	2025-10-31 11:04:09.14317+05:30	2025-10-31 11:04:09.14317+05:30	815
Sonkhar B.O	2025-10-31 11:04:09.145806+05:30	2025-10-31 11:04:09.145806+05:30	816
Sudkoli B.O	2025-10-31 11:04:09.166999+05:30	2025-10-31 11:04:09.166999+05:30	817
Sugawe B.O	2025-10-31 11:04:09.170775+05:30	2025-10-31 11:04:09.170775+05:30	818
Tala S.O (Raigarh(MH))	2025-10-31 11:04:09.174391+05:30	2025-10-31 11:04:09.174391+05:30	819
Talashet S.O	2025-10-31 11:04:09.177734+05:30	2025-10-31 11:04:09.177734+05:30	820
Talawali Terfe Diwali B.O	2025-10-31 11:04:09.180827+05:30	2025-10-31 11:04:09.180827+05:30	821
Talegaon Tarfe Goregaon B.O	2025-10-31 11:04:09.187035+05:30	2025-10-31 11:04:09.187035+05:30	822
Taloja A.V. S.O	2025-10-31 11:04:09.190806+05:30	2025-10-31 11:04:09.190806+05:30	823
Taloja B.O	2025-10-31 11:04:09.195402+05:30	2025-10-31 11:04:09.195402+05:30	824
Tambadi B.O	2025-10-31 11:04:09.216929+05:30	2025-10-31 11:04:09.216929+05:30	825
Tarankhop B.O	2025-10-31 11:04:09.220949+05:30	2025-10-31 11:04:09.220949+05:30	826
Tempale B.O	2025-10-31 11:04:09.224042+05:30	2025-10-31 11:04:09.224042+05:30	827
Thal S.O (Raigarh(MH))	2025-10-31 11:04:09.226805+05:30	2025-10-31 11:04:09.226805+05:30	828
Tiware B.O	2025-10-31 11:04:09.228918+05:30	2025-10-31 11:04:09.228918+05:30	829
Tokarde B.O	2025-10-31 11:04:09.231692+05:30	2025-10-31 11:04:09.231692+05:30	830
Tondra B.O	2025-10-31 11:04:09.234254+05:30	2025-10-31 11:04:09.234254+05:30	831
Ulwa B.O	2025-10-31 11:04:09.238157+05:30	2025-10-31 11:04:09.238157+05:30	832
Unegaon B.O	2025-10-31 11:04:09.241885+05:30	2025-10-31 11:04:09.241885+05:30	833
Uran S.O	2025-10-31 11:04:09.245867+05:30	2025-10-31 11:04:09.245867+05:30	834
Usar B.O	2025-10-31 11:04:09.268044+05:30	2025-10-31 11:04:09.268044+05:30	835
Usar Khurd B.O	2025-10-31 11:04:09.273381+05:30	2025-10-31 11:04:09.273381+05:30	836
Usarghar B.O	2025-10-31 11:04:09.276289+05:30	2025-10-31 11:04:09.276289+05:30	837
Vadhav B.O	2025-10-31 11:04:09.279035+05:30	2025-10-31 11:04:09.279035+05:30	838
Vadkhal B.O	2025-10-31 11:04:09.281994+05:30	2025-10-31 11:04:09.281994+05:30	839
Vahal B.O	2025-10-31 11:04:09.284797+05:30	2025-10-31 11:04:09.284797+05:30	840
Vaje B.O	2025-10-31 11:04:09.288918+05:30	2025-10-31 11:04:09.288918+05:30	841
Vakas B.O	2025-10-31 11:04:09.292835+05:30	2025-10-31 11:04:09.292835+05:30	842
Varsai B.O	2025-10-31 11:04:09.296469+05:30	2025-10-31 11:04:09.296469+05:30	843
Varsoli B.O	2025-10-31 11:04:09.318604+05:30	2025-10-31 11:04:09.318604+05:30	844
Vasheni B.O	2025-10-31 11:04:09.322423+05:30	2025-10-31 11:04:09.322423+05:30	845
Vashivali B.O	2025-10-31 11:04:09.325878+05:30	2025-10-31 11:04:09.325878+05:30	846
Vavoshi B.O	2025-10-31 11:04:09.32913+05:30	2025-10-31 11:04:09.32913+05:30	847
Vengaon B.O	2025-10-31 11:04:09.332085+05:30	2025-10-31 11:04:09.332085+05:30	848
Veshvi B.O	2025-10-31 11:04:09.33494+05:30	2025-10-31 11:04:09.33494+05:30	849
Vikram Baug B.O	2025-10-31 11:04:09.339179+05:30	2025-10-31 11:04:09.339179+05:30	850
Vile B.O	2025-10-31 11:04:09.343655+05:30	2025-10-31 11:04:09.343655+05:30	851
Virjoli B.O	2025-10-31 11:04:09.346749+05:30	2025-10-31 11:04:09.346749+05:30	852
Wadvali B.O	2025-10-31 11:04:09.36901+05:30	2025-10-31 11:04:09.36901+05:30	853
Wakanfata B.O	2025-10-31 11:04:09.372919+05:30	2025-10-31 11:04:09.372919+05:30	854
Wali B.O	2025-10-31 11:04:09.37639+05:30	2025-10-31 11:04:09.37639+05:30	855
Walke B.O	2025-10-31 11:04:09.379279+05:30	2025-10-31 11:04:09.379279+05:30	856
Washi B.O	2025-10-31 11:04:09.382389+05:30	2025-10-31 11:04:09.382389+05:30	857
Wavandhal B.O	2025-10-31 11:04:09.385671+05:30	2025-10-31 11:04:09.385671+05:30	858
Wavarle B.O	2025-10-31 11:04:09.38977+05:30	2025-10-31 11:04:09.38977+05:30	859
Wavediwali B.O	2025-10-31 11:04:09.393574+05:30	2025-10-31 11:04:09.393574+05:30	860
Wawanje B.O	2025-10-31 11:04:09.414961+05:30	2025-10-31 11:04:09.414961+05:30	861
Wighawali B.O	2025-10-31 11:04:09.419424+05:30	2025-10-31 11:04:09.419424+05:30	862
A I Staff Colony S.O	2025-10-31 11:04:05.180017+05:30	2025-10-31 11:04:05.180017+05:30	1
Aareymilk Colony S.O	2025-10-31 11:04:05.188397+05:30	2025-10-31 11:04:05.188397+05:30	2
Agripada S.O	2025-10-31 11:04:05.193157+05:30	2025-10-31 11:04:05.193157+05:30	3
Ambewadi S.O (Mumbai)	2025-10-31 11:04:05.215704+05:30	2025-10-31 11:04:05.215704+05:30	4
Andheri East S.O	2025-10-31 11:04:05.220593+05:30	2025-10-31 11:04:05.220593+05:30	5
Andheri H.O	2025-10-31 11:04:05.2314+05:30	2025-10-31 11:04:05.2314+05:30	6
Andheri Railway Station S.O	2025-10-31 11:04:05.235594+05:30	2025-10-31 11:04:05.235594+05:30	7
Antop Hill S.O	2025-10-31 11:04:05.239066+05:30	2025-10-31 11:04:05.239066+05:30	8
Anushakti Nagar S.O	2025-10-31 11:04:05.243901+05:30	2025-10-31 11:04:05.243901+05:30	9
Asvini S.O	2025-10-31 11:04:05.265637+05:30	2025-10-31 11:04:05.265637+05:30	10
Azad Nagar S.O (Mumbai)	2025-10-31 11:04:05.272884+05:30	2025-10-31 11:04:05.272884+05:30	11
B P T Colony S.O	2025-10-31 11:04:05.281912+05:30	2025-10-31 11:04:05.281912+05:30	12
B.N. Bhavan S.O	2025-10-31 11:04:05.29416+05:30	2025-10-31 11:04:05.29416+05:30	13
B.P.Lane S.O	2025-10-31 11:04:05.315059+05:30	2025-10-31 11:04:05.315059+05:30	14
Bandra West S.O	2025-10-31 11:04:05.31817+05:30	2025-10-31 11:04:05.31817+05:30	15
Bandra(East) S.O	2025-10-31 11:04:05.320737+05:30	2025-10-31 11:04:05.320737+05:30	16
Bangur Nagar S.O	2025-10-31 11:04:05.324363+05:30	2025-10-31 11:04:05.324363+05:30	17
BARC S.O	2025-10-31 11:04:05.327077+05:30	2025-10-31 11:04:05.327077+05:30	18
Barve Nagar S.O	2025-10-31 11:04:05.329725+05:30	2025-10-31 11:04:05.329725+05:30	19
Bazargate S.O	2025-10-31 11:04:05.332855+05:30	2025-10-31 11:04:05.332855+05:30	20
Best Staff Colony S.O	2025-10-31 11:04:05.339915+05:30	2025-10-31 11:04:05.339915+05:30	21
BEST STaff Quarters S.O	2025-10-31 11:04:05.346919+05:30	2025-10-31 11:04:05.346919+05:30	22
Bhandup Complex S.O	2025-10-31 11:04:05.368218+05:30	2025-10-31 11:04:05.368218+05:30	23
Bhandup East S.O	2025-10-31 11:04:05.373714+05:30	2025-10-31 11:04:05.373714+05:30	24
Bhandup Ind. Estate S.O	2025-10-31 11:04:05.379404+05:30	2025-10-31 11:04:05.379404+05:30	25
Bhandup West S.O	2025-10-31 11:04:05.38385+05:30	2025-10-31 11:04:05.38385+05:30	26
Bharat Nagar S.O (Mumbai)	2025-10-31 11:04:05.389086+05:30	2025-10-31 11:04:05.389086+05:30	27
Bhawani Shankar Rd S.O	2025-10-31 11:04:05.413671+05:30	2025-10-31 11:04:05.413671+05:30	28
Bhawani Shankar S.O	2025-10-31 11:04:05.418196+05:30	2025-10-31 11:04:05.418196+05:30	29
Borivali East S.O	2025-10-31 11:04:05.421824+05:30	2025-10-31 11:04:05.421824+05:30	30
Borivali H.O	2025-10-31 11:04:05.424929+05:30	2025-10-31 11:04:05.424929+05:30	31
Borivali West S.O	2025-10-31 11:04:05.427464+05:30	2025-10-31 11:04:05.427464+05:30	32
C G S Colony S.O	2025-10-31 11:04:05.430273+05:30	2025-10-31 11:04:05.430273+05:30	33
Central Building S.O	2025-10-31 11:04:05.442813+05:30	2025-10-31 11:04:05.442813+05:30	34
Century Mill S.O	2025-10-31 11:04:05.445318+05:30	2025-10-31 11:04:05.445318+05:30	35
Chakala Midc S.O	2025-10-31 11:04:05.465659+05:30	2025-10-31 11:04:05.465659+05:30	36
Chamarbaug S.O	2025-10-31 11:04:05.469908+05:30	2025-10-31 11:04:05.469908+05:30	37
Charkop S.O	2025-10-31 11:04:05.473738+05:30	2025-10-31 11:04:05.473738+05:30	38
Charni Road S.O	2025-10-31 11:04:05.477145+05:30	2025-10-31 11:04:05.477145+05:30	39
Chaupati S.O	2025-10-31 11:04:05.481289+05:30	2025-10-31 11:04:05.481289+05:30	40
Chembur Extension S.O	2025-10-31 11:04:05.484827+05:30	2025-10-31 11:04:05.484827+05:30	41
Chembur H.O	2025-10-31 11:04:05.490846+05:30	2025-10-31 11:04:05.490846+05:30	42
Chembur Rs S.O	2025-10-31 11:04:05.493099+05:30	2025-10-31 11:04:05.493099+05:30	43
Chinchbunder H.O	2025-10-31 11:04:05.495263+05:30	2025-10-31 11:04:05.495263+05:30	44
Chinchpokli S.O	2025-10-31 11:04:05.515125+05:30	2025-10-31 11:04:05.515125+05:30	45
Chunabhatti S.O	2025-10-31 11:04:05.519751+05:30	2025-10-31 11:04:05.519751+05:30	46
Churchgate S.O	2025-10-31 11:04:05.52284+05:30	2025-10-31 11:04:05.52284+05:30	47
Colaba Bazar S.O	2025-10-31 11:04:05.526079+05:30	2025-10-31 11:04:05.526079+05:30	48
Colaba S.O	2025-10-31 11:04:05.528779+05:30	2025-10-31 11:04:05.528779+05:30	49
Fort S.O	2025-10-31 11:04:05.533731+05:30	2025-10-31 11:04:05.533731+05:30	50
Cotton Exchange S.O	2025-10-31 11:04:05.536061+05:30	2025-10-31 11:04:05.536061+05:30	51
Cumballa Hill S.O	2025-10-31 11:04:05.53805+05:30	2025-10-31 11:04:05.53805+05:30	52
Cumballa Sea Face S.O	2025-10-31 11:04:05.540297+05:30	2025-10-31 11:04:05.540297+05:30	53
D.M. Colony S.O	2025-10-31 11:04:05.564328+05:30	2025-10-31 11:04:05.564328+05:30	54
Dadar Colony S.O	2025-10-31 11:04:05.568973+05:30	2025-10-31 11:04:05.568973+05:30	55
Dadar H.O	2025-10-31 11:04:05.573972+05:30	2025-10-31 11:04:05.573972+05:30	56
Dahisar RS S.O	2025-10-31 11:04:05.578199+05:30	2025-10-31 11:04:05.578199+05:30	57
Dahisar S.O	2025-10-31 11:04:05.581503+05:30	2025-10-31 11:04:05.581503+05:30	58
Danda S.O	2025-10-31 11:04:05.587073+05:30	2025-10-31 11:04:05.587073+05:30	59
Daulat Nagar S.O (Mumbai)	2025-10-31 11:04:05.589333+05:30	2025-10-31 11:04:05.589333+05:30	60
Delisle Road S.O	2025-10-31 11:04:05.5921+05:30	2025-10-31 11:04:05.5921+05:30	61
Dharavi Road S.O	2025-10-31 11:04:05.594316+05:30	2025-10-31 11:04:05.594316+05:30	62
Dharavi S.O	2025-10-31 11:04:05.596303+05:30	2025-10-31 11:04:05.596303+05:30	63
Dockyard Road S.O	2025-10-31 11:04:05.617556+05:30	2025-10-31 11:04:05.617556+05:30	64
Dr Deshmukh Marg S.O	2025-10-31 11:04:05.620664+05:30	2025-10-31 11:04:05.620664+05:30	65
Falkland Road S.O	2025-10-31 11:04:05.62409+05:30	2025-10-31 11:04:05.62409+05:30	66
FCI S.O	2025-10-31 11:04:05.626998+05:30	2025-10-31 11:04:05.626998+05:30	67
Ghatkopar West S.O	2025-10-31 11:04:05.633774+05:30	2025-10-31 11:04:05.633774+05:30	68
Girgaon S.O	2025-10-31 11:04:05.635841+05:30	2025-10-31 11:04:05.635841+05:30	69
Gokhale Road S.O (Mumbai)	2025-10-31 11:04:05.638494+05:30	2025-10-31 11:04:05.638494+05:30	70
Goregaon East S.O	2025-10-31 11:04:05.641219+05:30	2025-10-31 11:04:05.641219+05:30	71
Goregaon RS S.O	2025-10-31 11:04:05.643402+05:30	2025-10-31 11:04:05.643402+05:30	72
Goregaon S.O (Mumbai)	2025-10-31 11:04:05.645794+05:30	2025-10-31 11:04:05.645794+05:30	73
Govandi S.O	2025-10-31 11:04:05.66686+05:30	2025-10-31 11:04:05.66686+05:30	74
Government Colony S.O	2025-10-31 11:04:05.670509+05:30	2025-10-31 11:04:05.670509+05:30	75
Gowalia Tank S.O	2025-10-31 11:04:05.674013+05:30	2025-10-31 11:04:05.674013+05:30	76
Grant Road S.O	2025-10-31 11:04:05.677011+05:30	2025-10-31 11:04:05.677011+05:30	77
H.M.P. School S.O	2025-10-31 11:04:05.679928+05:30	2025-10-31 11:04:05.679928+05:30	78
Haffkin Institute S.O	2025-10-31 11:04:05.68287+05:30	2025-10-31 11:04:05.68287+05:30	79
Haines Road S.O	2025-10-31 11:04:05.687663+05:30	2025-10-31 11:04:05.687663+05:30	80
Haji Ali S.O	2025-10-31 11:04:05.690403+05:30	2025-10-31 11:04:05.690403+05:30	81
Hanuman Road S.O	2025-10-31 11:04:05.692395+05:30	2025-10-31 11:04:05.692395+05:30	82
High Court Building S.O (Mumbai)	2025-10-31 11:04:05.694368+05:30	2025-10-31 11:04:05.694368+05:30	83
Holiday Camp S.O	2025-10-31 11:04:05.69671+05:30	2025-10-31 11:04:05.69671+05:30	84
Ins Hamla S.O	2025-10-31 11:04:05.718927+05:30	2025-10-31 11:04:05.718927+05:30	85
International Airport S.O	2025-10-31 11:04:05.721969+05:30	2025-10-31 11:04:05.721969+05:30	86
IRLA S.O	2025-10-31 11:04:05.724616+05:30	2025-10-31 11:04:05.724616+05:30	87
J.B. Nagar S.O	2025-10-31 11:04:05.727198+05:30	2025-10-31 11:04:05.727198+05:30	88
J.J.Hospital S.O	2025-10-31 11:04:05.729736+05:30	2025-10-31 11:04:05.729736+05:30	89
J.M. Road S.O	2025-10-31 11:04:05.732572+05:30	2025-10-31 11:04:05.732572+05:30	90
Jacob Circle S.O	2025-10-31 11:04:05.735526+05:30	2025-10-31 11:04:05.735526+05:30	91
Jogeshwari East S.O	2025-10-31 11:04:05.738157+05:30	2025-10-31 11:04:05.738157+05:30	92
Jogeshwari West S.O	2025-10-31 11:04:05.740234+05:30	2025-10-31 11:04:05.740234+05:30	93
Juhu S.O	2025-10-31 11:04:05.765818+05:30	2025-10-31 11:04:05.765818+05:30	94
Kalachowki S.O	2025-10-31 11:04:05.769208+05:30	2025-10-31 11:04:05.769208+05:30	95
Kalbadevi H.O	2025-10-31 11:04:05.77266+05:30	2025-10-31 11:04:05.77266+05:30	96
Kamathipura S.O	2025-10-31 11:04:05.775427+05:30	2025-10-31 11:04:05.775427+05:30	97
Kandivali East S.O	2025-10-31 11:04:05.778034+05:30	2025-10-31 11:04:05.778034+05:30	98
Kandivali West S.O	2025-10-31 11:04:05.780346+05:30	2025-10-31 11:04:05.780346+05:30	99
Kannamwar Nagar S.O	2025-10-31 11:04:05.783296+05:30	2025-10-31 11:04:05.783296+05:30	100
Kapad Bazar S.O	2025-10-31 11:04:05.785413+05:30	2025-10-31 11:04:05.785413+05:30	101
Ketkipada B.O	2025-10-31 11:04:05.787396+05:30	2025-10-31 11:04:05.787396+05:30	102
Khar Colony S.O	2025-10-31 11:04:05.789776+05:30	2025-10-31 11:04:05.789776+05:30	103
Khar Delivery S.O	2025-10-31 11:04:05.792138+05:30	2025-10-31 11:04:05.792138+05:30	104
Kharodi S.O	2025-10-31 11:04:05.79436+05:30	2025-10-31 11:04:05.79436+05:30	105
Kherwadi S.O	2025-10-31 11:04:05.796655+05:30	2025-10-31 11:04:05.796655+05:30	106
Kidwai Nagar S.O (Mumbai)	2025-10-31 11:04:05.81784+05:30	2025-10-31 11:04:05.81784+05:30	107
Kurla North S.O	2025-10-31 11:04:05.820581+05:30	2025-10-31 11:04:05.820581+05:30	108
Kurla S.O	2025-10-31 11:04:05.823487+05:30	2025-10-31 11:04:05.823487+05:30	109
L B S N E collage S.O	2025-10-31 11:04:05.826466+05:30	2025-10-31 11:04:05.826466+05:30	110
Lal Baug S.O	2025-10-31 11:04:05.829245+05:30	2025-10-31 11:04:05.829245+05:30	111
Liberty Garden S.O	2025-10-31 11:04:05.832125+05:30	2025-10-31 11:04:05.832125+05:30	112
M A Marg S.O	2025-10-31 11:04:05.834267+05:30	2025-10-31 11:04:05.834267+05:30	113
M.P.T. S.O	2025-10-31 11:04:05.836949+05:30	2025-10-31 11:04:05.836949+05:30	114
Madh B.O	2025-10-31 11:04:05.839542+05:30	2025-10-31 11:04:05.839542+05:30	115
Madhavbaug S.O	2025-10-31 11:04:05.841569+05:30	2025-10-31 11:04:05.841569+05:30	116
Magthane B.O	2025-10-31 11:04:05.844109+05:30	2025-10-31 11:04:05.844109+05:30	117
Mahim Bazar S.O	2025-10-31 11:04:05.84662+05:30	2025-10-31 11:04:05.84662+05:30	118
Mahim East S.O	2025-10-31 11:04:05.868302+05:30	2025-10-31 11:04:05.868302+05:30	119
Mahim H.O	2025-10-31 11:04:05.871938+05:30	2025-10-31 11:04:05.871938+05:30	120
Mahul Road S.O	2025-10-31 11:04:05.877796+05:30	2025-10-31 11:04:05.877796+05:30	121
Malabar Hill S.O	2025-10-31 11:04:05.883341+05:30	2025-10-31 11:04:05.883341+05:30	122
Malad East S.O	2025-10-31 11:04:05.885626+05:30	2025-10-31 11:04:05.885626+05:30	123
Malad S.O	2025-10-31 11:04:05.887737+05:30	2025-10-31 11:04:05.887737+05:30	124
Malad West Dely S.O	2025-10-31 11:04:05.890362+05:30	2025-10-31 11:04:05.890362+05:30	125
Mandapeshwar S.O	2025-10-31 11:04:05.892804+05:30	2025-10-31 11:04:05.892804+05:30	126
Mandvi S.O (Mumbai)	2025-10-31 11:04:05.894715+05:30	2025-10-31 11:04:05.894715+05:30	127
Mantralaya S.O (Mumbai)	2025-10-31 11:04:05.91367+05:30	2025-10-31 11:04:05.91367+05:30	128
Marine Lines S.O	2025-10-31 11:04:05.919235+05:30	2025-10-31 11:04:05.919235+05:30	129
Marol Bazar S.O	2025-10-31 11:04:05.922754+05:30	2025-10-31 11:04:05.922754+05:30	130
Marol Naka S.O	2025-10-31 11:04:05.926186+05:30	2025-10-31 11:04:05.926186+05:30	131
Masjid S.O	2025-10-31 11:04:05.929349+05:30	2025-10-31 11:04:05.929349+05:30	132
Matunga S.O	2025-10-31 11:04:05.932239+05:30	2025-10-31 11:04:05.932239+05:30	133
Mazgaon Dock S.O	2025-10-31 11:04:05.934502+05:30	2025-10-31 11:04:05.934502+05:30	134
Mazgaon Road S.O	2025-10-31 11:04:05.937165+05:30	2025-10-31 11:04:05.937165+05:30	135
Mazgaon S.O	2025-10-31 11:04:05.939798+05:30	2025-10-31 11:04:05.939798+05:30	136
Mhada Colony S.O	2025-10-31 11:04:05.942427+05:30	2025-10-31 11:04:05.942427+05:30	137
Mori Road S.O	2025-10-31 11:04:05.944399+05:30	2025-10-31 11:04:05.944399+05:30	138
Motilal Nagar S.O	2025-10-31 11:04:05.946915+05:30	2025-10-31 11:04:05.946915+05:30	139
Mulund Colony S.O	2025-10-31 11:04:05.968951+05:30	2025-10-31 11:04:05.968951+05:30	140
Mulund Dd Road S.O	2025-10-31 11:04:05.972397+05:30	2025-10-31 11:04:05.972397+05:30	141
Mulund East S.O	2025-10-31 11:04:05.975375+05:30	2025-10-31 11:04:05.975375+05:30	142
Mulund West S.O	2025-10-31 11:04:05.978625+05:30	2025-10-31 11:04:05.978625+05:30	143
Mumbai Central H.O	2025-10-31 11:04:05.981744+05:30	2025-10-31 11:04:05.981744+05:30	144
Mumbai G.P.O.	2025-10-31 11:04:05.984587+05:30	2025-10-31 11:04:05.984587+05:30	145
N.S.Patkar Marg S.O	2025-10-31 11:04:05.98738+05:30	2025-10-31 11:04:05.98738+05:30	146
Nagardas Road S.O	2025-10-31 11:04:05.990093+05:30	2025-10-31 11:04:05.990093+05:30	147
Nagari Niwara S.O	2025-10-31 11:04:06.015996+05:30	2025-10-31 11:04:06.015996+05:30	148
Nahur S.O	2025-10-31 11:04:06.020672+05:30	2025-10-31 11:04:06.020672+05:30	149
Naigaon S.O (Mumbai)	2025-10-31 11:04:06.024148+05:30	2025-10-31 11:04:06.024148+05:30	150
Nariman Point S.O	2025-10-31 11:04:06.027611+05:30	2025-10-31 11:04:06.027611+05:30	151
Nehru Nagar S.O (Mumbai)	2025-10-31 11:04:06.030241+05:30	2025-10-31 11:04:06.030241+05:30	152
Nehru Road S.O (Mumbai)	2025-10-31 11:04:06.032745+05:30	2025-10-31 11:04:06.032745+05:30	153
Netajinagar S.O	2025-10-31 11:04:06.035416+05:30	2025-10-31 11:04:06.035416+05:30	154
New Prabhadevi Road S.O	2025-10-31 11:04:06.037773+05:30	2025-10-31 11:04:06.037773+05:30	155
New Yogakshema S.O	2025-10-31 11:04:06.040039+05:30	2025-10-31 11:04:06.040039+05:30	156
NITIE S.O	2025-10-31 11:04:06.042609+05:30	2025-10-31 11:04:06.042609+05:30	157
Noor Baug S.O	2025-10-31 11:04:06.044509+05:30	2025-10-31 11:04:06.044509+05:30	158
Null Bazar S.O	2025-10-31 11:04:06.046909+05:30	2025-10-31 11:04:06.046909+05:30	159
Opera House S.O	2025-10-31 11:04:06.067147+05:30	2025-10-31 11:04:06.067147+05:30	160
Orlem S.O	2025-10-31 11:04:06.06965+05:30	2025-10-31 11:04:06.06965+05:30	161
Oshiwara S.O	2025-10-31 11:04:06.073979+05:30	2025-10-31 11:04:06.073979+05:30	162
P.H. Colony S.O	2025-10-31 11:04:06.076423+05:30	2025-10-31 11:04:06.076423+05:30	163
Pant Nagar S.O	2025-10-31 11:04:06.078721+05:30	2025-10-31 11:04:06.078721+05:30	164
Parel Naka S.O	2025-10-31 11:04:06.081393+05:30	2025-10-31 11:04:06.081393+05:30	165
Parel Rly Work Shop S.O	2025-10-31 11:04:06.083902+05:30	2025-10-31 11:04:06.083902+05:30	166
Parel S.O	2025-10-31 11:04:06.08626+05:30	2025-10-31 11:04:06.08626+05:30	167
Powai Iit S.O	2025-10-31 11:04:06.08877+05:30	2025-10-31 11:04:06.08877+05:30	168
Prabhadevi S.O	2025-10-31 11:04:06.090774+05:30	2025-10-31 11:04:06.090774+05:30	169
Princess Dock S.O	2025-10-31 11:04:06.093295+05:30	2025-10-31 11:04:06.093295+05:30	170
Psm Colony S.O	2025-10-31 11:04:06.0959+05:30	2025-10-31 11:04:06.0959+05:30	171
R.A.Nagar S.O	2025-10-31 11:04:06.11498+05:30	2025-10-31 11:04:06.11498+05:30	172
Rajawadi S.O	2025-10-31 11:04:06.117943+05:30	2025-10-31 11:04:06.117943+05:30	173
Rajbhavan S.O (Mumbai)	2025-10-31 11:04:06.119933+05:30	2025-10-31 11:04:06.119933+05:30	174
Rajendra Nagar S.O (Mumbai)	2025-10-31 11:04:06.125485+05:30	2025-10-31 11:04:06.125485+05:30	175
Ramwadi S.O	2025-10-31 11:04:06.127945+05:30	2025-10-31 11:04:06.127945+05:30	176
Ranade Road S.O	2025-10-31 11:04:06.130395+05:30	2025-10-31 11:04:06.130395+05:30	177
Rani Sati Marg S.O	2025-10-31 11:04:06.13304+05:30	2025-10-31 11:04:06.13304+05:30	178
Raoli Camp S.O	2025-10-31 11:04:06.135391+05:30	2025-10-31 11:04:06.135391+05:30	179
Reay Road S.O	2025-10-31 11:04:06.137733+05:30	2025-10-31 11:04:06.137733+05:30	180
Rifle Range S.O	2025-10-31 11:04:06.140542+05:30	2025-10-31 11:04:06.140542+05:30	181
S R P F Camp S.O	2025-10-31 11:04:06.143166+05:30	2025-10-31 11:04:06.143166+05:30	182
S V Marg S.O	2025-10-31 11:04:06.145533+05:30	2025-10-31 11:04:06.145533+05:30	183
S V S Marg S.O	2025-10-31 11:04:06.165154+05:30	2025-10-31 11:04:06.165154+05:30	184
S. C. Court S.O	2025-10-31 11:04:06.167935+05:30	2025-10-31 11:04:06.167935+05:30	185
S. K.Nagar S.O	2025-10-31 11:04:06.173466+05:30	2025-10-31 11:04:06.173466+05:30	186
S.B. Road S.O	2025-10-31 11:04:06.175834+05:30	2025-10-31 11:04:06.175834+05:30	187
Sahakar Bhavan S.O	2025-10-31 11:04:06.178206+05:30	2025-10-31 11:04:06.178206+05:30	188
Sahar P & T Colony S.O	2025-10-31 11:04:06.180819+05:30	2025-10-31 11:04:06.180819+05:30	189
Sahargaon B.O	2025-10-31 11:04:06.183284+05:30	2025-10-31 11:04:06.183284+05:30	190
Sakinaka S.O	2025-10-31 11:04:06.185662+05:30	2025-10-31 11:04:06.185662+05:30	191
Santacruz Central S.O	2025-10-31 11:04:06.187657+05:30	2025-10-31 11:04:06.187657+05:30	192
Santacruz P&t Colony S.O	2025-10-31 11:04:06.189786+05:30	2025-10-31 11:04:06.189786+05:30	193
Santacruz(East) S.O	2025-10-31 11:04:06.192124+05:30	2025-10-31 11:04:06.192124+05:30	194
Santacruz(West) S.O	2025-10-31 11:04:06.193938+05:30	2025-10-31 11:04:06.193938+05:30	195
Secretariate S.O	2025-10-31 11:04:06.196061+05:30	2025-10-31 11:04:06.196061+05:30	196
Seepz S.O	2025-10-31 11:04:06.216821+05:30	2025-10-31 11:04:06.216821+05:30	197
Sewri S.O	2025-10-31 11:04:06.219726+05:30	2025-10-31 11:04:06.219726+05:30	198
Sharma Estate S.O	2025-10-31 11:04:06.222503+05:30	2025-10-31 11:04:06.222503+05:30	199
Shivaji Nagar S.O (Mumbai)	2025-10-31 11:04:06.225432+05:30	2025-10-31 11:04:06.225432+05:30	200
Shivaji Park S.O (Mumbai)	2025-10-31 11:04:06.227966+05:30	2025-10-31 11:04:06.227966+05:30	201
Shroff Mahajan S.O	2025-10-31 11:04:06.233269+05:30	2025-10-31 11:04:06.233269+05:30	202
Sindhi Society S.O	2025-10-31 11:04:06.23568+05:30	2025-10-31 11:04:06.23568+05:30	203
Sion S.O	2025-10-31 11:04:06.238035+05:30	2025-10-31 11:04:06.238035+05:30	204
Stock Exchange S.O	2025-10-31 11:04:06.240449+05:30	2025-10-31 11:04:06.240449+05:30	205
T.F.Donar S.O	2025-10-31 11:04:06.242925+05:30	2025-10-31 11:04:06.242925+05:30	206
Tagore Nagar S.O	2025-10-31 11:04:06.245271+05:30	2025-10-31 11:04:06.245271+05:30	207
Tajmahal S.O	2025-10-31 11:04:06.265641+05:30	2025-10-31 11:04:06.265641+05:30	208
Tank Road S.O	2025-10-31 11:04:06.270779+05:30	2025-10-31 11:04:06.270779+05:30	209
Tardeo S.O	2025-10-31 11:04:06.274503+05:30	2025-10-31 11:04:06.274503+05:30	210
Thakurdwar S.O	2025-10-31 11:04:06.277846+05:30	2025-10-31 11:04:06.277846+05:30	211
Tilak Nagar S.O (Mumbai)	2025-10-31 11:04:06.281285+05:30	2025-10-31 11:04:06.281285+05:30	212
Town Hall S.O (Mumbai)	2025-10-31 11:04:06.283979+05:30	2025-10-31 11:04:06.283979+05:30	213
Transit Camp S.O	2025-10-31 11:04:06.286582+05:30	2025-10-31 11:04:06.286582+05:30	214
Trombay S.O	2025-10-31 11:04:06.289364+05:30	2025-10-31 11:04:06.289364+05:30	215
Tulsiwadi S.O	2025-10-31 11:04:06.291984+05:30	2025-10-31 11:04:06.291984+05:30	216
Usha Nagar S.O	2025-10-31 11:04:06.294301+05:30	2025-10-31 11:04:06.294301+05:30	217
V J B Udyan S.O	2025-10-31 11:04:06.296653+05:30	2025-10-31 11:04:06.296653+05:30	218
V K Bhavan S.O	2025-10-31 11:04:06.317357+05:30	2025-10-31 11:04:06.317357+05:30	219
V.P. Road S.O	2025-10-31 11:04:06.320737+05:30	2025-10-31 11:04:06.320737+05:30	220
V.W.T.C. S.O	2025-10-31 11:04:06.324288+05:30	2025-10-31 11:04:06.324288+05:30	221
Vakola S.O	2025-10-31 11:04:06.327531+05:30	2025-10-31 11:04:06.327531+05:30	222
Vesava S.O	2025-10-31 11:04:06.330256+05:30	2025-10-31 11:04:06.330256+05:30	223
Vidyanagari S.O	2025-10-31 11:04:06.333234+05:30	2025-10-31 11:04:06.333234+05:30	224
Vihar Road S.O	2025-10-31 11:04:06.335469+05:30	2025-10-31 11:04:06.335469+05:30	225
Vikhroli S.O	2025-10-31 11:04:06.338087+05:30	2025-10-31 11:04:06.338087+05:30	226
Vileeparle (East) S.O	2025-10-31 11:04:06.340584+05:30	2025-10-31 11:04:06.340584+05:30	227
Vileparle Railway Station S.O	2025-10-31 11:04:06.345603+05:30	2025-10-31 11:04:06.345603+05:30	228
Vileparle(West) S.O	2025-10-31 11:04:06.366899+05:30	2025-10-31 11:04:06.366899+05:30	229
Wadala Rs S.O	2025-10-31 11:04:06.370539+05:30	2025-10-31 11:04:06.370539+05:30	230
Wadala S.O	2025-10-31 11:04:06.373608+05:30	2025-10-31 11:04:06.373608+05:30	231
Wadala Truck Terminal S.O	2025-10-31 11:04:06.376285+05:30	2025-10-31 11:04:06.376285+05:30	232
Worli Colony S.O	2025-10-31 11:04:06.378849+05:30	2025-10-31 11:04:06.378849+05:30	233
Worli Naka S.O	2025-10-31 11:04:06.381854+05:30	2025-10-31 11:04:06.381854+05:30	234
Worli Police Camp S.O	2025-10-31 11:04:06.385204+05:30	2025-10-31 11:04:06.385204+05:30	235
Worli S.O	2025-10-31 11:04:06.387561+05:30	2025-10-31 11:04:06.387561+05:30	236
Worli Sea Face S.O	2025-10-31 11:04:06.39022+05:30	2025-10-31 11:04:06.39022+05:30	237
Abitghar B.O	2025-10-31 11:04:06.393183+05:30	2025-10-31 11:04:06.393183+05:30	238
Abje B.O	2025-10-31 11:04:06.395211+05:30	2025-10-31 11:04:06.395211+05:30	239
Additional Ambernath S.O	2025-10-31 11:04:06.416693+05:30	2025-10-31 11:04:06.416693+05:30	240
Agarwadi B.O	2025-10-31 11:04:06.419603+05:30	2025-10-31 11:04:06.419603+05:30	241
Agashi S.O	2025-10-31 11:04:06.422407+05:30	2025-10-31 11:04:06.422407+05:30	242
Agawan B.O	2025-10-31 11:04:06.425223+05:30	2025-10-31 11:04:06.425223+05:30	243
Aghai B.O	2025-10-31 11:04:06.427373+05:30	2025-10-31 11:04:06.427373+05:30	244
Alonde B.O	2025-10-31 11:04:06.429473+05:30	2025-10-31 11:04:06.429473+05:30	245
Alyani B.O	2025-10-31 11:04:06.432407+05:30	2025-10-31 11:04:06.432407+05:30	246
Amane B.O	2025-10-31 11:04:06.434514+05:30	2025-10-31 11:04:06.434514+05:30	247
Ambarje B.O	2025-10-31 11:04:06.436452+05:30	2025-10-31 11:04:06.436452+05:30	248
Ambernath S.O	2025-10-31 11:04:06.438838+05:30	2025-10-31 11:04:06.438838+05:30	249
Ambernath South S.O	2025-10-31 11:04:06.440731+05:30	2025-10-31 11:04:06.440731+05:30	250
Andad B.O	2025-10-31 11:04:06.443076+05:30	2025-10-31 11:04:06.443076+05:30	251
Angaon B.O	2025-10-31 11:04:06.445361+05:30	2025-10-31 11:04:06.445361+05:30	252
Anjur B.O	2025-10-31 11:04:06.465576+05:30	2025-10-31 11:04:06.465576+05:30	253
Apna Bazar S.O	2025-10-31 11:04:06.469475+05:30	2025-10-31 11:04:06.469475+05:30	254
Arnala S.O	2025-10-31 11:04:06.472154+05:30	2025-10-31 11:04:06.472154+05:30	255
Asangaon B.O	2025-10-31 11:04:06.474949+05:30	2025-10-31 11:04:06.474949+05:30	256
Ase B.O	2025-10-31 11:04:06.485367+05:30	2025-10-31 11:04:06.485367+05:30	257
Ashagad B.O	2025-10-31 11:04:06.488906+05:30	2025-10-31 11:04:06.488906+05:30	258
Atali B.O	2025-10-31 11:04:06.492195+05:30	2025-10-31 11:04:06.492195+05:30	259
Atgaon B.O	2025-10-31 11:04:06.494216+05:30	2025-10-31 11:04:06.494216+05:30	260
Aware B.O	2025-10-31 11:04:06.496645+05:30	2025-10-31 11:04:06.496645+05:30	261
Badapokharan B.O	2025-10-31 11:04:06.51846+05:30	2025-10-31 11:04:06.51846+05:30	262
Badlapur E.D. B.O	2025-10-31 11:04:06.522146+05:30	2025-10-31 11:04:06.522146+05:30	263
Balegaon B.O	2025-10-31 11:04:06.524852+05:30	2025-10-31 11:04:06.524852+05:30	264
Balkum S.O	2025-10-31 11:04:06.527462+05:30	2025-10-31 11:04:06.527462+05:30	265
Bandhan B.O	2025-10-31 11:04:06.530204+05:30	2025-10-31 11:04:06.530204+05:30	266
Bapugaon B.O	2025-10-31 11:04:06.532524+05:30	2025-10-31 11:04:06.532524+05:30	267
Bassein Road S.O	2025-10-31 11:04:06.535139+05:30	2025-10-31 11:04:06.535139+05:30	268
Bassein S.O	2025-10-31 11:04:06.537197+05:30	2025-10-31 11:04:06.537197+05:30	269
Bategaon B.O	2025-10-31 11:04:06.539448+05:30	2025-10-31 11:04:06.539448+05:30	270
Bavada B.O	2025-10-31 11:04:06.541516+05:30	2025-10-31 11:04:06.541516+05:30	271
Belapur Node- V S.O	2025-10-31 11:04:06.543862+05:30	2025-10-31 11:04:06.543862+05:30	272
Belapur Node-- III S.O	2025-10-31 11:04:06.545799+05:30	2025-10-31 11:04:06.545799+05:30	273
Bhaji Market S.O	2025-10-31 11:04:06.566679+05:30	2025-10-31 11:04:06.566679+05:30	274
Bhatane B.O	2025-10-31 11:04:06.569932+05:30	2025-10-31 11:04:06.569932+05:30	275
Bhatsanagar S.O	2025-10-31 11:04:06.572651+05:30	2025-10-31 11:04:06.572651+05:30	276
Bhayander East S.O	2025-10-31 11:04:06.575604+05:30	2025-10-31 11:04:06.575604+05:30	277
Bhayander West S.O	2025-10-31 11:04:06.577967+05:30	2025-10-31 11:04:06.577967+05:30	278
Bhiwandi S.O	2025-10-31 11:04:06.580176+05:30	2025-10-31 11:04:06.580176+05:30	279
Bhopoli B.O	2025-10-31 11:04:06.582504+05:30	2025-10-31 11:04:06.582504+05:30	280
Bhuigaon B.O	2025-10-31 11:04:06.585244+05:30	2025-10-31 11:04:06.585244+05:30	281
Birwadi B.O	2025-10-31 11:04:06.587782+05:30	2025-10-31 11:04:06.587782+05:30	282
Boisar S.O	2025-10-31 11:04:06.590528+05:30	2025-10-31 11:04:06.590528+05:30	283
Bolinj B.O	2025-10-31 11:04:06.592953+05:30	2025-10-31 11:04:06.592953+05:30	284
Bus Terminus S.O	2025-10-31 11:04:06.595427+05:30	2025-10-31 11:04:06.595427+05:30	285
Chandansar B.O	2025-10-31 11:04:06.615302+05:30	2025-10-31 11:04:06.615302+05:30	286
Chande B.O	2025-10-31 11:04:06.62067+05:30	2025-10-31 11:04:06.62067+05:30	287
Chandigaon B.O	2025-10-31 11:04:06.624294+05:30	2025-10-31 11:04:06.624294+05:30	288
Chargaon B.O	2025-10-31 11:04:06.627794+05:30	2025-10-31 11:04:06.627794+05:30	289
Charoti B.O	2025-10-31 11:04:06.631443+05:30	2025-10-31 11:04:06.631443+05:30	290
Chikhal Dongre B.O	2025-10-31 11:04:06.634368+05:30	2025-10-31 11:04:06.634368+05:30	291
Chikhale B.O	2025-10-31 11:04:06.637121+05:30	2025-10-31 11:04:06.637121+05:30	292
Chimbipada B.O	2025-10-31 11:04:06.640084+05:30	2025-10-31 11:04:06.640084+05:30	293
Chinchani S.O	2025-10-31 11:04:06.64301+05:30	2025-10-31 11:04:06.64301+05:30	294
Chinchwali B.O	2025-10-31 11:04:06.645143+05:30	2025-10-31 11:04:06.645143+05:30	295
Chitalsar Manpada B.O	2025-10-31 11:04:06.665729+05:30	2025-10-31 11:04:06.665729+05:30	296
Chondhe Colony B.O	2025-10-31 11:04:06.669548+05:30	2025-10-31 11:04:06.669548+05:30	297
Dabhad B.O	2025-10-31 11:04:06.673259+05:30	2025-10-31 11:04:06.673259+05:30	298
Dahanu Road S.O	2025-10-31 11:04:06.676594+05:30	2025-10-31 11:04:06.676594+05:30	299
Dahanu S.O	2025-10-31 11:04:06.679368+05:30	2025-10-31 11:04:06.679368+05:30	300
Dahanu TPS S.O	2025-10-31 11:04:06.682518+05:30	2025-10-31 11:04:06.682518+05:30	301
Dahisar B.O	2025-10-31 11:04:06.684784+05:30	2025-10-31 11:04:06.684784+05:30	302
Dahisar Tarapur B.O	2025-10-31 11:04:06.68675+05:30	2025-10-31 11:04:06.68675+05:30	303
Dahisar tymanor B.O	2025-10-31 11:04:06.688778+05:30	2025-10-31 11:04:06.688778+05:30	304
Dahtsar T B.O	2025-10-31 11:04:06.691023+05:30	2025-10-31 11:04:06.691023+05:30	305
Dalkhan B.O	2025-10-31 11:04:06.693502+05:30	2025-10-31 11:04:06.693502+05:30	306
Dandekarwadi S.O	2025-10-31 11:04:06.695887+05:30	2025-10-31 11:04:06.695887+05:30	307
Dandi B.O	2025-10-31 11:04:06.716503+05:30	2025-10-31 11:04:06.716503+05:30	308
Dapchari S.O	2025-10-31 11:04:06.720092+05:30	2025-10-31 11:04:06.720092+05:30	309
Dapoli B.O	2025-10-31 11:04:06.723018+05:30	2025-10-31 11:04:06.723018+05:30	310
Darave B.O	2025-10-31 11:04:06.725914+05:30	2025-10-31 11:04:06.725914+05:30	311
Datiware B.O	2025-10-31 11:04:06.728154+05:30	2025-10-31 11:04:06.728154+05:30	312
Dawale B.O	2025-10-31 11:04:06.731038+05:30	2025-10-31 11:04:06.731038+05:30	313
Dhasai B.O	2025-10-31 11:04:06.733938+05:30	2025-10-31 11:04:06.733938+05:30	314
Dhasai S.O	2025-10-31 11:04:06.736652+05:30	2025-10-31 11:04:06.736652+05:30	315
Dhekale B.O	2025-10-31 11:04:06.739199+05:30	2025-10-31 11:04:06.739199+05:30	316
Dighashi B.O	2025-10-31 11:04:06.741713+05:30	2025-10-31 11:04:06.741713+05:30	317
Diwa B.O	2025-10-31 11:04:06.744094+05:30	2025-10-31 11:04:06.744094+05:30	318
Dohe B.O	2025-10-31 11:04:06.746493+05:30	2025-10-31 11:04:06.746493+05:30	319
Dolkhamb B.O	2025-10-31 11:04:06.767919+05:30	2025-10-31 11:04:06.767919+05:30	320
Dombivali I.A. S.O	2025-10-31 11:04:06.771437+05:30	2025-10-31 11:04:06.771437+05:30	321
Dombivali S.O	2025-10-31 11:04:06.774101+05:30	2025-10-31 11:04:06.774101+05:30	322
Dongri B.O	2025-10-31 11:04:06.77698+05:30	2025-10-31 11:04:06.77698+05:30	323
Dugad B.O	2025-10-31 11:04:06.779085+05:30	2025-10-31 11:04:06.779085+05:30	324
Dunge B.O	2025-10-31 11:04:06.781993+05:30	2025-10-31 11:04:06.781993+05:30	325
Dwarli B.O	2025-10-31 11:04:06.784683+05:30	2025-10-31 11:04:06.784683+05:30	326
Edwan B.O	2025-10-31 11:04:06.787295+05:30	2025-10-31 11:04:06.787295+05:30	327
Ganeshpuri S.O	2025-10-31 11:04:06.789709+05:30	2025-10-31 11:04:06.789709+05:30	328
Ganeshwadi S.O (Thane)	2025-10-31 11:04:06.791821+05:30	2025-10-31 11:04:06.791821+05:30	329
Ganjad B.O	2025-10-31 11:04:06.793654+05:30	2025-10-31 11:04:06.793654+05:30	330
Gass B.O	2025-10-31 11:04:06.795952+05:30	2025-10-31 11:04:06.795952+05:30	331
Gegaon B.O	2025-10-31 11:04:06.816003+05:30	2025-10-31 11:04:06.816003+05:30	332
Ghansoli S.O	2025-10-31 11:04:06.819526+05:30	2025-10-31 11:04:06.819526+05:30	333
Ghodbander B.O	2025-10-31 11:04:06.823029+05:30	2025-10-31 11:04:06.823029+05:30	334
Gholvad S.O	2025-10-31 11:04:06.825783+05:30	2025-10-31 11:04:06.825783+05:30	335
Girij B.O	2025-10-31 11:04:06.828016+05:30	2025-10-31 11:04:06.828016+05:30	336
Gokhale Road S.O (Thane)	2025-10-31 11:04:06.830973+05:30	2025-10-31 11:04:06.830973+05:30	337
Gokhiware B.O	2025-10-31 11:04:06.833264+05:30	2025-10-31 11:04:06.833264+05:30	338
Govade B.O	2025-10-31 11:04:06.835401+05:30	2025-10-31 11:04:06.835401+05:30	339
Gowane B.O	2025-10-31 11:04:06.838067+05:30	2025-10-31 11:04:06.838067+05:30	340
Gunde B.O	2025-10-31 11:04:06.840591+05:30	2025-10-31 11:04:06.840591+05:30	341
Holi Bazar B.O	2025-10-31 11:04:06.843262+05:30	2025-10-31 11:04:06.843262+05:30	342
Jambhul B.O	2025-10-31 11:04:06.845711+05:30	2025-10-31 11:04:06.845711+05:30	343
Jamshet B.O	2025-10-31 11:04:06.86689+05:30	2025-10-31 11:04:06.86689+05:30	344
Jekegram S.O	2025-10-31 11:04:06.871137+05:30	2025-10-31 11:04:06.871137+05:30	345
Juchandra B.O	2025-10-31 11:04:06.874063+05:30	2025-10-31 11:04:06.874063+05:30	346
K.U.Bazar S.O	2025-10-31 11:04:06.877606+05:30	2025-10-31 11:04:06.877606+05:30	347
Kainad B.O	2025-10-31 11:04:06.880008+05:30	2025-10-31 11:04:06.880008+05:30	348
Kalamb B.O	2025-10-31 11:04:06.883046+05:30	2025-10-31 11:04:06.883046+05:30	349
Kalambe B.O	2025-10-31 11:04:06.885374+05:30	2025-10-31 11:04:06.885374+05:30	350
Kalamgaon B.O	2025-10-31 11:04:06.887867+05:30	2025-10-31 11:04:06.887867+05:30	351
Kalher B.O	2025-10-31 11:04:06.890424+05:30	2025-10-31 11:04:06.890424+05:30	352
Kalwa S.O	2025-10-31 11:04:06.893036+05:30	2025-10-31 11:04:06.893036+05:30	353
Kalyan City H.O	2025-10-31 11:04:06.895016+05:30	2025-10-31 11:04:06.895016+05:30	354
Kalyan D.C. S.O	2025-10-31 11:04:06.915271+05:30	2025-10-31 11:04:06.915271+05:30	355
Kalyan Rs S.O	2025-10-31 11:04:06.919331+05:30	2025-10-31 11:04:06.919331+05:30	356
Kaman B.O	2025-10-31 11:04:06.922812+05:30	2025-10-31 11:04:06.922812+05:30	357
Kanchad B.O	2025-10-31 11:04:06.925776+05:30	2025-10-31 11:04:06.925776+05:30	358
Kansai S.O	2025-10-31 11:04:06.928706+05:30	2025-10-31 11:04:06.928706+05:30	359
Karaj Gaon B.O	2025-10-31 11:04:06.931922+05:30	2025-10-31 11:04:06.931922+05:30	360
Kasara S.O (Thane)	2025-10-31 11:04:06.934745+05:30	2025-10-31 11:04:06.934745+05:30	361
Kasarvadavali B.O	2025-10-31 11:04:06.936911+05:30	2025-10-31 11:04:06.936911+05:30	362
Kasarvadavali S.O	2025-10-31 11:04:06.939101+05:30	2025-10-31 11:04:06.939101+05:30	363
Kasegaon B.O	2025-10-31 11:04:06.941188+05:30	2025-10-31 11:04:06.941188+05:30	364
Kashi B.O	2025-10-31 11:04:06.943126+05:30	2025-10-31 11:04:06.943126+05:30	365
Katale B.O	2025-10-31 11:04:06.945605+05:30	2025-10-31 11:04:06.945605+05:30	366
Katemanivali S.O	2025-10-31 11:04:06.966766+05:30	2025-10-31 11:04:06.966766+05:30	367
Kaular Budruk B.O	2025-10-31 11:04:06.970888+05:30	2025-10-31 11:04:06.970888+05:30	368
Kausa B.O	2025-10-31 11:04:06.976317+05:30	2025-10-31 11:04:06.976317+05:30	369
Kelthan B.O	2025-10-31 11:04:06.979171+05:30	2025-10-31 11:04:06.979171+05:30	370
Kelwa Road B.O	2025-10-31 11:04:06.981603+05:30	2025-10-31 11:04:06.981603+05:30	371
Kelwa S.O (Thane)	2025-10-31 11:04:06.983802+05:30	2025-10-31 11:04:06.983802+05:30	372
Kelwa-mahim S.O	2025-10-31 11:04:06.986276+05:30	2025-10-31 11:04:06.986276+05:30	373
Kev B.O	2025-10-31 11:04:06.98848+05:30	2025-10-31 11:04:06.98848+05:30	374
Khadavali B.O	2025-10-31 11:04:06.991415+05:30	2025-10-31 11:04:06.991415+05:30	375
Khaniwade B.O	2025-10-31 11:04:06.993901+05:30	2025-10-31 11:04:06.993901+05:30	376
Khaniwali B.O	2025-10-31 11:04:07.017803+05:30	2025-10-31 11:04:07.017803+05:30	377
Kharade B.O	2025-10-31 11:04:07.021975+05:30	2025-10-31 11:04:07.021975+05:30	378
Kharbav B.O	2025-10-31 11:04:07.02553+05:30	2025-10-31 11:04:07.02553+05:30	379
Khardi B.O	2025-10-31 11:04:07.028314+05:30	2025-10-31 11:04:07.028314+05:30	380
Khare Ambiwali B.O	2025-10-31 11:04:07.031167+05:30	2025-10-31 11:04:07.031167+05:30	381
Kharegaon B.O	2025-10-31 11:04:07.034144+05:30	2025-10-31 11:04:07.034144+05:30	382
Kharekuran B.O	2025-10-31 11:04:07.036698+05:30	2025-10-31 11:04:07.036698+05:30	383
Kharid B.O	2025-10-31 11:04:07.039449+05:30	2025-10-31 11:04:07.039449+05:30	384
Kharivali B.O	2025-10-31 11:04:07.042223+05:30	2025-10-31 11:04:07.042223+05:30	385
Khariwali B.O	2025-10-31 11:04:07.044761+05:30	2025-10-31 11:04:07.044761+05:30	386
Khodale B.O	2025-10-31 11:04:07.065079+05:30	2025-10-31 11:04:07.065079+05:30	387
Khoni B.O	2025-10-31 11:04:07.0679+05:30	2025-10-31 11:04:07.0679+05:30	388
Khupri B.O	2025-10-31 11:04:07.070588+05:30	2025-10-31 11:04:07.070588+05:30	389
Khutal Baragaon B.O	2025-10-31 11:04:07.072609+05:30	2025-10-31 11:04:07.072609+05:30	390
Khutghar B.O	2025-10-31 11:04:07.075125+05:30	2025-10-31 11:04:07.075125+05:30	391
Kinholi S.O	2025-10-31 11:04:07.077525+05:30	2025-10-31 11:04:07.077525+05:30	392
Kishore B.O	2025-10-31 11:04:07.079895+05:30	2025-10-31 11:04:07.079895+05:30	393
Koch B.O	2025-10-31 11:04:07.082463+05:30	2025-10-31 11:04:07.082463+05:30	394
Kolthan B.O	2025-10-31 11:04:07.085025+05:30	2025-10-31 11:04:07.085025+05:30	395
Kon B.O	2025-10-31 11:04:07.087683+05:30	2025-10-31 11:04:07.087683+05:30	396
Kondhale B.O	2025-10-31 11:04:07.08979+05:30	2025-10-31 11:04:07.08979+05:30	397
Kondhan B.O	2025-10-31 11:04:07.092516+05:30	2025-10-31 11:04:07.092516+05:30	398
Kone B.O	2025-10-31 11:04:07.094625+05:30	2025-10-31 11:04:07.094625+05:30	399
Konkan Bhavan S.O	2025-10-31 11:04:07.096784+05:30	2025-10-31 11:04:07.096784+05:30	400
Kopar Khairne S.O	2025-10-31 11:04:07.118761+05:30	2025-10-31 11:04:07.118761+05:30	401
Kophrad B.O	2025-10-31 11:04:07.121521+05:30	2025-10-31 11:04:07.121521+05:30	402
Kopri Colony S.O	2025-10-31 11:04:07.125026+05:30	2025-10-31 11:04:07.125026+05:30	403
Kosbad-hill S.O	2025-10-31 11:04:07.127265+05:30	2025-10-31 11:04:07.127265+05:30	404
Kudan B.O	2025-10-31 11:04:07.129453+05:30	2025-10-31 11:04:07.129453+05:30	405
Kudus S.O	2025-10-31 11:04:07.132462+05:30	2025-10-31 11:04:07.132462+05:30	406
Kulgaon S.O	2025-10-31 11:04:07.135526+05:30	2025-10-31 11:04:07.135526+05:30	407
Kumbhawali B.O	2025-10-31 11:04:07.138783+05:30	2025-10-31 11:04:07.138783+05:30	408
Kunde B.O	2025-10-31 11:04:07.141604+05:30	2025-10-31 11:04:07.141604+05:30	409
Kurze B.O	2025-10-31 11:04:07.144117+05:30	2025-10-31 11:04:07.144117+05:30	410
Lenad Khurd B.O	2025-10-31 11:04:07.146488+05:30	2025-10-31 11:04:07.146488+05:30	411
Lonad B.O	2025-10-31 11:04:07.167634+05:30	2025-10-31 11:04:07.167634+05:30	412
Mahagaon B.O	2025-10-31 11:04:07.171514+05:30	2025-10-31 11:04:07.171514+05:30	413
Mahapoli B.O	2025-10-31 11:04:07.17537+05:30	2025-10-31 11:04:07.17537+05:30	414
Majgaon B.O	2025-10-31 11:04:07.178574+05:30	2025-10-31 11:04:07.178574+05:30	415
Mal B.O	2025-10-31 11:04:07.181465+05:30	2025-10-31 11:04:07.181465+05:30	416
Mala B.O	2025-10-31 11:04:07.184314+05:30	2025-10-31 11:04:07.184314+05:30	417
Malegaon B.O	2025-10-31 11:04:07.186995+05:30	2025-10-31 11:04:07.186995+05:30	418
Malwada B.O	2025-10-31 11:04:07.19018+05:30	2025-10-31 11:04:07.19018+05:30	419
Mamnoli B.O	2025-10-31 11:04:07.192796+05:30	2025-10-31 11:04:07.192796+05:30	420
Manda S.O	2025-10-31 11:04:07.195205+05:30	2025-10-31 11:04:07.195205+05:30	421
Mandvi B.O	2025-10-31 11:04:07.214286+05:30	2025-10-31 11:04:07.214286+05:30	422
Mangrul B.O	2025-10-31 11:04:07.21936+05:30	2025-10-31 11:04:07.21936+05:30	423
Manivali B.O	2025-10-31 11:04:07.224279+05:30	2025-10-31 11:04:07.224279+05:30	424
Maniwali B.O	2025-10-31 11:04:07.227462+05:30	2025-10-31 11:04:07.227462+05:30	425
Manjarli B.O	2025-10-31 11:04:07.230949+05:30	2025-10-31 11:04:07.230949+05:30	426
Manor S.O	2025-10-31 11:04:07.233767+05:30	2025-10-31 11:04:07.233767+05:30	427
Manpada S.O	2025-10-31 11:04:07.236445+05:30	2025-10-31 11:04:07.236445+05:30	428
Maswan B.O	2025-10-31 11:04:07.238759+05:30	2025-10-31 11:04:07.238759+05:30	429
Met B.O	2025-10-31 11:04:07.241552+05:30	2025-10-31 11:04:07.241552+05:30	430
Mhasa B.O	2025-10-31 11:04:07.246799+05:30	2025-10-31 11:04:07.246799+05:30	431
Milhe B.O	2025-10-31 11:04:07.269313+05:30	2025-10-31 11:04:07.269313+05:30	432
Millenium Business Park S.O	2025-10-31 11:04:07.273092+05:30	2025-10-31 11:04:07.273092+05:30	433
Mira Road S.O	2025-10-31 11:04:07.275932+05:30	2025-10-31 11:04:07.275932+05:30	434
Mira S.O	2025-10-31 11:04:07.279339+05:30	2025-10-31 11:04:07.279339+05:30	435
Mohone S.O	2025-10-31 11:04:07.282536+05:30	2025-10-31 11:04:07.282536+05:30	436
Moj B.O	2025-10-31 11:04:07.285323+05:30	2025-10-31 11:04:07.285323+05:30	437
Mokhada S.O	2025-10-31 11:04:07.288043+05:30	2025-10-31 11:04:07.288043+05:30	438
Mokhawane B.O	2025-10-31 11:04:07.290706+05:30	2025-10-31 11:04:07.290706+05:30	439
Morhanda B.O	2025-10-31 11:04:07.293187+05:30	2025-10-31 11:04:07.293187+05:30	440
Moroshi B.O	2025-10-31 11:04:07.295623+05:30	2025-10-31 11:04:07.295623+05:30	441
Mugaon B.O	2025-10-31 11:04:07.316446+05:30	2025-10-31 11:04:07.316446+05:30	442
Mulgaon B.O	2025-10-31 11:04:07.320412+05:30	2025-10-31 11:04:07.320412+05:30	443
Mumbra S.O	2025-10-31 11:04:07.324019+05:30	2025-10-31 11:04:07.324019+05:30	444
Murbad S.O	2025-10-31 11:04:07.32695+05:30	2025-10-31 11:04:07.32695+05:30	445
Murbe B.O	2025-10-31 11:04:07.329564+05:30	2025-10-31 11:04:07.329564+05:30	446
Nadore B.O	2025-10-31 11:04:07.332475+05:30	2025-10-31 11:04:07.332475+05:30	447
Naigaon B.O	2025-10-31 11:04:07.335202+05:30	2025-10-31 11:04:07.335202+05:30	448
Nala B.O	2025-10-31 11:04:07.337394+05:30	2025-10-31 11:04:07.337394+05:30	449
Nallosapare E S.O	2025-10-31 11:04:07.339897+05:30	2025-10-31 11:04:07.339897+05:30	450
Nanapur B.O	2025-10-31 11:04:07.342114+05:30	2025-10-31 11:04:07.342114+05:30	451
Nandgaon B.O	2025-10-31 11:04:07.344497+05:30	2025-10-31 11:04:07.344497+05:30	452
Nandgaon Tarapur B.O	2025-10-31 11:04:07.346882+05:30	2025-10-31 11:04:07.346882+05:30	453
Narivali B.O	2025-10-31 11:04:07.369261+05:30	2025-10-31 11:04:07.369261+05:30	454
Narpad B.O	2025-10-31 11:04:07.372604+05:30	2025-10-31 11:04:07.372604+05:30	455
Naupada S.O (Thane)	2025-10-31 11:04:07.377147+05:30	2025-10-31 11:04:07.377147+05:30	456
Navghar B.O	2025-10-31 11:04:07.380737+05:30	2025-10-31 11:04:07.380737+05:30	457
Nehroli B.O	2025-10-31 11:04:07.383556+05:30	2025-10-31 11:04:07.383556+05:30	458
Nerul Node-II S.O	2025-10-31 11:04:07.386239+05:30	2025-10-31 11:04:07.386239+05:30	459
Nerul Node-III S.O	2025-10-31 11:04:07.389077+05:30	2025-10-31 11:04:07.389077+05:30	460
Nerul Sec-48 S.O	2025-10-31 11:04:07.391867+05:30	2025-10-31 11:04:07.391867+05:30	461
Netaji Bazar S.O	2025-10-31 11:04:07.394434+05:30	2025-10-31 11:04:07.394434+05:30	462
Nihe B.O	2025-10-31 11:04:07.39642+05:30	2025-10-31 11:04:07.39642+05:30	463
Nikane B.O	2025-10-31 11:04:07.418187+05:30	2025-10-31 11:04:07.418187+05:30	464
Nilje B.O	2025-10-31 11:04:07.422097+05:30	2025-10-31 11:04:07.422097+05:30	465
Nirmal S.O (Thane)	2025-10-31 11:04:07.425489+05:30	2025-10-31 11:04:07.425489+05:30	466
O.E.Ambernath S.O	2025-10-31 11:04:07.428711+05:30	2025-10-31 11:04:07.428711+05:30	467
Pachhapur B.O	2025-10-31 11:04:07.431325+05:30	2025-10-31 11:04:07.431325+05:30	468
Padgha S.O	2025-10-31 11:04:07.434038+05:30	2025-10-31 11:04:07.434038+05:30	469
Padle B.O	2025-10-31 11:04:07.436277+05:30	2025-10-31 11:04:07.436277+05:30	470
Palghar H.O	2025-10-31 11:04:07.438932+05:30	2025-10-31 11:04:07.438932+05:30	471
Palsai B.O	2025-10-31 11:04:07.441576+05:30	2025-10-31 11:04:07.441576+05:30	472
Palu B.O	2025-10-31 11:04:07.443941+05:30	2025-10-31 11:04:07.443941+05:30	473
Papdi S.O	2025-10-31 11:04:07.446247+05:30	2025-10-31 11:04:07.446247+05:30	474
Parali B.O	2025-10-31 11:04:07.467679+05:30	2025-10-31 11:04:07.467679+05:30	475
Pargaon B.O	2025-10-31 11:04:07.471185+05:30	2025-10-31 11:04:07.471185+05:30	476
Parnali B.O	2025-10-31 11:04:07.47457+05:30	2025-10-31 11:04:07.47457+05:30	477
Parol B.O	2025-10-31 11:04:07.477145+05:30	2025-10-31 11:04:07.477145+05:30	478
Patgaon B.O	2025-10-31 11:04:07.479813+05:30	2025-10-31 11:04:07.479813+05:30	479
Paye B.O	2025-10-31 11:04:07.482804+05:30	2025-10-31 11:04:07.482804+05:30	480
Pelhar B.O	2025-10-31 11:04:07.48612+05:30	2025-10-31 11:04:07.48612+05:30	481
Phalegaon B.O	2025-10-31 11:04:07.488915+05:30	2025-10-31 11:04:07.488915+05:30	482
Pik B.O	2025-10-31 11:04:07.491572+05:30	2025-10-31 11:04:07.491572+05:30	483
Pimpaloli B.O	2025-10-31 11:04:07.494049+05:30	2025-10-31 11:04:07.494049+05:30	484
Pimplas B.O	2025-10-31 11:04:07.49647+05:30	2025-10-31 11:04:07.49647+05:30	485
Piwali B.O	2025-10-31 11:04:07.524577+05:30	2025-10-31 11:04:07.524577+05:30	486
Poshera B.O	2025-10-31 11:04:07.528294+05:30	2025-10-31 11:04:07.528294+05:30	487
Posheri B.O	2025-10-31 11:04:07.531924+05:30	2025-10-31 11:04:07.531924+05:30	488
Rai B.O	2025-10-31 11:04:07.534693+05:30	2025-10-31 11:04:07.534693+05:30	489
Rajawali B.O	2025-10-31 11:04:07.538522+05:30	2025-10-31 11:04:07.538522+05:30	490
Ramnagar S.O (Thane)	2025-10-31 11:04:07.542456+05:30	2025-10-31 11:04:07.542456+05:30	491
Ranshet B.O	2025-10-31 11:04:07.545132+05:30	2025-10-31 11:04:07.545132+05:30	492
Rayate B.O	2025-10-31 11:04:07.566635+05:30	2025-10-31 11:04:07.566635+05:30	493
Rehnal B.O	2025-10-31 11:04:07.570473+05:30	2025-10-31 11:04:07.570473+05:30	494
Saiwan B.O	2025-10-31 11:04:07.574146+05:30	2025-10-31 11:04:07.574146+05:30	495
Sakadbav B.O	2025-10-31 11:04:07.579412+05:30	2025-10-31 11:04:07.579412+05:30	496
Sakurli B.O	2025-10-31 11:04:07.582428+05:30	2025-10-31 11:04:07.582428+05:30	497
Saloli B.O	2025-10-31 11:04:07.585117+05:30	2025-10-31 11:04:07.585117+05:30	498
Salwad B.O	2025-10-31 11:04:07.587786+05:30	2025-10-31 11:04:07.587786+05:30	499
Sandozbaugh S.O	2025-10-31 11:04:07.590225+05:30	2025-10-31 11:04:07.590225+05:30	500
Sanpada S.O	2025-10-31 11:04:07.592746+05:30	2025-10-31 11:04:07.592746+05:30	501
Saralambe B.O	2025-10-31 11:04:07.595005+05:30	2025-10-31 11:04:07.595005+05:30	502
Saralgaon B.O	2025-10-31 11:04:07.616274+05:30	2025-10-31 11:04:07.616274+05:30	503
Saravali S.O	2025-10-31 11:04:07.620311+05:30	2025-10-31 11:04:07.620311+05:30	504
Sarawali B.O	2025-10-31 11:04:07.623455+05:30	2025-10-31 11:04:07.623455+05:30	505
Sasne B.O	2025-10-31 11:04:07.626432+05:30	2025-10-31 11:04:07.626432+05:30	506
Sasun Navghar B.O	2025-10-31 11:04:07.629153+05:30	2025-10-31 11:04:07.629153+05:30	507
Satiwai B.O	2025-10-31 11:04:07.632236+05:30	2025-10-31 11:04:07.632236+05:30	508
Satpati S.O	2025-10-31 11:04:07.634922+05:30	2025-10-31 11:04:07.634922+05:30	509
Sawaroli B.O	2025-10-31 11:04:07.636868+05:30	2025-10-31 11:04:07.636868+05:30	510
Sawata B.O	2025-10-31 11:04:07.640957+05:30	2025-10-31 11:04:07.640957+05:30	511
Sayale B.O	2025-10-31 11:04:07.643552+05:30	2025-10-31 11:04:07.643552+05:30	512
Shahad S.O	2025-10-31 11:04:07.645906+05:30	2025-10-31 11:04:07.645906+05:30	513
Shahapur S.O (Thane)	2025-10-31 11:04:07.665571+05:30	2025-10-31 11:04:07.665571+05:30	514
Shantinagar E.D. B.O	2025-10-31 11:04:07.669477+05:30	2025-10-31 11:04:07.669477+05:30	515
Shastrinagar S.O (Thane)	2025-10-31 11:04:07.672934+05:30	2025-10-31 11:04:07.672934+05:30	516
Shelar B.O	2025-10-31 11:04:07.675661+05:30	2025-10-31 11:04:07.675661+05:30	517
Shenwa B.O	2025-10-31 11:04:07.678297+05:30	2025-10-31 11:04:07.678297+05:30	518
Shere B.O	2025-10-31 11:04:07.68121+05:30	2025-10-31 11:04:07.68121+05:30	519
Shigaon B.O	2025-10-31 11:04:07.684014+05:30	2025-10-31 11:04:07.684014+05:30	520
Shirgaon B.O	2025-10-31 11:04:07.686452+05:30	2025-10-31 11:04:07.686452+05:30	521
Shirol B.O	2025-10-31 11:04:07.691015+05:30	2025-10-31 11:04:07.691015+05:30	522
Shiroshi B.O	2025-10-31 11:04:07.693386+05:30	2025-10-31 11:04:07.693386+05:30	523
Shivale B.O	2025-10-31 11:04:07.695798+05:30	2025-10-31 11:04:07.695798+05:30	524
Shrirangnagar B.O	2025-10-31 11:04:07.715577+05:30	2025-10-31 11:04:07.715577+05:30	525
Sogaon B.O	2025-10-31 11:04:07.718384+05:30	2025-10-31 11:04:07.718384+05:30	526
Somta B.O	2025-10-31 11:04:07.721003+05:30	2025-10-31 11:04:07.721003+05:30	527
Sonale B.O	2025-10-31 11:04:07.723847+05:30	2025-10-31 11:04:07.723847+05:30	528
Sopara S.O	2025-10-31 11:04:07.726611+05:30	2025-10-31 11:04:07.726611+05:30	529
Station Road Unr-3 S.O	2025-10-31 11:04:07.729836+05:30	2025-10-31 11:04:07.729836+05:30	530
Subhash Road S.O (Thane)	2025-10-31 11:04:07.732743+05:30	2025-10-31 11:04:07.732743+05:30	531
Suryanagar S.O (Thane)	2025-10-31 11:04:07.735105+05:30	2025-10-31 11:04:07.735105+05:30	532
Talegaon B.O	2025-10-31 11:04:07.737123+05:30	2025-10-31 11:04:07.737123+05:30	533
Tanashi B.O	2025-10-31 11:04:07.739392+05:30	2025-10-31 11:04:07.739392+05:30	534
Tandulwadi B.O	2025-10-31 11:04:07.741822+05:30	2025-10-31 11:04:07.741822+05:30	535
Tansa B.O	2025-10-31 11:04:07.744098+05:30	2025-10-31 11:04:07.744098+05:30	536
Tapasenagar B.O	2025-10-31 11:04:07.746442+05:30	2025-10-31 11:04:07.746442+05:30	537
Tarapur App S.O	2025-10-31 11:04:07.767955+05:30	2025-10-31 11:04:07.767955+05:30	538
Tarapur S.O (Thane)	2025-10-31 11:04:07.78143+05:30	2025-10-31 11:04:07.78143+05:30	539
Tarapur Ti S.O	2025-10-31 11:04:07.78443+05:30	2025-10-31 11:04:07.78443+05:30	540
Tembhikhodave B.O	2025-10-31 11:04:07.786504+05:30	2025-10-31 11:04:07.786504+05:30	541
Tembhode B.O	2025-10-31 11:04:07.789095+05:30	2025-10-31 11:04:07.789095+05:30	542
Tembhurli B.O	2025-10-31 11:04:07.791727+05:30	2025-10-31 11:04:07.791727+05:30	543
Thakurli B.O	2025-10-31 11:04:07.794241+05:30	2025-10-31 11:04:07.794241+05:30	544
Thane Bazar S.O	2025-10-31 11:04:07.796667+05:30	2025-10-31 11:04:07.796667+05:30	545
Thane East S.O	2025-10-31 11:04:07.818692+05:30	2025-10-31 11:04:07.818692+05:30	546
Thane H.O	2025-10-31 11:04:07.822363+05:30	2025-10-31 11:04:07.822363+05:30	547
Thane R.S. S.O	2025-10-31 11:04:07.825795+05:30	2025-10-31 11:04:07.825795+05:30	548
Thune B.O	2025-10-31 11:04:07.828506+05:30	2025-10-31 11:04:07.828506+05:30	549
Tilaknagar S.O (Thane)	2025-10-31 11:04:07.831381+05:30	2025-10-31 11:04:07.831381+05:30	550
Tilher B.O	2025-10-31 11:04:07.834054+05:30	2025-10-31 11:04:07.834054+05:30	551
Titwala B.O	2025-10-31 11:04:07.836617+05:30	2025-10-31 11:04:07.836617+05:30	552
Tokawade B.O	2025-10-31 11:04:07.839058+05:30	2025-10-31 11:04:07.839058+05:30	553
Tulai B.O	2025-10-31 11:04:07.841761+05:30	2025-10-31 11:04:07.841761+05:30	554
Turbhe Market S.O	2025-10-31 11:04:07.844173+05:30	2025-10-31 11:04:07.844173+05:30	555
Turbhe S.O	2025-10-31 11:04:07.846582+05:30	2025-10-31 11:04:07.846582+05:30	556
Tuse B.O	2025-10-31 11:04:07.868522+05:30	2025-10-31 11:04:07.868522+05:30	557
Uchat B.O	2025-10-31 11:04:07.87214+05:30	2025-10-31 11:04:07.87214+05:30	558
Udhale B.O	2025-10-31 11:04:07.875576+05:30	2025-10-31 11:04:07.875576+05:30	559
Ulhasnagar-1 S.O	2025-10-31 11:04:07.878236+05:30	2025-10-31 11:04:07.878236+05:30	560
Ulhasnagar-2 S.O	2025-10-31 11:04:07.881042+05:30	2025-10-31 11:04:07.881042+05:30	561
Ulhasnagar-4 S.O	2025-10-31 11:04:07.883746+05:30	2025-10-31 11:04:07.883746+05:30	562
Ulhasnagar-5 S.O	2025-10-31 11:04:07.885876+05:30	2025-10-31 11:04:07.885876+05:30	563
Umbarpada S.O	2025-10-31 11:04:07.887956+05:30	2025-10-31 11:04:07.887956+05:30	564
Umela B.O	2025-10-31 11:04:07.890418+05:30	2025-10-31 11:04:07.890418+05:30	565
Umrale B.O	2025-10-31 11:04:07.893011+05:30	2025-10-31 11:04:07.893011+05:30	566
Umroli B.O	2025-10-31 11:04:07.895405+05:30	2025-10-31 11:04:07.895405+05:30	567
Urse B.O	2025-10-31 11:04:07.916518+05:30	2025-10-31 11:04:07.916518+05:30	568
Usarani B.O	2025-10-31 11:04:07.92007+05:30	2025-10-31 11:04:07.92007+05:30	569
Utawali B.O	2025-10-31 11:04:07.923522+05:30	2025-10-31 11:04:07.923522+05:30	570
Uttan S.O	2025-10-31 11:04:07.926757+05:30	2025-10-31 11:04:07.926757+05:30	571
Vadavali B.O	2025-10-31 11:04:07.929354+05:30	2025-10-31 11:04:07.929354+05:30	572
Vadhavan B.O	2025-10-31 11:04:07.932306+05:30	2025-10-31 11:04:07.932306+05:30	573
Vadi B.O	2025-10-31 11:04:07.935054+05:30	2025-10-31 11:04:07.935054+05:30	574
Vadpe B.O	2025-10-31 11:04:07.937804+05:30	2025-10-31 11:04:07.937804+05:30	575
Vaholi B.O	2025-10-31 11:04:07.94038+05:30	2025-10-31 11:04:07.94038+05:30	576
Vaishakhare B.O	2025-10-31 11:04:07.942817+05:30	2025-10-31 11:04:07.942817+05:30	577
Vaitarna B.O	2025-10-31 11:04:07.945868+05:30	2025-10-31 11:04:07.945868+05:30	578
Vajreshwari S.O	2025-10-31 11:04:07.96719+05:30	2025-10-31 11:04:07.96719+05:30	579
Valiv B.O	2025-10-31 11:04:07.97126+05:30	2025-10-31 11:04:07.97126+05:30	580
Vangani B.O	2025-10-31 11:04:07.974502+05:30	2025-10-31 11:04:07.974502+05:30	581
Vangaon S.O	2025-10-31 11:04:07.977675+05:30	2025-10-31 11:04:07.977675+05:30	582
Varale B.O	2025-10-31 11:04:07.980422+05:30	2025-10-31 11:04:07.980422+05:30	583
Varap B.O	2025-10-31 11:04:07.983407+05:30	2025-10-31 11:04:07.983407+05:30	584
Varor B.O	2025-10-31 11:04:07.986183+05:30	2025-10-31 11:04:07.986183+05:30	585
Vasai East IE S.O	2025-10-31 11:04:07.989064+05:30	2025-10-31 11:04:07.989064+05:30	586
Vasai Road E S.O	2025-10-31 11:04:07.991721+05:30	2025-10-31 11:04:07.991721+05:30	587
Vashala B.O	2025-10-31 11:04:07.994129+05:30	2025-10-31 11:04:07.994129+05:30	588
Vashi S.O (Thane)	2025-10-31 11:04:08.018291+05:30	2025-10-31 11:04:08.018291+05:30	589
Vashi Sec-26 S.O	2025-10-31 11:04:08.021789+05:30	2025-10-31 11:04:08.021789+05:30	590
Vashi-VII S.O	2025-10-31 11:04:08.025242+05:30	2025-10-31 11:04:08.025242+05:30	591
Vashind E.D. B.O	2025-10-31 11:04:08.028742+05:30	2025-10-31 11:04:08.028742+05:30	592
Vatar B.O	2025-10-31 11:04:08.032076+05:30	2025-10-31 11:04:08.032076+05:30	593
Vedhe B.O	2025-10-31 11:04:08.034757+05:30	2025-10-31 11:04:08.034757+05:30	594
Vehele B.O	2025-10-31 11:04:08.037134+05:30	2025-10-31 11:04:08.037134+05:30	595
Vehloli B.O	2025-10-31 11:04:08.040017+05:30	2025-10-31 11:04:08.040017+05:30	596
Vengani B.O	2025-10-31 11:04:08.045249+05:30	2025-10-31 11:04:08.045249+05:30	597
Veur B.O	2025-10-31 11:04:08.065253+05:30	2025-10-31 11:04:08.065253+05:30	598
Vidyashram S.O	2025-10-31 11:04:08.068136+05:30	2025-10-31 11:04:08.068136+05:30	599
Vihigaon B.O	2025-10-31 11:04:08.070495+05:30	2025-10-31 11:04:08.070495+05:30	600
Vilkos B.O	2025-10-31 11:04:08.073201+05:30	2025-10-31 11:04:08.073201+05:30	601
Virar East S.O	2025-10-31 11:04:08.075662+05:30	2025-10-31 11:04:08.075662+05:30	602
Virar S.O	2025-10-31 11:04:08.077825+05:30	2025-10-31 11:04:08.077825+05:30	603
Virathan Budruk B.O	2025-10-31 11:04:08.080148+05:30	2025-10-31 11:04:08.080148+05:30	604
Vishnunagar S.O	2025-10-31 11:04:08.082426+05:30	2025-10-31 11:04:08.082426+05:30	605
Wada S.O	2025-10-31 11:04:08.084187+05:30	2025-10-31 11:04:08.084187+05:30	606
Wagle I.E. S.O	2025-10-31 11:04:08.086739+05:30	2025-10-31 11:04:08.086739+05:30	607
Waki B.O	2025-10-31 11:04:08.088485+05:30	2025-10-31 11:04:08.088485+05:30	608
Waklan B.O	2025-10-31 11:04:08.092464+05:30	2025-10-31 11:04:08.092464+05:30	609
Yeranjad B.O	2025-10-31 11:04:08.094433+05:30	2025-10-31 11:04:08.094433+05:30	610
Adai B.O	2025-10-31 11:04:08.096753+05:30	2025-10-31 11:04:08.096753+05:30	611
Adhi B.O	2025-10-31 11:04:08.117767+05:30	2025-10-31 11:04:08.117767+05:30	612
Agrav B.O	2025-10-31 11:04:08.120655+05:30	2025-10-31 11:04:08.120655+05:30	613
Akshi B.O	2025-10-31 11:04:08.124009+05:30	2025-10-31 11:04:08.124009+05:30	614
Alibag H.O	2025-10-31 11:04:08.126701+05:30	2025-10-31 11:04:08.126701+05:30	615
Ambeghar B.O	2025-10-31 11:04:08.128953+05:30	2025-10-31 11:04:08.128953+05:30	616
Ambivali B.O	2025-10-31 11:04:08.131505+05:30	2025-10-31 11:04:08.131505+05:30	617
Amtem B.O	2025-10-31 11:04:08.13392+05:30	2025-10-31 11:04:08.13392+05:30	618
Apta B.O	2025-10-31 11:04:08.136457+05:30	2025-10-31 11:04:08.136457+05:30	619
Ashtami B.O	2025-10-31 11:04:08.138693+05:30	2025-10-31 11:04:08.138693+05:30	620
Awas B.O	2025-10-31 11:04:08.141734+05:30	2025-10-31 11:04:08.141734+05:30	621
Awre B.O	2025-10-31 11:04:08.144248+05:30	2025-10-31 11:04:08.144248+05:30	622
Balavali B.O	2025-10-31 11:04:08.146848+05:30	2025-10-31 11:04:08.146848+05:30	623
Bamangaon B.O	2025-10-31 11:04:08.169363+05:30	2025-10-31 11:04:08.169363+05:30	624
Bamnoli B.O	2025-10-31 11:04:08.173458+05:30	2025-10-31 11:04:08.173458+05:30	625
Bapale B.O	2025-10-31 11:04:08.176021+05:30	2025-10-31 11:04:08.176021+05:30	626
Barapada B.O	2025-10-31 11:04:08.178811+05:30	2025-10-31 11:04:08.178811+05:30	627
Beed Budruk B.O	2025-10-31 11:04:08.181153+05:30	2025-10-31 11:04:08.181153+05:30	628
Bense B.O	2025-10-31 11:04:08.183827+05:30	2025-10-31 11:04:08.183827+05:30	629
Bhale B.O	2025-10-31 11:04:08.186329+05:30	2025-10-31 11:04:08.186329+05:30	630
Bhalgaon B.O	2025-10-31 11:04:08.189306+05:30	2025-10-31 11:04:08.189306+05:30	631
Bhira S.O (Raigarh(MH))	2025-10-31 11:04:08.19206+05:30	2025-10-31 11:04:08.19206+05:30	632
Bhivpuri Camp B.O	2025-10-31 11:04:08.194138+05:30	2025-10-31 11:04:08.194138+05:30	633
Bhonang B.O	2025-10-31 11:04:08.196556+05:30	2025-10-31 11:04:08.196556+05:30	634
Bokadvira B.O	2025-10-31 11:04:08.216161+05:30	2025-10-31 11:04:08.216161+05:30	635
Borgaon B.O	2025-10-31 11:04:08.21846+05:30	2025-10-31 11:04:08.21846+05:30	636
Borghar Haveli B.O	2025-10-31 11:04:08.220563+05:30	2025-10-31 11:04:08.220563+05:30	637
Borlimandla B.O	2025-10-31 11:04:08.223345+05:30	2025-10-31 11:04:08.223345+05:30	638
Borwadi B.O	2025-10-31 11:04:08.22547+05:30	2025-10-31 11:04:08.22547+05:30	639
Chandgaon B.O	2025-10-31 11:04:08.227984+05:30	2025-10-31 11:04:08.227984+05:30	640
Chandore B.O	2025-10-31 11:04:08.23065+05:30	2025-10-31 11:04:08.23065+05:30	641
Chanera B.O	2025-10-31 11:04:08.232841+05:30	2025-10-31 11:04:08.232841+05:30	642
Chanje B.O	2025-10-31 11:04:08.235233+05:30	2025-10-31 11:04:08.235233+05:30	643
Chaul S.O	2025-10-31 11:04:08.237707+05:30	2025-10-31 11:04:08.237707+05:30	644
Chawk B.O	2025-10-31 11:04:08.240428+05:30	2025-10-31 11:04:08.240428+05:30	645
Chinchoti B.O	2025-10-31 11:04:08.244975+05:30	2025-10-31 11:04:08.244975+05:30	646
Chinchwali Tarfe Atone B.O	2025-10-31 11:04:08.269574+05:30	2025-10-31 11:04:08.269574+05:30	647
Chirner B.O	2025-10-31 11:04:08.273512+05:30	2025-10-31 11:04:08.273512+05:30	648
Chondhi B.O	2025-10-31 11:04:08.277102+05:30	2025-10-31 11:04:08.277102+05:30	649
Chordhe B.O	2025-10-31 11:04:08.280516+05:30	2025-10-31 11:04:08.280516+05:30	650
Dadar B.O	2025-10-31 11:04:08.28345+05:30	2025-10-31 11:04:08.28345+05:30	651
Dahivali T.Need B.O	2025-10-31 11:04:08.286181+05:30	2025-10-31 11:04:08.286181+05:30	652
Dahivali T.Varedi B.O	2025-10-31 11:04:08.288962+05:30	2025-10-31 11:04:08.288962+05:30	653
Devali B.O	2025-10-31 11:04:08.291856+05:30	2025-10-31 11:04:08.291856+05:30	654
Devichapada B.O	2025-10-31 11:04:08.294439+05:30	2025-10-31 11:04:08.294439+05:30	655
Devkanhe B.O	2025-10-31 11:04:08.296444+05:30	2025-10-31 11:04:08.296444+05:30	656
Dhamansai B.O	2025-10-31 11:04:08.318686+05:30	2025-10-31 11:04:08.318686+05:30	657
Dhokawade B.O	2025-10-31 11:04:08.322694+05:30	2025-10-31 11:04:08.322694+05:30	658
Dighode B.O	2025-10-31 11:04:08.326416+05:30	2025-10-31 11:04:08.326416+05:30	659
Dolvi B.O	2025-10-31 11:04:08.329502+05:30	2025-10-31 11:04:08.329502+05:30	660
Donwat B.O	2025-10-31 11:04:08.332506+05:30	2025-10-31 11:04:08.332506+05:30	661
Elephanta Caves Po B.O	2025-10-31 11:04:08.334784+05:30	2025-10-31 11:04:08.334784+05:30	662
Gadab B.O	2025-10-31 11:04:08.337743+05:30	2025-10-31 11:04:08.337743+05:30	663
Gagode Budruk B.O	2025-10-31 11:04:08.340319+05:30	2025-10-31 11:04:08.340319+05:30	664
Gaulwadi B.O	2025-10-31 11:04:08.342791+05:30	2025-10-31 11:04:08.342791+05:30	665
Gaurkamath B.O	2025-10-31 11:04:08.345272+05:30	2025-10-31 11:04:08.345272+05:30	666
Gavan B.O	2025-10-31 11:04:08.365993+05:30	2025-10-31 11:04:08.365993+05:30	667
Ghosale B.O	2025-10-31 11:04:08.370075+05:30	2025-10-31 11:04:08.370075+05:30	668
Goregaon S.O (Raigarh(MH))	2025-10-31 11:04:08.377949+05:30	2025-10-31 11:04:08.377949+05:30	669
Govele B.O	2025-10-31 11:04:08.381057+05:30	2025-10-31 11:04:08.381057+05:30	670
Gulsunde B.O	2025-10-31 11:04:08.383887+05:30	2025-10-31 11:04:08.383887+05:30	671
Gundge B.O	2025-10-31 11:04:08.386829+05:30	2025-10-31 11:04:08.386829+05:30	672
Hamrapur B.O	2025-10-31 11:04:08.389642+05:30	2025-10-31 11:04:08.389642+05:30	673
Harkol B.O	2025-10-31 11:04:08.392257+05:30	2025-10-31 11:04:08.392257+05:30	674
Hashiware B.O	2025-10-31 11:04:08.39473+05:30	2025-10-31 11:04:08.39473+05:30	675
Hodgaon B.O	2025-10-31 11:04:08.396716+05:30	2025-10-31 11:04:08.396716+05:30	676
Humgaon B.O	2025-10-31 11:04:08.417897+05:30	2025-10-31 11:04:08.417897+05:30	677
Jagdish Nagar S.O	2025-10-31 11:04:08.421337+05:30	2025-10-31 11:04:08.421337+05:30	678
Jambrung B.O	2025-10-31 11:04:08.424256+05:30	2025-10-31 11:04:08.424256+05:30	679
Jamgaon B.O	2025-10-31 11:04:08.427558+05:30	2025-10-31 11:04:08.427558+05:30	680
Jasai B.O	2025-10-31 11:04:08.431024+05:30	2025-10-31 11:04:08.431024+05:30	681
Jaskhar B.O	2025-10-31 11:04:08.433749+05:30	2025-10-31 11:04:08.433749+05:30	682
Jci Kamothe B.O	2025-10-31 11:04:08.43603+05:30	2025-10-31 11:04:08.43603+05:30	683
Jite B.O	2025-10-31 11:04:08.438869+05:30	2025-10-31 11:04:08.438869+05:30	684
Jnpt S.O	2025-10-31 11:04:08.44355+05:30	2025-10-31 11:04:08.44355+05:30	685
Johe B.O	2025-10-31 11:04:08.445912+05:30	2025-10-31 11:04:08.445912+05:30	686
Jui B.O	2025-10-31 11:04:08.466849+05:30	2025-10-31 11:04:08.466849+05:30	687
Kadav B.O	2025-10-31 11:04:08.47153+05:30	2025-10-31 11:04:08.47153+05:30	688
Kalamboli Node S.O	2025-10-31 11:04:08.477843+05:30	2025-10-31 11:04:08.477843+05:30	689
Kamarle B.O	2025-10-31 11:04:08.48069+05:30	2025-10-31 11:04:08.48069+05:30	690
Kamarli B.O	2025-10-31 11:04:08.483593+05:30	2025-10-31 11:04:08.483593+05:30	691
Kandale B.O	2025-10-31 11:04:08.486285+05:30	2025-10-31 11:04:08.486285+05:30	692
Karanja B.O	2025-10-31 11:04:08.489154+05:30	2025-10-31 11:04:08.489154+05:30	693
Karjat S.O (Raigarh(MH))	2025-10-31 11:04:08.491691+05:30	2025-10-31 11:04:08.491691+05:30	694
Kashele B.O	2025-10-31 11:04:08.495277+05:30	2025-10-31 11:04:08.495277+05:30	695
Kasu B.O	2025-10-31 11:04:08.515083+05:30	2025-10-31 11:04:08.515083+05:30	696
Kavil Vahal B.O	2025-10-31 11:04:08.517845+05:30	2025-10-31 11:04:08.517845+05:30	697
Kegaon B.O	2025-10-31 11:04:08.520312+05:30	2025-10-31 11:04:08.520312+05:30	698
Kelevane B.O	2025-10-31 11:04:08.522803+05:30	2025-10-31 11:04:08.522803+05:30	699
Khaire Budruk B.O	2025-10-31 11:04:08.525278+05:30	2025-10-31 11:04:08.525278+05:30	700
Khalapur S.O	2025-10-31 11:04:08.527626+05:30	2025-10-31 11:04:08.527626+05:30	701
Khamb B.O	2025-10-31 11:04:08.529527+05:30	2025-10-31 11:04:08.529527+05:30	702
Khambewadi B.O	2025-10-31 11:04:08.532316+05:30	2025-10-31 11:04:08.532316+05:30	703
Khanda Colony S.O	2025-10-31 11:04:08.534734+05:30	2025-10-31 11:04:08.534734+05:30	704
Khandale B.O	2025-10-31 11:04:08.537036+05:30	2025-10-31 11:04:08.537036+05:30	705
Khandas B.O	2025-10-31 11:04:08.539488+05:30	2025-10-31 11:04:08.539488+05:30	706
Kharavali B.O	2025-10-31 11:04:08.542085+05:30	2025-10-31 11:04:08.542085+05:30	707
Khargaon B.O	2025-10-31 11:04:08.544462+05:30	2025-10-31 11:04:08.544462+05:30	708
Kharghar S.O	2025-10-31 11:04:08.546864+05:30	2025-10-31 11:04:08.546864+05:30	709
Kharpale B.O	2025-10-31 11:04:08.566376+05:30	2025-10-31 11:04:08.566376+05:30	710
Khopoli S.O	2025-10-31 11:04:08.56916+05:30	2025-10-31 11:04:08.56916+05:30	711
Kihim B.O	2025-10-31 11:04:08.571575+05:30	2025-10-31 11:04:08.571575+05:30	712
Kirwali B.O	2025-10-31 11:04:08.57404+05:30	2025-10-31 11:04:08.57404+05:30	713
Kokban B.O	2025-10-31 11:04:08.576576+05:30	2025-10-31 11:04:08.576576+05:30	714
Kolad S.O	2025-10-31 11:04:08.578871+05:30	2025-10-31 11:04:08.578871+05:30	715
Kondivade B.O	2025-10-31 11:04:08.581408+05:30	2025-10-31 11:04:08.581408+05:30	716
Koproli B.O	2025-10-31 11:04:08.583823+05:30	2025-10-31 11:04:08.583823+05:30	717
Korlai B.O	2025-10-31 11:04:08.588415+05:30	2025-10-31 11:04:08.588415+05:30	718
Koshane B.O	2025-10-31 11:04:08.591273+05:30	2025-10-31 11:04:08.591273+05:30	719
Koste Khurd B.O	2025-10-31 11:04:08.593825+05:30	2025-10-31 11:04:08.593825+05:30	720
Koynavale B.O	2025-10-31 11:04:08.596293+05:30	2025-10-31 11:04:08.596293+05:30	721
Kudli B.O	2025-10-31 11:04:08.616423+05:30	2025-10-31 11:04:08.616423+05:30	722
Kundevahal B.O	2025-10-31 11:04:08.619398+05:30	2025-10-31 11:04:08.619398+05:30	723
Kurdus B.O	2025-10-31 11:04:08.622055+05:30	2025-10-31 11:04:08.622055+05:30	724
Kurul B.O	2025-10-31 11:04:08.624364+05:30	2025-10-31 11:04:08.624364+05:30	725
Kurul RCF Colony S.O	2025-10-31 11:04:08.626992+05:30	2025-10-31 11:04:08.626992+05:30	726
Kusumbale B.O	2025-10-31 11:04:08.629515+05:30	2025-10-31 11:04:08.629515+05:30	727
Lodhivali B.O	2025-10-31 11:04:08.632454+05:30	2025-10-31 11:04:08.632454+05:30	728
Lonere B.O	2025-10-31 11:04:08.635179+05:30	2025-10-31 11:04:08.635179+05:30	729
Lonshi B.O	2025-10-31 11:04:08.637853+05:30	2025-10-31 11:04:08.637853+05:30	730
Malyan B.O	2025-10-31 11:04:08.719533+05:30	2025-10-31 11:04:08.719533+05:30	731
Mandad B.O	2025-10-31 11:04:08.722888+05:30	2025-10-31 11:04:08.722888+05:30	732
Mandavane B.O	2025-10-31 11:04:08.726257+05:30	2025-10-31 11:04:08.726257+05:30	733
Mangaon S.O (Raigarh(MH))	2025-10-31 11:04:08.736766+05:30	2025-10-31 11:04:08.736766+05:30	734
Mangaon T.Varedi B.O	2025-10-31 11:04:08.741356+05:30	2025-10-31 11:04:08.741356+05:30	735
Mangarul B.O	2025-10-31 11:04:08.745158+05:30	2025-10-31 11:04:08.745158+05:30	736
Manjaravane B.O	2025-10-31 11:04:08.770562+05:30	2025-10-31 11:04:08.770562+05:30	737
Mapgaon B.O	2025-10-31 11:04:08.774104+05:30	2025-10-31 11:04:08.774104+05:30	738
Mazgaon B.O	2025-10-31 11:04:08.777558+05:30	2025-10-31 11:04:08.777558+05:30	739
Medha B.O	2025-10-31 11:04:08.780072+05:30	2025-10-31 11:04:08.780072+05:30	740
Mohopada S.O	2025-10-31 11:04:08.783118+05:30	2025-10-31 11:04:08.783118+05:30	741
Mora B.O	2025-10-31 11:04:08.78612+05:30	2025-10-31 11:04:08.78612+05:30	742
Morbe B.O	2025-10-31 11:04:08.788544+05:30	2025-10-31 11:04:08.788544+05:30	743
Muthavali Tarfe Tala B.O	2025-10-31 11:04:08.79149+05:30	2025-10-31 11:04:08.79149+05:30	744
N.S.Karanja S.O	2025-10-31 11:04:08.79413+05:30	2025-10-31 11:04:08.79413+05:30	745
Nagaon B.O	2025-10-31 11:04:08.796663+05:30	2025-10-31 11:04:08.796663+05:30	746
Nagaon S.O	2025-10-31 11:04:08.818364+05:30	2025-10-31 11:04:08.818364+05:30	747
Nagothane S.O	2025-10-31 11:04:08.822095+05:30	2025-10-31 11:04:08.822095+05:30	748
Nandvi B.O	2025-10-31 11:04:08.828485+05:30	2025-10-31 11:04:08.828485+05:30	749
Narangi B.O	2025-10-31 11:04:08.832149+05:30	2025-10-31 11:04:08.832149+05:30	750
Nasarapur B.O	2025-10-31 11:04:08.835684+05:30	2025-10-31 11:04:08.835684+05:30	751
Navadar Navagaon B.O	2025-10-31 11:04:08.839485+05:30	2025-10-31 11:04:08.839485+05:30	752
Navde B.O	2025-10-31 11:04:08.842175+05:30	2025-10-31 11:04:08.842175+05:30	753
Neral S.O	2025-10-31 11:04:08.846622+05:30	2025-10-31 11:04:08.846622+05:30	754
Nere B.O	2025-10-31 11:04:08.866519+05:30	2025-10-31 11:04:08.866519+05:30	755
Nhava B.O	2025-10-31 11:04:08.869095+05:30	2025-10-31 11:04:08.869095+05:30	756
Nhave B.O	2025-10-31 11:04:08.871722+05:30	2025-10-31 11:04:08.871722+05:30	757
Nizampur S.O (Raigarh(MH))	2025-10-31 11:04:08.874409+05:30	2025-10-31 11:04:08.874409+05:30	758
Ongc Complex panvel S.O	2025-10-31 11:04:08.876894+05:30	2025-10-31 11:04:08.876894+05:30	759
ONGC-dronagiri B.O	2025-10-31 11:04:08.879136+05:30	2025-10-31 11:04:08.879136+05:30	760
Pabal B.O	2025-10-31 11:04:08.882105+05:30	2025-10-31 11:04:08.882105+05:30	761
Padghe B.O	2025-10-31 11:04:08.884213+05:30	2025-10-31 11:04:08.884213+05:30	762
Palas B.O	2025-10-31 11:04:08.886999+05:30	2025-10-31 11:04:08.886999+05:30	763
Palasdari B.O	2025-10-31 11:04:08.889928+05:30	2025-10-31 11:04:08.889928+05:30	764
Palasgaon Khurd B.O	2025-10-31 11:04:08.892883+05:30	2025-10-31 11:04:08.892883+05:30	765
Palaspe B.O	2025-10-31 11:04:08.895551+05:30	2025-10-31 11:04:08.895551+05:30	766
Panhalghar B.O	2025-10-31 11:04:08.916751+05:30	2025-10-31 11:04:08.916751+05:30	767
Panvel City S.O	2025-10-31 11:04:08.921321+05:30	2025-10-31 11:04:08.921321+05:30	768
Panvel H.O	2025-10-31 11:04:08.924964+05:30	2025-10-31 11:04:08.924964+05:30	769
Patalganga S.O	2025-10-31 11:04:08.931469+05:30	2025-10-31 11:04:08.931469+05:30	770
Pathraj B.O	2025-10-31 11:04:08.934309+05:30	2025-10-31 11:04:08.934309+05:30	771
Patnus B.O	2025-10-31 11:04:08.938112+05:30	2025-10-31 11:04:08.938112+05:30	772
PCTS Nagothane S.O	2025-10-31 11:04:08.941407+05:30	2025-10-31 11:04:08.941407+05:30	773
Pen S.O	2025-10-31 11:04:08.943895+05:30	2025-10-31 11:04:08.943895+05:30	774
Pen Tarfe Tale B.O	2025-10-31 11:04:08.94678+05:30	2025-10-31 11:04:08.94678+05:30	775
Pigonde B.O	2025-10-31 11:04:08.969104+05:30	2025-10-31 11:04:08.969104+05:30	776
Pingalsai B.O	2025-10-31 11:04:08.97311+05:30	2025-10-31 11:04:08.97311+05:30	777
Pipenagar S.O	2025-10-31 11:04:08.97667+05:30	2025-10-31 11:04:08.97667+05:30	778
Pitsai B.O	2025-10-31 11:04:08.979446+05:30	2025-10-31 11:04:08.979446+05:30	779
Poshir B.O	2025-10-31 11:04:08.982582+05:30	2025-10-31 11:04:08.982582+05:30	780
Poyanje B.O	2025-10-31 11:04:08.985853+05:30	2025-10-31 11:04:08.985853+05:30	781
Poynad S.O	2025-10-31 11:04:08.988853+05:30	2025-10-31 11:04:08.988853+05:30	782
Pugaon B.O	2025-10-31 11:04:08.991863+05:30	2025-10-31 11:04:08.991863+05:30	783
Purar B.O	2025-10-31 11:04:08.994407+05:30	2025-10-31 11:04:08.994407+05:30	784
Rahatad B.O	2025-10-31 11:04:08.996938+05:30	2025-10-31 11:04:08.996938+05:30	785
Ramraj B.O	2025-10-31 11:04:09.018968+05:30	2025-10-31 11:04:09.018968+05:30	786
Ransai B.O	2025-10-31 11:04:09.022661+05:30	2025-10-31 11:04:09.022661+05:30	787
Rasayani S.O	2025-10-31 11:04:09.026467+05:30	2025-10-31 11:04:09.026467+05:30	788
Ratwad B.O	2025-10-31 11:04:09.035315+05:30	2025-10-31 11:04:09.035315+05:30	789
Rave B.O	2025-10-31 11:04:09.038325+05:30	2025-10-31 11:04:09.038325+05:30	790
RCF Thal S.O	2025-10-31 11:04:09.041054+05:30	2025-10-31 11:04:09.041054+05:30	791
Revdanda S.O	2025-10-31 11:04:09.043291+05:30	2025-10-31 11:04:09.043291+05:30	792
Roha AV S.O	2025-10-31 11:04:09.045935+05:30	2025-10-31 11:04:09.045935+05:30	793
Roha S.O	2025-10-31 11:04:09.065486+05:30	2025-10-31 11:04:09.065486+05:30	794
Roth Khurd B.O	2025-10-31 11:04:09.068408+05:30	2025-10-31 11:04:09.068408+05:30	795
Sai B.O	2025-10-31 11:04:09.070885+05:30	2025-10-31 11:04:09.070885+05:30	796
Sai S.O	2025-10-31 11:04:09.073504+05:30	2025-10-31 11:04:09.073504+05:30	797
Sajgaon B.O	2025-10-31 11:04:09.076031+05:30	2025-10-31 11:04:09.076031+05:30	798
Salokh T.Need B.O	2025-10-31 11:04:09.078475+05:30	2025-10-31 11:04:09.078475+05:30	799
Sanegaon B.O	2025-10-31 11:04:09.081015+05:30	2025-10-31 11:04:09.081015+05:30	800
Saral B.O	2025-10-31 11:04:09.083437+05:30	2025-10-31 11:04:09.083437+05:30	801
Sarsoli B.O	2025-10-31 11:04:09.086225+05:30	2025-10-31 11:04:09.086225+05:30	802
Sasawane B.O	2025-10-31 11:04:09.088908+05:30	2025-10-31 11:04:09.088908+05:30	803
Sawarsai B.O	2025-10-31 11:04:09.091731+05:30	2025-10-31 11:04:09.091731+05:30	804
Shahabaj B.O	2025-10-31 11:04:09.09414+05:30	2025-10-31 11:04:09.09414+05:30	805
Shahapur B.O	2025-10-31 11:04:09.096711+05:30	2025-10-31 11:04:09.096711+05:30	806
Shedsai B.O	2025-10-31 11:04:09.118539+05:30	2025-10-31 11:04:09.118539+05:30	807
Shelu B.O	2025-10-31 11:04:09.122435+05:30	2025-10-31 11:04:09.122435+05:30	808
Shenwai B.O	2025-10-31 11:04:09.125727+05:30	2025-10-31 11:04:09.125727+05:30	809
Sheva B.O	2025-10-31 11:04:09.128535+05:30	2025-10-31 11:04:09.128535+05:30	810
Shilphata S.O	2025-10-31 11:04:09.131454+05:30	2025-10-31 11:04:09.131454+05:30	811
Shirawali B.O	2025-10-31 11:04:09.134332+05:30	2025-10-31 11:04:09.134332+05:30	812
\.


--
-- Data for Name: attachments; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.attachments (filename, "originalName", "filePath", "fileSize", "mimeType", "uploadedBy", "createdAt", id, "caseId", case_id, verification_task_id) FROM stdin;
\.


--
-- Data for Name: auditLogs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."auditLogs" ("userId", action, "entityType", "entityId", "oldValues", "newValues", "ipAddress", "userAgent", "createdAt", id, details) FROM stdin;
\.


--
-- Data for Name: autoSaves; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."autoSaves" ("userId", "formData", "createdAt", id, "caseId", case_id) FROM stdin;
\.


--
-- Data for Name: backgroundSyncQueue; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."backgroundSyncQueue" ("userId", action, "entityType", "entityData", status, "retryCount", "errorMessage", "createdAt", "processedAt", id) FROM stdin;
\.


--
-- Data for Name: builderVerificationReports; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."builderVerificationReports" (id, case_id, "caseId", form_type, verification_outcome, customer_name, customer_phone, customer_email, address_locatable, address_rating, full_address, locality, address_structure, address_floor, address_structure_color, door_color, company_nameplate_status, name_on_company_board, landmark1, landmark2, office_status, office_existence, builder_type, company_nature_of_business, business_period, establishment_period, office_approx_area, staff_strength, staff_seen, met_person_name, designation, builder_name, builder_owner_name, working_period, working_status, document_shown, tpc_met_person1, tpc_name1, tpc_confirmation1, tpc_met_person2, tpc_name2, tpc_confirmation2, shifted_period, old_office_shifted_period, current_company_name, current_company_period, premises_status, name_of_met_person, met_person_type, met_person_confirmation, applicant_working_status, contact_person, call_remark, political_connection, dominated_area, feedback_from_neighbour, other_observation, other_extra_remark, final_status, hold_reason, recommendation_status, verification_date, verification_time, verified_by, remarks, total_images, total_selfies, created_at, updated_at, landmark3, landmark4, applicant_designation, verification_task_id, report_sha256_hash, report_server_signature, report_generated_at, is_final) FROM stdin;
\.


--
-- Data for Name: businessVerificationReports; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."businessVerificationReports" (id, case_id, "caseId", form_type, verification_outcome, customer_name, customer_phone, customer_email, address_locatable, address_rating, full_address, locality, address_structure, address_floor, address_structure_color, door_color, company_nameplate_status, name_on_company_board, landmark1, landmark2, business_status, business_existence, business_type, ownership_type, address_status, company_nature_of_business, business_period, establishment_period, business_approx_area, staff_strength, staff_seen, met_person_name, designation, name_of_company_owners, owner_name, business_owner_name, document_shown, tpc_met_person1, tpc_name1, tpc_confirmation1, tpc_met_person2, tpc_name2, tpc_confirmation2, shifted_period, old_business_shifted_period, current_company_name, current_company_period, premises_status, name_of_met_person, met_person_type, met_person_confirmation, applicant_working_status, contact_person, call_remark, political_connection, dominated_area, feedback_from_neighbour, other_observation, other_extra_remark, final_status, hold_reason, recommendation_status, verification_date, verification_time, verified_by, remarks, total_images, total_selfies, created_at, updated_at, business_activity, business_setup, applicant_designation, working_period, working_status, applicant_working_premises, document_type, name_of_tpc1, name_of_tpc2, verification_task_id, landmark3, landmark4, report_sha256_hash, report_server_signature, report_generated_at, is_final) FROM stdin;
\.


--
-- Data for Name: caseDeduplicationAudit; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."caseDeduplicationAudit" ("searchCriteria", "duplicatesFound", "userDecision", rationale, "performedBy", "performedAt", id, "caseId", case_id) FROM stdin;
\.


--
-- Data for Name: case_assignment_conflicts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.case_assignment_conflicts (id, "caseId", "conflictType", "serverAssignedTo", "clientAssignedTo", "detectedAt", "resolvedAt", "resolvedBy", "resolutionStrategy", "resolutionData", status, metadata) FROM stdin;
\.


--
-- Data for Name: case_assignment_history; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.case_assignment_history (id, "previousAssignee", "newAssignee", reason, "assignedBy", "assignedAt", "createdAt", "caseId", case_id, "fromUserId", "toUserId", "assignedById", "batchId", metadata, "caseUUID") FROM stdin;
\.


--
-- Data for Name: case_assignment_queue_status; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.case_assignment_queue_status (id, "batchId", "jobId", "createdById", "assignedToId", status, "totalCases", "processedCases", "successfulAssignments", "failedAssignments", "startedAt", "completedAt", "createdAt", "updatedAt", errors, metadata) FROM stdin;
\.


--
-- Data for Name: case_configuration_errors; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.case_configuration_errors (id, case_id, error_code, error_message, error_details, created_at, resolved_at, resolved_by) FROM stdin;
\.


--
-- Data for Name: case_status_history; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.case_status_history (id, "caseId", status, "transitionedAt", "transitionedBy", "transitionReason", "createdAt", "updatedAt", case_id) FROM stdin;
\.


--
-- Data for Name: case_timeline_events; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.case_timeline_events (id, case_id, event_type, event_category, performed_by, event_data, previous_value, new_value, event_description, is_system_generated, event_timestamp, created_at) FROM stdin;
\.


--
-- Data for Name: cases; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.cases ("clientId", "productId", "verificationTypeId", "cityId", pincode, status, priority, "createdAt", "updatedAt", "panNumber", "deduplicationChecked", "deduplicationDecision", "deduplicationRationale", "applicantType", "backendContactNumber", trigger, "caseId", "customerName", "customerCallingCode", "customerPhone", "verificationType", "createdByBackendUser", revokereason, revokedat, "revokeReason", "revokedAt", id, form_completion_percentage, quality_score, last_form_submitted_at, total_forms_required, forms_submitted_count, validation_issues_count, "verificationData", "verificationOutcome", "completedAt", "rateTypeId", has_multiple_tasks, total_tasks_count, completed_tasks_count, case_completion_percentage) FROM stdin;
\.


--
-- Data for Name: cities; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.cities (name, "createdAt", "updatedAt", id, "stateId", "countryId") FROM stdin;
Thane	2025-10-31 11:04:06.392538+05:30	2025-10-31 11:04:06.392538+05:30	2	1	1
Raigarh	2025-10-31 11:04:08.096227+05:30	2025-10-31 11:04:08.096227+05:30	3	1	1
Montgomery	2026-02-25 01:05:11.042921+05:30	2026-02-25 01:05:11.042921+05:30	4	2	2
Mumbai	2025-10-31 11:04:05.176441+05:30	2026-02-25 01:11:31.411779+05:30	1	1	1
\.


--
-- Data for Name: clientDocumentTypes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."clientDocumentTypes" (id, "clientId", "documentTypeId", is_mandatory, is_active, display_order, created_by, updated_by, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: clientProducts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."clientProducts" ("isActive", "createdAt", "updatedAt", id, "clientId", "productId") FROM stdin;
\.


--
-- Data for Name: clients; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.clients (name, code, email, phone, address, "isActive", "createdAt", "updatedAt", id) FROM stdin;
\.


--
-- Data for Name: commission_batch_items; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.commission_batch_items (id, batch_id, commission_id, amount, created_at) FROM stdin;
\.


--
-- Data for Name: commission_calculations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.commission_calculations (id, case_id, case_number, user_id, client_id, rate_type_id, base_amount, commission_amount, calculated_commission, currency, calculation_method, status, case_completed_at, approved_by, approved_at, paid_by, paid_at, payment_method, transaction_id, rejection_reason, notes, created_at, updated_at, verification_task_id) FROM stdin;
\.


--
-- Data for Name: commission_payment_batches; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.commission_payment_batches (id, batch_number, total_amount, total_commissions, currency, payment_method, payment_date, status, created_by, processed_by, notes, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: commission_rate_types; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.commission_rate_types (id, rate_type_id, commission_amount, currency, is_active, created_by, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: countries; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.countries (name, code, continent, "createdAt", "updatedAt", id) FROM stdin;
United States	US	North America	2026-02-25 01:01:38.017654+05:30	2026-02-25 01:01:38.017654+05:30	2
India	IND	Asia	2025-10-31 11:04:05.166093+05:30	2026-02-25 01:11:04.862903+05:30	1
\.


--
-- Data for Name: departments; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.departments (name, description, "departmentHeadId", "isActive", "createdAt", "updatedAt", "createdBy", "updatedBy", id, "parentDepartmentId") FROM stdin;
IT	Information Technology department responsible for system administration and technical support	\N	t	2025-08-13 21:31:44.431671+05:30	2025-08-13 21:31:44.431671+05:30	\N	\N	1	\N
Operations	Operations department handling day-to-day business operations and field activities	\N	t	2025-08-13 21:31:44.431671+05:30	2025-08-13 21:31:44.431671+05:30	\N	\N	2	\N
Field Agent Department	Department For Field User	\N	t	2025-08-14 16:07:42.952544+05:30	2026-03-26 00:01:54.483433+05:30	70dcf247-759c-405d-a8fb-4c78b7b77747	70dcf247-759c-405d-a8fb-4c78b7b77747	5	2
\.


--
-- Data for Name: designations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.designations (name, description, "isActive", "createdAt", "updatedAt", "createdBy", "updatedBy", id, "departmentId") FROM stdin;
Manager	Manager For Multiple product access	t	2025-08-14 17:18:04.919487+05:30	2025-08-17 20:54:00.670391+05:30	70dcf247-759c-405d-a8fb-4c78b7b77747	70dcf247-759c-405d-a8fb-4c78b7b77747	3	2
Team Lead	Leads a team of developers	t	2025-08-14 12:35:44.546501+05:30	2025-08-17 20:54:00.670391+05:30	\N	70dcf247-759c-405d-a8fb-4c78b7b77747	4	2
Backend User	Handles day-to-day operations	t	2025-08-14 12:35:44.546501+05:30	2025-11-07 12:31:04.931824+05:30	\N	70dcf247-759c-405d-a8fb-4c78b7b77747	1	2
Field Agent	Handel Daily Field Verification Activity	t	2025-08-14 19:04:12.628982+05:30	2025-11-07 12:31:31.200151+05:30	70dcf247-759c-405d-a8fb-4c78b7b77747	70dcf247-759c-405d-a8fb-4c78b7b77747	2	2
Operation Head	Watch Daily Operation Activities	t	2025-11-07 12:32:27.790615+05:30	2025-11-07 12:32:27.790615+05:30	70dcf247-759c-405d-a8fb-4c78b7b77747	70dcf247-759c-405d-a8fb-4c78b7b77747	5	2
\.


--
-- Data for Name: documentTypeRates; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."documentTypeRates" (id, "clientId", "productId", "documentTypeId", amount, currency, "isActive", "effectiveFrom", "effectiveTo", "createdBy", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: documentTypes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."documentTypes" (id, name, code, created_by, updated_by, "createdAt", "updatedAt") FROM stdin;
1	Aadhaar Card	AADHAAR	70dcf247-759c-405d-a8fb-4c78b7b77747	70dcf247-759c-405d-a8fb-4c78b7b77747	2025-10-25 12:58:41.922388	2025-10-25 12:58:41.922388
2	PAN Card	PAN	70dcf247-759c-405d-a8fb-4c78b7b77747	70dcf247-759c-405d-a8fb-4c78b7b77747	2025-10-25 12:58:41.922388	2025-10-25 12:58:41.922388
4	Voter ID	VOTER_ID	70dcf247-759c-405d-a8fb-4c78b7b77747	70dcf247-759c-405d-a8fb-4c78b7b77747	2025-10-25 12:58:41.922388	2025-10-25 12:58:41.922388
5	Driving License	DRIVING_LICENSE	70dcf247-759c-405d-a8fb-4c78b7b77747	70dcf247-759c-405d-a8fb-4c78b7b77747	2025-10-25 12:58:41.922388	2025-10-25 12:58:41.922388
6	Electricity Bill	ELECTRICITY_BILL	70dcf247-759c-405d-a8fb-4c78b7b77747	70dcf247-759c-405d-a8fb-4c78b7b77747	2025-10-25 12:58:41.922388	2025-10-25 12:58:41.922388
7	Bank Statement	BANK_STATEMENT	70dcf247-759c-405d-a8fb-4c78b7b77747	70dcf247-759c-405d-a8fb-4c78b7b77747	2025-10-25 12:58:41.922388	2025-10-25 12:58:41.922388
8	Salary Slip	SALARY_SLIP	70dcf247-759c-405d-a8fb-4c78b7b77747	70dcf247-759c-405d-a8fb-4c78b7b77747	2025-10-25 12:58:41.922388	2025-10-25 12:58:41.922388
9	Property Documents	PROPERTY_DOCS	70dcf247-759c-405d-a8fb-4c78b7b77747	70dcf247-759c-405d-a8fb-4c78b7b77747	2025-10-25 12:58:41.922388	2025-10-25 12:58:41.922388
10	GST Certificate	GST_CERTIFICATE	70dcf247-759c-405d-a8fb-4c78b7b77747	70dcf247-759c-405d-a8fb-4c78b7b77747	2025-10-25 12:58:41.922388	2025-10-25 12:58:41.922388
3	Passport	PASSPORT	70dcf247-759c-405d-a8fb-4c78b7b77747	70dcf247-759c-405d-a8fb-4c78b7b77747	2025-10-25 12:58:41.922388	2026-02-24 12:31:55.392099
11	Employee ID	EMPLOYEEID	70dcf247-759c-405d-a8fb-4c78b7b77747	70dcf247-759c-405d-a8fb-4c78b7b77747	2026-02-25 00:08:03.34093	2026-02-25 00:08:03.34093
\.


--
-- Data for Name: dsaConnectorVerificationReports; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."dsaConnectorVerificationReports" (id, case_id, "caseId", form_type, verification_outcome, customer_name, customer_phone, customer_email, address_locatable, address_rating, full_address, locality, address_structure, address_floor, address_structure_color, door_color, landmark1, landmark2, landmark3, landmark4, connector_type, connector_code, connector_name, connector_designation, connector_experience, connector_status, business_name, business_type, business_registration_number, business_establishment_year, office_type, office_area, office_rent, total_staff, sales_staff, support_staff, team_size, monthly_business_volume, average_monthly_sales, annual_turnover, monthly_income, commission_structure, payment_terms, bank_account_details, computer_systems, internet_connection, software_systems, pos_terminals, printer_scanner, license_status, license_number, license_expiry_date, compliance_status, audit_status, training_status, met_person_name, met_person_designation, met_person_relation, met_person_contact, business_operational, customer_footfall, business_hours, weekend_operations, tpc_met_person1, tpc_name1, tpc_confirmation1, tpc_met_person2, tpc_name2, tpc_confirmation2, shifted_period, current_location, premises_status, previous_business_name, entry_restriction_reason, security_person_name, security_confirmation, contact_person, call_remark, market_presence, competitor_analysis, market_reputation, customer_feedback, political_connection, dominated_area, feedback_from_neighbour, infrastructure_status, commercial_viability, other_observation, business_concerns, operational_challenges, growth_potential, final_status, hold_reason, recommendation_status, risk_assessment, verification_date, verification_time, verified_by, remarks, total_images, total_selfies, created_at, updated_at, verification_task_id, report_sha256_hash, report_server_signature, report_generated_at, is_final) FROM stdin;
\.


--
-- Data for Name: error_logs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.error_logs (id, error_type, error_message, stack_trace, request_id, user_id, url, additional_data, "timestamp") FROM stdin;
\.


--
-- Data for Name: field_user_commission_assignments; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.field_user_commission_assignments (id, user_id, rate_type_id, commission_amount, currency, client_id, is_active, effective_from, effective_to, created_by, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: form_quality_metrics; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.form_quality_metrics (id, form_submission_id, overall_quality_score, completeness_score, accuracy_score, photo_quality_score, timeliness_score, consistency_score, calculated_at, calculated_by, notes, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: form_submissions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.form_submissions (id, case_id, verification_task_id, verification_type_id, form_type, submitted_by, submission_data, validation_status, validation_errors, photos_count, attachments_count, geo_location, submission_score, time_spent_minutes, device_info, network_quality, submitted_at, validated_at, validated_by, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: form_validation_logs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.form_validation_logs (id, form_submission_id, field_name, field_value, is_valid, error_message, validation_rule, validated_at, validated_by, created_at) FROM stdin;
\.


--
-- Data for Name: invoice_item_tasks; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.invoice_item_tasks (id, invoice_item_id, verification_task_id, case_id, client_id, billed_amount, created_at) FROM stdin;
\.


--
-- Data for Name: invoice_items; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.invoice_items (id, invoice_id, client_id, product_id, verification_type_id, rate_type_id, description, quantity, unit_price, amount, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: invoice_status_history; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.invoice_status_history (id, invoice_id, from_status, to_status, changed_by, notes, changed_at) FROM stdin;
\.


--
-- Data for Name: invoices; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.invoices (id, invoice_number, client_id, product_id, client_name, amount, subtotal_amount, tax_amount, total_amount, currency, status, billing_period_from, billing_period_to, issue_date, due_date, approved_by, approved_at, sent_at, paid_date, payment_method, transaction_id, notes, created_by, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: locations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.locations (latitude, longitude, accuracy, "recordedBy", "recordedAt", id, "caseId", case_id, verification_task_id) FROM stdin;
\.


--
-- Data for Name: migrations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.migrations (id, filename, "executedAt") FROM stdin;
001_complete_case_deduplication_system	001_complete_case_deduplication_system.sql	2025-08-18 02:06:06.410354+05:30
002_field_agent_territory_assignments	002_field_agent_territory_assignments.sql	2025-08-18 16:22:05.846255+05:30
003_add_attached_pincode_to_users	003_add_attached_pincode_to_users.sql	2025-08-19 12:18:21.137141+05:30
004_remove_attached_pincode_from_users	004_remove_attached_pincode_from_users.sql	2025-08-19 13:15:06.972817+05:30
004_add_missing_case_fields	004_add_missing_case_fields.sql	2025-08-19 15:16:36.38201+05:30
005_user_product_assignments_and_access_control	005_user_product_assignments_and_access_control.sql	2025-08-20 13:08:07.663682+05:30
006_update_cases_created_by_field	006_update_cases_created_by_field.sql	2025-08-22 00:50:01.380749+05:30
20250821_create_mobile_notification_audit	20250821_create_mobile_notification_audit.sql	2025-08-22 02:24:07.991872+05:30
007_add_revoke_columns	007_add_revoke_columns.sql	2025-08-25 14:28:12.061652+05:30
001_case_status_history	001_case_status_history.sql	2025-08-25 14:38:08.683716+05:30
002_add_revoke_columns	002_add_revoke_columns.sql	2025-08-25 14:38:08.695823+05:30
003_add_unassigned_status_support	003_add_unassigned_status_support.sql	2025-08-26 12:29:46.000007+05:30
20250831_standardize_cases_schema_v2	20250831_standardize_cases_schema_v2.sql	2025-09-01 01:14:42.653304+05:30
001_create_notifications_schema	001_create_notifications_schema.sql	2025-09-13 21:18:06.811471+05:30
\.


--
-- Data for Name: mobile_device_sync; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.mobile_device_sync (id, "userId", "deviceId", "lastSyncAt", "appVersion", platform, "syncCount", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: mobile_notification_audit; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.mobile_notification_audit (id, "notificationId", "userId", "caseId", "notificationType", "notificationData", "sentAt", "deliveryStatus", "acknowledgedAt", metadata, "createdAt", "updatedAt", case_id) FROM stdin;
\.


--
-- Data for Name: mobile_notification_queue; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.mobile_notification_queue (id, "userId", "notificationType", title, message, data, status, "scheduledAt", "sentAt", "failedAt", "retryCount", "maxRetries", error, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: nocVerificationReports; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."nocVerificationReports" (id, case_id, "caseId", form_type, verification_outcome, customer_name, customer_phone, customer_email, address_locatable, address_rating, full_address, locality, address_structure, address_floor, address_structure_color, door_color, landmark1, landmark2, landmark3, landmark4, noc_status, noc_type, noc_number, noc_issue_date, noc_expiry_date, noc_issuing_authority, noc_validity_status, property_type, project_name, project_status, construction_status, project_approval_status, total_units, completed_units, sold_units, possession_status, builder_name, builder_contact, developer_name, developer_contact, builder_registration_number, met_person_name, met_person_designation, met_person_relation, met_person_contact, document_shown_status, document_type, document_verification_status, tpc_met_person1, tpc_name1, tpc_confirmation1, tpc_met_person2, tpc_name2, tpc_confirmation2, shifted_period, current_location, premises_status, entry_restriction_reason, security_person_name, security_confirmation, contact_person, call_remark, environmental_clearance, fire_safety_clearance, pollution_clearance, water_connection_status, electricity_connection_status, political_connection, dominated_area, feedback_from_neighbour, infrastructure_status, road_connectivity, other_observation, compliance_issues, regulatory_concerns, final_status, hold_reason, recommendation_status, verification_date, verification_time, verified_by, remarks, total_images, total_selfies, created_at, updated_at, verification_task_id, report_sha256_hash, report_server_signature, report_generated_at, is_final) FROM stdin;
\.


--
-- Data for Name: notificationTokens; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."notificationTokens" ("userId", token, platform, "isActive", "createdAt", id) FROM stdin;
\.


--
-- Data for Name: notification_batches; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.notification_batches (id, batch_name, batch_type, target_user_ids, target_roles, status, total_notifications, sent_notifications, failed_notifications, scheduled_at, started_at, completed_at, created_by, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: notification_delivery_log; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.notification_delivery_log (id, notification_id, delivery_method, attempt_number, delivery_status, error_code, error_message, device_id, platform, push_token_used, attempted_at, completed_at, response_data) FROM stdin;
\.


--
-- Data for Name: notification_preferences; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.notification_preferences (id, user_id, case_assignment_enabled, case_assignment_push, case_assignment_websocket, case_reassignment_enabled, case_reassignment_push, case_reassignment_websocket, case_completion_enabled, case_completion_push, case_completion_websocket, case_revocation_enabled, case_revocation_push, case_revocation_websocket, system_notifications_enabled, system_notifications_push, system_notifications_websocket, quiet_hours_enabled, quiet_hours_start, quiet_hours_end, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: notification_tokens; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.notification_tokens (id, user_id, device_id, platform, push_token, is_active, created_at, updated_at, last_used_at) FROM stdin;
\.


--
-- Data for Name: notifications; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.notifications (id, user_id, title, message, type, case_id, case_number, data, action_url, action_type, is_read, read_at, delivery_status, sent_at, delivered_at, acknowledged_at, priority, expires_at, created_at, updated_at, task_id, task_number) FROM stdin;
\.


--
-- Data for Name: officeVerificationReports; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."officeVerificationReports" (id, case_id, "caseId", form_type, verification_outcome, customer_name, customer_phone, customer_email, address_locatable, address_rating, full_address, locality, address_structure, address_floor, address_structure_color, door_color, company_nameplate_status, name_on_company_board, landmark1, landmark2, office_status, office_existence, office_type, company_nature_of_business, business_period, establishment_period, office_approx_area, staff_strength, staff_seen, met_person_name, designation, applicant_designation, working_period, working_status, applicant_working_premises, sitting_location, current_company_name, document_shown, tpc_met_person1, tpc_name1, tpc_confirmation1, tpc_met_person2, tpc_name2, tpc_confirmation2, shifted_period, old_office_shifted_period, current_company_period, premises_status, name_of_met_person, met_person_type, met_person_confirmation, applicant_working_status, contact_person, call_remark, political_connection, dominated_area, feedback_from_neighbour, other_observation, other_extra_remark, final_status, hold_reason, recommendation_status, verification_date, verification_time, verified_by, remarks, total_images, total_selfies, created_at, updated_at, landmark3, landmark4, document_type, name_of_tpc1, name_of_tpc2, verification_task_id, report_sha256_hash, report_server_signature, report_generated_at, is_final) FROM stdin;
\.


--
-- Data for Name: performance_metrics; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.performance_metrics (id, request_id, method, url, status_code, response_time, memory_usage, user_id, "timestamp") FROM stdin;
\.


--
-- Data for Name: permissions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.permissions (id, code, module, description) FROM stdin;
b81a18e1-5523-4c99-834f-c9729458cfab	case.view	case	View cases
6a21d9b5-d839-4271-9fa2-2cd54eb80fdc	case.create	case	Create cases
9fcda086-8d71-445f-8003-0f8034931055	case.assign	case	Assign case/visit
14c315ed-336b-422d-b83b-e86347d8398a	case.reassign	case	Reassign case/visit
85263aa4-961e-41c3-b901-a849db60b5d1	case.update	case	Update case
731479d3-9f86-4a0e-9dae-56eca5f4f2b0	case.delete	case	Delete case
c2e4fee4-dde2-4952-9a8e-3736e8a7d05a	visit.start	visit	Start visit
017d46f3-af7d-4ed5-a73c-f6213032d218	visit.upload	visit	Upload visit evidence
b71c4aed-b5bd-4d1d-9be1-8285563f8d5b	visit.submit	visit	Submit visit
87697e58-0ee8-4df9-82d4-02c8f073ba3c	visit.revoke	visit	Revoke visit
15744cb8-6bee-4724-bc69-13000dad3e64	visit.revisit	visit	Create revisit visit
09e1fc5c-0f37-487b-b8a3-5caa6b80630b	review.view	review	View review
58923475-afdf-4b3b-968f-60ebf4a2f255	review.approve	review	Approve review
30488167-50a1-4fb7-af82-039da7be6711	review.rework	review	Send review rework
8bf5a9bc-08db-4181-8a1a-a549d46545a1	report.generate	report	Generate report
80fc1c81-ece4-46e7-b14a-5c90d70e1b66	report.download	report	Download report
696ec806-4b45-4580-8489-682d56f08def	billing.generate	billing	Generate billing
37457e0f-589f-4ab6-b66e-3b87e6b06ab4	billing.download	billing	Download billing
f008c3cb-46e1-4b24-a4d2-edf9004f5fdd	billing.approve	billing	Approve billing
d3cef74e-9efd-49d2-aacf-0b9ff0301f18	user.view	user	View users
89f49a4f-9071-4959-97f8-bd488af51e16	user.create	user	Create users
ffb6354b-2a8f-47cc-a8c0-a8a53d13797d	user.update	user	Update users
98c8c37d-3789-49b8-90f5-f5053e103b75	user.delete	user	Delete users
7a5a847e-7648-48ab-935b-8ef4fae2791d	role.manage	user	Manage roles
2e631b76-d12a-41fd-9d87-2680093ed1e5	permission.manage	user	Manage permissions
d7ad5160-4090-4c69-849f-2041b0841caa	territory.assign	user	Assign territories
03d8d720-393e-4768-883a-0fb886e63a0b	dashboard.view	system	View dashboard
a415148a-67f7-4e16-b017-1ad2859b4d2a	settings.manage	system	Manage settings
dbe2f5c2-638d-4238-9bfa-2240c8621a4c	page.dashboard	page	Access Dashboard page
3fc9017a-bbae-480a-8772-483a3fe63b55	page.cases	page	Access Case Management pages
1b5c86ab-fbd6-4817-8d2a-25ab40773071	page.tasks	page	Access Task Management pages
b7482c7e-388b-4dae-abdd-9d07c8fd9f40	page.reports	page	Access Reports pages
8e88cc67-b221-4556-ac00-18e8abdaefcf	page.billing	page	Access Billing and Commission pages
b3aac259-0cc8-45e7-a5eb-dc082b456709	page.users	page	Access User Management pages
91829baa-7c75-4213-ac08-41a3a164a100	page.rbac	page	Access RBAC Administration page
b5c73624-b4c7-407b-a8ac-a2c8da7f022f	page.settings	page	Access Settings page
a2cf843d-91da-4e2f-9fe5-b4d54c39dff1	page.masterdata	page	Access Master Data pages
7a787002-535f-468b-9b44-d90dcbeeedaf	page.analytics	page	Access Analytics and MIS pages
e8cd673b-30dc-49d9-a09d-0ecf7cbe573e	page.mobile	page	Access Mobile Web page
c2203837-7ddc-40bb-a93f-3913dc33f5fa	page.field_monitoring	page	Access Field Executive Monitoring Dashboard
bd10b273-edf2-450f-9cc4-58a4ef0556a3	task.revoke	task	Administrative task revocation
\.


--
-- Data for Name: pincodeAreas; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."pincodeAreas" ("displayOrder", "createdAt", "updatedAt", id, "pincodeId", "areaId") FROM stdin;
5	2025-10-31 11:04:09.193161+05:30	2025-10-31 11:04:09.193161+05:30	841	198	823
6	2025-10-31 11:04:09.196887+05:30	2025-10-31 11:04:09.196887+05:30	842	198	824
19	2025-10-31 11:04:09.219421+05:30	2025-10-31 11:04:09.219421+05:30	843	187	825
22	2025-10-31 11:04:09.222461+05:30	2025-10-31 11:04:09.222461+05:30	844	183	826
10	2025-10-31 11:04:09.22549+05:30	2025-10-31 11:04:09.22549+05:30	845	188	827
1	2025-10-31 11:04:09.227704+05:30	2025-10-31 11:04:09.227704+05:30	846	215	828
25	2025-10-31 11:04:09.230193+05:30	2025-10-31 11:04:09.230193+05:30	847	184	829
8	2025-10-31 11:04:09.233011+05:30	2025-10-31 11:04:09.233011+05:30	848	192	830
7	2025-10-31 11:04:09.236076+05:30	2025-10-31 11:04:09.236076+05:30	849	198	831
22	2025-10-31 11:04:09.239888+05:30	2025-10-31 11:04:09.239888+05:30	850	178	832
11	2025-10-31 11:04:09.243882+05:30	2025-10-31 11:04:09.243882+05:30	851	188	833
7	2025-10-31 11:04:09.265498+05:30	2025-10-31 11:04:09.265498+05:30	852	193	834
8	2025-10-31 11:04:09.271744+05:30	2025-10-31 11:04:09.271744+05:30	853	180	835
12	2025-10-31 11:04:09.274876+05:30	2025-10-31 11:04:09.274876+05:30	854	188	836
11	2025-10-31 11:04:09.277676+05:30	2025-10-31 11:04:09.277676+05:30	855	179	837
23	2025-10-31 11:04:09.280563+05:30	2025-10-31 11:04:09.280563+05:30	856	183	838
24	2025-10-31 11:04:09.283394+05:30	2025-10-31 11:04:09.283394+05:30	857	183	839
23	2025-10-31 11:04:09.286712+05:30	2025-10-31 11:04:09.286712+05:30	858	178	840
24	2025-10-31 11:04:09.290736+05:30	2025-10-31 11:04:09.290736+05:30	859	178	841
9	2025-10-31 11:04:09.294694+05:30	2025-10-31 11:04:09.294694+05:30	860	194	842
25	2025-10-31 11:04:09.316499+05:30	2025-10-31 11:04:09.316499+05:30	861	183	843
10	2025-10-31 11:04:09.320576+05:30	2025-10-31 11:04:09.320576+05:30	862	182	844
25	2025-10-31 11:04:09.324115+05:30	2025-10-31 11:04:09.324115+05:30	863	178	845
3	2025-10-31 11:04:09.327537+05:30	2025-10-31 11:04:09.327537+05:30	864	208	846
6	2025-10-31 11:04:09.330552+05:30	2025-10-31 11:04:09.330552+05:30	865	199	847
26	2025-10-31 11:04:09.333463+05:30	2025-10-31 11:04:09.333463+05:30	866	184	848
7	2025-10-31 11:04:09.337223+05:30	2025-10-31 11:04:09.337223+05:30	867	200	849
4	2025-10-31 11:04:09.341423+05:30	2025-10-31 11:04:09.341423+05:30	868	195	850
5	2025-10-31 11:04:09.345375+05:30	2025-10-31 11:04:09.345375+05:30	869	191	851
20	2025-10-31 11:04:09.366343+05:30	2025-10-31 11:04:09.366343+05:30	870	187	852
12	2025-10-31 11:04:09.370987+05:30	2025-10-31 11:04:09.370987+05:30	871	179	853
6	2025-10-31 11:04:09.374652+05:30	2025-10-31 11:04:09.374652+05:30	872	185	854
21	2025-10-31 11:04:09.377916+05:30	2025-10-31 11:04:09.377916+05:30	873	187	855
5	2025-10-31 11:04:09.380766+05:30	2025-10-31 11:04:09.380766+05:30	874	195	856
26	2025-10-31 11:04:09.38379+05:30	2025-10-31 11:04:09.38379+05:30	875	183	857
26	2025-10-31 11:04:09.387716+05:30	2025-10-31 11:04:09.387716+05:30	876	178	858
27	2025-10-31 11:04:09.391537+05:30	2025-10-31 11:04:09.391537+05:30	877	178	859
5	2025-10-31 11:04:09.39567+05:30	2025-10-31 11:04:09.39567+05:30	878	207	860
8	2025-10-31 11:04:09.41739+05:30	2025-10-31 11:04:09.41739+05:30	879	198	861
6	2025-10-31 11:04:09.421063+05:30	2025-10-31 11:04:09.421063+05:30	880	207	862
1	2025-10-31 11:04:05.184884+05:30	2025-10-31 11:04:05.184884+05:30	1	1	1
1	2025-10-31 11:04:05.190263+05:30	2025-10-31 11:04:05.190263+05:30	2	2	2
1	2025-10-31 11:04:05.195868+05:30	2025-10-31 11:04:05.195868+05:30	3	3	3
1	2025-10-31 11:04:05.218051+05:30	2025-10-31 11:04:05.218051+05:30	4	4	4
1	2025-10-31 11:04:05.222044+05:30	2025-10-31 11:04:05.222044+05:30	5	5	5
1	2025-10-31 11:04:05.233436+05:30	2025-10-31 11:04:05.233436+05:30	6	6	6
1	2025-10-31 11:04:05.236917+05:30	2025-10-31 11:04:05.236917+05:30	7	7	7
1	2025-10-31 11:04:05.24054+05:30	2025-10-31 11:04:05.24054+05:30	8	8	8
1	2025-10-31 11:04:05.245969+05:30	2025-10-31 11:04:05.245969+05:30	9	9	9
1	2025-10-31 11:04:05.27041+05:30	2025-10-31 11:04:05.27041+05:30	10	10	10
2	2025-10-31 11:04:05.278937+05:30	2025-10-31 11:04:05.278937+05:30	11	6	11
2	2025-10-31 11:04:05.284907+05:30	2025-10-31 11:04:05.284907+05:30	12	8	12
1	2025-10-31 11:04:05.295742+05:30	2025-10-31 11:04:05.295742+05:30	13	11	13
1	2025-10-31 11:04:05.316548+05:30	2025-10-31 11:04:05.316548+05:30	14	12	14
1	2025-10-31 11:04:05.319275+05:30	2025-10-31 11:04:05.319275+05:30	15	13	15
2	2025-10-31 11:04:05.322655+05:30	2025-10-31 11:04:05.322655+05:30	16	11	16
1	2025-10-31 11:04:05.32559+05:30	2025-10-31 11:04:05.32559+05:30	17	14	17
1	2025-10-31 11:04:05.328192+05:30	2025-10-31 11:04:05.328192+05:30	18	15	18
1	2025-10-31 11:04:05.331099+05:30	2025-10-31 11:04:05.331099+05:30	19	16	19
1	2025-10-31 11:04:05.336878+05:30	2025-10-31 11:04:05.336878+05:30	20	17	20
1	2025-10-31 11:04:05.341454+05:30	2025-10-31 11:04:05.341454+05:30	21	18	21
1	2025-10-31 11:04:05.365628+05:30	2025-10-31 11:04:05.365628+05:30	22	19	22
1	2025-10-31 11:04:05.369979+05:30	2025-10-31 11:04:05.369979+05:30	23	20	23
1	2025-10-31 11:04:05.377359+05:30	2025-10-31 11:04:05.377359+05:30	24	21	24
1	2025-10-31 11:04:05.380828+05:30	2025-10-31 11:04:05.380828+05:30	25	22	25
2	2025-10-31 11:04:05.387082+05:30	2025-10-31 11:04:05.387082+05:30	26	22	26
1	2025-10-31 11:04:05.390815+05:30	2025-10-31 11:04:05.390815+05:30	27	23	27
1	2025-10-31 11:04:05.416181+05:30	2025-10-31 11:04:05.416181+05:30	28	24	28
2	2025-10-31 11:04:05.420159+05:30	2025-10-31 11:04:05.420159+05:30	29	24	29
1	2025-10-31 11:04:05.423128+05:30	2025-10-31 11:04:05.423128+05:30	30	25	30
1	2025-10-31 11:04:05.426017+05:30	2025-10-31 11:04:05.426017+05:30	31	26	31
1	2025-10-31 11:04:05.428636+05:30	2025-10-31 11:04:05.428636+05:30	32	27	32
3	2025-10-31 11:04:05.432315+05:30	2025-10-31 11:04:05.432315+05:30	33	8	33
1	2025-10-31 11:04:05.443859+05:30	2025-10-31 11:04:05.443859+05:30	34	28	34
1	2025-10-31 11:04:05.446383+05:30	2025-10-31 11:04:05.446383+05:30	35	29	35
1	2025-10-31 11:04:05.467651+05:30	2025-10-31 11:04:05.467651+05:30	36	30	36
2	2025-10-31 11:04:05.471932+05:30	2025-10-31 11:04:05.471932+05:30	37	19	37
1	2025-10-31 11:04:05.474967+05:30	2025-10-31 11:04:05.474967+05:30	38	31	38
2	2025-10-31 11:04:05.479479+05:30	2025-10-31 11:04:05.479479+05:30	39	4	39
3	2025-10-31 11:04:05.483433+05:30	2025-10-31 11:04:05.483433+05:30	40	4	40
1	2025-10-31 11:04:05.489351+05:30	2025-10-31 11:04:05.489351+05:30	41	32	41
1	2025-10-31 11:04:05.491831+05:30	2025-10-31 11:04:05.491831+05:30	42	33	42
1	2025-10-31 11:04:05.494031+05:30	2025-10-31 11:04:05.494031+05:30	43	34	43
1	2025-10-31 11:04:05.496217+05:30	2025-10-31 11:04:05.496217+05:30	44	35	44
2	2025-10-31 11:04:05.517616+05:30	2025-10-31 11:04:05.517616+05:30	45	3	45
1	2025-10-31 11:04:05.520941+05:30	2025-10-31 11:04:05.520941+05:30	46	36	46
2	2025-10-31 11:04:05.524729+05:30	2025-10-31 11:04:05.524729+05:30	47	28	47
2	2025-10-31 11:04:05.527464+05:30	2025-10-31 11:04:05.527464+05:30	48	10	48
3	2025-10-31 11:04:05.530293+05:30	2025-10-31 11:04:05.530293+05:30	49	10	49
1	2025-10-31 11:04:05.532461+05:30	2025-10-31 11:04:05.532461+05:30	50	37	49
1	2025-10-31 11:04:05.534668+05:30	2025-10-31 11:04:05.534668+05:30	51	38	50
1	2025-10-31 11:04:05.536925+05:30	2025-10-31 11:04:05.536925+05:30	52	39	51
1	2025-10-31 11:04:05.539045+05:30	2025-10-31 11:04:05.539045+05:30	53	40	52
2	2025-10-31 11:04:05.541967+05:30	2025-10-31 11:04:05.541967+05:30	54	40	53
1	2025-10-31 11:04:05.566648+05:30	2025-10-31 11:04:05.566648+05:30	55	41	54
1	2025-10-31 11:04:05.570881+05:30	2025-10-31 11:04:05.570881+05:30	56	42	55
2	2025-10-31 11:04:05.576733+05:30	2025-10-31 11:04:05.576733+05:30	57	42	56
1	2025-10-31 11:04:05.579162+05:30	2025-10-31 11:04:05.579162+05:30	58	43	57
2	2025-10-31 11:04:05.585191+05:30	2025-10-31 11:04:05.585191+05:30	59	43	58
1	2025-10-31 11:04:05.588002+05:30	2025-10-31 11:04:05.588002+05:30	60	44	59
2	2025-10-31 11:04:05.590791+05:30	2025-10-31 11:04:05.590791+05:30	61	25	60
1	2025-10-31 11:04:05.592989+05:30	2025-10-31 11:04:05.592989+05:30	62	45	61
1	2025-10-31 11:04:05.595226+05:30	2025-10-31 11:04:05.595226+05:30	63	46	62
2	2025-10-31 11:04:05.61525+05:30	2025-10-31 11:04:05.61525+05:30	64	46	63
1	2025-10-31 11:04:05.618948+05:30	2025-10-31 11:04:05.618948+05:30	65	47	64
3	2025-10-31 11:04:05.622455+05:30	2025-10-31 11:04:05.622455+05:30	66	40	65
1	2025-10-31 11:04:05.625417+05:30	2025-10-31 11:04:05.625417+05:30	67	48	66
2	2025-10-31 11:04:05.632444+05:30	2025-10-31 11:04:05.632444+05:30	68	32	67
1	2025-10-31 11:04:05.634659+05:30	2025-10-31 11:04:05.634659+05:30	69	49	68
4	2025-10-31 11:04:05.637305+05:30	2025-10-31 11:04:05.637305+05:30	70	4	69
3	2025-10-31 11:04:05.640048+05:30	2025-10-31 11:04:05.640048+05:30	71	24	70
1	2025-10-31 11:04:05.642272+05:30	2025-10-31 11:04:05.642272+05:30	72	50	71
2	2025-10-31 11:04:05.644677+05:30	2025-10-31 11:04:05.644677+05:30	73	14	72
3	2025-10-31 11:04:05.663687+05:30	2025-10-31 11:04:05.663687+05:30	74	14	73
1	2025-10-31 11:04:05.668395+05:30	2025-10-31 11:04:05.668395+05:30	75	51	74
3	2025-10-31 11:04:05.672377+05:30	2025-10-31 11:04:05.672377+05:30	76	11	75
4	2025-10-31 11:04:05.675625+05:30	2025-10-31 11:04:05.675625+05:30	77	40	76
2	2025-10-31 11:04:05.67866+05:30	2025-10-31 11:04:05.67866+05:30	78	23	77
2	2025-10-31 11:04:05.681632+05:30	2025-10-31 11:04:05.681632+05:30	79	7	78
3	2025-10-31 11:04:05.684186+05:30	2025-10-31 11:04:05.684186+05:30	80	19	79
3	2025-10-31 11:04:05.689149+05:30	2025-10-31 11:04:05.689149+05:30	81	3	80
1	2025-10-31 11:04:05.691266+05:30	2025-10-31 11:04:05.691266+05:30	82	52	81
1	2025-10-31 11:04:05.693268+05:30	2025-10-31 11:04:05.693268+05:30	83	53	82
1	2025-10-31 11:04:05.695465+05:30	2025-10-31 11:04:05.695465+05:30	84	54	83
4	2025-10-31 11:04:05.716416+05:30	2025-10-31 11:04:05.716416+05:30	85	10	84
1	2025-10-31 11:04:05.720331+05:30	2025-10-31 11:04:05.720331+05:30	86	55	85
1	2025-10-31 11:04:05.723139+05:30	2025-10-31 11:04:05.723139+05:30	87	56	86
1	2025-10-31 11:04:05.725762+05:30	2025-10-31 11:04:05.725762+05:30	88	57	87
1	2025-10-31 11:04:05.728278+05:30	2025-10-31 11:04:05.728278+05:30	89	58	88
2	2025-10-31 11:04:05.731393+05:30	2025-10-31 11:04:05.731393+05:30	90	48	89
3	2025-10-31 11:04:05.733985+05:30	2025-10-31 11:04:05.733985+05:30	91	22	90
4	2025-10-31 11:04:05.736926+05:30	2025-10-31 11:04:05.736926+05:30	92	3	91
1	2025-10-31 11:04:05.739088+05:30	2025-10-31 11:04:05.739088+05:30	93	59	92
1	2025-10-31 11:04:05.741103+05:30	2025-10-31 11:04:05.741103+05:30	94	60	93
1	2025-10-31 11:04:05.767403+05:30	2025-10-31 11:04:05.767403+05:30	95	61	94
2	2025-10-31 11:04:05.771039+05:30	2025-10-31 11:04:05.771039+05:30	96	39	95
1	2025-10-31 11:04:05.773859+05:30	2025-10-31 11:04:05.773859+05:30	97	62	96
3	2025-10-31 11:04:05.776824+05:30	2025-10-31 11:04:05.776824+05:30	98	48	97
1	2025-10-31 11:04:05.778952+05:30	2025-10-31 11:04:05.778952+05:30	99	63	98
2	2025-10-31 11:04:05.78212+05:30	2025-10-31 11:04:05.78212+05:30	100	31	99
1	2025-10-31 11:04:05.784244+05:30	2025-10-31 11:04:05.784244+05:30	101	64	100
1	2025-10-31 11:04:05.786331+05:30	2025-10-31 11:04:05.786331+05:30	102	65	101
3	2025-10-31 11:04:05.788665+05:30	2025-10-31 11:04:05.788665+05:30	103	43	102
2	2025-10-31 11:04:05.790989+05:30	2025-10-31 11:04:05.790989+05:30	104	44	103
3	2025-10-31 11:04:05.793355+05:30	2025-10-31 11:04:05.793355+05:30	105	44	104
2	2025-10-31 11:04:05.795609+05:30	2025-10-31 11:04:05.795609+05:30	106	55	105
4	2025-10-31 11:04:05.815826+05:30	2025-10-31 11:04:05.815826+05:30	107	11	106
1	2025-10-31 11:04:05.819098+05:30	2025-10-31 11:04:05.819098+05:30	108	66	107
1	2025-10-31 11:04:05.821759+05:30	2025-10-31 11:04:05.821759+05:30	109	67	108
2	2025-10-31 11:04:05.825279+05:30	2025-10-31 11:04:05.825279+05:30	110	67	109
3	2025-10-31 11:04:05.827951+05:30	2025-10-31 11:04:05.827951+05:30	111	39	110
4	2025-10-31 11:04:05.830861+05:30	2025-10-31 11:04:05.830861+05:30	112	19	111
1	2025-10-31 11:04:05.833021+05:30	2025-10-31 11:04:05.833021+05:30	113	68	112
4	2025-10-31 11:04:05.835806+05:30	2025-10-31 11:04:05.835806+05:30	114	48	113
2	2025-10-31 11:04:05.838332+05:30	2025-10-31 11:04:05.838332+05:30	115	17	114
1	2025-10-31 11:04:05.840366+05:30	2025-10-31 11:04:05.840366+05:30	116	69	115
5	2025-10-31 11:04:05.842917+05:30	2025-10-31 11:04:05.842917+05:30	117	4	116
3	2025-10-31 11:04:05.845471+05:30	2025-10-31 11:04:05.845471+05:30	118	25	117
2	2025-10-31 11:04:05.865809+05:30	2025-10-31 11:04:05.865809+05:30	119	65	118
3	2025-10-31 11:04:05.870264+05:30	2025-10-31 11:04:05.870264+05:30	120	65	119
4	2025-10-31 11:04:05.875912+05:30	2025-10-31 11:04:05.875912+05:30	121	65	120
3	2025-10-31 11:04:05.879583+05:30	2025-10-31 11:04:05.879583+05:30	122	32	121
1	2025-10-31 11:04:05.884302+05:30	2025-10-31 11:04:05.884302+05:30	123	70	122
1	2025-10-31 11:04:05.886538+05:30	2025-10-31 11:04:05.886538+05:30	124	71	123
2	2025-10-31 11:04:05.889188+05:30	2025-10-31 11:04:05.889188+05:30	125	68	124
3	2025-10-31 11:04:05.891771+05:30	2025-10-31 11:04:05.891771+05:30	126	68	125
1	2025-10-31 11:04:05.893611+05:30	2025-10-31 11:04:05.893611+05:30	127	72	126
2	2025-10-31 11:04:05.896065+05:30	2025-10-31 11:04:05.896065+05:30	128	12	127
2	2025-10-31 11:04:05.917132+05:30	2025-10-31 11:04:05.917132+05:30	129	54	128
3	2025-10-31 11:04:05.921274+05:30	2025-10-31 11:04:05.921274+05:30	130	28	129
2	2025-10-31 11:04:05.924642+05:30	2025-10-31 11:04:05.924642+05:30	131	58	130
3	2025-10-31 11:04:05.927936+05:30	2025-10-31 11:04:05.927936+05:30	132	58	131
3	2025-10-31 11:04:05.93097+05:30	2025-10-31 11:04:05.93097+05:30	133	12	132
1	2025-10-31 11:04:05.933197+05:30	2025-10-31 11:04:05.933197+05:30	134	73	133
2	2025-10-31 11:04:05.935912+05:30	2025-10-31 11:04:05.935912+05:30	135	47	134
3	2025-10-31 11:04:05.938572+05:30	2025-10-31 11:04:05.938572+05:30	136	47	135
4	2025-10-31 11:04:05.941237+05:30	2025-10-31 11:04:05.941237+05:30	137	47	136
1	2025-10-31 11:04:05.943328+05:30	2025-10-31 11:04:05.943328+05:30	138	74	137
5	2025-10-31 11:04:05.945727+05:30	2025-10-31 11:04:05.945727+05:30	139	65	138
4	2025-10-31 11:04:05.96646+05:30	2025-10-31 11:04:05.96646+05:30	140	14	139
2	2025-10-31 11:04:05.970761+05:30	2025-10-31 11:04:05.970761+05:30	141	20	140
1	2025-10-31 11:04:05.97366+05:30	2025-10-31 11:04:05.97366+05:30	142	75	141
2	2025-10-31 11:04:05.977231+05:30	2025-10-31 11:04:05.977231+05:30	143	74	142
2	2025-10-31 11:04:05.980041+05:30	2025-10-31 11:04:05.980041+05:30	144	75	143
5	2025-10-31 11:04:05.98323+05:30	2025-10-31 11:04:05.98323+05:30	145	48	144
3	2025-10-31 11:04:05.986106+05:30	2025-10-31 11:04:05.986106+05:30	146	17	145
3	2025-10-31 11:04:05.988811+05:30	2025-10-31 11:04:05.988811+05:30	147	23	146
2	2025-10-31 11:04:05.996598+05:30	2025-10-31 11:04:05.996598+05:30	148	5	147
2	2025-10-31 11:04:06.01881+05:30	2025-10-31 11:04:06.01881+05:30	149	2	148
3	2025-10-31 11:04:06.022577+05:30	2025-10-31 11:04:06.022577+05:30	150	75	149
3	2025-10-31 11:04:06.026007+05:30	2025-10-31 11:04:06.026007+05:30	151	42	150
1	2025-10-31 11:04:06.028875+05:30	2025-10-31 11:04:06.028875+05:30	152	76	151
1	2025-10-31 11:04:06.031392+05:30	2025-10-31 11:04:06.031392+05:30	153	77	152
4	2025-10-31 11:04:06.034235+05:30	2025-10-31 11:04:06.034235+05:30	154	75	153
3	2025-10-31 11:04:06.036666+05:30	2025-10-31 11:04:06.036666+05:30	155	67	154
1	2025-10-31 11:04:06.038662+05:30	2025-10-31 11:04:06.038662+05:30	156	78	155
2	2025-10-31 11:04:06.041457+05:30	2025-10-31 11:04:06.041457+05:30	157	76	156
1	2025-10-31 11:04:06.043416+05:30	2025-10-31 11:04:06.043416+05:30	158	79	157
2	2025-10-31 11:04:06.045761+05:30	2025-10-31 11:04:06.045761+05:30	159	35	158
4	2025-10-31 11:04:06.065424+05:30	2025-10-31 11:04:06.065424+05:30	160	12	159
6	2025-10-31 11:04:06.068536+05:30	2025-10-31 11:04:06.068536+05:30	161	4	160
4	2025-10-31 11:04:06.071005+05:30	2025-10-31 11:04:06.071005+05:30	162	68	161
2	2025-10-31 11:04:06.075403+05:30	2025-10-31 11:04:06.075403+05:30	163	60	162
4	2025-10-31 11:04:06.077653+05:30	2025-10-31 11:04:06.077653+05:30	164	22	163
2	2025-10-31 11:04:06.07996+05:30	2025-10-31 11:04:06.07996+05:30	165	18	164
5	2025-10-31 11:04:06.082736+05:30	2025-10-31 11:04:06.082736+05:30	166	19	165
6	2025-10-31 11:04:06.085171+05:30	2025-10-31 11:04:06.085171+05:30	167	19	166
7	2025-10-31 11:04:06.087524+05:30	2025-10-31 11:04:06.087524+05:30	168	19	167
1	2025-10-31 11:04:06.089694+05:30	2025-10-31 11:04:06.089694+05:30	169	80	168
2	2025-10-31 11:04:06.092036+05:30	2025-10-31 11:04:06.092036+05:30	170	78	169
3	2025-10-31 11:04:06.094629+05:30	2025-10-31 11:04:06.094629+05:30	171	35	170
1	2025-10-31 11:04:06.096779+05:30	2025-10-31 11:04:06.096779+05:30	172	81	171
3	2025-10-31 11:04:06.116674+05:30	2025-10-31 11:04:06.116674+05:30	173	18	172
1	2025-10-31 11:04:06.118828+05:30	2025-10-31 11:04:06.118828+05:30	174	82	173
1	2025-10-31 11:04:06.124116+05:30	2025-10-31 11:04:06.124116+05:30	175	83	174
4	2025-10-31 11:04:06.126746+05:30	2025-10-31 11:04:06.126746+05:30	176	25	175
2	2025-10-31 11:04:06.129155+05:30	2025-10-31 11:04:06.129155+05:30	177	62	176
4	2025-10-31 11:04:06.131933+05:30	2025-10-31 11:04:06.131933+05:30	178	24	177
2	2025-10-31 11:04:06.134235+05:30	2025-10-31 11:04:06.134235+05:30	179	71	178
2	2025-10-31 11:04:06.136668+05:30	2025-10-31 11:04:06.136668+05:30	180	36	179
4	2025-10-31 11:04:06.139269+05:30	2025-10-31 11:04:06.139269+05:30	181	39	180
2	2025-10-31 11:04:06.141926+05:30	2025-10-31 11:04:06.141926+05:30	182	49	181
3	2025-10-31 11:04:06.144407+05:30	2025-10-31 11:04:06.144407+05:30	183	2	182
4	2025-10-31 11:04:06.146813+05:30	2025-10-31 11:04:06.146813+05:30	184	23	183
5	2025-10-31 11:04:06.166695+05:30	2025-10-31 11:04:06.166695+05:30	185	24	184
3	2025-10-31 11:04:06.172134+05:30	2025-10-31 11:04:06.172134+05:30	186	62	185
5	2025-10-31 11:04:06.174732+05:30	2025-10-31 11:04:06.174732+05:30	187	25	186
5	2025-10-31 11:04:06.177096+05:30	2025-10-31 11:04:06.177096+05:30	188	75	187
3	2025-10-31 11:04:06.179476+05:30	2025-10-31 11:04:06.179476+05:30	189	49	188
2	2025-10-31 11:04:06.182119+05:30	2025-10-31 11:04:06.182119+05:30	190	56	189
3	2025-10-31 11:04:06.184585+05:30	2025-10-31 11:04:06.184585+05:30	191	56	190
1	2025-10-31 11:04:06.186512+05:30	2025-10-31 11:04:06.186512+05:30	192	84	191
1	2025-10-31 11:04:06.1886+05:30	2025-10-31 11:04:06.1886+05:30	193	85	192
2	2025-10-31 11:04:06.191061+05:30	2025-10-31 11:04:06.191061+05:30	194	1	193
1	2025-10-31 11:04:06.192929+05:30	2025-10-31 11:04:06.192929+05:30	195	86	194
2	2025-10-31 11:04:06.195102+05:30	2025-10-31 11:04:06.195102+05:30	196	85	195
3	2025-10-31 11:04:06.214382+05:30	2025-10-31 11:04:06.214382+05:30	197	54	196
1	2025-10-31 11:04:06.2181+05:30	2025-10-31 11:04:06.2181+05:30	198	87	197
1	2025-10-31 11:04:06.220894+05:30	2025-10-31 11:04:06.220894+05:30	199	88	198
2	2025-10-31 11:04:06.224144+05:30	2025-10-31 11:04:06.224144+05:30	200	50	199
2	2025-10-31 11:04:06.226751+05:30	2025-10-31 11:04:06.226751+05:30	201	41	200
6	2025-10-31 11:04:06.23204+05:30	2025-10-31 11:04:06.23204+05:30	202	24	201
4	2025-10-31 11:04:06.2346+05:30	2025-10-31 11:04:06.2346+05:30	203	62	202
2	2025-10-31 11:04:06.236924+05:30	2025-10-31 11:04:06.236924+05:30	204	33	203
3	2025-10-31 11:04:06.239366+05:30	2025-10-31 11:04:06.239366+05:30	205	36	204
4	2025-10-31 11:04:06.241789+05:30	2025-10-31 11:04:06.241789+05:30	206	17	205
2	2025-10-31 11:04:06.244116+05:30	2025-10-31 11:04:06.244116+05:30	207	51	206
2	2025-10-31 11:04:06.246453+05:30	2025-10-31 11:04:06.246453+05:30	208	64	207
5	2025-10-31 11:04:06.268437+05:30	2025-10-31 11:04:06.268437+05:30	209	17	208
5	2025-10-31 11:04:06.272886+05:30	2025-10-31 11:04:06.272886+05:30	210	39	209
5	2025-10-31 11:04:06.276371+05:30	2025-10-31 11:04:06.276371+05:30	211	23	210
5	2025-10-31 11:04:06.27956+05:30	2025-10-31 11:04:06.27956+05:30	212	62	211
2	2025-10-31 11:04:06.282776+05:30	2025-10-31 11:04:06.282776+05:30	213	34	212
6	2025-10-31 11:04:06.285372+05:30	2025-10-31 11:04:06.285372+05:30	214	17	213
4	2025-10-31 11:04:06.287956+05:30	2025-10-31 11:04:06.287956+05:30	215	36	214
3	2025-10-31 11:04:06.290777+05:30	2025-10-31 11:04:06.290777+05:30	216	51	215
2	2025-10-31 11:04:06.293242+05:30	2025-10-31 11:04:06.293242+05:30	217	52	216
5	2025-10-31 11:04:06.295535+05:30	2025-10-31 11:04:06.295535+05:30	218	22	217
1	2025-10-31 11:04:06.315093+05:30	2025-10-31 11:04:06.315093+05:30	219	89	218
5	2025-10-31 11:04:06.319304+05:30	2025-10-31 11:04:06.319304+05:30	220	47	219
4	2025-10-31 11:04:06.322629+05:30	2025-10-31 11:04:06.322629+05:30	221	44	220
5	2025-10-31 11:04:06.326066+05:30	2025-10-31 11:04:06.326066+05:30	222	10	221
2	2025-10-31 11:04:06.328915+05:30	2025-10-31 11:04:06.328915+05:30	223	86	222
2	2025-10-31 11:04:06.331843+05:30	2025-10-31 11:04:06.331843+05:30	224	69	223
1	2025-10-31 11:04:06.334157+05:30	2025-10-31 11:04:06.334157+05:30	225	90	224
2	2025-10-31 11:04:06.336884+05:30	2025-10-31 11:04:06.336884+05:30	226	84	225
2	2025-10-31 11:04:06.339451+05:30	2025-10-31 11:04:06.339451+05:30	227	81	226
2	2025-10-31 11:04:06.341971+05:30	2025-10-31 11:04:06.341971+05:30	228	53	227
3	2025-10-31 11:04:06.363673+05:30	2025-10-31 11:04:06.363673+05:30	229	53	228
2	2025-10-31 11:04:06.369107+05:30	2025-10-31 11:04:06.369107+05:30	230	57	229
2	2025-10-31 11:04:06.372139+05:30	2025-10-31 11:04:06.372139+05:30	231	66	230
3	2025-10-31 11:04:06.375096+05:30	2025-10-31 11:04:06.375096+05:30	232	66	231
4	2025-10-31 11:04:06.377683+05:30	2025-10-31 11:04:06.377683+05:30	233	8	232
2	2025-10-31 11:04:06.380197+05:30	2025-10-31 11:04:06.380197+05:30	234	29	233
1	2025-10-31 11:04:06.383884+05:30	2025-10-31 11:04:06.383884+05:30	235	91	234
3	2025-10-31 11:04:06.386531+05:30	2025-10-31 11:04:06.386531+05:30	236	29	235
2	2025-10-31 11:04:06.388964+05:30	2025-10-31 11:04:06.388964+05:30	237	91	236
4	2025-10-31 11:04:06.391553+05:30	2025-10-31 11:04:06.391553+05:30	238	29	237
1	2025-10-31 11:04:06.394089+05:30	2025-10-31 11:04:06.394089+05:30	239	92	238
2	2025-10-31 11:04:06.414295+05:30	2025-10-31 11:04:06.414295+05:30	240	92	239
1	2025-10-31 11:04:06.418002+05:30	2025-10-31 11:04:06.418002+05:30	241	93	240
1	2025-10-31 11:04:06.420774+05:30	2025-10-31 11:04:06.420774+05:30	242	94	241
1	2025-10-31 11:04:06.423663+05:30	2025-10-31 11:04:06.423663+05:30	243	95	242
1	2025-10-31 11:04:06.42609+05:30	2025-10-31 11:04:06.42609+05:30	244	96	243
1	2025-10-31 11:04:06.428312+05:30	2025-10-31 11:04:06.428312+05:30	245	97	244
3	2025-10-31 11:04:06.431074+05:30	2025-10-31 11:04:06.431074+05:30	246	92	245
1	2025-10-31 11:04:06.433322+05:30	2025-10-31 11:04:06.433322+05:30	247	98	246
1	2025-10-31 11:04:06.435416+05:30	2025-10-31 11:04:06.435416+05:30	248	99	247
2	2025-10-31 11:04:06.437732+05:30	2025-10-31 11:04:06.437732+05:30	249	97	248
1	2025-10-31 11:04:06.43967+05:30	2025-10-31 11:04:06.43967+05:30	250	100	249
2	2025-10-31 11:04:06.44199+05:30	2025-10-31 11:04:06.44199+05:30	251	100	250
2	2025-10-31 11:04:06.444321+05:30	2025-10-31 11:04:06.444321+05:30	252	98	251
2	2025-10-31 11:04:06.446569+05:30	2025-10-31 11:04:06.446569+05:30	253	99	252
3	2025-10-31 11:04:06.467831+05:30	2025-10-31 11:04:06.467831+05:30	254	99	253
1	2025-10-31 11:04:06.470548+05:30	2025-10-31 11:04:06.470548+05:30	255	101	254
1	2025-10-31 11:04:06.47329+05:30	2025-10-31 11:04:06.47329+05:30	256	102	255
1	2025-10-31 11:04:06.475842+05:30	2025-10-31 11:04:06.475842+05:30	257	103	256
3	2025-10-31 11:04:06.483496+05:30	2025-10-31 11:04:06.483496+05:30	258	97	256
1	2025-10-31 11:04:06.487641+05:30	2025-10-31 11:04:06.487641+05:30	259	104	257
2	2025-10-31 11:04:06.490761+05:30	2025-10-31 11:04:06.490761+05:30	260	96	258
1	2025-10-31 11:04:06.493081+05:30	2025-10-31 11:04:06.493081+05:30	261	105	259
4	2025-10-31 11:04:06.495511+05:30	2025-10-31 11:04:06.495511+05:30	262	97	260
3	2025-10-31 11:04:06.515974+05:30	2025-10-31 11:04:06.515974+05:30	263	98	261
1	2025-10-31 11:04:06.520045+05:30	2025-10-31 11:04:06.520045+05:30	264	106	262
1	2025-10-31 11:04:06.523288+05:30	2025-10-31 11:04:06.523288+05:30	265	107	263
1	2025-10-31 11:04:06.526014+05:30	2025-10-31 11:04:06.526014+05:30	266	108	264
1	2025-10-31 11:04:06.52861+05:30	2025-10-31 11:04:06.52861+05:30	267	109	265
1	2025-10-31 11:04:06.531277+05:30	2025-10-31 11:04:06.531277+05:30	268	110	266
3	2025-10-31 11:04:06.533926+05:30	2025-10-31 11:04:06.533926+05:30	269	96	267
1	2025-10-31 11:04:06.536028+05:30	2025-10-31 11:04:06.536028+05:30	270	111	268
1	2025-10-31 11:04:06.538105+05:30	2025-10-31 11:04:06.538105+05:30	271	112	269
1	2025-10-31 11:04:06.540312+05:30	2025-10-31 11:04:06.540312+05:30	272	113	270
2	2025-10-31 11:04:06.542769+05:30	2025-10-31 11:04:06.542769+05:30	273	103	271
1	2025-10-31 11:04:06.544713+05:30	2025-10-31 11:04:06.544713+05:30	274	114	272
2	2025-10-31 11:04:06.547012+05:30	2025-10-31 11:04:06.547012+05:30	275	114	273
1	2025-10-31 11:04:06.568077+05:30	2025-10-31 11:04:06.568077+05:30	276	115	274
1	2025-10-31 11:04:06.571024+05:30	2025-10-31 11:04:06.571024+05:30	277	116	275
1	2025-10-31 11:04:06.57384+05:30	2025-10-31 11:04:06.57384+05:30	278	117	276
1	2025-10-31 11:04:06.576702+05:30	2025-10-31 11:04:06.576702+05:30	279	118	277
1	2025-10-31 11:04:06.578846+05:30	2025-10-31 11:04:06.578846+05:30	280	119	278
1	2025-10-31 11:04:06.58121+05:30	2025-10-31 11:04:06.58121+05:30	281	120	279
2	2025-10-31 11:04:06.584011+05:30	2025-10-31 11:04:06.584011+05:30	282	110	280
2	2025-10-31 11:04:06.58666+05:30	2025-10-31 11:04:06.58666+05:30	283	112	281
2	2025-10-31 11:04:06.589129+05:30	2025-10-31 11:04:06.589129+05:30	284	117	282
2	2025-10-31 11:04:06.591803+05:30	2025-10-31 11:04:06.591803+05:30	285	113	283
2	2025-10-31 11:04:06.594304+05:30	2025-10-31 11:04:06.594304+05:30	286	116	284
1	2025-10-31 11:04:06.596283+05:30	2025-10-31 11:04:06.596283+05:30	287	121	285
3	2025-10-31 11:04:06.618227+05:30	2025-10-31 11:04:06.618227+05:30	288	116	286
5	2025-10-31 11:04:06.622491+05:30	2025-10-31 11:04:06.622491+05:30	289	97	287
3	2025-10-31 11:04:06.62629+05:30	2025-10-31 11:04:06.62629+05:30	290	103	288
2	2025-10-31 11:04:06.629592+05:30	2025-10-31 11:04:06.629592+05:30	291	107	289
4	2025-10-31 11:04:06.633044+05:30	2025-10-31 11:04:06.633044+05:30	292	96	290
2	2025-10-31 11:04:06.635834+05:30	2025-10-31 11:04:06.635834+05:30	293	95	291
5	2025-10-31 11:04:06.638668+05:30	2025-10-31 11:04:06.638668+05:30	294	96	292
4	2025-10-31 11:04:06.64155+05:30	2025-10-31 11:04:06.64155+05:30	295	99	293
1	2025-10-31 11:04:06.643883+05:30	2025-10-31 11:04:06.643883+05:30	296	122	294
5	2025-10-31 11:04:06.646451+05:30	2025-10-31 11:04:06.646451+05:30	297	99	295
1	2025-10-31 11:04:06.667534+05:30	2025-10-31 11:04:06.667534+05:30	298	123	296
4	2025-10-31 11:04:06.671363+05:30	2025-10-31 11:04:06.671363+05:30	299	98	297
6	2025-10-31 11:04:06.675123+05:30	2025-10-31 11:04:06.675123+05:30	300	99	298
6	2025-10-31 11:04:06.678015+05:30	2025-10-31 11:04:06.678015+05:30	301	96	299
2	2025-10-31 11:04:06.680989+05:30	2025-10-31 11:04:06.680989+05:30	302	106	300
1	2025-10-31 11:04:06.683495+05:30	2025-10-31 11:04:06.683495+05:30	303	124	301
1	2025-10-31 11:04:06.685628+05:30	2025-10-31 11:04:06.685628+05:30	304	125	302
1	2025-10-31 11:04:06.687611+05:30	2025-10-31 11:04:06.687611+05:30	305	126	303
1	2025-10-31 11:04:06.689701+05:30	2025-10-31 11:04:06.689701+05:30	306	127	304
4	2025-10-31 11:04:06.692338+05:30	2025-10-31 11:04:06.692338+05:30	307	116	305
6	2025-10-31 11:04:06.69478+05:30	2025-10-31 11:04:06.69478+05:30	308	97	306
7	2025-10-31 11:04:06.714073+05:30	2025-10-31 11:04:06.714073+05:30	309	99	307
3	2025-10-31 11:04:06.718499+05:30	2025-10-31 11:04:06.718499+05:30	310	113	308
1	2025-10-31 11:04:06.721295+05:30	2025-10-31 11:04:06.721295+05:30	311	128	309
2	2025-10-31 11:04:06.724508+05:30	2025-10-31 11:04:06.724508+05:30	312	127	310
1	2025-10-31 11:04:06.726857+05:30	2025-10-31 11:04:06.726857+05:30	313	129	311
2	2025-10-31 11:04:06.729654+05:30	2025-10-31 11:04:06.729654+05:30	314	94	312
2	2025-10-31 11:04:06.732696+05:30	2025-10-31 11:04:06.732696+05:30	315	125	313
5	2025-10-31 11:04:06.735339+05:30	2025-10-31 11:04:06.735339+05:30	316	98	314
2	2025-10-31 11:04:06.73795+05:30	2025-10-31 11:04:06.73795+05:30	317	108	315
3	2025-10-31 11:04:06.740472+05:30	2025-10-31 11:04:06.740472+05:30	318	127	316
8	2025-10-31 11:04:06.742984+05:30	2025-10-31 11:04:06.742984+05:30	319	99	317
3	2025-10-31 11:04:06.74538+05:30	2025-10-31 11:04:06.74538+05:30	320	125	318
4	2025-10-31 11:04:06.765688+05:30	2025-10-31 11:04:06.765688+05:30	321	92	319
6	2025-10-31 11:04:06.769796+05:30	2025-10-31 11:04:06.769796+05:30	322	98	320
1	2025-10-31 11:04:06.772537+05:30	2025-10-31 11:04:06.772537+05:30	323	130	321
1	2025-10-31 11:04:06.77557+05:30	2025-10-31 11:04:06.77557+05:30	324	131	322
1	2025-10-31 11:04:06.777887+05:30	2025-10-31 11:04:06.777887+05:30	325	132	323
9	2025-10-31 11:04:06.780552+05:30	2025-10-31 11:04:06.780552+05:30	326	99	324
10	2025-10-31 11:04:06.78339+05:30	2025-10-31 11:04:06.78339+05:30	327	99	325
7	2025-10-31 11:04:06.786089+05:30	2025-10-31 11:04:06.786089+05:30	328	97	326
3	2025-10-31 11:04:06.788564+05:30	2025-10-31 11:04:06.788564+05:30	329	94	327
1	2025-10-31 11:04:06.790579+05:30	2025-10-31 11:04:06.790579+05:30	330	133	328
1	2025-10-31 11:04:06.792607+05:30	2025-10-31 11:04:06.792607+05:30	331	134	329
7	2025-10-31 11:04:06.794891+05:30	2025-10-31 11:04:06.794891+05:30	332	96	330
1	2025-10-31 11:04:06.796786+05:30	2025-10-31 11:04:06.796786+05:30	333	135	331
1	2025-10-31 11:04:06.81757+05:30	2025-10-31 11:04:06.81757+05:30	334	136	332
1	2025-10-31 11:04:06.821399+05:30	2025-10-31 11:04:06.821399+05:30	335	137	333
1	2025-10-31 11:04:06.824207+05:30	2025-10-31 11:04:06.824207+05:30	336	138	334
1	2025-10-31 11:04:06.826804+05:30	2025-10-31 11:04:06.826804+05:30	337	139	335
3	2025-10-31 11:04:06.829476+05:30	2025-10-31 11:04:06.829476+05:30	338	112	336
1	2025-10-31 11:04:06.832035+05:30	2025-10-31 11:04:06.832035+05:30	339	140	337
1	2025-10-31 11:04:06.834159+05:30	2025-10-31 11:04:06.834159+05:30	340	141	338
4	2025-10-31 11:04:06.836786+05:30	2025-10-31 11:04:06.836786+05:30	341	127	339
4	2025-10-31 11:04:06.839384+05:30	2025-10-31 11:04:06.839384+05:30	342	103	340
7	2025-10-31 11:04:06.842083+05:30	2025-10-31 11:04:06.842083+05:30	343	98	341
4	2025-10-31 11:04:06.844601+05:30	2025-10-31 11:04:06.844601+05:30	344	112	342
8	2025-10-31 11:04:06.863666+05:30	2025-10-31 11:04:06.863666+05:30	345	97	343
8	2025-10-31 11:04:06.869343+05:30	2025-10-31 11:04:06.869343+05:30	346	96	344
1	2025-10-31 11:04:06.872269+05:30	2025-10-31 11:04:06.872269+05:30	347	142	345
2	2025-10-31 11:04:06.875852+05:30	2025-10-31 11:04:06.875852+05:30	348	141	346
1	2025-10-31 11:04:06.878687+05:30	2025-10-31 11:04:06.878687+05:30	349	143	347
9	2025-10-31 11:04:06.881679+05:30	2025-10-31 11:04:06.881679+05:30	350	96	348
1	2025-10-31 11:04:06.883985+05:30	2025-10-31 11:04:06.883985+05:30	351	144	349
5	2025-10-31 11:04:06.886688+05:30	2025-10-31 11:04:06.886688+05:30	352	92	350
9	2025-10-31 11:04:06.889248+05:30	2025-10-31 11:04:06.889248+05:30	353	97	351
11	2025-10-31 11:04:06.891839+05:30	2025-10-31 11:04:06.891839+05:30	354	99	352
1	2025-10-31 11:04:06.893869+05:30	2025-10-31 11:04:06.893869+05:30	355	145	353
10	2025-10-31 11:04:06.896314+05:30	2025-10-31 11:04:06.896314+05:30	356	97	354
11	2025-10-31 11:04:06.917604+05:30	2025-10-31 11:04:06.917604+05:30	357	97	355
12	2025-10-31 11:04:06.921034+05:30	2025-10-31 11:04:06.921034+05:30	358	97	356
3	2025-10-31 11:04:06.924439+05:30	2025-10-31 11:04:06.924439+05:30	359	141	357
6	2025-10-31 11:04:06.927243+05:30	2025-10-31 11:04:06.927243+05:30	360	92	358
3	2025-10-31 11:04:06.930246+05:30	2025-10-31 11:04:06.930246+05:30	361	100	359
10	2025-10-31 11:04:06.933468+05:30	2025-10-31 11:04:06.933468+05:30	362	96	360
1	2025-10-31 11:04:06.935673+05:30	2025-10-31 11:04:06.935673+05:30	363	146	361
1	2025-10-31 11:04:06.937846+05:30	2025-10-31 11:04:06.937846+05:30	364	147	362
1	2025-10-31 11:04:06.939988+05:30	2025-10-31 11:04:06.939988+05:30	365	148	363
1	2025-10-31 11:04:06.94201+05:30	2025-10-31 11:04:06.94201+05:30	366	149	364
2	2025-10-31 11:04:06.944412+05:30	2025-10-31 11:04:06.944412+05:30	367	138	365
5	2025-10-31 11:04:06.946901+05:30	2025-10-31 11:04:06.946901+05:30	368	127	366
2	2025-10-31 11:04:06.969205+05:30	2025-10-31 11:04:06.969205+05:30	369	134	367
5	2025-10-31 11:04:06.972717+05:30	2025-10-31 11:04:06.972717+05:30	370	112	368
4	2025-10-31 11:04:06.977801+05:30	2025-10-31 11:04:06.977801+05:30	371	125	369
1	2025-10-31 11:04:06.980107+05:30	2025-10-31 11:04:06.980107+05:30	372	150	370
1	2025-10-31 11:04:06.98249+05:30	2025-10-31 11:04:06.98249+05:30	373	151	371
2	2025-10-31 11:04:06.985069+05:30	2025-10-31 11:04:06.985069+05:30	374	151	372
1	2025-10-31 11:04:06.98716+05:30	2025-10-31 11:04:06.98716+05:30	375	152	373
3	2025-10-31 11:04:06.989975+05:30	2025-10-31 11:04:06.989975+05:30	376	110	374
13	2025-10-31 11:04:06.992706+05:30	2025-10-31 11:04:06.992706+05:30	377	97	375
5	2025-10-31 11:04:07.014921+05:30	2025-10-31 11:04:07.014921+05:30	378	116	376
2	2025-10-31 11:04:07.020124+05:30	2025-10-31 11:04:07.020124+05:30	379	150	377
8	2025-10-31 11:04:07.023799+05:30	2025-10-31 11:04:07.023799+05:30	380	98	378
12	2025-10-31 11:04:07.027048+05:30	2025-10-31 11:04:07.027048+05:30	381	99	379
14	2025-10-31 11:04:07.029625+05:30	2025-10-31 11:04:07.029625+05:30	382	97	380
7	2025-10-31 11:04:07.032809+05:30	2025-10-31 11:04:07.032809+05:30	383	92	381
2	2025-10-31 11:04:07.035465+05:30	2025-10-31 11:04:07.035465+05:30	384	104	382
6	2025-10-31 11:04:07.038105+05:30	2025-10-31 11:04:07.038105+05:30	385	127	383
2	2025-10-31 11:04:07.040842+05:30	2025-10-31 11:04:07.040842+05:30	386	136	384
3	2025-10-31 11:04:07.04352+05:30	2025-10-31 11:04:07.04352+05:30	387	136	385
8	2025-10-31 11:04:07.046478+05:30	2025-10-31 11:04:07.046478+05:30	388	92	386
3	2025-10-31 11:04:07.066737+05:30	2025-10-31 11:04:07.066737+05:30	389	104	387
15	2025-10-31 11:04:07.069287+05:30	2025-10-31 11:04:07.069287+05:30	390	97	388
1	2025-10-31 11:04:07.071469+05:30	2025-10-31 11:04:07.071469+05:30	391	153	389
2	2025-10-31 11:04:07.073847+05:30	2025-10-31 11:04:07.073847+05:30	392	149	390
9	2025-10-31 11:04:07.076359+05:30	2025-10-31 11:04:07.076359+05:30	393	98	391
4	2025-10-31 11:04:07.078758+05:30	2025-10-31 11:04:07.078758+05:30	394	136	392
3	2025-10-31 11:04:07.081323+05:30	2025-10-31 11:04:07.081323+05:30	395	149	393
4	2025-10-31 11:04:07.083698+05:30	2025-10-31 11:04:07.083698+05:30	396	104	394
4	2025-10-31 11:04:07.086587+05:30	2025-10-31 11:04:07.086587+05:30	397	149	395
1	2025-10-31 11:04:07.088573+05:30	2025-10-31 11:04:07.088573+05:30	398	154	396
2	2025-10-31 11:04:07.090932+05:30	2025-10-31 11:04:07.090932+05:30	399	153	397
4	2025-10-31 11:04:07.093616+05:30	2025-10-31 11:04:07.093616+05:30	400	110	398
9	2025-10-31 11:04:07.095806+05:30	2025-10-31 11:04:07.095806+05:30	401	92	399
3	2025-10-31 11:04:07.116664+05:30	2025-10-31 11:04:07.116664+05:30	402	114	400
1	2025-10-31 11:04:07.119866+05:30	2025-10-31 11:04:07.119866+05:30	403	155	401
3	2025-10-31 11:04:07.123457+05:30	2025-10-31 11:04:07.123457+05:30	404	95	402
1	2025-10-31 11:04:07.126032+05:30	2025-10-31 11:04:07.126032+05:30	405	156	403
1	2025-10-31 11:04:07.128239+05:30	2025-10-31 11:04:07.128239+05:30	406	157	404
2	2025-10-31 11:04:07.131048+05:30	2025-10-31 11:04:07.131048+05:30	407	126	405
3	2025-10-31 11:04:07.133847+05:30	2025-10-31 11:04:07.133847+05:30	408	153	406
3	2025-10-31 11:04:07.136847+05:30	2025-10-31 11:04:07.136847+05:30	409	107	407
4	2025-10-31 11:04:07.140414+05:30	2025-10-31 11:04:07.140414+05:30	410	113	408
13	2025-10-31 11:04:07.142989+05:30	2025-10-31 11:04:07.142989+05:30	411	99	409
5	2025-10-31 11:04:07.14537+05:30	2025-10-31 11:04:07.14537+05:30	412	110	410
10	2025-10-31 11:04:07.16516+05:30	2025-10-31 11:04:07.16516+05:30	413	98	411
14	2025-10-31 11:04:07.1696+05:30	2025-10-31 11:04:07.1696+05:30	414	99	412
5	2025-10-31 11:04:07.173615+05:30	2025-10-31 11:04:07.173615+05:30	415	113	413
15	2025-10-31 11:04:07.177067+05:30	2025-10-31 11:04:07.177067+05:30	416	99	414
5	2025-10-31 11:04:07.179963+05:30	2025-10-31 11:04:07.179963+05:30	417	149	415
3	2025-10-31 11:04:07.183023+05:30	2025-10-31 11:04:07.183023+05:30	418	108	416
10	2025-10-31 11:04:07.185756+05:30	2025-10-31 11:04:07.185756+05:30	419	92	417
5	2025-10-31 11:04:07.188417+05:30	2025-10-31 11:04:07.188417+05:30	420	136	418
11	2025-10-31 11:04:07.191628+05:30	2025-10-31 11:04:07.191628+05:30	421	92	419
16	2025-10-31 11:04:07.194063+05:30	2025-10-31 11:04:07.194063+05:30	422	97	420
1	2025-10-31 11:04:07.196027+05:30	2025-10-31 11:04:07.196027+05:30	423	158	421
6	2025-10-31 11:04:07.217249+05:30	2025-10-31 11:04:07.217249+05:30	424	116	422
17	2025-10-31 11:04:07.222327+05:30	2025-10-31 11:04:07.222327+05:30	425	97	423
2	2025-10-31 11:04:07.225996+05:30	2025-10-31 11:04:07.225996+05:30	426	105	424
12	2025-10-31 11:04:07.229178+05:30	2025-10-31 11:04:07.229178+05:30	427	92	425
4	2025-10-31 11:04:07.232395+05:30	2025-10-31 11:04:07.232395+05:30	428	107	426
6	2025-10-31 11:04:07.235185+05:30	2025-10-31 11:04:07.235185+05:30	429	110	427
1	2025-10-31 11:04:07.237408+05:30	2025-10-31 11:04:07.237408+05:30	430	159	428
7	2025-10-31 11:04:07.240182+05:30	2025-10-31 11:04:07.240182+05:30	431	127	429
4	2025-10-31 11:04:07.242793+05:30	2025-10-31 11:04:07.242793+05:30	432	153	430
6	2025-10-31 11:04:07.266714+05:30	2025-10-31 11:04:07.266714+05:30	433	149	431
7	2025-10-31 11:04:07.271407+05:30	2025-10-31 11:04:07.271407+05:30	434	149	432
1	2025-10-31 11:04:07.274284+05:30	2025-10-31 11:04:07.274284+05:30	435	160	433
3	2025-10-31 11:04:07.277734+05:30	2025-10-31 11:04:07.277734+05:30	436	138	434
4	2025-10-31 11:04:07.281165+05:30	2025-10-31 11:04:07.281165+05:30	437	138	435
3	2025-10-31 11:04:07.284089+05:30	2025-10-31 11:04:07.284089+05:30	438	105	436
13	2025-10-31 11:04:07.28677+05:30	2025-10-31 11:04:07.28677+05:30	439	92	437
5	2025-10-31 11:04:07.289477+05:30	2025-10-31 11:04:07.289477+05:30	440	104	438
2	2025-10-31 11:04:07.292003+05:30	2025-10-31 11:04:07.292003+05:30	441	146	439
6	2025-10-31 11:04:07.294455+05:30	2025-10-31 11:04:07.294455+05:30	442	104	440
8	2025-10-31 11:04:07.296868+05:30	2025-10-31 11:04:07.296868+05:30	443	149	441
6	2025-10-31 11:04:07.318746+05:30	2025-10-31 11:04:07.318746+05:30	444	136	442
6	2025-10-31 11:04:07.322224+05:30	2025-10-31 11:04:07.322224+05:30	445	112	443
5	2025-10-31 11:04:07.325656+05:30	2025-10-31 11:04:07.325656+05:30	446	125	444
9	2025-10-31 11:04:07.328324+05:30	2025-10-31 11:04:07.328324+05:30	447	149	445
6	2025-10-31 11:04:07.331203+05:30	2025-10-31 11:04:07.331203+05:30	448	113	446
8	2025-10-31 11:04:07.333879+05:30	2025-10-31 11:04:07.333879+05:30	449	127	447
1	2025-10-31 11:04:07.336099+05:30	2025-10-31 11:04:07.336099+05:30	450	161	448
2	2025-10-31 11:04:07.338713+05:30	2025-10-31 11:04:07.338713+05:30	451	135	449
1	2025-10-31 11:04:07.340849+05:30	2025-10-31 11:04:07.340849+05:30	452	162	450
7	2025-10-31 11:04:07.343352+05:30	2025-10-31 11:04:07.343352+05:30	453	113	451
11	2025-10-31 11:04:07.345763+05:30	2025-10-31 11:04:07.345763+05:30	454	98	452
8	2025-10-31 11:04:07.366715+05:30	2025-10-31 11:04:07.366715+05:30	455	113	453
10	2025-10-31 11:04:07.370962+05:30	2025-10-31 11:04:07.370962+05:30	456	149	454
3	2025-10-31 11:04:07.375616+05:30	2025-10-31 11:04:07.375616+05:30	457	106	455
2	2025-10-31 11:04:07.378964+05:30	2025-10-31 11:04:07.378964+05:30	458	140	456
4	2025-10-31 11:04:07.382262+05:30	2025-10-31 11:04:07.382262+05:30	459	94	457
5	2025-10-31 11:04:07.384982+05:30	2025-10-31 11:04:07.384982+05:30	460	153	458
2	2025-10-31 11:04:07.387741+05:30	2025-10-31 11:04:07.387741+05:30	461	129	459
3	2025-10-31 11:04:07.390526+05:30	2025-10-31 11:04:07.390526+05:30	462	129	460
4	2025-10-31 11:04:07.393295+05:30	2025-10-31 11:04:07.393295+05:30	463	129	461
1	2025-10-31 11:04:07.395265+05:30	2025-10-31 11:04:07.395265+05:30	464	163	462
9	2025-10-31 11:04:07.415513+05:30	2025-10-31 11:04:07.415513+05:30	465	127	463
11	2025-10-31 11:04:07.420378+05:30	2025-10-31 11:04:07.420378+05:30	466	96	464
2	2025-10-31 11:04:07.423844+05:30	2025-10-31 11:04:07.423844+05:30	467	159	465
2	2025-10-31 11:04:07.427161+05:30	2025-10-31 11:04:07.427161+05:30	468	144	466
1	2025-10-31 11:04:07.429752+05:30	2025-10-31 11:04:07.429752+05:30	469	164	467
16	2025-10-31 11:04:07.43275+05:30	2025-10-31 11:04:07.43275+05:30	470	99	468
1	2025-10-31 11:04:07.434947+05:30	2025-10-31 11:04:07.434947+05:30	471	165	469
3	2025-10-31 11:04:07.437622+05:30	2025-10-31 11:04:07.437622+05:30	472	159	470
10	2025-10-31 11:04:07.440368+05:30	2025-10-31 11:04:07.440368+05:30	473	127	471
6	2025-10-31 11:04:07.442831+05:30	2025-10-31 11:04:07.442831+05:30	474	153	472
4	2025-10-31 11:04:07.44513+05:30	2025-10-31 11:04:07.44513+05:30	475	108	473
2	2025-10-31 11:04:07.465181+05:30	2025-10-31 11:04:07.465181+05:30	476	161	474
14	2025-10-31 11:04:07.469659+05:30	2025-10-31 11:04:07.469659+05:30	477	92	475
5	2025-10-31 11:04:07.472924+05:30	2025-10-31 11:04:07.472924+05:30	478	94	476
1	2025-10-31 11:04:07.475855+05:30	2025-10-31 11:04:07.475855+05:30	479	166	477
7	2025-10-31 11:04:07.4785+05:30	2025-10-31 11:04:07.4785+05:30	480	116	478
11	2025-10-31 11:04:07.48137+05:30	2025-10-31 11:04:07.48137+05:30	481	149	479
17	2025-10-31 11:04:07.484173+05:30	2025-10-31 11:04:07.484173+05:30	482	99	480
4	2025-10-31 11:04:07.487614+05:30	2025-10-31 11:04:07.487614+05:30	483	141	481
18	2025-10-31 11:04:07.490234+05:30	2025-10-31 11:04:07.490234+05:30	484	97	482
15	2025-10-31 11:04:07.492851+05:30	2025-10-31 11:04:07.492851+05:30	485	92	483
5	2025-10-31 11:04:07.49533+05:30	2025-10-31 11:04:07.49533+05:30	486	107	484
2	2025-10-31 11:04:07.522317+05:30	2025-10-31 11:04:07.522317+05:30	487	154	485
19	2025-10-31 11:04:07.526506+05:30	2025-10-31 11:04:07.526506+05:30	488	97	486
7	2025-10-31 11:04:07.530026+05:30	2025-10-31 11:04:07.530026+05:30	489	104	487
16	2025-10-31 11:04:07.533371+05:30	2025-10-31 11:04:07.533371+05:30	490	92	488
2	2025-10-31 11:04:07.536499+05:30	2025-10-31 11:04:07.536499+05:30	491	119	489
5	2025-10-31 11:04:07.540461+05:30	2025-10-31 11:04:07.540461+05:30	492	141	490
2	2025-10-31 11:04:07.543926+05:30	2025-10-31 11:04:07.543926+05:30	493	131	491
12	2025-10-31 11:04:07.546555+05:30	2025-10-31 11:04:07.546555+05:30	494	96	492
20	2025-10-31 11:04:07.568967+05:30	2025-10-31 11:04:07.568967+05:30	495	97	493
18	2025-10-31 11:04:07.572327+05:30	2025-10-31 11:04:07.572327+05:30	496	99	494
8	2025-10-31 11:04:07.575662+05:30	2025-10-31 11:04:07.575662+05:30	497	116	495
13	2025-10-31 11:04:07.57805+05:30	2025-10-31 11:04:07.57805+05:30	498	96	495
12	2025-10-31 11:04:07.58104+05:30	2025-10-31 11:04:07.58104+05:30	499	98	496
13	2025-10-31 11:04:07.583833+05:30	2025-10-31 11:04:07.583833+05:30	500	98	497
7	2025-10-31 11:04:07.586504+05:30	2025-10-31 11:04:07.586504+05:30	501	112	498
2	2025-10-31 11:04:07.589066+05:30	2025-10-31 11:04:07.589066+05:30	502	166	499
2	2025-10-31 11:04:07.59159+05:30	2025-10-31 11:04:07.59159+05:30	503	123	500
1	2025-10-31 11:04:07.593656+05:30	2025-10-31 11:04:07.593656+05:30	504	167	501
14	2025-10-31 11:04:07.596935+05:30	2025-10-31 11:04:07.596935+05:30	505	98	502
12	2025-10-31 11:04:07.618631+05:30	2025-10-31 11:04:07.618631+05:30	506	149	503
3	2025-10-31 11:04:07.622005+05:30	2025-10-31 11:04:07.622005+05:30	507	154	504
9	2025-10-31 11:04:07.624755+05:30	2025-10-31 11:04:07.624755+05:30	508	113	505
13	2025-10-31 11:04:07.627881+05:30	2025-10-31 11:04:07.627881+05:30	509	149	506
6	2025-10-31 11:04:07.630664+05:30	2025-10-31 11:04:07.630664+05:30	510	141	507
7	2025-10-31 11:04:07.633483+05:30	2025-10-31 11:04:07.633483+05:30	511	141	508
1	2025-10-31 11:04:07.635716+05:30	2025-10-31 11:04:07.635716+05:30	512	168	509
15	2025-10-31 11:04:07.638238+05:30	2025-10-31 11:04:07.638238+05:30	513	98	510
14	2025-10-31 11:04:07.64232+05:30	2025-10-31 11:04:07.64232+05:30	514	96	511
14	2025-10-31 11:04:07.644793+05:30	2025-10-31 11:04:07.644793+05:30	515	149	512
1	2025-10-31 11:04:07.646701+05:30	2025-10-31 11:04:07.646701+05:30	516	169	513
16	2025-10-31 11:04:07.667708+05:30	2025-10-31 11:04:07.667708+05:30	517	98	514
19	2025-10-31 11:04:07.671193+05:30	2025-10-31 11:04:07.671193+05:30	518	99	515
20	2025-10-31 11:04:07.674382+05:30	2025-10-31 11:04:07.674382+05:30	519	99	516
21	2025-10-31 11:04:07.677033+05:30	2025-10-31 11:04:07.677033+05:30	520	99	517
17	2025-10-31 11:04:07.679709+05:30	2025-10-31 11:04:07.679709+05:30	521	98	518
21	2025-10-31 11:04:07.682686+05:30	2025-10-31 11:04:07.682686+05:30	522	97	519
10	2025-10-31 11:04:07.685334+05:30	2025-10-31 11:04:07.685334+05:30	523	113	520
18	2025-10-31 11:04:07.687618+05:30	2025-10-31 11:04:07.687618+05:30	524	98	521
11	2025-10-31 11:04:07.689851+05:30	2025-10-31 11:04:07.689851+05:30	525	127	521
3	2025-10-31 11:04:07.692279+05:30	2025-10-31 11:04:07.692279+05:30	526	146	522
5	2025-10-31 11:04:07.694552+05:30	2025-10-31 11:04:07.694552+05:30	527	108	523
15	2025-10-31 11:04:07.696941+05:30	2025-10-31 11:04:07.696941+05:30	528	149	524
2	2025-10-31 11:04:07.717072+05:30	2025-10-31 11:04:07.717072+05:30	529	147	525
7	2025-10-31 11:04:07.719757+05:30	2025-10-31 11:04:07.719757+05:30	530	136	526
7	2025-10-31 11:04:07.722495+05:30	2025-10-31 11:04:07.722495+05:30	531	110	527
17	2025-10-31 11:04:07.725349+05:30	2025-10-31 11:04:07.725349+05:30	532	92	528
3	2025-10-31 11:04:07.72868+05:30	2025-10-31 11:04:07.72868+05:30	533	135	529
2	2025-10-31 11:04:07.731418+05:30	2025-10-31 11:04:07.731418+05:30	534	115	530
22	2025-10-31 11:04:07.733963+05:30	2025-10-31 11:04:07.733963+05:30	535	97	531
1	2025-10-31 11:04:07.735849+05:30	2025-10-31 11:04:07.735849+05:30	536	170	532
16	2025-10-31 11:04:07.738319+05:30	2025-10-31 11:04:07.738319+05:30	537	149	533
2	2025-10-31 11:04:07.740628+05:30	2025-10-31 11:04:07.740628+05:30	538	122	534
6	2025-10-31 11:04:07.743058+05:30	2025-10-31 11:04:07.743058+05:30	539	94	535
23	2025-10-31 11:04:07.745336+05:30	2025-10-31 11:04:07.745336+05:30	540	97	536
3	2025-10-31 11:04:07.765407+05:30	2025-10-31 11:04:07.765407+05:30	541	147	537
3	2025-10-31 11:04:07.769877+05:30	2025-10-31 11:04:07.769877+05:30	542	166	538
3	2025-10-31 11:04:07.783171+05:30	2025-10-31 11:04:07.783171+05:30	543	126	539
1	2025-10-31 11:04:07.785309+05:30	2025-10-31 11:04:07.785309+05:30	544	171	540
7	2025-10-31 11:04:07.787819+05:30	2025-10-31 11:04:07.787819+05:30	545	94	541
12	2025-10-31 11:04:07.790472+05:30	2025-10-31 11:04:07.790472+05:30	546	127	542
19	2025-10-31 11:04:07.793+05:30	2025-10-31 11:04:07.793+05:30	547	98	543
3	2025-10-31 11:04:07.795461+05:30	2025-10-31 11:04:07.795461+05:30	548	131	544
4	2025-10-31 11:04:07.815972+05:30	2025-10-31 11:04:07.815972+05:30	549	147	545
2	2025-10-31 11:04:07.820607+05:30	2025-10-31 11:04:07.820607+05:30	550	156	546
5	2025-10-31 11:04:07.824186+05:30	2025-10-31 11:04:07.824186+05:30	551	147	547
6	2025-10-31 11:04:07.827127+05:30	2025-10-31 11:04:07.827127+05:30	552	147	548
8	2025-10-31 11:04:07.82992+05:30	2025-10-31 11:04:07.82992+05:30	553	136	549
4	2025-10-31 11:04:07.832767+05:30	2025-10-31 11:04:07.832767+05:30	554	131	550
9	2025-10-31 11:04:07.835389+05:30	2025-10-31 11:04:07.835389+05:30	555	116	551
2	2025-10-31 11:04:07.837888+05:30	2025-10-31 11:04:07.837888+05:30	556	158	552
6	2025-10-31 11:04:07.840488+05:30	2025-10-31 11:04:07.840488+05:30	557	108	553
17	2025-10-31 11:04:07.84298+05:30	2025-10-31 11:04:07.84298+05:30	558	149	554
2	2025-10-31 11:04:07.845364+05:30	2025-10-31 11:04:07.845364+05:30	559	143	555
3	2025-10-31 11:04:07.866027+05:30	2025-10-31 11:04:07.866027+05:30	560	143	556
18	2025-10-31 11:04:07.870264+05:30	2025-10-31 11:04:07.870264+05:30	561	92	557
7	2025-10-31 11:04:07.873938+05:30	2025-10-31 11:04:07.873938+05:30	562	153	558
8	2025-10-31 11:04:07.876911+05:30	2025-10-31 11:04:07.876911+05:30	563	104	559
2	2025-10-31 11:04:07.879548+05:30	2025-10-31 11:04:07.879548+05:30	564	121	560
3	2025-10-31 11:04:07.882522+05:30	2025-10-31 11:04:07.882522+05:30	565	115	561
1	2025-10-31 11:04:07.884657+05:30	2025-10-31 11:04:07.884657+05:30	566	172	562
1	2025-10-31 11:04:07.886732+05:30	2025-10-31 11:04:07.886732+05:30	567	173	563
8	2025-10-31 11:04:07.889254+05:30	2025-10-31 11:04:07.889254+05:30	568	94	564
2	2025-10-31 11:04:07.891683+05:30	2025-10-31 11:04:07.891683+05:30	569	111	565
4	2025-10-31 11:04:07.894237+05:30	2025-10-31 11:04:07.894237+05:30	570	135	566
13	2025-10-31 11:04:07.896577+05:30	2025-10-31 11:04:07.896577+05:30	571	127	567
15	2025-10-31 11:04:07.91846+05:30	2025-10-31 11:04:07.91846+05:30	572	96	568
9	2025-10-31 11:04:07.921804+05:30	2025-10-31 11:04:07.921804+05:30	573	94	569
19	2025-10-31 11:04:07.925295+05:30	2025-10-31 11:04:07.925295+05:30	574	92	570
2	2025-10-31 11:04:07.928048+05:30	2025-10-31 11:04:07.928048+05:30	575	132	571
22	2025-10-31 11:04:07.930766+05:30	2025-10-31 11:04:07.930766+05:30	576	99	572
3	2025-10-31 11:04:07.933747+05:30	2025-10-31 11:04:07.933747+05:30	577	122	573
24	2025-10-31 11:04:07.936431+05:30	2025-10-31 11:04:07.936431+05:30	578	97	574
23	2025-10-31 11:04:07.939191+05:30	2025-10-31 11:04:07.939191+05:30	579	99	575
25	2025-10-31 11:04:07.941644+05:30	2025-10-31 11:04:07.941644+05:30	580	97	576
7	2025-10-31 11:04:07.944031+05:30	2025-10-31 11:04:07.944031+05:30	581	108	577
26	2025-10-31 11:04:07.964467+05:30	2025-10-31 11:04:07.964467+05:30	582	97	578
3	2025-10-31 11:04:07.969329+05:30	2025-10-31 11:04:07.969329+05:30	583	150	579
8	2025-10-31 11:04:07.972918+05:30	2025-10-31 11:04:07.972918+05:30	584	141	580
6	2025-10-31 11:04:07.976191+05:30	2025-10-31 11:04:07.976191+05:30	585	107	581
5	2025-10-31 11:04:07.979128+05:30	2025-10-31 11:04:07.979128+05:30	586	103	582
20	2025-10-31 11:04:07.982094+05:30	2025-10-31 11:04:07.982094+05:30	587	92	583
27	2025-10-31 11:04:07.984825+05:30	2025-10-31 11:04:07.984825+05:30	588	97	584
4	2025-10-31 11:04:07.987605+05:30	2025-10-31 11:04:07.987605+05:30	589	122	585
9	2025-10-31 11:04:07.990368+05:30	2025-10-31 11:04:07.990368+05:30	590	141	586
3	2025-10-31 11:04:07.992974+05:30	2025-10-31 11:04:07.992974+05:30	591	111	587
4	2025-10-31 11:04:07.996114+05:30	2025-10-31 11:04:07.996114+05:30	592	146	588
9	2025-10-31 11:04:08.016354+05:30	2025-10-31 11:04:08.016354+05:30	593	104	588
4	2025-10-31 11:04:08.02003+05:30	2025-10-31 11:04:08.02003+05:30	594	143	589
5	2025-10-31 11:04:08.023541+05:30	2025-10-31 11:04:08.023541+05:30	595	143	590
6	2025-10-31 11:04:08.026692+05:30	2025-10-31 11:04:08.026692+05:30	596	143	591
28	2025-10-31 11:04:08.030243+05:30	2025-10-31 11:04:08.030243+05:30	597	97	592
4	2025-10-31 11:04:08.033557+05:30	2025-10-31 11:04:08.033557+05:30	598	95	593
4	2025-10-31 11:04:08.035958+05:30	2025-10-31 11:04:08.035958+05:30	599	150	594
29	2025-10-31 11:04:08.03857+05:30	2025-10-31 11:04:08.03857+05:30	600	97	595
20	2025-10-31 11:04:08.041469+05:30	2025-10-31 11:04:08.041469+05:30	601	98	596
30	2025-10-31 11:04:08.043906+05:30	2025-10-31 11:04:08.043906+05:30	602	97	596
4	2025-10-31 11:04:08.046814+05:30	2025-10-31 11:04:08.046814+05:30	603	126	597
14	2025-10-31 11:04:08.066805+05:30	2025-10-31 11:04:08.066805+05:30	604	127	598
1	2025-10-31 11:04:08.069224+05:30	2025-10-31 11:04:08.069224+05:30	605	174	599
5	2025-10-31 11:04:08.071818+05:30	2025-10-31 11:04:08.071818+05:30	606	146	600
21	2025-10-31 11:04:08.074472+05:30	2025-10-31 11:04:08.074472+05:30	607	92	601
1	2025-10-31 11:04:08.076438+05:30	2025-10-31 11:04:08.076438+05:30	608	175	602
10	2025-10-31 11:04:08.079021+05:30	2025-10-31 11:04:08.079021+05:30	609	116	603
10	2025-10-31 11:04:08.081355+05:30	2025-10-31 11:04:08.081355+05:30	610	94	604
1	2025-10-31 11:04:08.083168+05:30	2025-10-31 11:04:08.083168+05:30	611	176	605
22	2025-10-31 11:04:08.085652+05:30	2025-10-31 11:04:08.085652+05:30	612	92	606
1	2025-10-31 11:04:08.087392+05:30	2025-10-31 11:04:08.087392+05:30	613	177	607
23	2025-10-31 11:04:08.089602+05:30	2025-10-31 11:04:08.089602+05:30	614	92	608
16	2025-10-31 11:04:08.091511+05:30	2025-10-31 11:04:08.091511+05:30	615	96	608
6	2025-10-31 11:04:08.093491+05:30	2025-10-31 11:04:08.093491+05:30	616	125	609
7	2025-10-31 11:04:08.095525+05:30	2025-10-31 11:04:08.095525+05:30	617	107	610
1	2025-10-31 11:04:08.115353+05:30	2025-10-31 11:04:08.115353+05:30	618	178	611
1	2025-10-31 11:04:08.118938+05:30	2025-10-31 11:04:08.118938+05:30	619	179	612
1	2025-10-31 11:04:08.121932+05:30	2025-10-31 11:04:08.121932+05:30	620	180	613
1	2025-10-31 11:04:08.125229+05:30	2025-10-31 11:04:08.125229+05:30	621	181	614
1	2025-10-31 11:04:08.127633+05:30	2025-10-31 11:04:08.127633+05:30	622	182	615
1	2025-10-31 11:04:08.129932+05:30	2025-10-31 11:04:08.129932+05:30	623	183	616
1	2025-10-31 11:04:08.132574+05:30	2025-10-31 11:04:08.132574+05:30	624	184	617
1	2025-10-31 11:04:08.134871+05:30	2025-10-31 11:04:08.134871+05:30	625	185	618
1	2025-10-31 11:04:08.137389+05:30	2025-10-31 11:04:08.137389+05:30	626	186	619
1	2025-10-31 11:04:08.139557+05:30	2025-10-31 11:04:08.139557+05:30	627	187	620
2	2025-10-31 11:04:08.143041+05:30	2025-10-31 11:04:08.143041+05:30	628	182	621
2	2025-10-31 11:04:08.14553+05:30	2025-10-31 11:04:08.14553+05:30	629	178	622
2	2025-10-31 11:04:08.166765+05:30	2025-10-31 11:04:08.166765+05:30	630	183	623
2	2025-10-31 11:04:08.171283+05:30	2025-10-31 11:04:08.171283+05:30	631	181	624
1	2025-10-31 11:04:08.174667+05:30	2025-10-31 11:04:08.174667+05:30	632	188	625
2	2025-10-31 11:04:08.177479+05:30	2025-10-31 11:04:08.177479+05:30	633	180	626
1	2025-10-31 11:04:08.179668+05:30	2025-10-31 11:04:08.179668+05:30	634	189	627
2	2025-10-31 11:04:08.182553+05:30	2025-10-31 11:04:08.182553+05:30	635	184	628
2	2025-10-31 11:04:08.185058+05:30	2025-10-31 11:04:08.185058+05:30	636	185	629
1	2025-10-31 11:04:08.187925+05:30	2025-10-31 11:04:08.187925+05:30	637	190	630
2	2025-10-31 11:04:08.19078+05:30	2025-10-31 11:04:08.19078+05:30	638	187	631
1	2025-10-31 11:04:08.192891+05:30	2025-10-31 11:04:08.192891+05:30	639	191	632
3	2025-10-31 11:04:08.195396+05:30	2025-10-31 11:04:08.195396+05:30	640	184	633
1	2025-10-31 11:04:08.214397+05:30	2025-10-31 11:04:08.214397+05:30	641	192	634
1	2025-10-31 11:04:08.217178+05:30	2025-10-31 11:04:08.217178+05:30	642	193	635
1	2025-10-31 11:04:08.219348+05:30	2025-10-31 11:04:08.219348+05:30	643	194	636
2	2025-10-31 11:04:08.221911+05:30	2025-10-31 11:04:08.221911+05:30	644	192	637
1	2025-10-31 11:04:08.224197+05:30	2025-10-31 11:04:08.224197+05:30	645	195	638
2	2025-10-31 11:04:08.226814+05:30	2025-10-31 11:04:08.226814+05:30	646	190	639
3	2025-10-31 11:04:08.229293+05:30	2025-10-31 11:04:08.229293+05:30	647	187	640
1	2025-10-31 11:04:08.231573+05:30	2025-10-31 11:04:08.231573+05:30	648	196	641
4	2025-10-31 11:04:08.234025+05:30	2025-10-31 11:04:08.234025+05:30	649	187	642
2	2025-10-31 11:04:08.236486+05:30	2025-10-31 11:04:08.236486+05:30	650	193	643
3	2025-10-31 11:04:08.239208+05:30	2025-10-31 11:04:08.239208+05:30	651	180	644
3	2025-10-31 11:04:08.24168+05:30	2025-10-31 11:04:08.24168+05:30	652	178	645
2	2025-10-31 11:04:08.24374+05:30	2025-10-31 11:04:08.24374+05:30	653	189	292
4	2025-10-31 11:04:08.246205+05:30	2025-10-31 11:04:08.246205+05:30	654	180	646
4	2025-10-31 11:04:08.267396+05:30	2025-10-31 11:04:08.267396+05:30	655	184	295
1	2025-10-31 11:04:08.271719+05:30	2025-10-31 11:04:08.271719+05:30	656	197	647
4	2025-10-31 11:04:08.275394+05:30	2025-10-31 11:04:08.275394+05:30	657	178	648
3	2025-10-31 11:04:08.278851+05:30	2025-10-31 11:04:08.278851+05:30	658	182	649
5	2025-10-31 11:04:08.282031+05:30	2025-10-31 11:04:08.282031+05:30	659	187	650
3	2025-10-31 11:04:08.284832+05:30	2025-10-31 11:04:08.284832+05:30	660	183	651
5	2025-10-31 11:04:08.287564+05:30	2025-10-31 11:04:08.287564+05:30	661	184	652
2	2025-10-31 11:04:08.290467+05:30	2025-10-31 11:04:08.290467+05:30	662	194	653
2	2025-10-31 11:04:08.293096+05:30	2025-10-31 11:04:08.293096+05:30	663	179	654
1	2025-10-31 11:04:08.295265+05:30	2025-10-31 11:04:08.295265+05:30	664	198	655
2	2025-10-31 11:04:08.315875+05:30	2025-10-31 11:04:08.315875+05:30	665	197	656
6	2025-10-31 11:04:08.320959+05:30	2025-10-31 11:04:08.320959+05:30	666	187	657
4	2025-10-31 11:04:08.324529+05:30	2025-10-31 11:04:08.324529+05:30	667	182	658
5	2025-10-31 11:04:08.328128+05:30	2025-10-31 11:04:08.328128+05:30	668	178	659
4	2025-10-31 11:04:08.330972+05:30	2025-10-31 11:04:08.330972+05:30	669	183	660
1	2025-10-31 11:04:08.333457+05:30	2025-10-31 11:04:08.333457+05:30	670	199	661
7	2025-10-31 11:04:08.336425+05:30	2025-10-31 11:04:08.336425+05:30	671	17	662
5	2025-10-31 11:04:08.339041+05:30	2025-10-31 11:04:08.339041+05:30	672	183	663
6	2025-10-31 11:04:08.341583+05:30	2025-10-31 11:04:08.341583+05:30	673	183	664
6	2025-10-31 11:04:08.344085+05:30	2025-10-31 11:04:08.344085+05:30	674	184	665
7	2025-10-31 11:04:08.346526+05:30	2025-10-31 11:04:08.346526+05:30	675	184	666
6	2025-10-31 11:04:08.368299+05:30	2025-10-31 11:04:08.368299+05:30	676	178	667
7	2025-10-31 11:04:08.371775+05:30	2025-10-31 11:04:08.371775+05:30	677	187	668
3	2025-10-31 11:04:08.379431+05:30	2025-10-31 11:04:08.379431+05:30	678	179	669
2	2025-10-31 11:04:08.382564+05:30	2025-10-31 11:04:08.382564+05:30	679	196	670
2	2025-10-31 11:04:08.385378+05:30	2025-10-31 11:04:08.385378+05:30	680	186	671
8	2025-10-31 11:04:08.388075+05:30	2025-10-31 11:04:08.388075+05:30	681	184	672
7	2025-10-31 11:04:08.390977+05:30	2025-10-31 11:04:08.390977+05:30	682	183	673
4	2025-10-31 11:04:08.393551+05:30	2025-10-31 11:04:08.393551+05:30	683	179	674
1	2025-10-31 11:04:08.39555+05:30	2025-10-31 11:04:08.39555+05:30	684	200	675
2	2025-10-31 11:04:08.415776+05:30	2025-10-31 11:04:08.415776+05:30	685	188	676
9	2025-10-31 11:04:08.419594+05:30	2025-10-31 11:04:08.419594+05:30	686	184	677
1	2025-10-31 11:04:08.422479+05:30	2025-10-31 11:04:08.422479+05:30	687	201	678
10	2025-10-31 11:04:08.426002+05:30	2025-10-31 11:04:08.426002+05:30	688	184	679
2	2025-10-31 11:04:08.429235+05:30	2025-10-31 11:04:08.429235+05:30	689	191	680
7	2025-10-31 11:04:08.432392+05:30	2025-10-31 11:04:08.432392+05:30	690	178	681
1	2025-10-31 11:04:08.43466+05:30	2025-10-31 11:04:08.43466+05:30	691	202	682
8	2025-10-31 11:04:08.437361+05:30	2025-10-31 11:04:08.437361+05:30	692	178	683
3	2025-10-31 11:04:08.440252+05:30	2025-10-31 11:04:08.440252+05:30	693	190	684
8	2025-10-31 11:04:08.442415+05:30	2025-10-31 11:04:08.442415+05:30	694	183	684
2	2025-10-31 11:04:08.444775+05:30	2025-10-31 11:04:08.444775+05:30	695	202	685
9	2025-10-31 11:04:08.463648+05:30	2025-10-31 11:04:08.463648+05:30	696	183	686
9	2025-10-31 11:04:08.469453+05:30	2025-10-31 11:04:08.469453+05:30	697	178	687
11	2025-10-31 11:04:08.473273+05:30	2025-10-31 11:04:08.473273+05:30	698	184	688
3	2025-10-31 11:04:08.476203+05:30	2025-10-31 11:04:08.476203+05:30	699	194	349
1	2025-10-31 11:04:08.478935+05:30	2025-10-31 11:04:08.478935+05:30	700	203	689
2	2025-10-31 11:04:08.482229+05:30	2025-10-31 11:04:08.482229+05:30	701	200	690
10	2025-10-31 11:04:08.484935+05:30	2025-10-31 11:04:08.484935+05:30	702	183	691
11	2025-10-31 11:04:08.487686+05:30	2025-10-31 11:04:08.487686+05:30	703	183	692
3	2025-10-31 11:04:08.490418+05:30	2025-10-31 11:04:08.490418+05:30	704	193	693
12	2025-10-31 11:04:08.494105+05:30	2025-10-31 11:04:08.494105+05:30	705	184	694
13	2025-10-31 11:04:08.496562+05:30	2025-10-31 11:04:08.496562+05:30	706	184	695
12	2025-10-31 11:04:08.516624+05:30	2025-10-31 11:04:08.516624+05:30	707	183	696
3	2025-10-31 11:04:08.519048+05:30	2025-10-31 11:04:08.519048+05:30	708	188	697
4	2025-10-31 11:04:08.521606+05:30	2025-10-31 11:04:08.521606+05:30	709	193	698
10	2025-10-31 11:04:08.524055+05:30	2025-10-31 11:04:08.524055+05:30	710	178	699
8	2025-10-31 11:04:08.526437+05:30	2025-10-31 11:04:08.526437+05:30	711	187	700
1	2025-10-31 11:04:08.528353+05:30	2025-10-31 11:04:08.528353+05:30	712	204	701
3	2025-10-31 11:04:08.531005+05:30	2025-10-31 11:04:08.531005+05:30	713	197	702
2	2025-10-31 11:04:08.53354+05:30	2025-10-31 11:04:08.53354+05:30	714	199	703
11	2025-10-31 11:04:08.535875+05:30	2025-10-31 11:04:08.535875+05:30	715	178	704
3	2025-10-31 11:04:08.538224+05:30	2025-10-31 11:04:08.538224+05:30	716	200	705
14	2025-10-31 11:04:08.540748+05:30	2025-10-31 11:04:08.540748+05:30	717	184	706
4	2025-10-31 11:04:08.543361+05:30	2025-10-31 11:04:08.543361+05:30	718	188	707
9	2025-10-31 11:04:08.545674+05:30	2025-10-31 11:04:08.545674+05:30	719	187	708
1	2025-10-31 11:04:08.56488+05:30	2025-10-31 11:04:08.56488+05:30	720	205	709
13	2025-10-31 11:04:08.567858+05:30	2025-10-31 11:04:08.567858+05:30	721	183	710
3	2025-10-31 11:04:08.570325+05:30	2025-10-31 11:04:08.570325+05:30	722	199	711
5	2025-10-31 11:04:08.572862+05:30	2025-10-31 11:04:08.572862+05:30	723	182	712
15	2025-10-31 11:04:08.575399+05:30	2025-10-31 11:04:08.575399+05:30	724	184	713
10	2025-10-31 11:04:08.577718+05:30	2025-10-31 11:04:08.577718+05:30	725	187	714
4	2025-10-31 11:04:08.579993+05:30	2025-10-31 11:04:08.579993+05:30	726	197	715
16	2025-10-31 11:04:08.582636+05:30	2025-10-31 11:04:08.582636+05:30	727	184	716
14	2025-10-31 11:04:08.585114+05:30	2025-10-31 11:04:08.585114+05:30	728	183	717
12	2025-10-31 11:04:08.58718+05:30	2025-10-31 11:04:08.58718+05:30	729	178	717
2	2025-10-31 11:04:08.589983+05:30	2025-10-31 11:04:08.589983+05:30	730	195	718
17	2025-10-31 11:04:08.592584+05:30	2025-10-31 11:04:08.592584+05:30	731	184	719
4	2025-10-31 11:04:08.595018+05:30	2025-10-31 11:04:08.595018+05:30	732	190	720
2	2025-10-31 11:04:08.614672+05:30	2025-10-31 11:04:08.614672+05:30	733	198	721
3	2025-10-31 11:04:08.618058+05:30	2025-10-31 11:04:08.618058+05:30	734	191	722
13	2025-10-31 11:04:08.620667+05:30	2025-10-31 11:04:08.620667+05:30	735	178	723
1	2025-10-31 11:04:08.623097+05:30	2025-10-31 11:04:08.623097+05:30	736	206	724
6	2025-10-31 11:04:08.625722+05:30	2025-10-31 11:04:08.625722+05:30	737	182	725
4	2025-10-31 11:04:08.628269+05:30	2025-10-31 11:04:08.628269+05:30	738	200	726
2	2025-10-31 11:04:08.630938+05:30	2025-10-31 11:04:08.630938+05:30	739	206	727
14	2025-10-31 11:04:08.633797+05:30	2025-10-31 11:04:08.633797+05:30	740	178	728
5	2025-10-31 11:04:08.636549+05:30	2025-10-31 11:04:08.636549+05:30	741	179	729
5	2025-10-31 11:04:08.639687+05:30	2025-10-31 11:04:08.639687+05:30	742	188	730
1	2025-10-31 11:04:08.717616+05:30	2025-10-31 11:04:08.717616+05:30	743	207	413
5	2025-10-31 11:04:08.721341+05:30	2025-10-31 11:04:08.721341+05:30	744	180	731
3	2025-10-31 11:04:08.72472+05:30	2025-10-31 11:04:08.72472+05:30	745	192	732
18	2025-10-31 11:04:08.734837+05:30	2025-10-31 11:04:08.734837+05:30	746	184	733
6	2025-10-31 11:04:08.738829+05:30	2025-10-31 11:04:08.738829+05:30	747	188	734
4	2025-10-31 11:04:08.743349+05:30	2025-10-31 11:04:08.743349+05:30	748	194	735
6	2025-10-31 11:04:08.763677+05:30	2025-10-31 11:04:08.763677+05:30	749	179	736
5	2025-10-31 11:04:08.768877+05:30	2025-10-31 11:04:08.768877+05:30	750	194	424
3	2025-10-31 11:04:08.772272+05:30	2025-10-31 11:04:08.772272+05:30	751	196	737
7	2025-10-31 11:04:08.775886+05:30	2025-10-31 11:04:08.775886+05:30	752	182	738
1	2025-10-31 11:04:08.778596+05:30	2025-10-31 11:04:08.778596+05:30	753	208	739
11	2025-10-31 11:04:08.781572+05:30	2025-10-31 11:04:08.781572+05:30	754	187	740
1	2025-10-31 11:04:08.784032+05:30	2025-10-31 11:04:08.784032+05:30	755	209	741
1	2025-10-31 11:04:08.787126+05:30	2025-10-31 11:04:08.787126+05:30	756	210	742
15	2025-10-31 11:04:08.790054+05:30	2025-10-31 11:04:08.790054+05:30	757	178	743
2	2025-10-31 11:04:08.792852+05:30	2025-10-31 11:04:08.792852+05:30	758	207	744
2	2025-10-31 11:04:08.795401+05:30	2025-10-31 11:04:08.795401+05:30	759	210	745
7	2025-10-31 11:04:08.816238+05:30	2025-10-31 11:04:08.816238+05:30	760	179	746
3	2025-10-31 11:04:08.820272+05:30	2025-10-31 11:04:08.820272+05:30	761	181	747
3	2025-10-31 11:04:08.823777+05:30	2025-10-31 11:04:08.823777+05:30	762	185	748
19	2025-10-31 11:04:08.826871+05:30	2025-10-31 11:04:08.826871+05:30	763	184	452
8	2025-10-31 11:04:08.830224+05:30	2025-10-31 11:04:08.830224+05:30	764	179	749
5	2025-10-31 11:04:08.833803+05:30	2025-10-31 11:04:08.833803+05:30	765	200	750
20	2025-10-31 11:04:08.837473+05:30	2025-10-31 11:04:08.837473+05:30	766	184	751
8	2025-10-31 11:04:08.84095+05:30	2025-10-31 11:04:08.84095+05:30	767	182	752
3	2025-10-31 11:04:08.843308+05:30	2025-10-31 11:04:08.843308+05:30	768	198	753
3	2025-10-31 11:04:08.845443+05:30	2025-10-31 11:04:08.845443+05:30	769	202	457
6	2025-10-31 11:04:08.865132+05:30	2025-10-31 11:04:08.865132+05:30	770	194	754
16	2025-10-31 11:04:08.867812+05:30	2025-10-31 11:04:08.867812+05:30	771	178	755
17	2025-10-31 11:04:08.870405+05:30	2025-10-31 11:04:08.870405+05:30	772	178	756
12	2025-10-31 11:04:08.873156+05:30	2025-10-31 11:04:08.873156+05:30	773	187	757
5	2025-10-31 11:04:08.875622+05:30	2025-10-31 11:04:08.875622+05:30	774	190	758
3	2025-10-31 11:04:08.878083+05:30	2025-10-31 11:04:08.878083+05:30	775	189	759
5	2025-10-31 11:04:08.880998+05:30	2025-10-31 11:04:08.880998+05:30	776	193	760
15	2025-10-31 11:04:08.883123+05:30	2025-10-31 11:04:08.883123+05:30	777	183	761
4	2025-10-31 11:04:08.88568+05:30	2025-10-31 11:04:08.88568+05:30	778	198	762
4	2025-10-31 11:04:08.88842+05:30	2025-10-31 11:04:08.88842+05:30	779	185	763
21	2025-10-31 11:04:08.891424+05:30	2025-10-31 11:04:08.891424+05:30	780	184	764
7	2025-10-31 11:04:08.894163+05:30	2025-10-31 11:04:08.894163+05:30	781	188	765
4	2025-10-31 11:04:08.896852+05:30	2025-10-31 11:04:08.896852+05:30	782	189	766
9	2025-10-31 11:04:08.919425+05:30	2025-10-31 11:04:08.919425+05:30	783	179	767
18	2025-10-31 11:04:08.923217+05:30	2025-10-31 11:04:08.923217+05:30	784	178	768
19	2025-10-31 11:04:08.926668+05:30	2025-10-31 11:04:08.926668+05:30	785	178	769
20	2025-10-31 11:04:08.929709+05:30	2025-10-31 11:04:08.929709+05:30	786	178	476
2	2025-10-31 11:04:08.932965+05:30	2025-10-31 11:04:08.932965+05:30	787	208	770
22	2025-10-31 11:04:08.935879+05:30	2025-10-31 11:04:08.935879+05:30	788	184	771
4	2025-10-31 11:04:08.939812+05:30	2025-10-31 11:04:08.939812+05:30	789	191	772
1	2025-10-31 11:04:08.942404+05:30	2025-10-31 11:04:08.942404+05:30	790	211	773
16	2025-10-31 11:04:08.945471+05:30	2025-10-31 11:04:08.945471+05:30	791	183	774
8	2025-10-31 11:04:08.96639+05:30	2025-10-31 11:04:08.96639+05:30	792	188	775
5	2025-10-31 11:04:08.971292+05:30	2025-10-31 11:04:08.971292+05:30	793	185	776
13	2025-10-31 11:04:08.974979+05:30	2025-10-31 11:04:08.974979+05:30	794	187	777
1	2025-10-31 11:04:08.977768+05:30	2025-10-31 11:04:08.977768+05:30	795	212	778
4	2025-10-31 11:04:08.980993+05:30	2025-10-31 11:04:08.980993+05:30	796	192	779
7	2025-10-31 11:04:08.984101+05:30	2025-10-31 11:04:08.984101+05:30	797	194	780
5	2025-10-31 11:04:08.98738+05:30	2025-10-31 11:04:08.98738+05:30	798	189	781
3	2025-10-31 11:04:08.990214+05:30	2025-10-31 11:04:08.990214+05:30	799	206	782
5	2025-10-31 11:04:08.993136+05:30	2025-10-31 11:04:08.993136+05:30	800	197	783
10	2025-10-31 11:04:08.995634+05:30	2025-10-31 11:04:08.995634+05:30	801	179	784
5	2025-10-31 11:04:09.016753+05:30	2025-10-31 11:04:09.016753+05:30	802	192	785
6	2025-10-31 11:04:09.020644+05:30	2025-10-31 11:04:09.020644+05:30	803	180	786
17	2025-10-31 11:04:09.024589+05:30	2025-10-31 11:04:09.024589+05:30	804	183	787
3	2025-10-31 11:04:09.028619+05:30	2025-10-31 11:04:09.028619+05:30	805	186	788
3	2025-10-31 11:04:09.036965+05:30	2025-10-31 11:04:09.036965+05:30	806	207	789
18	2025-10-31 11:04:09.039644+05:30	2025-10-31 11:04:09.039644+05:30	807	183	790
1	2025-10-31 11:04:09.041994+05:30	2025-10-31 11:04:09.041994+05:30	808	213	791
3	2025-10-31 11:04:09.044514+05:30	2025-10-31 11:04:09.044514+05:30	809	195	792
1	2025-10-31 11:04:09.046979+05:30	2025-10-31 11:04:09.046979+05:30	810	214	793
14	2025-10-31 11:04:09.06709+05:30	2025-10-31 11:04:09.06709+05:30	811	187	794
2	2025-10-31 11:04:09.069676+05:30	2025-10-31 11:04:09.069676+05:30	812	214	795
6	2025-10-31 11:04:09.072119+05:30	2025-10-31 11:04:09.072119+05:30	813	189	796
4	2025-10-31 11:04:09.074824+05:30	2025-10-31 11:04:09.074824+05:30	814	196	797
4	2025-10-31 11:04:09.077203+05:30	2025-10-31 11:04:09.077203+05:30	815	199	798
23	2025-10-31 11:04:09.079667+05:30	2025-10-31 11:04:09.079667+05:30	816	184	799
15	2025-10-31 11:04:09.08225+05:30	2025-10-31 11:04:09.08225+05:30	817	187	800
6	2025-10-31 11:04:09.084683+05:30	2025-10-31 11:04:09.084683+05:30	818	200	801
16	2025-10-31 11:04:09.087616+05:30	2025-10-31 11:04:09.087616+05:30	819	187	802
9	2025-10-31 11:04:09.090274+05:30	2025-10-31 11:04:09.090274+05:30	820	182	803
19	2025-10-31 11:04:09.092915+05:30	2025-10-31 11:04:09.092915+05:30	821	183	804
4	2025-10-31 11:04:09.095361+05:30	2025-10-31 11:04:09.095361+05:30	822	206	805
5	2025-10-31 11:04:09.11632+05:30	2025-10-31 11:04:09.11632+05:30	823	206	806
17	2025-10-31 11:04:09.12051+05:30	2025-10-31 11:04:09.12051+05:30	824	187	807
8	2025-10-31 11:04:09.124172+05:30	2025-10-31 11:04:09.124172+05:30	825	194	808
18	2025-10-31 11:04:09.127187+05:30	2025-10-31 11:04:09.127187+05:30	826	187	809
6	2025-10-31 11:04:09.129898+05:30	2025-10-31 11:04:09.129898+05:30	827	193	810
5	2025-10-31 11:04:09.132917+05:30	2025-10-31 11:04:09.132917+05:30	828	199	811
6	2025-10-31 11:04:09.136026+05:30	2025-10-31 11:04:09.136026+05:30	829	190	812
7	2025-10-31 11:04:09.138762+05:30	2025-10-31 11:04:09.138762+05:30	830	189	813
20	2025-10-31 11:04:09.141438+05:30	2025-10-31 11:04:09.141438+05:30	831	183	814
21	2025-10-31 11:04:09.144503+05:30	2025-10-31 11:04:09.144503+05:30	832	178	815
21	2025-10-31 11:04:09.163701+05:30	2025-10-31 11:04:09.163701+05:30	833	183	816
7	2025-10-31 11:04:09.169107+05:30	2025-10-31 11:04:09.169107+05:30	834	180	817
24	2025-10-31 11:04:09.172464+05:30	2025-10-31 11:04:09.172464+05:30	835	184	818
6	2025-10-31 11:04:09.176107+05:30	2025-10-31 11:04:09.176107+05:30	836	192	819
4	2025-10-31 11:04:09.179237+05:30	2025-10-31 11:04:09.179237+05:30	837	207	820
6	2025-10-31 11:04:09.182184+05:30	2025-10-31 11:04:09.182184+05:30	838	197	821
7	2025-10-31 11:04:09.184826+05:30	2025-10-31 11:04:09.184826+05:30	839	192	533
9	2025-10-31 11:04:09.188992+05:30	2025-10-31 11:04:09.188992+05:30	840	188	822
\.


--
-- Data for Name: pincodes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.pincodes (code, "createdAt", "updatedAt", id, "cityId") FROM stdin;
400094	2025-10-31 11:04:05.245319+05:30	2025-10-31 11:04:05.245319+05:30	9	1
400053	2025-10-31 11:04:05.232529+05:30	2025-10-31 11:04:05.273931+05:30	6	1
400050	2025-10-31 11:04:05.318822+05:30	2025-10-31 11:04:05.318822+05:30	13	1
400035	2025-10-31 11:04:06.122721+05:30	2025-10-31 11:04:06.122721+05:30	83	1
400085	2025-10-31 11:04:05.327738+05:30	2025-10-31 11:04:05.327738+05:30	15	1
400084	2025-10-31 11:04:05.330493+05:30	2025-10-31 11:04:05.330493+05:30	16	1
400042	2025-10-31 11:04:05.374869+05:30	2025-10-31 11:04:05.374869+05:30	21	1
400089	2025-10-31 11:04:05.493701+05:30	2025-10-31 11:04:06.281864+05:30	34	1
400103	2025-10-31 11:04:05.893302+05:30	2025-10-31 11:04:05.893302+05:30	72	1
400091	2025-10-31 11:04:05.425621+05:30	2025-10-31 11:04:05.425621+05:30	26	1
400092	2025-10-31 11:04:05.428132+05:30	2025-10-31 11:04:05.428132+05:30	27	1
400093	2025-10-31 11:04:05.466953+05:30	2025-10-31 11:04:05.466953+05:30	30	1
400022	2025-10-31 11:04:05.520465+05:30	2025-10-31 11:04:06.287128+05:30	36	1
400020	2025-10-31 11:04:05.443431+05:30	2025-10-31 11:04:05.920002+05:30	28	1
400088	2025-10-31 11:04:05.667779+05:30	2025-10-31 11:04:06.289935+05:30	51	1
400097	2025-10-31 11:04:05.886168+05:30	2025-10-31 11:04:06.133507+05:30	71	1
400059	2025-10-31 11:04:05.727828+05:30	2025-10-31 11:04:05.926877+05:30	58	1
400034	2025-10-31 11:04:05.690916+05:30	2025-10-31 11:04:06.292462+05:30	52	1
400039	2025-10-31 11:04:05.532073+05:30	2025-10-31 11:04:05.532073+05:30	37	1
400023	2025-10-31 11:04:05.534304+05:30	2025-10-31 11:04:05.534304+05:30	38	1
400019	2025-10-31 11:04:05.932772+05:30	2025-10-31 11:04:05.932772+05:30	73	1
400078	2025-10-31 11:04:05.380207+05:30	2025-10-31 11:04:06.294774+05:30	22	1
400027	2025-10-31 11:04:06.314174+05:30	2025-10-31 11:04:06.314174+05:30	89	1
400065	2025-10-31 11:04:05.189341+05:30	2025-10-31 11:04:06.143659+05:30	2	1
400013	2025-10-31 11:04:05.59264+05:30	2025-10-31 11:04:05.59264+05:30	45	1
400017	2025-10-31 11:04:05.59486+05:30	2025-10-31 11:04:05.596814+05:30	46	1
400016	2025-10-31 11:04:05.785993+05:30	2025-10-31 11:04:05.94495+05:30	65	1
400010	2025-10-31 11:04:05.618371+05:30	2025-10-31 11:04:06.31825+05:30	47	1
400104	2025-10-31 11:04:05.325056+05:30	2025-10-31 11:04:05.964678+05:30	14	1
400052	2025-10-31 11:04:05.587581+05:30	2025-10-31 11:04:06.321497+05:30	44	1
400082	2025-10-31 11:04:05.369051+05:30	2025-10-31 11:04:05.969696+05:30	20	1
400026	2025-10-31 11:04:05.538674+05:30	2025-10-31 11:04:05.674656+05:30	40	1
400005	2025-10-31 11:04:05.269143+05:30	2025-10-31 11:04:06.325032+05:30	10	1
400058	2025-10-31 11:04:05.236419+05:30	2025-10-31 11:04:05.680612+05:30	7	1
400081	2025-10-31 11:04:05.942974+05:30	2025-10-31 11:04:05.976107+05:30	74	1
401102	2025-10-31 11:04:06.420323+05:30	2025-10-31 11:04:08.08067+05:30	94	2
400055	2025-10-31 11:04:06.192618+05:30	2025-10-31 11:04:06.328085+05:30	86	1
400066	2025-10-31 11:04:05.422605+05:30	2025-10-31 11:04:06.173922+05:30	25	1
400011	2025-10-31 11:04:05.194373+05:30	2025-10-31 11:04:05.736071+05:30	3	1
400060	2025-10-31 11:04:05.738735+05:30	2025-10-31 11:04:05.738735+05:30	59	1
400049	2025-10-31 11:04:05.766849+05:30	2025-10-31 11:04:05.766849+05:30	61	1
400008	2025-10-31 11:04:05.624846+05:30	2025-10-31 11:04:05.982328+05:30	48	1
400061	2025-10-31 11:04:05.840041+05:30	2025-10-31 11:04:06.33091+05:30	69	1
400101	2025-10-31 11:04:05.778566+05:30	2025-10-31 11:04:05.778566+05:30	63	1
400067	2025-10-31 11:04:05.474514+05:30	2025-10-31 11:04:05.78108+05:30	31	1
400068	2025-10-31 11:04:05.578772+05:30	2025-10-31 11:04:05.787894+05:30	43	1
400098	2025-10-31 11:04:06.333787+05:30	2025-10-31 11:04:06.333787+05:30	90	1
400095	2025-10-31 11:04:05.719838+05:30	2025-10-31 11:04:05.794861+05:30	55	1
400051	2025-10-31 11:04:05.295114+05:30	2025-10-31 11:04:05.813674+05:30	11	1
400080	2025-10-31 11:04:05.973147+05:30	2025-10-31 11:04:06.176326+05:30	75	1
400072	2025-10-31 11:04:06.186192+05:30	2025-10-31 11:04:06.336028+05:30	84	1
400086	2025-10-31 11:04:05.634275+05:30	2025-10-31 11:04:06.178713+05:30	49	1
400079	2025-10-31 11:04:06.096453+05:30	2025-10-31 11:04:06.338619+05:30	81	1
400099	2025-10-31 11:04:05.72262+05:30	2025-10-31 11:04:06.183787+05:30	56	1
400069	2025-10-31 11:04:05.221392+05:30	2025-10-31 11:04:05.993949+05:30	5	1
400057	2025-10-31 11:04:05.692912+05:30	2025-10-31 11:04:06.346299+05:30	53	1
400074	2025-10-31 11:04:05.485439+05:30	2025-10-31 11:04:05.878454+05:30	32	1
400006	2025-10-31 11:04:05.883917+05:30	2025-10-31 11:04:05.883917+05:30	70	1
400029	2025-10-31 11:04:05.183759+05:30	2025-10-31 11:04:06.190294+05:30	1	1
400014	2025-10-31 11:04:05.570216+05:30	2025-10-31 11:04:06.024894+05:30	42	1
400024	2025-10-31 11:04:06.030952+05:30	2025-10-31 11:04:06.030952+05:30	77	1
400056	2025-10-31 11:04:05.725309+05:30	2025-10-31 11:04:06.367817+05:30	57	1
400070	2025-10-31 11:04:05.821287+05:30	2025-10-31 11:04:06.035901+05:30	67	1
400021	2025-10-31 11:04:06.028415+05:30	2025-10-31 11:04:06.040584+05:30	76	1
400087	2025-10-31 11:04:06.043091+05:30	2025-10-31 11:04:06.043091+05:30	79	1
400003	2025-10-31 11:04:05.316009+05:30	2025-10-31 11:04:06.064323+05:30	12	1
400004	2025-10-31 11:04:05.217371+05:30	2025-10-31 11:04:06.067739+05:30	4	1
400064	2025-10-31 11:04:05.832679+05:30	2025-10-31 11:04:06.070247+05:30	68	1
400102	2025-10-31 11:04:05.740754+05:30	2025-10-31 11:04:06.074501+05:30	60	1
400054	2025-10-31 11:04:06.18821+05:30	2025-10-31 11:04:06.194406+05:30	85	1
400032	2025-10-31 11:04:05.695109+05:30	2025-10-31 11:04:06.1965+05:30	54	1
400096	2025-10-31 11:04:06.217573+05:30	2025-10-31 11:04:06.217573+05:30	87	1
400012	2025-10-31 11:04:05.364914+05:30	2025-10-31 11:04:06.086706+05:30	19	1
400076	2025-10-31 11:04:06.089334+05:30	2025-10-31 11:04:06.089334+05:30	80	1
400025	2025-10-31 11:04:06.038303+05:30	2025-10-31 11:04:06.091247+05:30	78	1
400009	2025-10-31 11:04:05.495884+05:30	2025-10-31 11:04:06.093834+05:30	35	1
400075	2025-10-31 11:04:05.34079+05:30	2025-10-31 11:04:06.1157+05:30	18	1
400077	2025-10-31 11:04:06.118486+05:30	2025-10-31 11:04:06.118486+05:30	82	1
400015	2025-10-31 11:04:06.220392+05:30	2025-10-31 11:04:06.220392+05:30	88	1
400063	2025-10-31 11:04:05.641841+05:30	2025-10-31 11:04:06.223151+05:30	50	1
400043	2025-10-31 11:04:05.565778+05:30	2025-10-31 11:04:06.22592+05:30	41	1
400028	2025-10-31 11:04:05.415435+05:30	2025-10-31 11:04:06.231041+05:30	24	1
400071	2025-10-31 11:04:05.491395+05:30	2025-10-31 11:04:06.236178+05:30	33	1
421402	2025-10-31 11:04:06.525568+05:30	2025-10-31 11:04:07.943316+05:30	108	2
400031	2025-10-31 11:04:05.818654+05:30	2025-10-31 11:04:06.374164+05:30	66	1
401604	2025-10-31 11:04:06.487321+05:30	2025-10-31 11:04:08.014996+05:30	104	2
400083	2025-10-31 11:04:05.783852+05:30	2025-10-31 11:04:06.245714+05:30	64	1
400033	2025-10-31 11:04:05.536593+05:30	2025-10-31 11:04:06.271682+05:30	39	1
400007	2025-10-31 11:04:05.389969+05:30	2025-10-31 11:04:06.275335+05:30	23	1
400002	2025-10-31 11:04:05.773392+05:30	2025-10-31 11:04:06.27849+05:30	62	1
400037	2025-10-31 11:04:05.239943+05:30	2025-10-31 11:04:06.376842+05:30	8	1
400610	2025-10-31 11:04:06.470118+05:30	2025-10-31 11:04:06.470118+05:30	101	2
400018	2025-10-31 11:04:06.383464+05:30	2025-10-31 11:04:06.388146+05:30	91	1
400030	2025-10-31 11:04:05.445948+05:30	2025-10-31 11:04:06.390727+05:30	29	1
421506	2025-10-31 11:04:06.417491+05:30	2025-10-31 11:04:06.417491+05:30	93	2
401302	2025-10-31 11:04:06.472804+05:30	2025-10-31 11:04:06.472804+05:30	102	2
401501	2025-10-31 11:04:06.539995+05:30	2025-10-31 11:04:07.684578+05:30	113	2
401601	2025-10-31 11:04:06.519514+05:30	2025-10-31 11:04:07.374492+05:30	106	2
400608	2025-10-31 11:04:06.528154+05:30	2025-10-31 11:04:06.528154+05:30	109	2
401103	2025-10-31 11:04:06.47545+05:30	2025-10-31 11:04:07.978298+05:30	103	2
401502	2025-10-31 11:04:06.687254+05:30	2025-10-31 11:04:08.045851+05:30	126	2
401105	2025-10-31 11:04:06.576263+05:30	2025-10-31 11:04:06.576263+05:30	118	2
421308	2025-10-31 11:04:06.580819+05:30	2025-10-31 11:04:06.580819+05:30	120	2
421301	2025-10-31 11:04:06.427951+05:30	2025-10-31 11:04:08.04313+05:30	97	2
421503	2025-10-31 11:04:06.522847+05:30	2025-10-31 11:04:08.094859+05:30	107	2
421603	2025-10-31 11:04:06.57338+05:30	2025-10-31 11:04:06.588297+05:30	117	2
401610	2025-10-31 11:04:06.720819+05:30	2025-10-31 11:04:06.720819+05:30	128	2
401202	2025-10-31 11:04:06.535667+05:30	2025-10-31 11:04:07.992238+05:30	111	2
400706	2025-10-31 11:04:06.726477+05:30	2025-10-31 11:04:07.392473+05:30	129	2
400612	2025-10-31 11:04:06.685284+05:30	2025-10-31 11:04:08.09287+05:30	125	2
401101	2025-10-31 11:04:06.578512+05:30	2025-10-31 11:04:07.535306+05:30	119	2
400001	2025-10-31 11:04:05.336317+05:30	2025-10-31 11:04:08.335542+05:30	17	3
401608	2025-10-31 11:04:06.683108+05:30	2025-10-31 11:04:06.683108+05:30	124	2
401301	2025-10-31 11:04:06.423187+05:30	2025-10-31 11:04:08.032709+05:30	95	2
421501	2025-10-31 11:04:06.439331+05:30	2025-10-31 11:04:06.929248+05:30	100	2
400614	2025-10-31 11:04:06.544384+05:30	2025-10-31 11:04:07.114562+05:30	114	2
421001	2025-10-31 11:04:06.595927+05:30	2025-10-31 11:04:07.878774+05:30	121	2
421203	2025-10-31 11:04:06.77212+05:30	2025-10-31 11:04:06.77212+05:30	130	2
401303	2025-10-31 11:04:06.570584+05:30	2025-10-31 11:04:08.078269+05:30	116	2
421102	2025-10-31 11:04:06.492702+05:30	2025-10-31 11:04:07.283119+05:30	105	2
421601	2025-10-31 11:04:06.432959+05:30	2025-10-31 11:04:08.040591+05:30	98	2
400607	2025-10-31 11:04:06.6669+05:30	2025-10-31 11:04:07.590781+05:30	123	2
401403	2025-10-31 11:04:06.530858+05:30	2025-10-31 11:04:07.721623+05:30	110	2
401201	2025-10-31 11:04:06.537728+05:30	2025-10-31 11:04:07.585743+05:30	112	2
401602	2025-10-31 11:04:06.425724+05:30	2025-10-31 11:04:08.090756+05:30	96	2
401404	2025-10-31 11:04:06.689294+05:30	2025-10-31 11:04:08.065937+05:30	127	2
421002	2025-10-31 11:04:06.567569+05:30	2025-10-31 11:04:07.881729+05:30	115	2
421303	2025-10-31 11:04:06.393721+05:30	2025-10-31 11:04:08.088868+05:30	92	2
401203	2025-10-31 11:04:06.796426+05:30	2025-10-31 11:04:07.893499+05:30	135	2
401206	2025-10-31 11:04:06.790256+05:30	2025-10-31 11:04:06.790256+05:30	133	2
400701	2025-10-31 11:04:06.820206+05:30	2025-10-31 11:04:06.820206+05:30	137	2
401702	2025-10-31 11:04:06.826387+05:30	2025-10-31 11:04:06.826387+05:30	139	2
400606	2025-10-31 11:04:06.871836+05:30	2025-10-31 11:04:06.871836+05:30	142	2
401106	2025-10-31 11:04:06.77752+05:30	2025-10-31 11:04:07.927292+05:30	132	2
402202	2025-10-31 11:04:08.223844+05:30	2025-10-31 11:04:09.379812+05:30	195	3
400605	2025-10-31 11:04:06.893551+05:30	2025-10-31 11:04:06.893551+05:30	145	2
402107	2025-10-31 11:04:08.129506+05:30	2025-10-31 11:04:09.382955+05:30	183	3
400615	2025-10-31 11:04:06.939657+05:30	2025-10-31 11:04:06.939657+05:30	148	2
421302	2025-10-31 11:04:06.435052+05:30	2025-10-31 11:04:07.938332+05:30	99	2
421306	2025-10-31 11:04:06.792279+05:30	2025-10-31 11:04:06.967931+05:30	134	2
401401	2025-10-31 11:04:06.982119+05:30	2025-10-31 11:04:06.984314+05:30	151	2
401402	2025-10-31 11:04:06.986809+05:30	2025-10-31 11:04:06.986809+05:30	152	2
400707	2025-10-31 11:04:08.434291+05:30	2025-10-31 11:04:08.844701+05:30	202	3
402208	2025-10-31 11:04:09.041629+05:30	2025-10-31 11:04:09.041629+05:30	213	3
401503	2025-10-31 11:04:06.643531+05:30	2025-10-31 11:04:07.986733+05:30	122	2
401208	2025-10-31 11:04:06.833799+05:30	2025-10-31 11:04:07.989614+05:30	141	2
410206	2025-10-31 11:04:08.11439+05:30	2025-10-31 11:04:09.390372+05:30	178	3
402116	2025-10-31 11:04:09.046521+05:30	2025-10-31 11:04:09.068887+05:30	214	3
400703	2025-10-31 11:04:06.878318+05:30	2025-10-31 11:04:08.025881+05:30	143	2
400709	2025-10-31 11:04:07.119428+05:30	2025-10-31 11:04:07.119428+05:30	155	2
401703	2025-10-31 11:04:07.127873+05:30	2025-10-31 11:04:07.127873+05:30	157	2
401204	2025-10-31 11:04:06.979727+05:30	2025-10-31 11:04:08.035233+05:30	150	2
421305	2025-10-31 11:04:08.068811+05:30	2025-10-31 11:04:08.068811+05:30	174	2
421602	2025-10-31 11:04:06.935305+05:30	2025-10-31 11:04:08.071024+05:30	146	2
401305	2025-10-31 11:04:08.076118+05:30	2025-10-31 11:04:08.076118+05:30	175	2
421202	2025-10-31 11:04:08.082859+05:30	2025-10-31 11:04:08.082859+05:30	176	2
400604	2025-10-31 11:04:08.087147+05:30	2025-10-31 11:04:08.087147+05:30	177	2
400710	2025-10-31 11:04:07.27379+05:30	2025-10-31 11:04:07.27379+05:30	160	2
401107	2025-10-31 11:04:06.823769+05:30	2025-10-31 11:04:07.280056+05:30	138	2
401209	2025-10-31 11:04:07.340394+05:30	2025-10-31 11:04:07.340394+05:30	162	2
400602	2025-10-31 11:04:06.831601+05:30	2025-10-31 11:04:07.37786+05:30	140	2
421505	2025-10-31 11:04:07.394932+05:30	2025-10-31 11:04:07.394932+05:30	163	2
401304	2025-10-31 11:04:06.883608+05:30	2025-10-31 11:04:07.426136+05:30	144	2
421502	2025-10-31 11:04:07.42939+05:30	2025-10-31 11:04:07.42939+05:30	164	2
410208	2025-10-31 11:04:08.294924+05:30	2025-10-31 11:04:09.41594+05:30	198	3
421101	2025-10-31 11:04:07.434581+05:30	2025-10-31 11:04:07.434581+05:30	165	2
421204	2025-10-31 11:04:07.237+05:30	2025-10-31 11:04:07.436793+05:30	159	2
402207	2025-10-31 11:04:09.227362+05:30	2025-10-31 11:04:09.227362+05:30	215	3
401207	2025-10-31 11:04:07.335731+05:30	2025-10-31 11:04:07.446775+05:30	161	2
410216	2025-10-31 11:04:08.422043+05:30	2025-10-31 11:04:08.422043+05:30	201	3
402122	2025-10-31 11:04:08.23122+05:30	2025-10-31 11:04:09.073965+05:30	196	3
402112	2025-10-31 11:04:08.71652+05:30	2025-10-31 11:04:09.420073+05:30	207	3
402111	2025-10-31 11:04:08.213614+05:30	2025-10-31 11:04:09.232221+05:30	192	3
400705	2025-10-31 11:04:07.593255+05:30	2025-10-31 11:04:07.593255+05:30	167	2
421311	2025-10-31 11:04:07.088233+05:30	2025-10-31 11:04:07.620908+05:30	154	2
401405	2025-10-31 11:04:07.635378+05:30	2025-10-31 11:04:07.635378+05:30	168	2
421103	2025-10-31 11:04:07.646393+05:30	2025-10-31 11:04:07.646393+05:30	169	2
401609	2025-10-31 11:04:07.735548+05:30	2025-10-31 11:04:07.735548+05:30	170	2
400702	2025-10-31 11:04:08.21676+05:30	2025-10-31 11:04:09.246668+05:30	193	3
402203	2025-10-31 11:04:08.121479+05:30	2025-10-31 11:04:09.270451+05:30	180	3
401504	2025-10-31 11:04:07.4754+05:30	2025-10-31 11:04:07.768742+05:30	166	2
401506	2025-10-31 11:04:07.784949+05:30	2025-10-31 11:04:07.784949+05:30	171	2
402108	2025-10-31 11:04:08.622683+05:30	2025-10-31 11:04:09.114362+05:30	206	3
402104	2025-10-31 11:04:08.174191+05:30	2025-10-31 11:04:09.273911+05:30	188	3
400603	2025-10-31 11:04:07.125647+05:30	2025-10-31 11:04:07.819501+05:30	156	2
400601	2025-10-31 11:04:06.937469+05:30	2025-10-31 11:04:07.826299+05:30	147	2
421403	2025-10-31 11:04:06.816958+05:30	2025-10-31 11:04:07.829033+05:30	136	2
421201	2025-10-31 11:04:06.774845+05:30	2025-10-31 11:04:07.831964+05:30	131	2
421605	2025-10-31 11:04:07.195698+05:30	2025-10-31 11:04:07.837176+05:30	158	2
421401	2025-10-31 11:04:06.941663+05:30	2025-10-31 11:04:07.842262+05:30	149	2
421312	2025-10-31 11:04:07.071151+05:30	2025-10-31 11:04:07.872911+05:30	153	2
421004	2025-10-31 11:04:07.884288+05:30	2025-10-31 11:04:07.884288+05:30	172	2
421005	2025-10-31 11:04:07.886411+05:30	2025-10-31 11:04:07.886411+05:30	173	2
410218	2025-10-31 11:04:08.478502+05:30	2025-10-31 11:04:08.478502+05:30	203	3
402120	2025-10-31 11:04:08.187566+05:30	2025-10-31 11:04:09.135099+05:30	190	3
410221	2025-10-31 11:04:08.179328+05:30	2025-10-31 11:04:09.137972+05:30	189	3
402125	2025-10-31 11:04:08.941951+05:30	2025-10-31 11:04:08.941951+05:30	211	3
410222	2025-10-31 11:04:08.783665+05:30	2025-10-31 11:04:08.783665+05:30	209	3
410202	2025-10-31 11:04:08.528058+05:30	2025-10-31 11:04:08.528058+05:30	204	3
410101	2025-10-31 11:04:08.219007+05:30	2025-10-31 11:04:09.293493+05:30	194	3
400704	2025-10-31 11:04:08.786734+05:30	2025-10-31 11:04:08.794631+05:30	210	3
402201	2025-10-31 11:04:08.127266+05:30	2025-10-31 11:04:09.319481+05:30	182	3
402126	2025-10-31 11:04:08.977331+05:30	2025-10-31 11:04:08.977331+05:30	212	3
410210	2025-10-31 11:04:08.564348+05:30	2025-10-31 11:04:08.564348+05:30	205	3
410220	2025-10-31 11:04:08.778179+05:30	2025-10-31 11:04:09.326545+05:30	208	3
410203	2025-10-31 11:04:08.333085+05:30	2025-10-31 11:04:09.329641+05:30	199	3
410201	2025-10-31 11:04:08.132201+05:30	2025-10-31 11:04:09.332612+05:30	184	3
402204	2025-10-31 11:04:08.124824+05:30	2025-10-31 11:04:08.819115+05:30	181	3
402304	2025-10-31 11:04:08.270405+05:30	2025-10-31 11:04:09.18141+05:30	197	3
402209	2025-10-31 11:04:08.395221+05:30	2025-10-31 11:04:09.335702+05:30	200	3
402308	2025-10-31 11:04:08.192566+05:30	2025-10-31 11:04:09.344338+05:30	191	3
402103	2025-10-31 11:04:08.118471+05:30	2025-10-31 11:04:09.369868+05:30	179	3
402106	2025-10-31 11:04:08.13452+05:30	2025-10-31 11:04:09.373632+05:30	185	3
410207	2025-10-31 11:04:08.136999+05:30	2025-10-31 11:04:09.02702+05:30	186	3
402109	2025-10-31 11:04:08.139204+05:30	2025-10-31 11:04:09.377102+05:30	187	3
\.


--
-- Data for Name: productDocumentTypes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."productDocumentTypes" (id, "productId", "documentTypeId", is_mandatory, is_active, display_order, created_by, updated_by, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: productVerificationTypes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."productVerificationTypes" ("isActive", "createdAt", "updatedAt", id, "productId", "verificationTypeId") FROM stdin;
\.


--
-- Data for Name: products; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.products (name, code, description, "createdAt", "updatedAt", "isActive", id) FROM stdin;
\.


--
-- Data for Name: propertyApfVerificationReports; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."propertyApfVerificationReports" (id, case_id, "caseId", form_type, verification_outcome, customer_name, customer_phone, customer_email, address_locatable, address_rating, full_address, locality, address_structure, address_floor, address_structure_color, door_color, landmark1, landmark2, landmark3, landmark4, property_type, property_status, property_ownership, property_age, property_condition, property_area, property_value, market_value, apf_status, apf_number, apf_issue_date, apf_expiry_date, apf_issuing_authority, apf_validity_status, apf_amount, apf_utilized_amount, apf_balance_amount, project_name, project_status, project_approval_status, project_completion_percentage, total_units, completed_units, sold_units, available_units, possession_status, builder_name, builder_contact, developer_name, developer_contact, builder_registration_number, rera_registration_number, loan_amount, loan_purpose, loan_status, bank_name, loan_account_number, emi_amount, met_person_name, met_person_designation, met_person_relation, met_person_contact, document_shown_status, document_type, document_verification_status, tpc_met_person1, tpc_name1, tpc_confirmation1, tpc_met_person2, tpc_name2, tpc_confirmation2, shifted_period, current_location, premises_status, entry_restriction_reason, security_person_name, security_confirmation, contact_person, call_remark, legal_clearance, title_clearance, encumbrance_status, litigation_status, political_connection, dominated_area, feedback_from_neighbour, infrastructure_status, road_connectivity, other_observation, property_concerns, financial_concerns, final_status, hold_reason, recommendation_status, verification_date, verification_time, verified_by, remarks, total_images, total_selfies, created_at, updated_at, building_status, name_of_met_person, met_person_confirmation, construction_activity, designation, activity_stop_reason, project_started_date, project_completion_date, total_wing, total_flats, staff_strength, staff_seen, company_name_board, name_on_board, total_buildings_in_project, total_flats_in_building, project_start_date, project_end_date, verification_task_id, report_sha256_hash, report_server_signature, report_generated_at, is_final) FROM stdin;
\.


--
-- Data for Name: propertyIndividualVerificationReports; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."propertyIndividualVerificationReports" (id, case_id, "caseId", form_type, verification_outcome, customer_name, customer_phone, customer_email, address_locatable, address_rating, full_address, locality, address_structure, address_floor, address_structure_color, door_color, landmark1, landmark2, landmark3, landmark4, property_type, property_status, property_ownership, property_age, property_condition, property_area, property_value, market_value, construction_type, owner_name, owner_relation, owner_age, owner_occupation, owner_income, years_of_residence, family_members, earning_members, property_documents, document_verification_status, title_clear_status, mutation_status, tax_payment_status, met_person_name, met_person_designation, met_person_relation, met_person_contact, neighbor1_name, neighbor1_confirmation, neighbor2_name, neighbor2_confirmation, locality_reputation, tpc_met_person1, tpc_name1, tpc_confirmation1, tpc_met_person2, tpc_name2, tpc_confirmation2, shifted_period, current_location, premises_status, previous_owner_name, entry_restriction_reason, security_person_name, security_confirmation, contact_person, call_remark, legal_issues, loan_against_property, bank_name, loan_amount, emi_amount, electricity_connection, water_connection, gas_connection, internet_connection, road_connectivity, public_transport, political_connection, dominated_area, feedback_from_neighbour, infrastructure_status, safety_security, other_observation, property_concerns, verification_challenges, final_status, hold_reason, recommendation_status, verification_date, verification_time, verified_by, remarks, total_images, total_selfies, created_at, updated_at, property_location, property_description, construction_year, renovation_year, property_amenities, individual_name, individual_age, individual_occupation, individual_income, individual_education, individual_marital_status, individual_experience, employment_type, employer_name, employment_duration, monthly_income, annual_income, income_source, business_name, business_type, business_experience, business_income, verification_task_id, report_sha256_hash, report_server_signature, report_generated_at, is_final) FROM stdin;
\.


--
-- Data for Name: query_performance; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.query_performance (id, query_hash, query_text, execution_time, rows_returned, rows_examined, query_plan, "timestamp") FROM stdin;
\.


--
-- Data for Name: rateHistory; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."rateHistory" ("oldAmount", "newAmount", "changeReason", "changedBy", "changedAt", id, "rateId") FROM stdin;
\.


--
-- Data for Name: rateTypeAssignments; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."rateTypeAssignments" ("isActive", "createdAt", "updatedAt", id, "clientId", "productId", "verificationTypeId", "rateTypeId") FROM stdin;
\.


--
-- Data for Name: rateTypes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."rateTypes" (name, description, "isActive", "createdAt", "updatedAt", id) FROM stdin;
Local	Local area verification rates	t	2025-08-17 18:59:11.147966+05:30	2025-08-17 18:59:11.147966+05:30	1
Local1	Local area verification rates - Type 1	t	2025-08-17 18:59:11.147966+05:30	2025-08-17 18:59:11.147966+05:30	2
Local2	Local area verification rates - Type 2	t	2025-08-17 18:59:11.147966+05:30	2025-08-17 18:59:11.147966+05:30	3
Outstation	Outstation verification rates	t	2025-08-17 18:59:11.147966+05:30	2025-08-17 18:59:11.147966+05:30	7
OGL	Out of Geo/Local verification rates	t	2025-08-17 18:59:11.147966+05:30	2025-09-02 12:49:33.083161+05:30	4
OGL1	Out of Geo/Local verification rates - Type 1	t	2025-08-17 18:59:11.147966+05:30	2025-09-02 12:49:55.000398+05:30	5
OGL2	Out of Geo/Local verification rates - Type 2	t	2025-08-17 18:59:11.147966+05:30	2025-09-02 12:50:06.750155+05:30	6
Outstation 1	Outstation 1	t	2025-10-30 14:02:39.166191+05:30	2025-10-30 14:02:39.166191+05:30	8
\.


--
-- Data for Name: rates; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.rates (amount, currency, "isActive", "effectiveFrom", "effectiveTo", "createdBy", "createdAt", "updatedAt", id, "clientId", "productId", "verificationTypeId", "rateTypeId") FROM stdin;
\.


--
-- Data for Name: refreshTokens; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."refreshTokens" ("userId", token, "expiresAt", "createdAt", id, "ipAddress", "userAgent") FROM stdin;
\.


--
-- Data for Name: residenceCumOfficeVerificationReports; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."residenceCumOfficeVerificationReports" (id, case_id, "caseId", form_type, verification_outcome, customer_name, customer_phone, customer_email, address_locatable, address_rating, full_address, locality, address_structure, address_floor, address_structure_color, door_color, company_nameplate_status, name_on_company_board, door_nameplate_status, name_on_door_plate, society_nameplate_status, name_on_society_board, landmark1, landmark2, landmark3, landmark4, house_status, met_person_name, met_person_relation, total_family_members, total_earning, applicant_dob, applicant_age, staying_period, staying_status, approx_area, document_shown_status, document_type, office_status, office_existence, office_type, designation, applicant_designation, working_period, working_status, applicant_working_premises, sitting_location, current_company_name, company_nature_of_business, business_period, establishment_period, staff_strength, staff_seen, tpc_met_person1, tpc_name1, tpc_confirmation1, tpc_met_person2, tpc_name2, tpc_confirmation2, shifted_period, old_office_shifted_period, current_company_period, premises_status, name_of_met_person, met_person_type, met_person_confirmation, applicant_working_status, applicant_staying_status, contact_person, call_remark, political_connection, dominated_area, feedback_from_neighbour, other_observation, other_extra_remark, final_status, hold_reason, recommendation_status, verification_date, verification_time, verified_by, remarks, total_images, total_selfies, created_at, updated_at, staying_person_name, verification_task_id, report_sha256_hash, report_server_signature, report_generated_at, is_final) FROM stdin;
\.


--
-- Data for Name: residenceVerificationReports; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."residenceVerificationReports" (id, case_id, "caseId", form_type, verification_outcome, customer_name, customer_phone, customer_email, address_locatable, address_rating, full_address, locality, address_structure, address_floor, address_structure_color, door_color, door_nameplate_status, name_on_door_plate, society_nameplate_status, name_on_society_board, company_nameplate_status, name_on_company_board, landmark1, landmark2, landmark3, landmark4, house_status, room_status, met_person_name, met_person_relation, met_person_status, staying_person_name, total_family_members, total_earning, applicant_dob, applicant_age, working_status, company_name, staying_period, staying_status, approx_area, document_shown_status, document_type, tpc_met_person1, tpc_name1, tpc_confirmation1, tpc_met_person2, tpc_name2, tpc_confirmation2, shifted_period, premises_status, name_of_met_person, met_person_type, met_person_confirmation, applicant_staying_status, call_remark, political_connection, dominated_area, feedback_from_neighbour, other_observation, final_status, hold_reason, recommendation_status, verification_date, verification_time, verified_by, remarks, total_images, total_selfies, created_at, updated_at, verification_task_id, report_sha256_hash, report_server_signature, report_generated_at, is_final) FROM stdin;
\.


--
-- Data for Name: role_permissions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.role_permissions (id, role_id, permission_id, allowed) FROM stdin;
859add10-6b6f-4064-be68-588af267e408	688a9754-30ec-41fc-9c93-58e33fa7bf1e	14c315ed-336b-422d-b83b-e86347d8398a	t
22be77c6-098b-4d16-904d-e6342b2fa668	688a9754-30ec-41fc-9c93-58e33fa7bf1e	6a21d9b5-d839-4271-9fa2-2cd54eb80fdc	t
9595d30c-8062-45fa-b483-58e75a0fe834	688a9754-30ec-41fc-9c93-58e33fa7bf1e	85263aa4-961e-41c3-b901-a849db60b5d1	t
e1e20d77-c0bf-4e1a-a3bd-8e2f7e569c65	688a9754-30ec-41fc-9c93-58e33fa7bf1e	9fcda086-8d71-445f-8003-0f8034931055	t
3804afa8-c5a0-4811-872e-364a4ffd6a47	688a9754-30ec-41fc-9c93-58e33fa7bf1e	b71c4aed-b5bd-4d1d-9be1-8285563f8d5b	t
71a0439a-c3b2-465f-9def-a846eae1f4ff	688a9754-30ec-41fc-9c93-58e33fa7bf1e	b7482c7e-388b-4dae-abdd-9d07c8fd9f40	t
6d5de99f-d037-42bf-9244-02116178ee13	688a9754-30ec-41fc-9c93-58e33fa7bf1e	b81a18e1-5523-4c99-834f-c9729458cfab	t
46e3937e-7da9-403c-a137-041a1a22e5c1	688a9754-30ec-41fc-9c93-58e33fa7bf1e	c2e4fee4-dde2-4952-9a8e-3736e8a7d05a	t
ee79965f-ac42-4a29-8b96-a6a6fffef00e	688a9754-30ec-41fc-9c93-58e33fa7bf1e	d3cef74e-9efd-49d2-aacf-0b9ff0301f18	t
cb1712af-f160-4fd4-8c59-44885a73bdb8	688a9754-30ec-41fc-9c93-58e33fa7bf1e	d7ad5160-4090-4c69-849f-2041b0841caa	t
4a726f89-7b6b-48cc-9d91-ab28a123101e	688a9754-30ec-41fc-9c93-58e33fa7bf1e	dbe2f5c2-638d-4238-9bfa-2240c8621a4c	t
8428d9de-1c13-4050-b0ec-cd40ad6624e4	688a9754-30ec-41fc-9c93-58e33fa7bf1e	f008c3cb-46e1-4b24-a4d2-edf9004f5fdd	t
8e162cba-6a19-49b4-a9c0-37161feeb18f	688a9754-30ec-41fc-9c93-58e33fa7bf1e	ffb6354b-2a8f-47cc-a8c0-a8a53d13797d	t
15496ee7-2184-494a-a894-9235952e946c	688a9754-30ec-41fc-9c93-58e33fa7bf1e	731479d3-9f86-4a0e-9dae-56eca5f4f2b0	t
b660a27d-5137-4bff-b5fc-fa1baffe64c5	688a9754-30ec-41fc-9c93-58e33fa7bf1e	c2203837-7ddc-40bb-a93f-3913dc33f5fa	t
e6aff5de-b735-43d5-804a-bd10ad0355ee	688a9754-30ec-41fc-9c93-58e33fa7bf1e	017d46f3-af7d-4ed5-a73c-f6213032d218	t
3909aa84-348c-468a-b6e3-995674bbc955	688a9754-30ec-41fc-9c93-58e33fa7bf1e	03d8d720-393e-4768-883a-0fb886e63a0b	t
78087f31-0a04-4b4b-88a2-c4a865552a3f	688a9754-30ec-41fc-9c93-58e33fa7bf1e	09e1fc5c-0f37-487b-b8a3-5caa6b80630b	t
3f7276ad-831d-4212-a091-65aa2e8ba0b4	688a9754-30ec-41fc-9c93-58e33fa7bf1e	15744cb8-6bee-4724-bc69-13000dad3e64	t
8adb5ce6-eb4d-4470-bab5-157857f6e36e	688a9754-30ec-41fc-9c93-58e33fa7bf1e	1b5c86ab-fbd6-4817-8d2a-25ab40773071	t
6a53af5d-e06d-4941-a112-4f5f2007f20a	688a9754-30ec-41fc-9c93-58e33fa7bf1e	30488167-50a1-4fb7-af82-039da7be6711	t
843f0a3f-0802-481b-a3be-883465405987	688a9754-30ec-41fc-9c93-58e33fa7bf1e	37457e0f-589f-4ab6-b66e-3b87e6b06ab4	t
9a083989-d91f-48c9-a8bf-fb7ed1c9a871	688a9754-30ec-41fc-9c93-58e33fa7bf1e	3fc9017a-bbae-480a-8772-483a3fe63b55	t
68f07c2b-f359-4082-8752-44483c587fcc	688a9754-30ec-41fc-9c93-58e33fa7bf1e	58923475-afdf-4b3b-968f-60ebf4a2f255	t
3fb1d973-bad3-4d00-aea5-a3165acda050	688a9754-30ec-41fc-9c93-58e33fa7bf1e	7a5a847e-7648-48ab-935b-8ef4fae2791d	t
12e873a9-a1a3-459e-9f90-eff2b8673894	688a9754-30ec-41fc-9c93-58e33fa7bf1e	2e631b76-d12a-41fd-9d87-2680093ed1e5	t
1ea57e6d-9893-4b3b-a8ed-195455f25012	688a9754-30ec-41fc-9c93-58e33fa7bf1e	696ec806-4b45-4580-8489-682d56f08def	t
bfd53511-4c32-4235-9362-f4db0252d1d9	688a9754-30ec-41fc-9c93-58e33fa7bf1e	80fc1c81-ece4-46e7-b14a-5c90d70e1b66	t
4a369a6c-147d-4983-90b6-526cb88039e7	688a9754-30ec-41fc-9c93-58e33fa7bf1e	87697e58-0ee8-4df9-82d4-02c8f073ba3c	t
a117d1ce-4ed6-4c07-b6a5-f06fb0f3a845	688a9754-30ec-41fc-9c93-58e33fa7bf1e	89f49a4f-9071-4959-97f8-bd488af51e16	t
947274f5-70cc-4c89-9f28-b1f2cbbe6067	688a9754-30ec-41fc-9c93-58e33fa7bf1e	8bf5a9bc-08db-4181-8a1a-a549d46545a1	t
d62c4b62-9627-4cc9-b514-65694ecbbf1e	688a9754-30ec-41fc-9c93-58e33fa7bf1e	8e88cc67-b221-4556-ac00-18e8abdaefcf	t
ce8a1bf4-61d1-4fb6-a57e-0a4549cbf821	688a9754-30ec-41fc-9c93-58e33fa7bf1e	98c8c37d-3789-49b8-90f5-f5053e103b75	t
a852d7e5-d87b-4a04-ac44-767a4eeb6ac1	688a9754-30ec-41fc-9c93-58e33fa7bf1e	a415148a-67f7-4e16-b017-1ad2859b4d2a	t
e5a90247-6a9b-4df5-9990-d69dd8af22e9	688a9754-30ec-41fc-9c93-58e33fa7bf1e	bd10b273-edf2-450f-9cc4-58a4ef0556a3	t
a7a68fad-8142-4b15-bbc7-c60422940d45	688a9754-30ec-41fc-9c93-58e33fa7bf1e	7a787002-535f-468b-9b44-d90dcbeeedaf	t
287ed6e2-1918-4739-96c8-94e94dd949f0	688a9754-30ec-41fc-9c93-58e33fa7bf1e	91829baa-7c75-4213-ac08-41a3a164a100	t
c4c87514-7a43-45d0-a21b-6fb3adaa3928	688a9754-30ec-41fc-9c93-58e33fa7bf1e	a2cf843d-91da-4e2f-9fe5-b4d54c39dff1	t
89d7ac7c-b323-4a7d-9d46-261b263d298f	688a9754-30ec-41fc-9c93-58e33fa7bf1e	b3aac259-0cc8-45e7-a5eb-dc082b456709	t
60ffb6b6-c4ec-4af7-87d8-d657a5e50c3f	688a9754-30ec-41fc-9c93-58e33fa7bf1e	b5c73624-b4c7-407b-a8ac-a2c8da7f022f	t
e3457013-663f-4a65-8ecd-864c361a63ac	688a9754-30ec-41fc-9c93-58e33fa7bf1e	e8cd673b-30dc-49d9-a09d-0ecf7cbe573e	t
\.


--
-- Data for Name: role_routes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.role_routes (id, role_id, route_key, allowed) FROM stdin;
\.


--
-- Data for Name: roles_v2; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.roles_v2 (id, name, description, parent_role_id, is_system, created_at, updated_at) FROM stdin;
688a9754-30ec-41fc-9c93-58e33fa7bf1e	SUPER_ADMIN	System super administrator	\N	t	2026-02-25 15:38:02.777116+05:30	2026-02-25 15:38:02.777116+05:30
\.


--
-- Data for Name: scheduled_reports; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.scheduled_reports (id, name, report_type, format, frequency, recipients, filters, options, is_active, created_by, created_at, updated_at, last_run, next_run) FROM stdin;
\.


--
-- Data for Name: schema_migrations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.schema_migrations (id, filename, executed_at, checksum, execution_time_ms, success) FROM stdin;
20260225_rbac_role_routes	20260225_rbac_role_routes.sql	2026-02-26 16:13:24.015241	2f677c440f400b7e71dc5ac9b08163f2256f6661218e07c2af351a79de2403a9	39	t
20260225_true_rbac	20260225_true_rbac.sql	2026-02-26 16:13:24.033504	6ac5634f45117b2266df6ed9e1cc1614a327a873eddb5739bad9265eee43079c	17	t
20260226_page_permissions	20260226_page_permissions.sql	2026-02-26 16:13:24.03778	7065925646ae51e22494c1651b5daf00e2d0df47a8059d8c4f7f04eb69233185	3	t
20260226_rbac_canonical_role_consolidation	20260226_rbac_canonical_role_consolidation.sql	2026-02-26 16:14:36.302934	5d41d934ee288d90f247536bf91640a5e22121df3abff0122bfe5e05e886e394	17	t
20260226_territory_integrity_phase4	20260226_territory_integrity_phase4.sql	2026-02-26 16:14:36.314524	9a0d5a785a9e5bcf6d7a8e208529c112ef5212b48ec24a54888ba19b3d5c6878	10	t
20260226_user_hierarchy_roles	20260226_user_hierarchy_roles.sql	2026-02-26 16:37:50.216229	ca700f7fac5c27cd5769d0462bc04ac85211f0091d515a6357c73f27ab1613f5	265	t
20260227_archive_legacy_schema_migrations	20260227_archive_legacy_schema_migrations.sql	2026-02-27 13:05:44.416937	2502e6a70d4f16954eb02fcf8fdb13a603e03002d4b689e1bd07d7271d2ca247	37	t
20260227_add_field_monitoring_page_permission	20260227_add_field_monitoring_page_permission.sql	2026-02-27 15:59:57.684274	b694727f2d21141a3fc03bba36c194b97298c87842f495f99640c226eb796526	8	t
20260301_fix_update_updated_at_trigger_function	20260301_fix_update_updated_at_trigger_function.sql	2026-03-01 13:38:09.80583	ac4f1f1d5345ca22508ca7cf451df345c1865fd9f51d82d01c82fe61c65e4a4b	15	t
20260301_create_real_invoice_tables	20260301_create_real_invoice_tables.sql	2026-03-01 16:14:14.748266	3aa7c3582e68568e17100b206fd5e263c7d3a4063bba93be8b25d41b117380a9	77	t
20260301_add_task_revocations	20260301_add_task_revocations.sql	2026-03-02 13:47:28.795155	ab20f650e7194a5ba4918b258345d44d7d93fa63618a0c39a3b64368cd742f37	58	t
\.


--
-- Data for Name: schema_migrations_legacy_archive; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.schema_migrations_legacy_archive (id, filename, executed_at, checksum, execution_time_ms, success, archived_at) FROM stdin;
001_create_verification_tasks	001_create_verification_tasks.sql	2025-09-25 17:14:00.740177	9f24fb20cb8f019b85e6048f8c04c92ac8a1a7d2bd3a217a1d5af403217d27d8	79	t	2026-02-27 13:05:44.416937
002_enhance_cases_and_templates	002_enhance_cases_and_templates.sql	2025-09-25 17:14:00.821276	7dc16d3070b2b6cfa97adcffd058fd9d8725abf58d4b991e4137c078efa3e960	24	t	2026-02-27 13:05:44.416937
003_create_views_and_analytics	003_create_views_and_analytics.sql	2025-09-25 17:14:00.847162	5d854bb43f8498daad1e2303d870446ca88a392a672c9f7d5db5f277bda32cc1	18	t	2026-02-27 13:05:44.416937
004_migrate_existing_data	004_migrate_existing_data.sql	2025-09-25 17:14:00.866016	318ed5867696c90d6b19f2a3f26b711b66080a800aab47358b0c72a78d73ffc2	5	t	2026-02-27 13:05:44.416937
005_fix_migration_function	005_fix_migration_function.sql	2025-09-25 17:16:19.399849	34762e782d7a5c513039afe6ee750d90163170d6997f9cce95d0985beb4bb431	14	t	2026-02-27 13:05:44.416937
006_fix_column_names	006_fix_column_names.sql	2025-09-25 17:18:09.53784	da7c2b655ff8bd4df0d7e56ff32674856edcb8a66f620430857a4fab86623c46	12	t	2026-02-27 13:05:44.416937
007_fix_trigger_function	007_fix_trigger_function.sql	2025-09-25 17:19:36.267436	b7da6dfe76da79fd6df927856e630b640a7572346da806263d40e45dbe142961	16	t	2026-02-27 13:05:44.416937
001_test_migration_system	001_test_migration_system.sql	2025-10-24 20:19:54.743773	b37a88176ac1237c738e4cc654dd6be923529140e7c3ea0f5c329605cdc7c97f	35	t	2026-02-27 13:05:44.416937
006_add_trigger_applicant_type_to_verification_tasks	006_add_trigger_applicant_type_to_verification_tasks.sql	2025-10-25 12:56:46.718347	8ba9e95c407f4649e6346968213d85e4a1082918f1b2611d1d7929e1b168d6fc	15	t	2026-02-27 13:05:44.416937
007_create_document_types_tables	007_create_document_types_tables.sql	2025-10-25 12:56:46.755077	bd431a27e0279b4461ffe5530d7123876b3ef431fe54f247d2f7d239ce5383b8	19	f	2026-02-27 13:05:44.416937
999_cleanup_test_migration	999_cleanup_test_migration.sql	2025-10-25 12:57:38.581022	6b344736b864bc4b05ccb646650b97fdf47bd11bd38a677b2e9879e49c6ee6e3	7	t	2026-02-27 13:05:44.416937
008_create_document_type_rates_table	008_create_document_type_rates_table.sql	2025-10-25 13:38:06.500964	742deeae460373342958145d61e5091b7c303696bcefd74443b3d6f40e665d77	43	t	2026-02-27 13:05:44.416937
009_add_task_linking_to_form_submissions	009_add_task_linking_to_form_submissions.sql	2025-10-25 18:43:31.47384	2e2301c0d7384366f4811230ce81be9188789fdc3d53fe7cc71b0625229ed907	67	t	2026-02-27 13:05:44.416937
007_add_task_revocation_fields	007_add_task_revocation_fields.sql	2025-11-22 17:35:47.148279	e0bdf30b13515868229f51104db5cd59bfaa2476ccd5433c3351754fb09fe8e5	96	t	2026-02-27 13:05:44.416937
008_fix_roles_updated_at_trigger	008_fix_roles_updated_at_trigger.sql	2025-11-22 17:35:47.247895	2d04ba4a449e022271dac604f9093d769933d609c9e59861fccdac5d95119d3a	4	t	2026-02-27 13:05:44.416937
009_add_revisit_task_fields	009_add_revisit_task_fields.sql	2025-11-22 17:35:47.266204	a0be05e0b2d09756b07beb3ba781330d8b08a73ed7f5b32781fbdce5388f2e21	14	f	2026-02-27 13:05:44.416937
001_add_saved_fields_to_verification_tasks	001_add_saved_fields_to_verification_tasks.sql	2025-12-02 13:41:49.260429	613101a9b4a0b0a760e9d6a3146fe9913c7756da3aac4aa2adbda6d773f8c8c8	14	t	2026-02-27 13:05:44.416937
002_update_case_status_trigger	002_update_case_status_trigger.sql	2025-12-02 13:41:49.268729	a682e5dff1589727ed1bdd5dd1638cfff64c77a3429ae4d392b3705c3c7b7fb4	2	t	2026-02-27 13:05:44.416937
003_fix_case_status_data	003_fix_case_status_data.sql	2025-12-02 13:41:49.304044	06227db6cd611f1688d3eba8e6ee4e5e9e33d48eeac21bb46f01d3a6548dde07	26	t	2026-02-27 13:05:44.416937
009_backfill_user_timestamps	009_backfill_user_timestamps.sql	2025-12-12 00:18:56.947285	f5697fb9b59c4755b112afa94785e40a905130b4a877af18865b05b9a0a20548	12	t	2026-02-27 13:05:44.416937
010_add_cascade_delete	010_add_cascade_delete.sql	2025-12-12 00:33:43.189075	1f8bdd4851c3e54a1ef6c3ceb925fb3ab33ca7b89f23ce85aff6dbd330063bc1	49	f	2026-02-27 13:05:44.416937
010_improve_user_deletion	010_improve_user_deletion.sql	2026-02-16 15:04:07.31331	141c69ba2ad70da0dc40d8afb464d6b844dfe49a2acc1b31ed049b9421aec823	68	t	2026-02-27 13:05:44.416937
011_fix_updated_at_trigger	011_fix_updated_at_trigger.sql	2026-02-16 15:04:07.320001	517aa11db8e1c249b3aa138862efa21176d59fdecdaf07a28b8fb4078eb7a675	5	t	2026-02-27 13:05:44.416937
012_fix_territory_unique_constraints	012_fix_territory_unique_constraints.sql	2026-02-16 15:04:07.322839	88bedb278855f99c42dd3d5364806e8c225249a965d6f114c483d7b79f905444	2	f	2026-02-27 13:05:44.416937
013_add_tat_tracking_fields	013_add_tat_tracking_fields.sql	2026-02-19 17:41:01.625287	1de14d548ca58ccf747cec1a20bc621e0e272486aeab0770b9d21204878c222e	36	t	2026-02-27 13:05:44.416937
014_update_task_status_constraint	014_update_task_status_constraint.sql	2026-02-19 17:41:01.62866	05c1d323738675056032a737548597fd83a138f2ce7efc327d46412eefef6a04	60	t	2026-02-27 13:05:44.416937
20260216_add_commission_idempotency	20260216_add_commission_idempotency.sql	2026-02-19 17:41:01.696676	dfe3be92c87677efca35f667e9262eef0c84b4132c76d624036cbca16b8705ef	6	f	2026-02-27 13:05:44.416937
015_unify_cancelled_to_revoked	015_unify_cancelled_to_revoked.sql	2026-02-19 17:51:23.001201	0ae8279ad855a61086f9583f628eacf2f5df9ebab32b6e40e222e0e5a15da138	56	t	2026-02-27 13:05:44.416937
20260216_add_config_quarantine	20260216_add_config_quarantine.sql	2026-02-19 17:51:23.060501	3caac56f872e9d87cb1382e066b1882c70a4080018c507ad49f7a3f31919e7b4	3	t	2026-02-27 13:05:44.416937
20260216_add_service_zones	20260216_add_service_zones.sql	2026-02-19 17:51:23.064012	b7c1b6da0c629e530de1ea7bde99b417d502e31d131e4b576ecac755b177110e	73	t	2026-02-27 13:05:44.416937
20260216_add_sla_indexes	20260216_add_sla_indexes.sql	2026-02-19 17:51:23.13781	e024596df896d69980de13ed0ec3d9b89b1f9aa1f6f49ee0e0b8fce3ca748001	2	t	2026-02-27 13:05:44.416937
20260216_add_zone_rate_mapping	20260216_add_zone_rate_mapping.sql	2026-02-19 17:51:23.140095	a0686025b1b49ad4546ca12f66f2444508276305f69aa34e351272b148c5aa1c	2	t	2026-02-27 13:05:44.416937
20260217_forensic_tamper_proofing	20260217_forensic_tamper_proofing.sql	2026-02-19 17:51:23.313504	bda85027e384affa09773b91516bf5b8a4174797d4810bc232bad8659075889a	172	t	2026-02-27 13:05:44.416937
20260217_stage1_task_evidence_linking	20260217_stage1_task_evidence_linking.sql	2026-02-19 17:51:23.351668	08f9dc437bd302fa1e6e5d92990e3c76d99a1cadb77fa6e384dad46f17f7192e	37	t	2026-02-27 13:05:44.416937
acs_db_complete_backup_20260216	acs_db_complete_backup_20260216.sql	2026-02-19 17:51:23.443387	ff831e52914e62e9d0795d69a2405fbd52ef755cff05f0a36b0a567dcd55bb0f	90	f	2026-02-27 13:05:44.416937
acs_db_final_export_20260216	acs_db_final_export_20260216.sql	2026-02-21 21:04:34.869103	71a850df0f1fc75a46f2510318013e1d096d7f2048c43e0caa01d53e3f33bc34	34	f	2026-02-27 13:05:44.416937
20260223_initial_fi_rcu_hierarchy	20260223_initial_fi_rcu_hierarchy.sql	2026-02-23 11:52:57.201326	592188a3fe96e33a0af56da7cce752b78de8b9bf22de127f016605b03026efba	66	t	2026-02-27 13:05:44.416937
\.


--
-- Data for Name: security_audit_events; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.security_audit_events (id, event_type, severity, user_id, entity_type, entity_id, details, ip_address, user_agent, created_at) FROM stdin;
\.


--
-- Data for Name: service_zone_rules; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.service_zone_rules (id, client_id, product_id, pincode_id, area_id, service_zone_id, is_active, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: service_zones; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.service_zones (id, name, sla_hours, is_active, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: states; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.states (name, code, "createdAt", "updatedAt", id, "countryId") FROM stdin;
MAHARASHTRA	MAH	2025-10-31 11:04:05.171196+05:30	2025-10-31 11:04:05.171196+05:30	1	1
Alabama	AL	2026-02-25 01:04:42.392416+05:30	2026-02-25 01:11:15.911949+05:30	2	2
\.


--
-- Data for Name: system_health_metrics; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.system_health_metrics (id, metric_name, metric_value, metric_unit, tags, "timestamp") FROM stdin;
\.


--
-- Data for Name: task_assignment_history; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.task_assignment_history (id, verification_task_id, case_id, assigned_from, assigned_to, assigned_by, assignment_reason, assigned_at, task_status_before, task_status_after, created_at) FROM stdin;
\.


--
-- Data for Name: task_commission_calculations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.task_commission_calculations (id, verification_task_id, case_id, task_number, user_id, client_id, rate_type_id, base_amount, commission_amount, calculated_commission, currency, calculation_method, calculation_date, status, approved_by, approved_at, paid_by, paid_at, payment_method, transaction_id, rejection_reason, task_completed_at, verification_outcome, created_at, updated_at, created_by, notes) FROM stdin;
\.


--
-- Data for Name: task_form_submissions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.task_form_submissions (id, verification_task_id, case_id, form_submission_id, form_type, submitted_by, submitted_at, validation_status, validated_by, validated_at, validation_notes, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: task_revocations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.task_revocations (id, task_id, revoked_by_user_id, revoked_by_role, revoked_from_user_id, revoke_reason, previous_status, revoked_at, reassigned, reassigned_to_user_id, reassigned_at, created_at) FROM stdin;
\.


--
-- Data for Name: template_reports; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.template_reports (id, case_id, submission_id, verification_type, outcome, report_content, metadata, created_by, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: territoryAssignmentAudit; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."territoryAssignmentAudit" (id, "userId", "assignmentType", "assignmentId", action, "previousData", "newData", "performedBy", "performedAt", reason) FROM stdin;
\.


--
-- Data for Name: trusted_devices; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.trusted_devices (id, user_id, device_id, device_model, os_version, first_seen_at, last_seen_at, is_blocked, created_at) FROM stdin;
\.


--
-- Data for Name: userAreaAssignments; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."userAreaAssignments" (id, "userId", "pincodeId", "areaId", "userPincodeAssignmentId", "assignedBy", "assignedAt", "isActive", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: userClientAssignments; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."userClientAssignments" (id, "userId", "clientId", "createdAt", "updatedAt", "assignedAt", "assignedBy") FROM stdin;
\.


--
-- Data for Name: userPincodeAssignments; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."userPincodeAssignments" (id, "userId", "pincodeId", "assignedBy", "assignedAt", "isActive", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: userProductAssignments; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."userProductAssignments" (id, "userId", "productId", "assignedAt", "assignedBy", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: user_roles; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.user_roles (id, user_id, role_id) FROM stdin;
f73428a9-7eae-4db5-9999-c00fe7d2905e	70dcf247-759c-405d-a8fb-4c78b7b77747	688a9754-30ec-41fc-9c93-58e33fa7bf1e
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.users (id, name, username, password, "passwordHash", role, email, phone, "isActive", "lastLogin", "createdAt", "updatedAt", "employeeId", designation, department, "profilePhotoUrl", "departmentId", "designationId", performance_rating, total_cases_handled, avg_case_completion_days, last_active_at, preferred_form_types, "deletedAt", team_leader_id, manager_id) FROM stdin;
70dcf247-759c-405d-a8fb-4c78b7b77747	System Administrator	admin	$2b$10$DZ4mB9LG.w0mFzg1Hg10GeEkAEruMuTXY1g22BL/p8p9YmYdYj84O	$2b$10$DZ4mB9LG.w0mFzg1Hg10GeEkAEruMuTXY1g22BL/p8p9YmYdYj84O	SUPER_ADMIN	\N	\N	t	2026-03-25 23:47:36.8178+05:30	2025-08-13 18:17:35.989427+05:30	2026-03-26 00:25:08.32101+05:30	EMP001	System Administrator	IT Administration	\N	2	\N	\N	0	\N	\N	\N	\N	\N	\N
\.


--
-- Data for Name: verificationTypes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."verificationTypes" (name, code, description, "createdAt", "updatedAt", "isActive", id) FROM stdin;
Residence Verification	RV	Verification of residential address	2025-08-17 17:57:46.115771+05:30	2025-08-17 17:57:46.115771+05:30	t	1
Office Verification	OV	Verification of office address	2025-08-17 17:57:46.115771+05:30	2025-08-17 17:57:46.115771+05:30	t	2
Residence cum office Verification	RC	Reference verification	2025-08-17 17:57:46.115771+05:30	2025-08-17 17:57:46.115771+05:30	t	3
Business Verification	EV	Employment verification	2025-08-17 17:57:46.115771+05:30	2025-08-17 17:57:46.115771+05:30	t	4
Noc Verification	NV	\N	2025-08-26 17:13:43.171598+05:30	2025-08-26 17:13:43.171598+05:30	t	6
DSA DST & connector Verification	DV	\N	2025-08-26 17:13:43.171598+05:30	2025-08-26 17:13:43.171598+05:30	t	7
Property APF Verification	PAV	\N	2025-08-26 17:13:43.171598+05:30	2025-08-26 17:13:43.171598+05:30	t	8
Property Individual Verification	PIV	\N	2025-08-26 17:13:43.171598+05:30	2025-08-26 17:13:43.171598+05:30	t	9
Builder Verification	BV	\N	2025-08-26 17:13:43.171598+05:30	2026-02-24 12:31:35.211642+05:30	t	5
\.


--
-- Data for Name: verification_attachments; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.verification_attachments (id, case_id, "caseId", verification_type, filename, "originalName", "mimeType", "fileSize", "filePath", "thumbnailPath", "uploadedBy", "geoLocation", "photoType", "submissionId", "createdAt", "updatedAt", verification_task_id, sha256_hash, server_sha256_hash, hash_verified, server_signature, file_size_bytes, capture_time, gps_latitude, gps_longitude, gps_validation_status, gps_distance_meters, device_id, app_version, exif_json, deleted_at, deleted_by, deletion_reason) FROM stdin;
\.


--
-- Data for Name: verification_task_templates; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.verification_task_templates (id, name, description, category, tasks, estimated_total_cost, estimated_duration_days, usage_count, is_active, created_at, updated_at, created_by) FROM stdin;
1	Standard Individual KYC	Complete KYC verification for individual customers	INDIVIDUAL	[{"title": "Verify Residential Address", "priority": "HIGH", "task_type": "RESIDENCE_ADDR"}, {"title": "Verify Identity Documents", "priority": "HIGH", "task_type": "DOCUMENT"}, {"title": "Verify Personal Identity", "priority": "MEDIUM", "task_type": "IDENTITY"}]	1500.00	3	0	t	2025-09-25 17:14:00.821276	2025-09-25 17:14:00.821276	\N
2	Business Verification Package	Complete verification for business entities	BUSINESS	[{"title": "Verify Business Address", "priority": "HIGH", "task_type": "OFFICE_ADDR"}, {"title": "Verify Business Operations", "priority": "HIGH", "task_type": "BUSINESS"}, {"title": "Verify Business Documents", "priority": "MEDIUM", "task_type": "DOCUMENT"}]	2500.00	5	0	t	2025-09-25 17:14:00.821276	2025-09-25 17:14:00.821276	\N
3	Property Verification Complete	Comprehensive property verification package	PROPERTY	[{"title": "Verify Property Address", "priority": "HIGH", "task_type": "RESIDENCE_ADDR"}, {"title": "Verify Property Documents", "priority": "HIGH", "task_type": "DOCUMENT"}, {"title": "Verify Property Business Use", "priority": "MEDIUM", "task_type": "BUSINESS"}]	2000.00	4	0	t	2025-09-25 17:14:00.821276	2025-09-25 17:14:00.821276	\N
\.


--
-- Data for Name: verification_task_types; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.verification_task_types (id, name, code, description, category, default_priority, estimated_duration_hours, requires_location, requires_documents, required_form_type, validation_rules, is_active, created_at, updated_at, created_by) FROM stdin;
1	Residence Address Verification	RESIDENCE_ADDR	Verify residential address and occupancy	ADDRESS	MEDIUM	24	t	f	RESIDENCE	\N	t	2025-09-25 17:14:00.821276	2025-09-25 17:14:00.821276	\N
2	Office Address Verification	OFFICE_ADDR	Verify office/business address	ADDRESS	MEDIUM	24	t	f	OFFICE	\N	t	2025-09-25 17:14:00.821276	2025-09-25 17:14:00.821276	\N
3	Document Verification	DOCUMENT	Verify authenticity of provided documents	DOCUMENT	MEDIUM	24	f	t	DOCUMENT	\N	t	2025-09-25 17:14:00.821276	2025-09-25 17:14:00.821276	\N
4	Identity Verification	IDENTITY	Verify identity of the applicant	IDENTITY	MEDIUM	24	f	t	IDENTITY	\N	t	2025-09-25 17:14:00.821276	2025-09-25 17:14:00.821276	\N
5	Business Verification	BUSINESS	Verify business operations and legitimacy	BUSINESS	MEDIUM	24	t	t	BUSINESS	\N	t	2025-09-25 17:14:00.821276	2025-09-25 17:14:00.821276	\N
6	Bank Account Verification	BANK_ACCOUNT	Verify bank account details	FINANCIAL	MEDIUM	24	f	t	FINANCIAL	\N	t	2025-09-25 17:14:00.821276	2025-09-25 17:14:00.821276	\N
7	Employment Verification	EMPLOYMENT	Verify employment status and details	EMPLOYMENT	MEDIUM	24	t	f	OFFICE	\N	t	2025-09-25 17:14:00.821276	2025-09-25 17:14:00.821276	\N
\.


--
-- Data for Name: verification_tasks; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.verification_tasks (id, task_number, case_id, verification_type_id, task_title, task_description, priority, assigned_to, assigned_by, assigned_at, status, verification_outcome, rate_type_id, estimated_amount, actual_amount, address, pincode, latitude, longitude, document_type, document_number, document_details, estimated_completion_date, started_at, completed_at, created_at, updated_at, created_by, trigger, applicant_type, revoked_at, revoked_by, revocation_reason, cancelled_at, cancelled_by, cancellation_reason, task_type, parent_task_id, saved_at, is_saved, first_assigned_at, current_assigned_at, service_zone_id, forensic_version, device_id, app_version, submitted_at, reviewer_id, reviewed_at, review_notes, area_id) FROM stdin;
\.


--
-- Data for Name: verifications; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.verifications (id, applicant_id, verification_type_id, address, pincode_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: visits; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.visits (id, verification_id, visit_number, assigned_to, status, assigned_at, started_at, completed_at, revoked_at, sla_deadline, geo_evidence, photos, form_data, review_notes, report_url, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: zone_rate_type_mapping; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.zone_rate_type_mapping (id, client_id, product_id, verification_type_id, service_zone_id, rate_type_id, is_active, created_at, updated_at) FROM stdin;
\.


--
-- Name: areas_temp_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.areas_temp_id_seq', 862, true);


--
-- Name: attachments_temp_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.attachments_temp_id_seq', 1, false);


--
-- Name: auditLogs_temp_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public."auditLogs_temp_id_seq"', 1, false);


--
-- Name: autoSaves_temp_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public."autoSaves_temp_id_seq"', 1, false);


--
-- Name: backgroundSyncQueue_temp_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public."backgroundSyncQueue_temp_id_seq"', 1, false);


--
-- Name: caseDeduplicationAudit_temp_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public."caseDeduplicationAudit_temp_id_seq"', 1, false);


--
-- Name: case_assignment_history_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.case_assignment_history_id_seq', 1, false);


--
-- Name: case_configuration_errors_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.case_configuration_errors_id_seq', 1, false);


--
-- Name: cases_caseId_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public."cases_caseId_seq"', 1, false);


--
-- Name: cities_temp_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.cities_temp_id_seq', 4, true);


--
-- Name: clientDocumentTypes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public."clientDocumentTypes_id_seq"', 1, false);


--
-- Name: clientProducts_temp_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public."clientProducts_temp_id_seq"', 1, false);


--
-- Name: clients_temp_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.clients_temp_id_seq', 1, false);


--
-- Name: commission_batch_items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.commission_batch_items_id_seq', 1, false);


--
-- Name: commission_calculations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.commission_calculations_id_seq', 1, false);


--
-- Name: commission_payment_batches_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.commission_payment_batches_id_seq', 1, false);


--
-- Name: commission_rate_types_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.commission_rate_types_id_seq', 1, false);


--
-- Name: countries_temp_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.countries_temp_id_seq', 2, true);


--
-- Name: departments_temp_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.departments_temp_id_seq', 5, true);


--
-- Name: designations_temp_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.designations_temp_id_seq', 5, true);


--
-- Name: documentTypeRates_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public."documentTypeRates_id_seq"', 1, false);


--
-- Name: documentTypes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public."documentTypes_id_seq"', 11, true);


--
-- Name: error_logs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.error_logs_id_seq', 1, false);


--
-- Name: field_user_commission_assignments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.field_user_commission_assignments_id_seq', 1, false);


--
-- Name: invoice_item_tasks_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.invoice_item_tasks_id_seq', 1, false);


--
-- Name: invoice_items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.invoice_items_id_seq', 1, false);


--
-- Name: invoice_status_history_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.invoice_status_history_id_seq', 1, false);


--
-- Name: invoices_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.invoices_id_seq', 1, false);


--
-- Name: locations_temp_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.locations_temp_id_seq', 1, false);


--
-- Name: mobile_notification_audit_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.mobile_notification_audit_id_seq', 1, false);


--
-- Name: notificationTokens_temp_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public."notificationTokens_temp_id_seq"', 1, false);


--
-- Name: performance_metrics_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.performance_metrics_id_seq', 1, false);


--
-- Name: pincodeAreas_temp_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public."pincodeAreas_temp_id_seq"', 880, true);


--
-- Name: pincodes_temp_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.pincodes_temp_id_seq', 215, true);


--
-- Name: productDocumentTypes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public."productDocumentTypes_id_seq"', 1, false);


--
-- Name: productVerificationTypes_temp_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public."productVerificationTypes_temp_id_seq"', 1, false);


--
-- Name: products_temp_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.products_temp_id_seq', 1, false);


--
-- Name: query_performance_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.query_performance_id_seq', 1, false);


--
-- Name: rateHistory_temp_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public."rateHistory_temp_id_seq"', 1, false);


--
-- Name: rateTypeAssignments_temp_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public."rateTypeAssignments_temp_id_seq"', 1, false);


--
-- Name: rateTypes_temp_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public."rateTypes_temp_id_seq"', 8, true);


--
-- Name: rates_temp_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.rates_temp_id_seq', 1, false);


--
-- Name: refreshTokens_temp_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public."refreshTokens_temp_id_seq"', 1, false);


--
-- Name: service_zone_rules_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.service_zone_rules_id_seq', 1, false);


--
-- Name: service_zones_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.service_zones_id_seq', 1, false);


--
-- Name: states_temp_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.states_temp_id_seq', 2, true);


--
-- Name: system_health_metrics_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.system_health_metrics_id_seq', 1, false);


--
-- Name: task_revocations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.task_revocations_id_seq', 1, false);


--
-- Name: territoryAssignmentAudit_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public."territoryAssignmentAudit_id_seq"', 1, false);


--
-- Name: userAreaAssignments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public."userAreaAssignments_id_seq"', 1, false);


--
-- Name: userClientAssignments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public."userClientAssignments_id_seq"', 1, false);


--
-- Name: userPincodeAssignments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public."userPincodeAssignments_id_seq"', 1, false);


--
-- Name: userProductAssignments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public."userProductAssignments_id_seq"', 1, false);


--
-- Name: verificationTypes_temp_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public."verificationTypes_temp_id_seq"', 9, true);


--
-- Name: verification_attachments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.verification_attachments_id_seq', 1, false);


--
-- Name: verification_task_number_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.verification_task_number_seq', 77, true);


--
-- Name: verification_task_templates_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.verification_task_templates_id_seq', 3, true);


--
-- Name: verification_task_types_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.verification_task_types_id_seq', 7, true);


--
-- Name: zone_rate_type_mapping_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.zone_rate_type_mapping_id_seq', 1, false);


--
-- Name: agent_performance_daily agent_performance_daily_agent_id_date_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_performance_daily
    ADD CONSTRAINT agent_performance_daily_agent_id_date_key UNIQUE (agent_id, date);


--
-- Name: agent_performance_daily agent_performance_daily_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_performance_daily
    ADD CONSTRAINT agent_performance_daily_pkey PRIMARY KEY (id);


--
-- Name: ai_reports ai_reports_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ai_reports
    ADD CONSTRAINT ai_reports_pkey PRIMARY KEY (id);


--
-- Name: applicants applicants_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.applicants
    ADD CONSTRAINT applicants_pkey PRIMARY KEY (id);


--
-- Name: areas areas_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.areas
    ADD CONSTRAINT areas_pkey PRIMARY KEY (id);


--
-- Name: attachments attachments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.attachments
    ADD CONSTRAINT attachments_pkey PRIMARY KEY (id);


--
-- Name: auditLogs auditLogs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."auditLogs"
    ADD CONSTRAINT "auditLogs_pkey" PRIMARY KEY (id);


--
-- Name: autoSaves autoSaves_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."autoSaves"
    ADD CONSTRAINT "autoSaves_pkey" PRIMARY KEY (id);


--
-- Name: backgroundSyncQueue backgroundSyncQueue_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."backgroundSyncQueue"
    ADD CONSTRAINT "backgroundSyncQueue_pkey" PRIMARY KEY (id);


--
-- Name: builderVerificationReports builderVerificationReports_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."builderVerificationReports"
    ADD CONSTRAINT "builderVerificationReports_pkey" PRIMARY KEY (id);


--
-- Name: businessVerificationReports businessVerificationReports_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."businessVerificationReports"
    ADD CONSTRAINT "businessVerificationReports_pkey" PRIMARY KEY (id);


--
-- Name: caseDeduplicationAudit caseDeduplicationAudit_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."caseDeduplicationAudit"
    ADD CONSTRAINT "caseDeduplicationAudit_pkey" PRIMARY KEY (id);


--
-- Name: case_assignment_conflicts case_assignment_conflicts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.case_assignment_conflicts
    ADD CONSTRAINT case_assignment_conflicts_pkey PRIMARY KEY (id);


--
-- Name: case_assignment_history case_assignment_history_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.case_assignment_history
    ADD CONSTRAINT case_assignment_history_pkey PRIMARY KEY (id);


--
-- Name: case_assignment_queue_status case_assignment_queue_status_batchId_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.case_assignment_queue_status
    ADD CONSTRAINT "case_assignment_queue_status_batchId_key" UNIQUE ("batchId");


--
-- Name: case_assignment_queue_status case_assignment_queue_status_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.case_assignment_queue_status
    ADD CONSTRAINT case_assignment_queue_status_pkey PRIMARY KEY (id);


--
-- Name: case_configuration_errors case_configuration_errors_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.case_configuration_errors
    ADD CONSTRAINT case_configuration_errors_pkey PRIMARY KEY (id);


--
-- Name: case_status_history case_status_history_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.case_status_history
    ADD CONSTRAINT case_status_history_pkey PRIMARY KEY (id);


--
-- Name: case_timeline_events case_timeline_events_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.case_timeline_events
    ADD CONSTRAINT case_timeline_events_pkey PRIMARY KEY (id);


--
-- Name: cases cases_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cases
    ADD CONSTRAINT cases_pkey PRIMARY KEY ("caseId");


--
-- Name: cities cities_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cities
    ADD CONSTRAINT cities_pkey PRIMARY KEY (id);


--
-- Name: clientDocumentTypes clientDocumentTypes_clientId_documentTypeId_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."clientDocumentTypes"
    ADD CONSTRAINT "clientDocumentTypes_clientId_documentTypeId_key" UNIQUE ("clientId", "documentTypeId");


--
-- Name: clientDocumentTypes clientDocumentTypes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."clientDocumentTypes"
    ADD CONSTRAINT "clientDocumentTypes_pkey" PRIMARY KEY (id);


--
-- Name: clientProducts clientProducts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."clientProducts"
    ADD CONSTRAINT "clientProducts_pkey" PRIMARY KEY (id);


--
-- Name: clients clients_code_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.clients
    ADD CONSTRAINT clients_code_key UNIQUE (code);


--
-- Name: clients clients_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.clients
    ADD CONSTRAINT clients_pkey PRIMARY KEY (id);


--
-- Name: commission_batch_items commission_batch_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.commission_batch_items
    ADD CONSTRAINT commission_batch_items_pkey PRIMARY KEY (id);


--
-- Name: commission_calculations commission_calculations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.commission_calculations
    ADD CONSTRAINT commission_calculations_pkey PRIMARY KEY (id);


--
-- Name: commission_payment_batches commission_payment_batches_batch_number_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.commission_payment_batches
    ADD CONSTRAINT commission_payment_batches_batch_number_key UNIQUE (batch_number);


--
-- Name: commission_payment_batches commission_payment_batches_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.commission_payment_batches
    ADD CONSTRAINT commission_payment_batches_pkey PRIMARY KEY (id);


--
-- Name: commission_rate_types commission_rate_types_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.commission_rate_types
    ADD CONSTRAINT commission_rate_types_pkey PRIMARY KEY (id);


--
-- Name: countries countries_code_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.countries
    ADD CONSTRAINT countries_code_key UNIQUE (code);


--
-- Name: countries countries_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.countries
    ADD CONSTRAINT countries_name_key UNIQUE (name);


--
-- Name: countries countries_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.countries
    ADD CONSTRAINT countries_pkey PRIMARY KEY (id);


--
-- Name: departments departments_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.departments
    ADD CONSTRAINT departments_name_key UNIQUE (name);


--
-- Name: departments departments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.departments
    ADD CONSTRAINT departments_pkey PRIMARY KEY (id);


--
-- Name: designations designations_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.designations
    ADD CONSTRAINT designations_name_key UNIQUE (name);


--
-- Name: designations designations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.designations
    ADD CONSTRAINT designations_pkey PRIMARY KEY (id);


--
-- Name: documentTypeRates documentTypeRates_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."documentTypeRates"
    ADD CONSTRAINT "documentTypeRates_pkey" PRIMARY KEY (id);


--
-- Name: documentTypes documentTypes_code_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."documentTypes"
    ADD CONSTRAINT "documentTypes_code_key" UNIQUE (code);


--
-- Name: documentTypes documentTypes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."documentTypes"
    ADD CONSTRAINT "documentTypes_pkey" PRIMARY KEY (id);


--
-- Name: dsaConnectorVerificationReports dsaConnectorVerificationReports_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."dsaConnectorVerificationReports"
    ADD CONSTRAINT "dsaConnectorVerificationReports_pkey" PRIMARY KEY (id);


--
-- Name: error_logs error_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.error_logs
    ADD CONSTRAINT error_logs_pkey PRIMARY KEY (id);


--
-- Name: field_user_commission_assignments field_user_commission_assignments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.field_user_commission_assignments
    ADD CONSTRAINT field_user_commission_assignments_pkey PRIMARY KEY (id);


--
-- Name: form_quality_metrics form_quality_metrics_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.form_quality_metrics
    ADD CONSTRAINT form_quality_metrics_pkey PRIMARY KEY (id);


--
-- Name: form_submissions form_submissions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.form_submissions
    ADD CONSTRAINT form_submissions_pkey PRIMARY KEY (id);


--
-- Name: form_validation_logs form_validation_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.form_validation_logs
    ADD CONSTRAINT form_validation_logs_pkey PRIMARY KEY (id);


--
-- Name: invoice_item_tasks invoice_item_tasks_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invoice_item_tasks
    ADD CONSTRAINT invoice_item_tasks_pkey PRIMARY KEY (id);


--
-- Name: invoice_item_tasks invoice_item_tasks_verification_task_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invoice_item_tasks
    ADD CONSTRAINT invoice_item_tasks_verification_task_id_key UNIQUE (verification_task_id);


--
-- Name: invoice_items invoice_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invoice_items
    ADD CONSTRAINT invoice_items_pkey PRIMARY KEY (id);


--
-- Name: invoice_status_history invoice_status_history_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invoice_status_history
    ADD CONSTRAINT invoice_status_history_pkey PRIMARY KEY (id);


--
-- Name: invoices invoices_invoice_number_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invoices
    ADD CONSTRAINT invoices_invoice_number_key UNIQUE (invoice_number);


--
-- Name: invoices invoices_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invoices
    ADD CONSTRAINT invoices_pkey PRIMARY KEY (id);


--
-- Name: locations locations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.locations
    ADD CONSTRAINT locations_pkey PRIMARY KEY (id);


--
-- Name: migrations migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.migrations
    ADD CONSTRAINT migrations_pkey PRIMARY KEY (id);


--
-- Name: mobile_device_sync mobile_device_sync_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mobile_device_sync
    ADD CONSTRAINT mobile_device_sync_pkey PRIMARY KEY (id);


--
-- Name: mobile_device_sync mobile_device_sync_userId_deviceId_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mobile_device_sync
    ADD CONSTRAINT "mobile_device_sync_userId_deviceId_key" UNIQUE ("userId", "deviceId");


--
-- Name: mobile_notification_audit mobile_notification_audit_notificationId_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mobile_notification_audit
    ADD CONSTRAINT "mobile_notification_audit_notificationId_key" UNIQUE ("notificationId");


--
-- Name: mobile_notification_audit mobile_notification_audit_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mobile_notification_audit
    ADD CONSTRAINT mobile_notification_audit_pkey PRIMARY KEY (id);


--
-- Name: mobile_notification_queue mobile_notification_queue_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mobile_notification_queue
    ADD CONSTRAINT mobile_notification_queue_pkey PRIMARY KEY (id);


--
-- Name: nocVerificationReports nocVerificationReports_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."nocVerificationReports"
    ADD CONSTRAINT "nocVerificationReports_pkey" PRIMARY KEY (id);


--
-- Name: notificationTokens notificationTokens_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."notificationTokens"
    ADD CONSTRAINT "notificationTokens_pkey" PRIMARY KEY (id);


--
-- Name: notification_batches notification_batches_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notification_batches
    ADD CONSTRAINT notification_batches_pkey PRIMARY KEY (id);


--
-- Name: notification_delivery_log notification_delivery_log_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notification_delivery_log
    ADD CONSTRAINT notification_delivery_log_pkey PRIMARY KEY (id);


--
-- Name: notification_preferences notification_preferences_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notification_preferences
    ADD CONSTRAINT notification_preferences_pkey PRIMARY KEY (id);


--
-- Name: notification_preferences notification_preferences_user_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notification_preferences
    ADD CONSTRAINT notification_preferences_user_id_key UNIQUE (user_id);


--
-- Name: notification_tokens notification_tokens_device_id_platform_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notification_tokens
    ADD CONSTRAINT notification_tokens_device_id_platform_key UNIQUE (device_id, platform);


--
-- Name: notification_tokens notification_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notification_tokens
    ADD CONSTRAINT notification_tokens_pkey PRIMARY KEY (id);


--
-- Name: notificationTokens notification_tokens_token_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."notificationTokens"
    ADD CONSTRAINT notification_tokens_token_key UNIQUE (token);


--
-- Name: notifications notifications_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_pkey PRIMARY KEY (id);


--
-- Name: officeVerificationReports officeVerificationReports_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."officeVerificationReports"
    ADD CONSTRAINT "officeVerificationReports_pkey" PRIMARY KEY (id);


--
-- Name: performance_metrics performance_metrics_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.performance_metrics
    ADD CONSTRAINT performance_metrics_pkey PRIMARY KEY (id);


--
-- Name: permissions permissions_code_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.permissions
    ADD CONSTRAINT permissions_code_key UNIQUE (code);


--
-- Name: permissions permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.permissions
    ADD CONSTRAINT permissions_pkey PRIMARY KEY (id);


--
-- Name: pincodeAreas pincodeAreas_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."pincodeAreas"
    ADD CONSTRAINT "pincodeAreas_pkey" PRIMARY KEY (id);


--
-- Name: pincodes pincodes_code_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pincodes
    ADD CONSTRAINT pincodes_code_key UNIQUE (code);


--
-- Name: pincodes pincodes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pincodes
    ADD CONSTRAINT pincodes_pkey PRIMARY KEY (id);


--
-- Name: productDocumentTypes productDocumentTypes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."productDocumentTypes"
    ADD CONSTRAINT "productDocumentTypes_pkey" PRIMARY KEY (id);


--
-- Name: productDocumentTypes productDocumentTypes_productId_documentTypeId_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."productDocumentTypes"
    ADD CONSTRAINT "productDocumentTypes_productId_documentTypeId_key" UNIQUE ("productId", "documentTypeId");


--
-- Name: productVerificationTypes productVerificationTypes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."productVerificationTypes"
    ADD CONSTRAINT "productVerificationTypes_pkey" PRIMARY KEY (id);


--
-- Name: products products_code_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT products_code_key UNIQUE (code);


--
-- Name: products products_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT products_pkey PRIMARY KEY (id);


--
-- Name: propertyApfVerificationReports propertyApfVerificationReports_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."propertyApfVerificationReports"
    ADD CONSTRAINT "propertyApfVerificationReports_pkey" PRIMARY KEY (id);


--
-- Name: propertyIndividualVerificationReports propertyIndividualVerificationReports_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."propertyIndividualVerificationReports"
    ADD CONSTRAINT "propertyIndividualVerificationReports_pkey" PRIMARY KEY (id);


--
-- Name: query_performance query_performance_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.query_performance
    ADD CONSTRAINT query_performance_pkey PRIMARY KEY (id);


--
-- Name: rateHistory rateHistory_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."rateHistory"
    ADD CONSTRAINT "rateHistory_pkey" PRIMARY KEY (id);


--
-- Name: rateTypeAssignments rateTypeAssignments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."rateTypeAssignments"
    ADD CONSTRAINT "rateTypeAssignments_pkey" PRIMARY KEY (id);


--
-- Name: rateTypes rateTypes_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."rateTypes"
    ADD CONSTRAINT "rateTypes_name_key" UNIQUE (name);


--
-- Name: rateTypes rateTypes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."rateTypes"
    ADD CONSTRAINT "rateTypes_pkey" PRIMARY KEY (id);


--
-- Name: rates rates_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rates
    ADD CONSTRAINT rates_pkey PRIMARY KEY (id);


--
-- Name: refreshTokens refreshTokens_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."refreshTokens"
    ADD CONSTRAINT "refreshTokens_pkey" PRIMARY KEY (id);


--
-- Name: refreshTokens refresh_tokens_token_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."refreshTokens"
    ADD CONSTRAINT refresh_tokens_token_key UNIQUE (token);


--
-- Name: residenceCumOfficeVerificationReports residenceCumOfficeVerificationReports_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."residenceCumOfficeVerificationReports"
    ADD CONSTRAINT "residenceCumOfficeVerificationReports_pkey" PRIMARY KEY (id);


--
-- Name: residenceVerificationReports residenceVerificationReports_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."residenceVerificationReports"
    ADD CONSTRAINT "residenceVerificationReports_pkey" PRIMARY KEY (id);


--
-- Name: role_permissions role_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.role_permissions
    ADD CONSTRAINT role_permissions_pkey PRIMARY KEY (id);


--
-- Name: role_permissions role_permissions_role_id_permission_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.role_permissions
    ADD CONSTRAINT role_permissions_role_id_permission_id_key UNIQUE (role_id, permission_id);


--
-- Name: role_routes role_routes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.role_routes
    ADD CONSTRAINT role_routes_pkey PRIMARY KEY (id);


--
-- Name: role_routes role_routes_role_id_route_key_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.role_routes
    ADD CONSTRAINT role_routes_role_id_route_key_key UNIQUE (role_id, route_key);


--
-- Name: roles_v2 roles_v2_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.roles_v2
    ADD CONSTRAINT roles_v2_name_key UNIQUE (name);


--
-- Name: roles_v2 roles_v2_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.roles_v2
    ADD CONSTRAINT roles_v2_pkey PRIMARY KEY (id);


--
-- Name: scheduled_reports scheduled_reports_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.scheduled_reports
    ADD CONSTRAINT scheduled_reports_pkey PRIMARY KEY (id);


--
-- Name: schema_migrations_legacy_archive schema_migrations_legacy_archive_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.schema_migrations_legacy_archive
    ADD CONSTRAINT schema_migrations_legacy_archive_pkey PRIMARY KEY (id);


--
-- Name: schema_migrations schema_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.schema_migrations
    ADD CONSTRAINT schema_migrations_pkey PRIMARY KEY (id);


--
-- Name: security_audit_events security_audit_events_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.security_audit_events
    ADD CONSTRAINT security_audit_events_pkey PRIMARY KEY (id);


--
-- Name: service_zone_rules service_zone_rules_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.service_zone_rules
    ADD CONSTRAINT service_zone_rules_pkey PRIMARY KEY (id);


--
-- Name: service_zones service_zones_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.service_zones
    ADD CONSTRAINT service_zones_name_key UNIQUE (name);


--
-- Name: service_zones service_zones_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.service_zones
    ADD CONSTRAINT service_zones_pkey PRIMARY KEY (id);


--
-- Name: states states_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.states
    ADD CONSTRAINT states_pkey PRIMARY KEY (id);


--
-- Name: system_health_metrics system_health_metrics_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.system_health_metrics
    ADD CONSTRAINT system_health_metrics_pkey PRIMARY KEY (id);


--
-- Name: task_assignment_history task_assignment_history_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.task_assignment_history
    ADD CONSTRAINT task_assignment_history_pkey PRIMARY KEY (id);


--
-- Name: task_commission_calculations task_commission_calculations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.task_commission_calculations
    ADD CONSTRAINT task_commission_calculations_pkey PRIMARY KEY (id);


--
-- Name: task_form_submissions task_form_submissions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.task_form_submissions
    ADD CONSTRAINT task_form_submissions_pkey PRIMARY KEY (id);


--
-- Name: task_revocations task_revocations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.task_revocations
    ADD CONSTRAINT task_revocations_pkey PRIMARY KEY (id);


--
-- Name: template_reports template_reports_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.template_reports
    ADD CONSTRAINT template_reports_pkey PRIMARY KEY (id);


--
-- Name: territoryAssignmentAudit territoryAssignmentAudit_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."territoryAssignmentAudit"
    ADD CONSTRAINT "territoryAssignmentAudit_pkey" PRIMARY KEY (id);


--
-- Name: trusted_devices trusted_devices_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trusted_devices
    ADD CONSTRAINT trusted_devices_pkey PRIMARY KEY (id);


--
-- Name: trusted_devices trusted_devices_user_id_device_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trusted_devices
    ADD CONSTRAINT trusted_devices_user_id_device_id_key UNIQUE (user_id, device_id);


--
-- Name: commission_batch_items uk_commission_batch_items_commission; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.commission_batch_items
    ADD CONSTRAINT uk_commission_batch_items_commission UNIQUE (commission_id);


--
-- Name: field_user_commission_assignments uk_field_user_commission_assignments; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.field_user_commission_assignments
    ADD CONSTRAINT uk_field_user_commission_assignments UNIQUE (user_id, rate_type_id, client_id, effective_from);


--
-- Name: userClientAssignments uk_user_client_assignments_user_client; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."userClientAssignments"
    ADD CONSTRAINT uk_user_client_assignments_user_client UNIQUE ("userId", "clientId");


--
-- Name: userProductAssignments uk_user_product_assignments_user_product; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."userProductAssignments"
    ADD CONSTRAINT uk_user_product_assignments_user_product UNIQUE ("userId", "productId");


--
-- Name: documentTypeRates unique_active_document_type_rate; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."documentTypeRates"
    ADD CONSTRAINT unique_active_document_type_rate UNIQUE ("clientId", "productId", "documentTypeId", "isActive") DEFERRABLE INITIALLY DEFERRED;


--
-- Name: commission_calculations unique_commission_per_task; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.commission_calculations
    ADD CONSTRAINT unique_commission_per_task UNIQUE (verification_task_id);


--
-- Name: CONSTRAINT unique_commission_per_task ON commission_calculations; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON CONSTRAINT unique_commission_per_task ON public.commission_calculations IS 'Ensures each verification task can generate commission only once. Prevents duplicate payouts from concurrent requests or retries.';


--
-- Name: task_commission_calculations unique_task_commission; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.task_commission_calculations
    ADD CONSTRAINT unique_task_commission UNIQUE (verification_task_id, user_id);


--
-- Name: task_form_submissions unique_task_form_submission; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.task_form_submissions
    ADD CONSTRAINT unique_task_form_submission UNIQUE (verification_task_id, form_submission_id);


--
-- Name: verification_tasks unique_task_number; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.verification_tasks
    ADD CONSTRAINT unique_task_number UNIQUE (task_number);


--
-- Name: userAreaAssignments userAreaAssignments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."userAreaAssignments"
    ADD CONSTRAINT "userAreaAssignments_pkey" PRIMARY KEY (id);


--
-- Name: userClientAssignments userClientAssignments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."userClientAssignments"
    ADD CONSTRAINT "userClientAssignments_pkey" PRIMARY KEY (id);


--
-- Name: userPincodeAssignments userPincodeAssignments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."userPincodeAssignments"
    ADD CONSTRAINT "userPincodeAssignments_pkey" PRIMARY KEY (id);


--
-- Name: userProductAssignments userProductAssignments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."userProductAssignments"
    ADD CONSTRAINT "userProductAssignments_pkey" PRIMARY KEY (id);


--
-- Name: user_roles user_roles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT user_roles_pkey PRIMARY KEY (id);


--
-- Name: user_roles user_roles_user_id_role_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT user_roles_user_id_role_id_key UNIQUE (user_id, role_id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: users users_username_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_username_key UNIQUE (username);


--
-- Name: verificationTypes verificationTypes_code_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."verificationTypes"
    ADD CONSTRAINT "verificationTypes_code_key" UNIQUE (code);


--
-- Name: verificationTypes verificationTypes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."verificationTypes"
    ADD CONSTRAINT "verificationTypes_pkey" PRIMARY KEY (id);


--
-- Name: verification_attachments verification_attachments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.verification_attachments
    ADD CONSTRAINT verification_attachments_pkey PRIMARY KEY (id);


--
-- Name: verification_task_templates verification_task_templates_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.verification_task_templates
    ADD CONSTRAINT verification_task_templates_pkey PRIMARY KEY (id);


--
-- Name: verification_task_types verification_task_types_code_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.verification_task_types
    ADD CONSTRAINT verification_task_types_code_key UNIQUE (code);


--
-- Name: verification_task_types verification_task_types_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.verification_task_types
    ADD CONSTRAINT verification_task_types_name_key UNIQUE (name);


--
-- Name: verification_task_types verification_task_types_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.verification_task_types
    ADD CONSTRAINT verification_task_types_pkey PRIMARY KEY (id);


--
-- Name: verification_tasks verification_tasks_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.verification_tasks
    ADD CONSTRAINT verification_tasks_pkey PRIMARY KEY (id);


--
-- Name: verifications verifications_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.verifications
    ADD CONSTRAINT verifications_pkey PRIMARY KEY (id);


--
-- Name: visits visits_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.visits
    ADD CONSTRAINT visits_pkey PRIMARY KEY (id);


--
-- Name: zone_rate_type_mapping zone_rate_type_mapping_client_id_product_id_verification_ty_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.zone_rate_type_mapping
    ADD CONSTRAINT zone_rate_type_mapping_client_id_product_id_verification_ty_key UNIQUE (client_id, product_id, verification_type_id, service_zone_id);


--
-- Name: zone_rate_type_mapping zone_rate_type_mapping_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.zone_rate_type_mapping
    ADD CONSTRAINT zone_rate_type_mapping_pkey PRIMARY KEY (id);


--
-- Name: cases_id_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX cases_id_unique ON public.cases USING btree (id);


--
-- Name: idx_agent_performance_daily_agent_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_agent_performance_daily_agent_id ON public.agent_performance_daily USING btree (agent_id);


--
-- Name: idx_agent_performance_daily_composite; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_agent_performance_daily_composite ON public.agent_performance_daily USING btree (agent_id, date);


--
-- Name: idx_agent_performance_daily_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_agent_performance_daily_date ON public.agent_performance_daily USING btree (date);


--
-- Name: idx_agent_performance_daily_quality_score; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_agent_performance_daily_quality_score ON public.agent_performance_daily USING btree (quality_score);


--
-- Name: idx_ai_reports_case_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_ai_reports_case_id ON public.ai_reports USING btree (case_id);


--
-- Name: idx_ai_reports_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_ai_reports_created_at ON public.ai_reports USING btree (created_at);


--
-- Name: idx_ai_reports_generated_by; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_ai_reports_generated_by ON public.ai_reports USING btree (generated_by);


--
-- Name: idx_ai_reports_submission_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_ai_reports_submission_id ON public.ai_reports USING btree (submission_id);


--
-- Name: idx_ai_reports_unique_submission; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_ai_reports_unique_submission ON public.ai_reports USING btree (case_id, submission_id);


--
-- Name: idx_attachments_case_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_attachments_case_created ON public.attachments USING btree ("caseId", "createdAt");


--
-- Name: INDEX idx_attachments_case_created; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON INDEX public.idx_attachments_case_created IS 'Performance index for attachments by case and date';


--
-- Name: idx_attachments_case_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_attachments_case_id ON public.attachments USING btree ("caseId");


--
-- Name: idx_attachments_case_uuid; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_attachments_case_uuid ON public.attachments USING btree (case_id);


--
-- Name: idx_attachments_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_attachments_created_at ON public.attachments USING btree ("createdAt");


--
-- Name: idx_attachments_uploaded_by; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_attachments_uploaded_by ON public.attachments USING btree ("uploadedBy");


--
-- Name: idx_attachments_verification_task_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_attachments_verification_task_id ON public.attachments USING btree (verification_task_id);


--
-- Name: idx_audit_logs_action; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_audit_logs_action ON public."auditLogs" USING btree (action);


--
-- Name: idx_audit_logs_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_audit_logs_created_at ON public."auditLogs" USING btree ("createdAt");


--
-- Name: idx_audit_logs_entity_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_audit_logs_entity_id ON public."auditLogs" USING btree ("entityId");


--
-- Name: idx_audit_logs_entity_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_audit_logs_entity_type ON public."auditLogs" USING btree ("entityType");


--
-- Name: idx_audit_logs_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_audit_logs_user_id ON public."auditLogs" USING btree ("userId");


--
-- Name: idx_autosaves_case_uuid; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_autosaves_case_uuid ON public."autoSaves" USING btree (case_id);


--
-- Name: idx_background_sync_queue_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_background_sync_queue_status ON public."backgroundSyncQueue" USING btree (status);


--
-- Name: idx_background_sync_queue_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_background_sync_queue_user_id ON public."backgroundSyncQueue" USING btree ("userId");


--
-- Name: idx_builder_reports_task_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_builder_reports_task_id ON public."builderVerificationReports" USING btree (verification_task_id);


--
-- Name: idx_builder_verification_case_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_builder_verification_case_id ON public."builderVerificationReports" USING btree (case_id);


--
-- Name: idx_builder_verification_customer_name; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_builder_verification_customer_name ON public."builderVerificationReports" USING btree (customer_name);


--
-- Name: idx_builder_verification_customer_phone; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_builder_verification_customer_phone ON public."builderVerificationReports" USING btree (customer_phone);


--
-- Name: idx_builder_verification_final_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_builder_verification_final_status ON public."builderVerificationReports" USING btree (final_status);


--
-- Name: idx_builder_verification_form_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_builder_verification_form_type ON public."builderVerificationReports" USING btree (form_type);


--
-- Name: idx_builder_verification_legacy_case_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_builder_verification_legacy_case_id ON public."builderVerificationReports" USING btree ("caseId");


--
-- Name: idx_builder_verification_locality; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_builder_verification_locality ON public."builderVerificationReports" USING btree (locality);


--
-- Name: idx_builder_verification_outcome; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_builder_verification_outcome ON public."builderVerificationReports" USING btree (verification_outcome);


--
-- Name: idx_builder_verification_verification_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_builder_verification_verification_date ON public."builderVerificationReports" USING btree (verification_date);


--
-- Name: idx_builder_verification_verified_by; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_builder_verification_verified_by ON public."builderVerificationReports" USING btree (verified_by);


--
-- Name: idx_business_reports_task_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_business_reports_task_id ON public."businessVerificationReports" USING btree (verification_task_id);


--
-- Name: idx_business_verification_case_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_business_verification_case_id ON public."businessVerificationReports" USING btree (case_id);


--
-- Name: idx_business_verification_customer_name; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_business_verification_customer_name ON public."businessVerificationReports" USING btree (customer_name);


--
-- Name: idx_business_verification_customer_phone; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_business_verification_customer_phone ON public."businessVerificationReports" USING btree (customer_phone);


--
-- Name: idx_business_verification_final_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_business_verification_final_status ON public."businessVerificationReports" USING btree (final_status);


--
-- Name: idx_business_verification_form_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_business_verification_form_type ON public."businessVerificationReports" USING btree (form_type);


--
-- Name: idx_business_verification_legacy_case_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_business_verification_legacy_case_id ON public."businessVerificationReports" USING btree ("caseId");


--
-- Name: idx_business_verification_locality; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_business_verification_locality ON public."businessVerificationReports" USING btree (locality);


--
-- Name: idx_business_verification_outcome; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_business_verification_outcome ON public."businessVerificationReports" USING btree (verification_outcome);


--
-- Name: idx_business_verification_verification_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_business_verification_verification_date ON public."businessVerificationReports" USING btree (verification_date);


--
-- Name: idx_business_verification_verified_by; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_business_verification_verified_by ON public."businessVerificationReports" USING btree (verified_by);


--
-- Name: idx_case_assignment_conflicts_case_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_case_assignment_conflicts_case_id ON public.case_assignment_conflicts USING btree ("caseId");


--
-- Name: idx_case_assignment_conflicts_detected_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_case_assignment_conflicts_detected_at ON public.case_assignment_conflicts USING btree ("detectedAt");


--
-- Name: idx_case_assignment_conflicts_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_case_assignment_conflicts_status ON public.case_assignment_conflicts USING btree (status);


--
-- Name: idx_case_assignment_history_assigned_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_case_assignment_history_assigned_at ON public.case_assignment_history USING btree ("assignedAt");


--
-- Name: idx_case_assignment_history_assigned_by; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_case_assignment_history_assigned_by ON public.case_assignment_history USING btree ("assignedById");


--
-- Name: idx_case_assignment_history_batch_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_case_assignment_history_batch_id ON public.case_assignment_history USING btree ("batchId") WHERE ("batchId" IS NOT NULL);


--
-- Name: idx_case_assignment_history_case_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_case_assignment_history_case_id ON public.case_assignment_history USING btree ("caseId");


--
-- Name: idx_case_assignment_history_case_uuid; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_case_assignment_history_case_uuid ON public.case_assignment_history USING btree (case_id);


--
-- Name: idx_case_assignment_history_from_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_case_assignment_history_from_user ON public.case_assignment_history USING btree ("fromUserId");


--
-- Name: idx_case_assignment_history_to_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_case_assignment_history_to_user ON public.case_assignment_history USING btree ("toUserId");


--
-- Name: idx_case_assignment_queue_status_batch_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_case_assignment_queue_status_batch_id ON public.case_assignment_queue_status USING btree ("batchId");


--
-- Name: idx_case_assignment_queue_status_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_case_assignment_queue_status_created_at ON public.case_assignment_queue_status USING btree ("createdAt");


--
-- Name: idx_case_assignment_queue_status_created_by; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_case_assignment_queue_status_created_by ON public.case_assignment_queue_status USING btree ("createdById");


--
-- Name: idx_case_assignment_queue_status_job_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_case_assignment_queue_status_job_id ON public.case_assignment_queue_status USING btree ("jobId");


--
-- Name: idx_case_assignment_queue_status_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_case_assignment_queue_status_status ON public.case_assignment_queue_status USING btree (status);


--
-- Name: idx_case_config_errors_case_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_case_config_errors_case_id ON public.case_configuration_errors USING btree (case_id);


--
-- Name: idx_case_config_errors_unresolved; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_case_config_errors_unresolved ON public.case_configuration_errors USING btree (case_id) WHERE (resolved_at IS NULL);


--
-- Name: idx_case_deduplication_audit_duplicates_found; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_case_deduplication_audit_duplicates_found ON public."caseDeduplicationAudit" USING gin ("duplicatesFound");


--
-- Name: idx_case_deduplication_audit_performed_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_case_deduplication_audit_performed_at ON public."caseDeduplicationAudit" USING btree ("performedAt");


--
-- Name: idx_case_deduplication_audit_performed_by; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_case_deduplication_audit_performed_by ON public."caseDeduplicationAudit" USING btree ("performedBy");


--
-- Name: idx_case_deduplication_audit_search_criteria; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_case_deduplication_audit_search_criteria ON public."caseDeduplicationAudit" USING gin ("searchCriteria");


--
-- Name: idx_case_deduplication_audit_user_decision; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_case_deduplication_audit_user_decision ON public."caseDeduplicationAudit" USING btree ("userDecision");


--
-- Name: idx_case_status_history_case_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_case_status_history_case_id ON public.case_status_history USING btree ("caseId");


--
-- Name: idx_case_status_history_case_uuid; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_case_status_history_case_uuid ON public.case_status_history USING btree (case_id);


--
-- Name: idx_case_status_history_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_case_status_history_status ON public.case_status_history USING btree (status);


--
-- Name: idx_case_status_history_transitioned_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_case_status_history_transitioned_at ON public.case_status_history USING btree ("transitionedAt");


--
-- Name: idx_case_timeline_events_case_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_case_timeline_events_case_id ON public.case_timeline_events USING btree (case_id);


--
-- Name: idx_case_timeline_events_composite; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_case_timeline_events_composite ON public.case_timeline_events USING btree (case_id, event_timestamp);


--
-- Name: idx_case_timeline_events_event_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_case_timeline_events_event_type ON public.case_timeline_events USING btree (event_type);


--
-- Name: idx_case_timeline_events_performed_by; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_case_timeline_events_performed_by ON public.case_timeline_events USING btree (performed_by);


--
-- Name: idx_case_timeline_events_timestamp; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_case_timeline_events_timestamp ON public.case_timeline_events USING btree (event_timestamp);


--
-- Name: idx_casededuplicationaudit_case_uuid; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_casededuplicationaudit_case_uuid ON public."caseDeduplicationAudit" USING btree (case_id);


--
-- Name: idx_cases_case_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_cases_case_id ON public.cases USING btree ("caseId");


--
-- Name: idx_cases_client_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_cases_client_id ON public.cases USING btree ("clientId");


--
-- Name: idx_cases_client_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_cases_client_status ON public.cases USING btree ("clientId", status);


--
-- Name: idx_cases_completion_percentage; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_cases_completion_percentage ON public.cases USING btree (case_completion_percentage);


--
-- Name: idx_cases_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_cases_created_at ON public.cases USING btree ("createdAt");


--
-- Name: idx_cases_created_by_backend_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_cases_created_by_backend_user ON public.cases USING btree ("createdByBackendUser");


--
-- Name: idx_cases_created_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_cases_created_status ON public.cases USING btree ("createdAt", status);


--
-- Name: idx_cases_customer_name_gin; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_cases_customer_name_gin ON public.cases USING gin (to_tsvector('english'::regconfig, ("customerName")::text));


--
-- Name: idx_cases_customer_name_search; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_cases_customer_name_search ON public.cases USING gin (to_tsvector('english'::regconfig, ("customerName")::text));


--
-- Name: idx_cases_customer_name_trgm; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_cases_customer_name_trgm ON public.cases USING gin ("customerName" public.gin_trgm_ops);


--
-- Name: idx_cases_customer_phone; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_cases_customer_phone ON public.cases USING btree ("customerPhone") WHERE ("customerPhone" IS NOT NULL);


--
-- Name: idx_cases_deduplication_fields; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_cases_deduplication_fields ON public.cases USING btree ("panNumber", "customerPhone");


--
-- Name: idx_cases_form_completion_percentage; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_cases_form_completion_percentage ON public.cases USING btree (form_completion_percentage);


--
-- Name: idx_cases_has_multiple_tasks; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_cases_has_multiple_tasks ON public.cases USING btree (has_multiple_tasks);


--
-- Name: idx_cases_last_form_submitted_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_cases_last_form_submitted_at ON public.cases USING btree (last_form_submitted_at);


--
-- Name: idx_cases_pan_number; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_cases_pan_number ON public.cases USING btree ("panNumber") WHERE ("panNumber" IS NOT NULL);


--
-- Name: idx_cases_priority; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_cases_priority ON public.cases USING btree (priority);


--
-- Name: idx_cases_product_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_cases_product_id ON public.cases USING btree ("productId");


--
-- Name: idx_cases_quality_score; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_cases_quality_score ON public.cases USING btree (quality_score);


--
-- Name: idx_cases_rate_type_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_cases_rate_type_id ON public.cases USING btree ("rateTypeId");


--
-- Name: idx_cases_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_cases_status ON public.cases USING btree (status);


--
-- Name: idx_cases_total_tasks_count; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_cases_total_tasks_count ON public.cases USING btree (total_tasks_count);


--
-- Name: idx_cases_updated_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_cases_updated_at ON public.cases USING btree ("updatedAt");


--
-- Name: idx_cases_verification_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_cases_verification_type ON public.cases USING btree ("verificationType") WHERE ("verificationType" IS NOT NULL);


--
-- Name: idx_cases_verification_type_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_cases_verification_type_id ON public.cases USING btree ("verificationTypeId");


--
-- Name: idx_cities_name; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_cities_name ON public.cities USING btree (name);


--
-- Name: idx_cities_state_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_cities_state_id ON public.cities USING btree ("stateId");


--
-- Name: idx_client_document_types_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_client_document_types_active ON public."clientDocumentTypes" USING btree (is_active);


--
-- Name: idx_client_document_types_client; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_client_document_types_client ON public."clientDocumentTypes" USING btree ("clientId");


--
-- Name: idx_client_document_types_document; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_client_document_types_document ON public."clientDocumentTypes" USING btree ("documentTypeId");


--
-- Name: idx_client_products_client_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_client_products_client_id ON public."clientProducts" USING btree ("clientId");


--
-- Name: idx_client_products_product_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_client_products_product_id ON public."clientProducts" USING btree ("productId");


--
-- Name: idx_clients_code; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_clients_code ON public.clients USING btree (code);


--
-- Name: idx_clients_name_search; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_clients_name_search ON public.clients USING gin (to_tsvector('english'::regconfig, (name)::text));


--
-- Name: idx_commission_batch_items_batch_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_commission_batch_items_batch_id ON public.commission_batch_items USING btree (batch_id);


--
-- Name: idx_commission_batch_items_commission_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_commission_batch_items_commission_id ON public.commission_batch_items USING btree (commission_id);


--
-- Name: idx_commission_calc_task_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_commission_calc_task_id ON public.commission_calculations USING btree (verification_task_id);


--
-- Name: idx_commission_calculations_case_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_commission_calculations_case_id ON public.commission_calculations USING btree (case_id);


--
-- Name: idx_commission_calculations_client_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_commission_calculations_client_id ON public.commission_calculations USING btree (client_id);


--
-- Name: idx_commission_calculations_completed_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_commission_calculations_completed_at ON public.commission_calculations USING btree (case_completed_at);


--
-- Name: idx_commission_calculations_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_commission_calculations_status ON public.commission_calculations USING btree (status);


--
-- Name: idx_commission_calculations_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_commission_calculations_user_id ON public.commission_calculations USING btree (user_id);


--
-- Name: idx_commission_calculations_user_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_commission_calculations_user_status ON public.commission_calculations USING btree (user_id, status);


--
-- Name: idx_commission_payment_batches_created_by; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_commission_payment_batches_created_by ON public.commission_payment_batches USING btree (created_by);


--
-- Name: idx_commission_payment_batches_payment_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_commission_payment_batches_payment_date ON public.commission_payment_batches USING btree (payment_date);


--
-- Name: idx_commission_payment_batches_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_commission_payment_batches_status ON public.commission_payment_batches USING btree (status);


--
-- Name: idx_commission_rate_types_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_commission_rate_types_active ON public.commission_rate_types USING btree (is_active);


--
-- Name: idx_commission_rate_types_rate_type_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_commission_rate_types_rate_type_id ON public.commission_rate_types USING btree (rate_type_id);


--
-- Name: idx_countries_code; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_countries_code ON public.countries USING btree (code);


--
-- Name: idx_countries_continent; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_countries_continent ON public.countries USING btree (continent);


--
-- Name: idx_dedup_audit_performed_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_dedup_audit_performed_at ON public."caseDeduplicationAudit" USING btree ("performedAt");


--
-- Name: idx_dedup_audit_performed_by; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_dedup_audit_performed_by ON public."caseDeduplicationAudit" USING btree ("performedBy");


--
-- Name: idx_departments_head; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_departments_head ON public.departments USING btree ("departmentHeadId");


--
-- Name: idx_departments_is_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_departments_is_active ON public.departments USING btree ("isActive");


--
-- Name: idx_departments_name; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_departments_name ON public.departments USING btree (name);


--
-- Name: idx_designations_is_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_designations_is_active ON public.designations USING btree ("isActive");


--
-- Name: idx_designations_name; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_designations_name ON public.designations USING btree (name);


--
-- Name: idx_document_type_rates_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_document_type_rates_active ON public."documentTypeRates" USING btree ("isActive");


--
-- Name: idx_document_type_rates_client; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_document_type_rates_client ON public."documentTypeRates" USING btree ("clientId");


--
-- Name: idx_document_type_rates_created_by; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_document_type_rates_created_by ON public."documentTypeRates" USING btree ("createdBy");


--
-- Name: idx_document_type_rates_document_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_document_type_rates_document_type ON public."documentTypeRates" USING btree ("documentTypeId");


--
-- Name: idx_document_type_rates_effective; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_document_type_rates_effective ON public."documentTypeRates" USING btree ("effectiveFrom", "effectiveTo");


--
-- Name: idx_document_type_rates_lookup; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_document_type_rates_lookup ON public."documentTypeRates" USING btree ("clientId", "productId", "documentTypeId", "isActive");


--
-- Name: idx_document_type_rates_product; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_document_type_rates_product ON public."documentTypeRates" USING btree ("productId");


--
-- Name: idx_document_types_code; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_document_types_code ON public."documentTypes" USING btree (code);


--
-- Name: idx_dsa_connector_reports_task_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_dsa_connector_reports_task_id ON public."dsaConnectorVerificationReports" USING btree (verification_task_id);


--
-- Name: idx_dsa_connector_verification_business_name; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_dsa_connector_verification_business_name ON public."dsaConnectorVerificationReports" USING btree (business_name);


--
-- Name: idx_dsa_connector_verification_case_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_dsa_connector_verification_case_id ON public."dsaConnectorVerificationReports" USING btree (case_id);


--
-- Name: idx_dsa_connector_verification_connector_code; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_dsa_connector_verification_connector_code ON public."dsaConnectorVerificationReports" USING btree (connector_code);


--
-- Name: idx_dsa_connector_verification_connector_name; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_dsa_connector_verification_connector_name ON public."dsaConnectorVerificationReports" USING btree (connector_name);


--
-- Name: idx_dsa_connector_verification_connector_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_dsa_connector_verification_connector_type ON public."dsaConnectorVerificationReports" USING btree (connector_type);


--
-- Name: idx_dsa_connector_verification_customer_name; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_dsa_connector_verification_customer_name ON public."dsaConnectorVerificationReports" USING btree (customer_name);


--
-- Name: idx_dsa_connector_verification_customer_phone; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_dsa_connector_verification_customer_phone ON public."dsaConnectorVerificationReports" USING btree (customer_phone);


--
-- Name: idx_dsa_connector_verification_final_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_dsa_connector_verification_final_status ON public."dsaConnectorVerificationReports" USING btree (final_status);


--
-- Name: idx_dsa_connector_verification_form_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_dsa_connector_verification_form_type ON public."dsaConnectorVerificationReports" USING btree (form_type);


--
-- Name: idx_dsa_connector_verification_legacy_case_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_dsa_connector_verification_legacy_case_id ON public."dsaConnectorVerificationReports" USING btree ("caseId");


--
-- Name: idx_dsa_connector_verification_locality; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_dsa_connector_verification_locality ON public."dsaConnectorVerificationReports" USING btree (locality);


--
-- Name: idx_dsa_connector_verification_outcome; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_dsa_connector_verification_outcome ON public."dsaConnectorVerificationReports" USING btree (verification_outcome);


--
-- Name: idx_dsa_connector_verification_verification_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_dsa_connector_verification_verification_date ON public."dsaConnectorVerificationReports" USING btree (verification_date);


--
-- Name: idx_dsa_connector_verification_verified_by; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_dsa_connector_verification_verified_by ON public."dsaConnectorVerificationReports" USING btree (verified_by);


--
-- Name: idx_error_logs_error_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_error_logs_error_type ON public.error_logs USING btree (error_type);


--
-- Name: idx_error_logs_request_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_error_logs_request_id ON public.error_logs USING btree (request_id);


--
-- Name: idx_error_logs_timestamp; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_error_logs_timestamp ON public.error_logs USING btree ("timestamp");


--
-- Name: idx_error_logs_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_error_logs_user_id ON public.error_logs USING btree (user_id);


--
-- Name: idx_field_user_commission_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_field_user_commission_active ON public.field_user_commission_assignments USING btree (is_active);


--
-- Name: idx_field_user_commission_client_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_field_user_commission_client_id ON public.field_user_commission_assignments USING btree (client_id);


--
-- Name: idx_field_user_commission_effective; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_field_user_commission_effective ON public.field_user_commission_assignments USING btree (effective_from, effective_to);


--
-- Name: idx_field_user_commission_rate_type_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_field_user_commission_rate_type_id ON public.field_user_commission_assignments USING btree (rate_type_id);


--
-- Name: idx_field_user_commission_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_field_user_commission_user_id ON public.field_user_commission_assignments USING btree (user_id);


--
-- Name: idx_form_quality_metrics_calculated_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_form_quality_metrics_calculated_at ON public.form_quality_metrics USING btree (calculated_at);


--
-- Name: idx_form_quality_metrics_overall_score; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_form_quality_metrics_overall_score ON public.form_quality_metrics USING btree (overall_quality_score);


--
-- Name: idx_form_quality_metrics_submission_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_form_quality_metrics_submission_id ON public.form_quality_metrics USING btree (form_submission_id);


--
-- Name: idx_form_submissions_case_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_form_submissions_case_id ON public.form_submissions USING btree (case_id);


--
-- Name: idx_form_submissions_composite; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_form_submissions_composite ON public.form_submissions USING btree (form_type, validation_status, submitted_at);


--
-- Name: idx_form_submissions_form_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_form_submissions_form_type ON public.form_submissions USING btree (form_type);


--
-- Name: idx_form_submissions_submitted_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_form_submissions_submitted_at ON public.form_submissions USING btree (submitted_at);


--
-- Name: idx_form_submissions_submitted_by; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_form_submissions_submitted_by ON public.form_submissions USING btree (submitted_by);


--
-- Name: idx_form_submissions_task_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_form_submissions_task_id ON public.form_submissions USING btree (verification_task_id);


--
-- Name: idx_form_submissions_validation_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_form_submissions_validation_status ON public.form_submissions USING btree (validation_status);


--
-- Name: idx_form_submissions_verification_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_form_submissions_verification_type ON public.form_submissions USING btree (verification_type_id);


--
-- Name: idx_form_validation_logs_field_name; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_form_validation_logs_field_name ON public.form_validation_logs USING btree (field_name);


--
-- Name: idx_form_validation_logs_is_valid; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_form_validation_logs_is_valid ON public.form_validation_logs USING btree (is_valid);


--
-- Name: idx_form_validation_logs_submission_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_form_validation_logs_submission_id ON public.form_validation_logs USING btree (form_submission_id);


--
-- Name: idx_form_validation_logs_validated_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_form_validation_logs_validated_at ON public.form_validation_logs USING btree (validated_at);


--
-- Name: idx_invoice_item_tasks_case_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_invoice_item_tasks_case_id ON public.invoice_item_tasks USING btree (case_id);


--
-- Name: idx_invoice_item_tasks_client_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_invoice_item_tasks_client_id ON public.invoice_item_tasks USING btree (client_id);


--
-- Name: idx_invoice_item_tasks_invoice_item_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_invoice_item_tasks_invoice_item_id ON public.invoice_item_tasks USING btree (invoice_item_id);


--
-- Name: idx_invoice_items_client_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_invoice_items_client_id ON public.invoice_items USING btree (client_id);


--
-- Name: idx_invoice_items_invoice_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_invoice_items_invoice_id ON public.invoice_items USING btree (invoice_id);


--
-- Name: idx_invoice_status_history_invoice_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_invoice_status_history_invoice_id ON public.invoice_status_history USING btree (invoice_id, changed_at DESC);


--
-- Name: idx_invoices_client_status_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_invoices_client_status_date ON public.invoices USING btree (client_id, status, issue_date DESC);


--
-- Name: idx_invoices_due_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_invoices_due_date ON public.invoices USING btree (due_date);


--
-- Name: idx_invoices_product_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_invoices_product_status ON public.invoices USING btree (product_id, status);


--
-- Name: idx_locations_case_uuid; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_locations_case_uuid ON public.locations USING btree (case_id);


--
-- Name: idx_locations_task_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_locations_task_id ON public.locations USING btree (verification_task_id);


--
-- Name: idx_mobile_device_sync_last_sync; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_mobile_device_sync_last_sync ON public.mobile_device_sync USING btree ("lastSyncAt");


--
-- Name: idx_mobile_device_sync_platform; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_mobile_device_sync_platform ON public.mobile_device_sync USING btree (platform);


--
-- Name: idx_mobile_device_sync_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_mobile_device_sync_user_id ON public.mobile_device_sync USING btree ("userId");


--
-- Name: idx_mobile_notification_audit_case_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_mobile_notification_audit_case_id ON public.mobile_notification_audit USING btree ("caseId");


--
-- Name: idx_mobile_notification_audit_case_uuid; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_mobile_notification_audit_case_uuid ON public.mobile_notification_audit USING btree (case_id);


--
-- Name: idx_mobile_notification_audit_notification_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_mobile_notification_audit_notification_id ON public.mobile_notification_audit USING btree ("notificationId");


--
-- Name: idx_mobile_notification_audit_sent_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_mobile_notification_audit_sent_at ON public.mobile_notification_audit USING btree ("sentAt");


--
-- Name: idx_mobile_notification_audit_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_mobile_notification_audit_status ON public.mobile_notification_audit USING btree ("deliveryStatus");


--
-- Name: idx_mobile_notification_audit_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_mobile_notification_audit_type ON public.mobile_notification_audit USING btree ("notificationType");


--
-- Name: idx_mobile_notification_audit_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_mobile_notification_audit_user_id ON public.mobile_notification_audit USING btree ("userId");


--
-- Name: idx_mobile_notification_queue_notification_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_mobile_notification_queue_notification_type ON public.mobile_notification_queue USING btree ("notificationType");


--
-- Name: idx_mobile_notification_queue_scheduled_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_mobile_notification_queue_scheduled_at ON public.mobile_notification_queue USING btree ("scheduledAt");


--
-- Name: idx_mobile_notification_queue_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_mobile_notification_queue_status ON public.mobile_notification_queue USING btree (status);


--
-- Name: idx_mobile_notification_queue_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_mobile_notification_queue_user_id ON public.mobile_notification_queue USING btree ("userId");


--
-- Name: idx_noc_reports_task_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_noc_reports_task_id ON public."nocVerificationReports" USING btree (verification_task_id);


--
-- Name: idx_noc_verification_builder_name; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_noc_verification_builder_name ON public."nocVerificationReports" USING btree (builder_name);


--
-- Name: idx_noc_verification_case_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_noc_verification_case_id ON public."nocVerificationReports" USING btree (case_id);


--
-- Name: idx_noc_verification_customer_name; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_noc_verification_customer_name ON public."nocVerificationReports" USING btree (customer_name);


--
-- Name: idx_noc_verification_customer_phone; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_noc_verification_customer_phone ON public."nocVerificationReports" USING btree (customer_phone);


--
-- Name: idx_noc_verification_final_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_noc_verification_final_status ON public."nocVerificationReports" USING btree (final_status);


--
-- Name: idx_noc_verification_form_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_noc_verification_form_type ON public."nocVerificationReports" USING btree (form_type);


--
-- Name: idx_noc_verification_legacy_case_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_noc_verification_legacy_case_id ON public."nocVerificationReports" USING btree ("caseId");


--
-- Name: idx_noc_verification_locality; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_noc_verification_locality ON public."nocVerificationReports" USING btree (locality);


--
-- Name: idx_noc_verification_noc_number; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_noc_verification_noc_number ON public."nocVerificationReports" USING btree (noc_number);


--
-- Name: idx_noc_verification_outcome; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_noc_verification_outcome ON public."nocVerificationReports" USING btree (verification_outcome);


--
-- Name: idx_noc_verification_project_name; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_noc_verification_project_name ON public."nocVerificationReports" USING btree (project_name);


--
-- Name: idx_noc_verification_verification_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_noc_verification_verification_date ON public."nocVerificationReports" USING btree (verification_date);


--
-- Name: idx_noc_verification_verified_by; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_noc_verification_verified_by ON public."nocVerificationReports" USING btree (verified_by);


--
-- Name: idx_notification_batches_batch_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_notification_batches_batch_type ON public.notification_batches USING btree (batch_type);


--
-- Name: idx_notification_batches_created_by; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_notification_batches_created_by ON public.notification_batches USING btree (created_by);


--
-- Name: idx_notification_batches_scheduled_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_notification_batches_scheduled_at ON public.notification_batches USING btree (scheduled_at);


--
-- Name: idx_notification_batches_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_notification_batches_status ON public.notification_batches USING btree (status);


--
-- Name: idx_notification_delivery_log_attempted_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_notification_delivery_log_attempted_at ON public.notification_delivery_log USING btree (attempted_at DESC);


--
-- Name: idx_notification_delivery_log_delivery_method; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_notification_delivery_log_delivery_method ON public.notification_delivery_log USING btree (delivery_method);


--
-- Name: idx_notification_delivery_log_delivery_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_notification_delivery_log_delivery_status ON public.notification_delivery_log USING btree (delivery_status);


--
-- Name: idx_notification_delivery_log_notification_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_notification_delivery_log_notification_id ON public.notification_delivery_log USING btree (notification_id);


--
-- Name: idx_notification_preferences_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_notification_preferences_user_id ON public.notification_preferences USING btree (user_id);


--
-- Name: idx_notification_tokens_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_notification_tokens_active ON public.notification_tokens USING btree (is_active);


--
-- Name: idx_notification_tokens_platform; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_notification_tokens_platform ON public.notification_tokens USING btree (platform);


--
-- Name: idx_notification_tokens_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_notification_tokens_user_id ON public."notificationTokens" USING btree ("userId");


--
-- Name: idx_notifications_case_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_notifications_case_id ON public.notifications USING btree (case_id);


--
-- Name: idx_notifications_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_notifications_created_at ON public.notifications USING btree (created_at DESC);


--
-- Name: idx_notifications_delivery_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_notifications_delivery_status ON public.notifications USING btree (delivery_status);


--
-- Name: idx_notifications_expires_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_notifications_expires_at ON public.notifications USING btree (expires_at);


--
-- Name: idx_notifications_is_read; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_notifications_is_read ON public.notifications USING btree (is_read);


--
-- Name: idx_notifications_priority; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_notifications_priority ON public.notifications USING btree (priority);


--
-- Name: idx_notifications_task_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_notifications_task_id ON public.notifications USING btree (task_id);


--
-- Name: idx_notifications_task_number; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_notifications_task_number ON public.notifications USING btree (task_number);


--
-- Name: idx_notifications_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_notifications_type ON public.notifications USING btree (type);


--
-- Name: idx_notifications_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_notifications_user_id ON public.notifications USING btree (user_id);


--
-- Name: idx_office_reports_task_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_office_reports_task_id ON public."officeVerificationReports" USING btree (verification_task_id);


--
-- Name: idx_office_verification_case_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_office_verification_case_id ON public."officeVerificationReports" USING btree (case_id);


--
-- Name: idx_office_verification_customer_name; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_office_verification_customer_name ON public."officeVerificationReports" USING btree (customer_name);


--
-- Name: idx_office_verification_customer_phone; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_office_verification_customer_phone ON public."officeVerificationReports" USING btree (customer_phone);


--
-- Name: idx_office_verification_final_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_office_verification_final_status ON public."officeVerificationReports" USING btree (final_status);


--
-- Name: idx_office_verification_form_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_office_verification_form_type ON public."officeVerificationReports" USING btree (form_type);


--
-- Name: idx_office_verification_legacy_case_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_office_verification_legacy_case_id ON public."officeVerificationReports" USING btree ("caseId");


--
-- Name: idx_office_verification_locality; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_office_verification_locality ON public."officeVerificationReports" USING btree (locality);


--
-- Name: idx_office_verification_outcome; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_office_verification_outcome ON public."officeVerificationReports" USING btree (verification_outcome);


--
-- Name: idx_office_verification_verification_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_office_verification_verification_date ON public."officeVerificationReports" USING btree (verification_date);


--
-- Name: idx_office_verification_verified_by; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_office_verification_verified_by ON public."officeVerificationReports" USING btree (verified_by);


--
-- Name: idx_performance_metrics_response_time; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_performance_metrics_response_time ON public.performance_metrics USING btree (response_time);


--
-- Name: idx_performance_metrics_status_code; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_performance_metrics_status_code ON public.performance_metrics USING btree (status_code);


--
-- Name: idx_performance_metrics_timestamp; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_performance_metrics_timestamp ON public.performance_metrics USING btree ("timestamp");


--
-- Name: idx_performance_metrics_url; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_performance_metrics_url ON public.performance_metrics USING btree (url);


--
-- Name: idx_performance_metrics_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_performance_metrics_user_id ON public.performance_metrics USING btree (user_id);


--
-- Name: idx_pincode_areas_area_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_pincode_areas_area_id ON public."pincodeAreas" USING btree ("areaId");


--
-- Name: idx_pincode_areas_pincode_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_pincode_areas_pincode_id ON public."pincodeAreas" USING btree ("pincodeId");


--
-- Name: idx_pincodes_city_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_pincodes_city_id ON public.pincodes USING btree ("cityId");


--
-- Name: idx_pincodes_code; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_pincodes_code ON public.pincodes USING btree (code);


--
-- Name: idx_product_document_types_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_product_document_types_active ON public."productDocumentTypes" USING btree (is_active);


--
-- Name: idx_product_document_types_document; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_product_document_types_document ON public."productDocumentTypes" USING btree ("documentTypeId");


--
-- Name: idx_product_document_types_product; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_product_document_types_product ON public."productDocumentTypes" USING btree ("productId");


--
-- Name: idx_product_verification_types_product_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_product_verification_types_product_id ON public."productVerificationTypes" USING btree ("productId");


--
-- Name: idx_product_verification_types_verification_type_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_product_verification_types_verification_type_id ON public."productVerificationTypes" USING btree ("verificationTypeId");


--
-- Name: idx_property_apf_reports_task_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_property_apf_reports_task_id ON public."propertyApfVerificationReports" USING btree (verification_task_id);


--
-- Name: idx_property_apf_verification_apf_number; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_property_apf_verification_apf_number ON public."propertyApfVerificationReports" USING btree (apf_number);


--
-- Name: idx_property_apf_verification_builder_name; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_property_apf_verification_builder_name ON public."propertyApfVerificationReports" USING btree (builder_name);


--
-- Name: idx_property_apf_verification_case_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_property_apf_verification_case_id ON public."propertyApfVerificationReports" USING btree (case_id);


--
-- Name: idx_property_apf_verification_customer_name; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_property_apf_verification_customer_name ON public."propertyApfVerificationReports" USING btree (customer_name);


--
-- Name: idx_property_apf_verification_customer_phone; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_property_apf_verification_customer_phone ON public."propertyApfVerificationReports" USING btree (customer_phone);


--
-- Name: idx_property_apf_verification_final_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_property_apf_verification_final_status ON public."propertyApfVerificationReports" USING btree (final_status);


--
-- Name: idx_property_apf_verification_form_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_property_apf_verification_form_type ON public."propertyApfVerificationReports" USING btree (form_type);


--
-- Name: idx_property_apf_verification_legacy_case_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_property_apf_verification_legacy_case_id ON public."propertyApfVerificationReports" USING btree ("caseId");


--
-- Name: idx_property_apf_verification_locality; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_property_apf_verification_locality ON public."propertyApfVerificationReports" USING btree (locality);


--
-- Name: idx_property_apf_verification_outcome; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_property_apf_verification_outcome ON public."propertyApfVerificationReports" USING btree (verification_outcome);


--
-- Name: idx_property_apf_verification_project_name; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_property_apf_verification_project_name ON public."propertyApfVerificationReports" USING btree (project_name);


--
-- Name: idx_property_apf_verification_property_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_property_apf_verification_property_type ON public."propertyApfVerificationReports" USING btree (property_type);


--
-- Name: idx_property_apf_verification_verification_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_property_apf_verification_verification_date ON public."propertyApfVerificationReports" USING btree (verification_date);


--
-- Name: idx_property_apf_verification_verified_by; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_property_apf_verification_verified_by ON public."propertyApfVerificationReports" USING btree (verified_by);


--
-- Name: idx_property_individual_reports_task_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_property_individual_reports_task_id ON public."propertyIndividualVerificationReports" USING btree (verification_task_id);


--
-- Name: idx_property_individual_verification_case_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_property_individual_verification_case_id ON public."propertyIndividualVerificationReports" USING btree (case_id);


--
-- Name: idx_property_individual_verification_customer_name; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_property_individual_verification_customer_name ON public."propertyIndividualVerificationReports" USING btree (customer_name);


--
-- Name: idx_property_individual_verification_customer_phone; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_property_individual_verification_customer_phone ON public."propertyIndividualVerificationReports" USING btree (customer_phone);


--
-- Name: idx_property_individual_verification_final_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_property_individual_verification_final_status ON public."propertyIndividualVerificationReports" USING btree (final_status);


--
-- Name: idx_property_individual_verification_form_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_property_individual_verification_form_type ON public."propertyIndividualVerificationReports" USING btree (form_type);


--
-- Name: idx_property_individual_verification_legacy_case_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_property_individual_verification_legacy_case_id ON public."propertyIndividualVerificationReports" USING btree ("caseId");


--
-- Name: idx_property_individual_verification_locality; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_property_individual_verification_locality ON public."propertyIndividualVerificationReports" USING btree (locality);


--
-- Name: idx_property_individual_verification_outcome; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_property_individual_verification_outcome ON public."propertyIndividualVerificationReports" USING btree (verification_outcome);


--
-- Name: idx_property_individual_verification_owner_name; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_property_individual_verification_owner_name ON public."propertyIndividualVerificationReports" USING btree (owner_name);


--
-- Name: idx_property_individual_verification_property_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_property_individual_verification_property_type ON public."propertyIndividualVerificationReports" USING btree (property_type);


--
-- Name: idx_property_individual_verification_verification_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_property_individual_verification_verification_date ON public."propertyIndividualVerificationReports" USING btree (verification_date);


--
-- Name: idx_property_individual_verification_verified_by; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_property_individual_verification_verified_by ON public."propertyIndividualVerificationReports" USING btree (verified_by);


--
-- Name: idx_query_performance_execution_time; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_query_performance_execution_time ON public.query_performance USING btree (execution_time);


--
-- Name: idx_query_performance_hash; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_query_performance_hash ON public.query_performance USING btree (query_hash);


--
-- Name: idx_query_performance_timestamp; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_query_performance_timestamp ON public.query_performance USING btree ("timestamp");


--
-- Name: idx_rate_history_changed_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_rate_history_changed_at ON public."rateHistory" USING btree ("changedAt");


--
-- Name: idx_rates_effective_from; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_rates_effective_from ON public.rates USING btree ("effectiveFrom");


--
-- Name: idx_rates_effective_to; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_rates_effective_to ON public.rates USING btree ("effectiveTo");


--
-- Name: idx_refresh_tokens_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_refresh_tokens_user_id ON public."refreshTokens" USING btree ("userId");


--
-- Name: idx_res_cum_office_verification_case_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_res_cum_office_verification_case_id ON public."residenceCumOfficeVerificationReports" USING btree (case_id);


--
-- Name: idx_res_cum_office_verification_customer_name; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_res_cum_office_verification_customer_name ON public."residenceCumOfficeVerificationReports" USING btree (customer_name);


--
-- Name: idx_res_cum_office_verification_customer_phone; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_res_cum_office_verification_customer_phone ON public."residenceCumOfficeVerificationReports" USING btree (customer_phone);


--
-- Name: idx_res_cum_office_verification_final_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_res_cum_office_verification_final_status ON public."residenceCumOfficeVerificationReports" USING btree (final_status);


--
-- Name: idx_res_cum_office_verification_form_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_res_cum_office_verification_form_type ON public."residenceCumOfficeVerificationReports" USING btree (form_type);


--
-- Name: idx_res_cum_office_verification_legacy_case_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_res_cum_office_verification_legacy_case_id ON public."residenceCumOfficeVerificationReports" USING btree ("caseId");


--
-- Name: idx_res_cum_office_verification_locality; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_res_cum_office_verification_locality ON public."residenceCumOfficeVerificationReports" USING btree (locality);


--
-- Name: idx_res_cum_office_verification_outcome; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_res_cum_office_verification_outcome ON public."residenceCumOfficeVerificationReports" USING btree (verification_outcome);


--
-- Name: idx_res_cum_office_verification_verification_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_res_cum_office_verification_verification_date ON public."residenceCumOfficeVerificationReports" USING btree (verification_date);


--
-- Name: idx_res_cum_office_verification_verified_by; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_res_cum_office_verification_verified_by ON public."residenceCumOfficeVerificationReports" USING btree (verified_by);


--
-- Name: idx_residence_cum_office_reports_task_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_residence_cum_office_reports_task_id ON public."residenceCumOfficeVerificationReports" USING btree (verification_task_id);


--
-- Name: idx_residence_reports_task_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_residence_reports_task_id ON public."residenceVerificationReports" USING btree (verification_task_id);


--
-- Name: idx_residence_verification_case_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_residence_verification_case_id ON public."residenceVerificationReports" USING btree (case_id);


--
-- Name: idx_residence_verification_customer_name; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_residence_verification_customer_name ON public."residenceVerificationReports" USING btree (customer_name);


--
-- Name: idx_residence_verification_customer_phone; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_residence_verification_customer_phone ON public."residenceVerificationReports" USING btree (customer_phone);


--
-- Name: idx_residence_verification_final_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_residence_verification_final_status ON public."residenceVerificationReports" USING btree (final_status);


--
-- Name: idx_residence_verification_form_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_residence_verification_form_type ON public."residenceVerificationReports" USING btree (form_type);


--
-- Name: idx_residence_verification_legacy_case_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_residence_verification_legacy_case_id ON public."residenceVerificationReports" USING btree ("caseId");


--
-- Name: idx_residence_verification_locality; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_residence_verification_locality ON public."residenceVerificationReports" USING btree (locality);


--
-- Name: idx_residence_verification_outcome; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_residence_verification_outcome ON public."residenceVerificationReports" USING btree (verification_outcome);


--
-- Name: idx_residence_verification_verification_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_residence_verification_verification_date ON public."residenceVerificationReports" USING btree (verification_date);


--
-- Name: idx_residence_verification_verified_by; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_residence_verification_verified_by ON public."residenceVerificationReports" USING btree (verified_by);


--
-- Name: idx_scheduled_reports_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_scheduled_reports_active ON public.scheduled_reports USING btree (is_active);


--
-- Name: idx_scheduled_reports_created_by; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_scheduled_reports_created_by ON public.scheduled_reports USING btree (created_by);


--
-- Name: idx_scheduled_reports_next_run; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_scheduled_reports_next_run ON public.scheduled_reports USING btree (next_run);


--
-- Name: idx_schema_migrations_executed_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_schema_migrations_executed_at ON public.schema_migrations USING btree (executed_at);


--
-- Name: idx_security_audit_events_severity; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_security_audit_events_severity ON public.security_audit_events USING btree (severity, created_at DESC);


--
-- Name: idx_security_audit_events_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_security_audit_events_type ON public.security_audit_events USING btree (event_type, created_at DESC);


--
-- Name: idx_security_audit_events_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_security_audit_events_user ON public.security_audit_events USING btree (user_id, created_at DESC);


--
-- Name: idx_service_zone_rules_exact_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_service_zone_rules_exact_unique ON public.service_zone_rules USING btree (client_id, product_id, pincode_id, area_id);


--
-- Name: idx_states_code; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_states_code ON public.states USING btree (code);


--
-- Name: idx_states_country_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_states_country_id ON public.states USING btree ("countryId");


--
-- Name: idx_states_name; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_states_name ON public.states USING btree (name);


--
-- Name: idx_system_health_metrics_name; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_system_health_metrics_name ON public.system_health_metrics USING btree (metric_name);


--
-- Name: idx_system_health_metrics_timestamp; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_system_health_metrics_timestamp ON public.system_health_metrics USING btree ("timestamp");


--
-- Name: idx_sz_rules_lookup; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_sz_rules_lookup ON public.service_zone_rules USING btree (client_id, product_id, pincode_id, area_id);


--
-- Name: idx_task_assignment_assigned_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_task_assignment_assigned_at ON public.task_assignment_history USING btree (assigned_at);


--
-- Name: idx_task_assignment_assigned_by; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_task_assignment_assigned_by ON public.task_assignment_history USING btree (assigned_by);


--
-- Name: idx_task_assignment_assigned_to; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_task_assignment_assigned_to ON public.task_assignment_history USING btree (assigned_to);


--
-- Name: idx_task_assignment_verification_task; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_task_assignment_verification_task ON public.task_assignment_history USING btree (verification_task_id);


--
-- Name: idx_task_commission_calculation_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_task_commission_calculation_date ON public.task_commission_calculations USING btree (calculation_date);


--
-- Name: idx_task_commission_case; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_task_commission_case ON public.task_commission_calculations USING btree (case_id);


--
-- Name: idx_task_commission_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_task_commission_status ON public.task_commission_calculations USING btree (status);


--
-- Name: idx_task_commission_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_task_commission_user ON public.task_commission_calculations USING btree (user_id);


--
-- Name: idx_task_commission_verification_task; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_task_commission_verification_task ON public.task_commission_calculations USING btree (verification_task_id);


--
-- Name: idx_task_form_case; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_task_form_case ON public.task_form_submissions USING btree (case_id);


--
-- Name: idx_task_form_submission; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_task_form_submission ON public.task_form_submissions USING btree (form_submission_id);


--
-- Name: idx_task_form_submissions_task_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_task_form_submissions_task_id ON public.task_form_submissions USING btree (verification_task_id);


--
-- Name: idx_task_form_submitted_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_task_form_submitted_at ON public.task_form_submissions USING btree (submitted_at);


--
-- Name: idx_task_form_verification_task; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_task_form_verification_task ON public.task_form_submissions USING btree (verification_task_id);


--
-- Name: idx_task_revocations_reassigned; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_task_revocations_reassigned ON public.task_revocations USING btree (reassigned);


--
-- Name: idx_task_revocations_revoked_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_task_revocations_revoked_at ON public.task_revocations USING btree (revoked_at DESC);


--
-- Name: idx_task_revocations_revoked_by_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_task_revocations_revoked_by_user_id ON public.task_revocations USING btree (revoked_by_user_id);


--
-- Name: idx_task_revocations_revoked_from_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_task_revocations_revoked_from_user_id ON public.task_revocations USING btree (revoked_from_user_id);


--
-- Name: idx_task_revocations_task_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_task_revocations_task_id ON public.task_revocations USING btree (task_id);


--
-- Name: idx_task_templates_category; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_task_templates_category ON public.verification_task_templates USING btree (category);


--
-- Name: idx_task_templates_is_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_task_templates_is_active ON public.verification_task_templates USING btree (is_active);


--
-- Name: idx_task_templates_usage_count; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_task_templates_usage_count ON public.verification_task_templates USING btree (usage_count);


--
-- Name: idx_task_types_category; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_task_types_category ON public.verification_task_types USING btree (category);


--
-- Name: idx_task_types_code; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_task_types_code ON public.verification_task_types USING btree (code);


--
-- Name: idx_task_types_is_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_task_types_is_active ON public.verification_task_types USING btree (is_active);


--
-- Name: idx_template_reports_case_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_template_reports_case_id ON public.template_reports USING btree (case_id);


--
-- Name: idx_template_reports_case_submission; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_template_reports_case_submission ON public.template_reports USING btree (case_id, submission_id);


--
-- Name: idx_template_reports_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_template_reports_created_at ON public.template_reports USING btree (created_at);


--
-- Name: idx_template_reports_created_by; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_template_reports_created_by ON public.template_reports USING btree (created_by);


--
-- Name: idx_template_reports_outcome; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_template_reports_outcome ON public.template_reports USING btree (outcome);


--
-- Name: idx_template_reports_submission_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_template_reports_submission_id ON public.template_reports USING btree (submission_id);


--
-- Name: idx_template_reports_verification_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_template_reports_verification_type ON public.template_reports USING btree (verification_type);


--
-- Name: idx_territory_assignment_audit_assignment_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_territory_assignment_audit_assignment_type ON public."territoryAssignmentAudit" USING btree ("assignmentType");


--
-- Name: idx_territory_assignment_audit_new_data; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_territory_assignment_audit_new_data ON public."territoryAssignmentAudit" USING gin ("newData");


--
-- Name: idx_territory_assignment_audit_performed_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_territory_assignment_audit_performed_at ON public."territoryAssignmentAudit" USING btree ("performedAt");


--
-- Name: idx_territory_assignment_audit_previous_data; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_territory_assignment_audit_previous_data ON public."territoryAssignmentAudit" USING gin ("previousData");


--
-- Name: idx_territory_assignment_audit_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_territory_assignment_audit_user_id ON public."territoryAssignmentAudit" USING btree ("userId");


--
-- Name: idx_trusted_devices_blocked; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_trusted_devices_blocked ON public.trusted_devices USING btree (is_blocked) WHERE (is_blocked = true);


--
-- Name: idx_trusted_devices_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_trusted_devices_user_id ON public.trusted_devices USING btree (user_id);


--
-- Name: idx_user_area_assignments_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_user_area_assignments_active ON public."userAreaAssignments" USING btree ("isActive") WHERE ("isActive" = true);


--
-- Name: idx_user_area_assignments_area_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_user_area_assignments_area_id ON public."userAreaAssignments" USING btree ("areaId");


--
-- Name: idx_user_area_assignments_pincode_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_user_area_assignments_pincode_id ON public."userAreaAssignments" USING btree ("pincodeId");


--
-- Name: idx_user_area_assignments_user_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_user_area_assignments_user_active ON public."userAreaAssignments" USING btree ("userId", "isActive") WHERE ("isActive" = true);


--
-- Name: idx_user_area_assignments_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_user_area_assignments_user_id ON public."userAreaAssignments" USING btree ("userId");


--
-- Name: idx_user_area_assignments_user_pincode_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_user_area_assignments_user_pincode_active ON public."userAreaAssignments" USING btree ("userId", "pincodeId", "isActive") WHERE ("isActive" = true);


--
-- Name: idx_user_area_assignments_user_pincode_assignment_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_user_area_assignments_user_pincode_assignment_id ON public."userAreaAssignments" USING btree ("userPincodeAssignmentId");


--
-- Name: idx_user_client_assignments_client_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_user_client_assignments_client_id ON public."userClientAssignments" USING btree ("clientId");


--
-- Name: idx_user_client_assignments_user_client; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_user_client_assignments_user_client ON public."userClientAssignments" USING btree ("userId", "clientId");


--
-- Name: idx_user_client_assignments_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_user_client_assignments_user_id ON public."userClientAssignments" USING btree ("userId");


--
-- Name: idx_user_pincode_assignments_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_user_pincode_assignments_active ON public."userPincodeAssignments" USING btree ("isActive") WHERE ("isActive" = true);


--
-- Name: idx_user_pincode_assignments_pincode_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_user_pincode_assignments_pincode_id ON public."userPincodeAssignments" USING btree ("pincodeId");


--
-- Name: idx_user_pincode_assignments_user_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_user_pincode_assignments_user_active ON public."userPincodeAssignments" USING btree ("userId", "isActive") WHERE ("isActive" = true);


--
-- Name: idx_user_pincode_assignments_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_user_pincode_assignments_user_id ON public."userPincodeAssignments" USING btree ("userId");


--
-- Name: idx_user_product_assignments_product_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_user_product_assignments_product_id ON public."userProductAssignments" USING btree ("productId");


--
-- Name: idx_user_product_assignments_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_user_product_assignments_user_id ON public."userProductAssignments" USING btree ("userId");


--
-- Name: idx_user_product_assignments_user_product; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_user_product_assignments_user_product ON public."userProductAssignments" USING btree ("userId", "productId");


--
-- Name: idx_users_deleted_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_users_deleted_at ON public.users USING btree ("deletedAt");


--
-- Name: idx_users_department_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_users_department_id ON public.users USING btree ("departmentId");


--
-- Name: idx_users_designation_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_users_designation_id ON public.users USING btree ("designationId");


--
-- Name: idx_users_email; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_users_email ON public.users USING btree (email);


--
-- Name: idx_users_employee_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_users_employee_id ON public.users USING btree ("employeeId");


--
-- Name: idx_users_is_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_users_is_active ON public.users USING btree ("isActive");


--
-- Name: idx_users_last_active_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_users_last_active_at ON public.users USING btree (last_active_at);


--
-- Name: idx_users_last_login; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_users_last_login ON public.users USING btree ("lastLogin");


--
-- Name: idx_users_manager_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_users_manager_id ON public.users USING btree (manager_id);


--
-- Name: idx_users_name_search; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_users_name_search ON public.users USING gin (to_tsvector('english'::regconfig, (name)::text));


--
-- Name: idx_users_performance_rating; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_users_performance_rating ON public.users USING btree (performance_rating);


--
-- Name: idx_users_role; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_users_role ON public.users USING btree (role);


--
-- Name: idx_users_role_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_users_role_active ON public.users USING btree (role, "isActive");


--
-- Name: idx_users_team_leader_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_users_team_leader_id ON public.users USING btree (team_leader_id);


--
-- Name: idx_users_username; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_users_username ON public.users USING btree (username);


--
-- Name: idx_verification_attachments_case_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_verification_attachments_case_id ON public.verification_attachments USING btree (case_id);


--
-- Name: idx_verification_attachments_deleted; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_verification_attachments_deleted ON public.verification_attachments USING btree (deleted_at) WHERE (deleted_at IS NOT NULL);


--
-- Name: idx_verification_attachments_device_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_verification_attachments_device_id ON public.verification_attachments USING btree (device_id);


--
-- Name: idx_verification_attachments_gps_validation; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_verification_attachments_gps_validation ON public.verification_attachments USING btree (gps_validation_status) WHERE ((gps_validation_status)::text = 'MISMATCH'::text);


--
-- Name: idx_verification_attachments_hash_verified; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_verification_attachments_hash_verified ON public.verification_attachments USING btree (hash_verified) WHERE (hash_verified = false);


--
-- Name: idx_verification_attachments_photo_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_verification_attachments_photo_type ON public.verification_attachments USING btree ("photoType");


--
-- Name: idx_verification_attachments_submission_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_verification_attachments_submission_id ON public.verification_attachments USING btree ("submissionId");


--
-- Name: idx_verification_attachments_task_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_verification_attachments_task_id ON public.verification_attachments USING btree (verification_task_id);


--
-- Name: idx_verification_attachments_verification_task_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_verification_attachments_verification_task_id ON public.verification_attachments USING btree (verification_task_id);


--
-- Name: idx_verification_attachments_verification_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_verification_attachments_verification_type ON public.verification_attachments USING btree (verification_type);


--
-- Name: idx_verification_tasks_applicant_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_verification_tasks_applicant_type ON public.verification_tasks USING btree (applicant_type);


--
-- Name: idx_verification_tasks_area_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_verification_tasks_area_id ON public.verification_tasks USING btree (area_id);


--
-- Name: idx_verification_tasks_assigned_to; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_verification_tasks_assigned_to ON public.verification_tasks USING btree (assigned_to);


--
-- Name: idx_verification_tasks_cancelled_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_verification_tasks_cancelled_at ON public.verification_tasks USING btree (cancelled_at) WHERE (cancelled_at IS NOT NULL);


--
-- Name: idx_verification_tasks_case_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_verification_tasks_case_id ON public.verification_tasks USING btree (case_id);


--
-- Name: idx_verification_tasks_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_verification_tasks_created_at ON public.verification_tasks USING btree (created_at);


--
-- Name: idx_verification_tasks_is_saved; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_verification_tasks_is_saved ON public.verification_tasks USING btree (is_saved) WHERE (is_saved = true);


--
-- Name: idx_verification_tasks_parent_task_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_verification_tasks_parent_task_id ON public.verification_tasks USING btree (parent_task_id);


--
-- Name: idx_verification_tasks_priority; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_verification_tasks_priority ON public.verification_tasks USING btree (priority);


--
-- Name: idx_verification_tasks_reviewer_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_verification_tasks_reviewer_id ON public.verification_tasks USING btree (reviewer_id);


--
-- Name: idx_verification_tasks_revoked_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_verification_tasks_revoked_at ON public.verification_tasks USING btree (revoked_at) WHERE (revoked_at IS NOT NULL);


--
-- Name: idx_verification_tasks_revoked_by; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_verification_tasks_revoked_by ON public.verification_tasks USING btree (revoked_by) WHERE (revoked_by IS NOT NULL);


--
-- Name: idx_verification_tasks_saved_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_verification_tasks_saved_at ON public.verification_tasks USING btree (saved_at) WHERE (saved_at IS NOT NULL);


--
-- Name: idx_verification_tasks_service_zone_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_verification_tasks_service_zone_id ON public.verification_tasks USING btree (service_zone_id);


--
-- Name: idx_verification_tasks_sla_monitoring; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_verification_tasks_sla_monitoring ON public.verification_tasks USING btree (status, first_assigned_at, service_zone_id) WHERE (((status)::text = ANY (ARRAY[('ASSIGNED'::character varying)::text, ('IN_PROGRESS'::character varying)::text])) AND (first_assigned_at IS NOT NULL) AND (service_zone_id IS NOT NULL));


--
-- Name: INDEX idx_verification_tasks_sla_monitoring; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON INDEX public.idx_verification_tasks_sla_monitoring IS 'Partial index for SLA risk monitoring queries. Only indexes active tasks with SLA tracking data.';


--
-- Name: idx_verification_tasks_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_verification_tasks_status ON public.verification_tasks USING btree (status);


--
-- Name: idx_verification_tasks_submitted; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_verification_tasks_submitted ON public.verification_tasks USING btree (status, submitted_at) WHERE ((status)::text = ANY (ARRAY[('SUBMITTED'::character varying)::text, ('UNDER_REVIEW'::character varying)::text]));


--
-- Name: idx_verification_tasks_task_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_verification_tasks_task_type ON public.verification_tasks USING btree (task_type);


--
-- Name: idx_verification_tasks_verification_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_verification_tasks_verification_type ON public.verification_tasks USING btree (verification_type_id);


--
-- Name: idx_visits_assigned_to; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_visits_assigned_to ON public.visits USING btree (assigned_to);


--
-- Name: idx_visits_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_visits_status ON public.visits USING btree (status);


--
-- Name: idx_visits_verification_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_visits_verification_id ON public.visits USING btree (verification_id);


--
-- Name: idx_zone_rate_mapping; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_zone_rate_mapping ON public.zone_rate_type_mapping USING btree (client_id, product_id, verification_type_id, service_zone_id);


--
-- Name: uk_user_area_assignments_active_only; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uk_user_area_assignments_active_only ON public."userAreaAssignments" USING btree ("userId", "pincodeId", "areaId") WHERE ("isActive" = true);


--
-- Name: uk_user_pincode_assignments_active_only; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uk_user_pincode_assignments_active_only ON public."userPincodeAssignments" USING btree ("userId", "pincodeId") WHERE ("isActive" = true);


--
-- Name: uniq_locations_verification_task; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uniq_locations_verification_task ON public.locations USING btree (verification_task_id) WHERE (verification_task_id IS NOT NULL);


--
-- Name: uq_pincode_areas_pincode_area; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uq_pincode_areas_pincode_area ON public."pincodeAreas" USING btree ("pincodeId", "areaId");


--
-- Name: uq_service_zone_rules_active_scope; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uq_service_zone_rules_active_scope ON public.service_zone_rules USING btree (COALESCE(client_id, '-1'::integer), COALESCE(product_id, '-1'::integer), pincode_id, COALESCE(area_id, '-1'::integer)) WHERE (is_active = true);


--
-- Name: userAreaAssignments audit_user_area_assignments; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER audit_user_area_assignments AFTER INSERT OR UPDATE ON public."userAreaAssignments" FOR EACH ROW EXECUTE FUNCTION public.audit_territory_assignment_changes();


--
-- Name: userPincodeAssignments audit_user_pincode_assignments; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER audit_user_pincode_assignments AFTER INSERT OR UPDATE ON public."userPincodeAssignments" FOR EACH ROW EXECUTE FUNCTION public.audit_territory_assignment_changes();


--
-- Name: rates rate_history_trigger; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER rate_history_trigger AFTER UPDATE ON public.rates FOR EACH ROW EXECUTE FUNCTION public.create_rate_history();


--
-- Name: applicants trg_applicants_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_applicants_updated_at BEFORE UPDATE ON public.applicants FOR EACH ROW EXECUTE FUNCTION public.update_cases_updated_at();


--
-- Name: roles_v2 trg_roles_v2_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_roles_v2_updated_at BEFORE UPDATE ON public.roles_v2 FOR EACH ROW EXECUTE FUNCTION public.set_updated_at_roles_v2();


--
-- Name: verifications trg_verifications_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_verifications_updated_at BEFORE UPDATE ON public.verifications FOR EACH ROW EXECUTE FUNCTION public.update_cases_updated_at();


--
-- Name: visits trg_visits_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_visits_updated_at BEFORE UPDATE ON public.visits FOR EACH ROW EXECUTE FUNCTION public.update_cases_updated_at();


--
-- Name: users trigger_create_notification_preferences; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trigger_create_notification_preferences AFTER INSERT ON public.users FOR EACH ROW EXECUTE FUNCTION public.create_default_notification_preferences();


--
-- Name: verification_tasks trigger_generate_task_number; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trigger_generate_task_number BEFORE INSERT ON public.verification_tasks FOR EACH ROW EXECUTE FUNCTION public.generate_task_number();


--
-- Name: notification_batches trigger_notification_batches_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trigger_notification_batches_updated_at BEFORE UPDATE ON public.notification_batches FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: notification_preferences trigger_notification_preferences_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trigger_notification_preferences_updated_at BEFORE UPDATE ON public.notification_preferences FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: notification_tokens trigger_notification_tokens_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trigger_notification_tokens_updated_at BEFORE UPDATE ON public.notification_tokens FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: notifications trigger_notifications_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trigger_notifications_updated_at BEFORE UPDATE ON public.notifications FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: ai_reports trigger_update_ai_reports_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trigger_update_ai_reports_updated_at BEFORE UPDATE ON public.ai_reports FOR EACH ROW EXECUTE FUNCTION public.update_ai_reports_updated_at();


--
-- Name: verification_tasks trigger_update_case_completion; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trigger_update_case_completion AFTER INSERT OR UPDATE OF status ON public.verification_tasks FOR EACH ROW EXECUTE FUNCTION public.update_case_completion_percentage();


--
-- Name: task_commission_calculations trigger_update_commission_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trigger_update_commission_updated_at BEFORE UPDATE ON public.task_commission_calculations FOR EACH ROW EXECUTE FUNCTION public.update_task_updated_at();


--
-- Name: documentTypeRates trigger_update_document_type_rates_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trigger_update_document_type_rates_updated_at BEFORE UPDATE ON public."documentTypeRates" FOR EACH ROW EXECUTE FUNCTION public.update_document_type_rates_updated_at();


--
-- Name: mobile_notification_audit trigger_update_mobile_notification_audit_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trigger_update_mobile_notification_audit_updated_at BEFORE UPDATE ON public.mobile_notification_audit FOR EACH ROW EXECUTE FUNCTION public.update_mobile_notification_audit_updated_at();


--
-- Name: verification_tasks trigger_update_task_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trigger_update_task_updated_at BEFORE UPDATE ON public.verification_tasks FOR EACH ROW EXECUTE FUNCTION public.update_task_updated_at();


--
-- Name: template_reports trigger_update_template_reports_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trigger_update_template_reports_updated_at BEFORE UPDATE ON public.template_reports FOR EACH ROW EXECUTE FUNCTION public.update_template_reports_updated_at();


--
-- Name: builderVerificationReports update_builder_verification_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_builder_verification_updated_at BEFORE UPDATE ON public."builderVerificationReports" FOR EACH ROW EXECUTE FUNCTION public.update_builder_verification_updated_at();


--
-- Name: businessVerificationReports update_business_verification_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_business_verification_updated_at BEFORE UPDATE ON public."businessVerificationReports" FOR EACH ROW EXECUTE FUNCTION public.update_business_verification_updated_at();


--
-- Name: case_assignment_queue_status update_case_assignment_queue_status_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_case_assignment_queue_status_updated_at BEFORE UPDATE ON public.case_assignment_queue_status FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: caseDeduplicationAudit update_case_deduplication_audit_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_case_deduplication_audit_updated_at BEFORE UPDATE ON public."caseDeduplicationAudit" FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: cases update_cases_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_cases_updated_at BEFORE UPDATE ON public.cases FOR EACH ROW EXECUTE FUNCTION public.update_cases_updated_at();


--
-- Name: cities update_cities_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_cities_updated_at BEFORE UPDATE ON public.cities FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: clients update_clients_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_clients_updated_at BEFORE UPDATE ON public.clients FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: commission_calculations update_commission_calculations_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_commission_calculations_updated_at BEFORE UPDATE ON public.commission_calculations FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: commission_payment_batches update_commission_payment_batches_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_commission_payment_batches_updated_at BEFORE UPDATE ON public.commission_payment_batches FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: commission_rate_types update_commission_rate_types_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_commission_rate_types_updated_at BEFORE UPDATE ON public.commission_rate_types FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: countries update_countries_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_countries_updated_at BEFORE UPDATE ON public.countries FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: departments update_departments_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_departments_updated_at BEFORE UPDATE ON public.departments FOR EACH ROW EXECUTE FUNCTION public.update_departments_updated_at();


--
-- Name: designations update_designations_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_designations_updated_at BEFORE UPDATE ON public.designations FOR EACH ROW EXECUTE FUNCTION public.update_designations_updated_at();


--
-- Name: dsaConnectorVerificationReports update_dsa_connector_verification_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_dsa_connector_verification_updated_at BEFORE UPDATE ON public."dsaConnectorVerificationReports" FOR EACH ROW EXECUTE FUNCTION public.update_dsa_connector_verification_updated_at();


--
-- Name: field_user_commission_assignments update_field_user_commission_assignments_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_field_user_commission_assignments_updated_at BEFORE UPDATE ON public.field_user_commission_assignments FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: mobile_device_sync update_mobile_device_sync_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_mobile_device_sync_updated_at BEFORE UPDATE ON public.mobile_device_sync FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: mobile_notification_queue update_mobile_notification_queue_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_mobile_notification_queue_updated_at BEFORE UPDATE ON public.mobile_notification_queue FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: nocVerificationReports update_noc_verification_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_noc_verification_updated_at BEFORE UPDATE ON public."nocVerificationReports" FOR EACH ROW EXECUTE FUNCTION public.update_noc_verification_updated_at();


--
-- Name: officeVerificationReports update_office_verification_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_office_verification_updated_at BEFORE UPDATE ON public."officeVerificationReports" FOR EACH ROW EXECUTE FUNCTION public.update_office_verification_updated_at();


--
-- Name: pincodeAreas update_pincode_areas_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_pincode_areas_updated_at BEFORE UPDATE ON public."pincodeAreas" FOR EACH ROW EXECUTE FUNCTION public.update_pincode_areas_updated_at();


--
-- Name: propertyApfVerificationReports update_property_apf_verification_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_property_apf_verification_updated_at BEFORE UPDATE ON public."propertyApfVerificationReports" FOR EACH ROW EXECUTE FUNCTION public.update_property_apf_verification_updated_at();


--
-- Name: propertyIndividualVerificationReports update_property_individual_verification_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_property_individual_verification_updated_at BEFORE UPDATE ON public."propertyIndividualVerificationReports" FOR EACH ROW EXECUTE FUNCTION public.update_property_individual_verification_updated_at();


--
-- Name: residenceCumOfficeVerificationReports update_residence_cum_office_verification_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_residence_cum_office_verification_updated_at BEFORE UPDATE ON public."residenceCumOfficeVerificationReports" FOR EACH ROW EXECUTE FUNCTION public.update_residence_cum_office_verification_updated_at();


--
-- Name: residenceVerificationReports update_residence_verification_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_residence_verification_updated_at BEFORE UPDATE ON public."residenceVerificationReports" FOR EACH ROW EXECUTE FUNCTION public.update_residence_verification_updated_at();


--
-- Name: states update_states_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_states_updated_at BEFORE UPDATE ON public.states FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: userAreaAssignments update_user_area_assignments_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_user_area_assignments_updated_at BEFORE UPDATE ON public."userAreaAssignments" FOR EACH ROW EXECUTE FUNCTION public.update_camel_case_updated_at();


--
-- Name: userClientAssignments update_user_client_assignments_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_user_client_assignments_updated_at BEFORE UPDATE ON public."userClientAssignments" FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: userPincodeAssignments update_user_pincode_assignments_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_user_pincode_assignments_updated_at BEFORE UPDATE ON public."userPincodeAssignments" FOR EACH ROW EXECUTE FUNCTION public.update_camel_case_updated_at();


--
-- Name: userProductAssignments update_user_product_assignments_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_user_product_assignments_updated_at BEFORE UPDATE ON public."userProductAssignments" FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: users update_users_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_users_updated_at BEFORE UPDATE ON public.users FOR EACH ROW EXECUTE FUNCTION public.update_users_updated_at();


--
-- Name: agent_performance_daily agent_performance_daily_agent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_performance_daily
    ADD CONSTRAINT agent_performance_daily_agent_id_fkey FOREIGN KEY (agent_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: attachments attachments_uploaded_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.attachments
    ADD CONSTRAINT attachments_uploaded_by_fkey FOREIGN KEY ("uploadedBy") REFERENCES public.users(id) ON DELETE RESTRICT;


--
-- Name: attachments attachments_verification_task_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.attachments
    ADD CONSTRAINT attachments_verification_task_id_fkey FOREIGN KEY (verification_task_id) REFERENCES public.verification_tasks(id) ON DELETE CASCADE;


--
-- Name: auditLogs audit_logs_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."auditLogs"
    ADD CONSTRAINT audit_logs_user_id_fkey FOREIGN KEY ("userId") REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: autoSaves auto_saves_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."autoSaves"
    ADD CONSTRAINT auto_saves_user_id_fkey FOREIGN KEY ("userId") REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: backgroundSyncQueue background_sync_queue_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."backgroundSyncQueue"
    ADD CONSTRAINT background_sync_queue_user_id_fkey FOREIGN KEY ("userId") REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: builderVerificationReports builderVerificationReports_verification_task_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."builderVerificationReports"
    ADD CONSTRAINT "builderVerificationReports_verification_task_id_fkey" FOREIGN KEY (verification_task_id) REFERENCES public.verification_tasks(id) ON DELETE CASCADE;


--
-- Name: businessVerificationReports businessVerificationReports_verification_task_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."businessVerificationReports"
    ADD CONSTRAINT "businessVerificationReports_verification_task_id_fkey" FOREIGN KEY (verification_task_id) REFERENCES public.verification_tasks(id) ON DELETE CASCADE;


--
-- Name: case_assignment_conflicts case_assignment_conflicts_caseId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.case_assignment_conflicts
    ADD CONSTRAINT "case_assignment_conflicts_caseId_fkey" FOREIGN KEY ("caseId") REFERENCES public.cases(id) ON DELETE CASCADE;


--
-- Name: case_assignment_conflicts case_assignment_conflicts_clientAssignedTo_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.case_assignment_conflicts
    ADD CONSTRAINT "case_assignment_conflicts_clientAssignedTo_fkey" FOREIGN KEY ("clientAssignedTo") REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: case_assignment_conflicts case_assignment_conflicts_resolvedBy_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.case_assignment_conflicts
    ADD CONSTRAINT "case_assignment_conflicts_resolvedBy_fkey" FOREIGN KEY ("resolvedBy") REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: case_assignment_conflicts case_assignment_conflicts_serverAssignedTo_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.case_assignment_conflicts
    ADD CONSTRAINT "case_assignment_conflicts_serverAssignedTo_fkey" FOREIGN KEY ("serverAssignedTo") REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: case_assignment_history case_assignment_history_assignedById_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.case_assignment_history
    ADD CONSTRAINT "case_assignment_history_assignedById_fkey" FOREIGN KEY ("assignedById") REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: case_assignment_history case_assignment_history_assignedBy_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.case_assignment_history
    ADD CONSTRAINT "case_assignment_history_assignedBy_fkey" FOREIGN KEY ("assignedBy") REFERENCES public.users(id);


--
-- Name: case_assignment_history case_assignment_history_caseId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.case_assignment_history
    ADD CONSTRAINT "case_assignment_history_caseId_fkey" FOREIGN KEY ("caseId") REFERENCES public.cases("caseId") ON DELETE CASCADE;


--
-- Name: case_assignment_history case_assignment_history_fromUserId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.case_assignment_history
    ADD CONSTRAINT "case_assignment_history_fromUserId_fkey" FOREIGN KEY ("fromUserId") REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: case_assignment_history case_assignment_history_newAssignee_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.case_assignment_history
    ADD CONSTRAINT "case_assignment_history_newAssignee_fkey" FOREIGN KEY ("newAssignee") REFERENCES public.users(id);


--
-- Name: case_assignment_history case_assignment_history_previousAssignee_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.case_assignment_history
    ADD CONSTRAINT "case_assignment_history_previousAssignee_fkey" FOREIGN KEY ("previousAssignee") REFERENCES public.users(id);


--
-- Name: case_assignment_history case_assignment_history_toUserId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.case_assignment_history
    ADD CONSTRAINT "case_assignment_history_toUserId_fkey" FOREIGN KEY ("toUserId") REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: case_assignment_queue_status case_assignment_queue_status_assignedToId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.case_assignment_queue_status
    ADD CONSTRAINT "case_assignment_queue_status_assignedToId_fkey" FOREIGN KEY ("assignedToId") REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: case_assignment_queue_status case_assignment_queue_status_createdById_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.case_assignment_queue_status
    ADD CONSTRAINT "case_assignment_queue_status_createdById_fkey" FOREIGN KEY ("createdById") REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: case_configuration_errors case_configuration_errors_case_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.case_configuration_errors
    ADD CONSTRAINT case_configuration_errors_case_id_fkey FOREIGN KEY (case_id) REFERENCES public.cases(id) ON DELETE CASCADE;


--
-- Name: case_configuration_errors case_configuration_errors_resolved_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.case_configuration_errors
    ADD CONSTRAINT case_configuration_errors_resolved_by_fkey FOREIGN KEY (resolved_by) REFERENCES public.users(id);


--
-- Name: caseDeduplicationAudit case_deduplication_audit_performedBy_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."caseDeduplicationAudit"
    ADD CONSTRAINT "case_deduplication_audit_performedBy_fkey" FOREIGN KEY ("performedBy") REFERENCES public.users(id) ON DELETE RESTRICT;


--
-- Name: case_timeline_events case_timeline_events_case_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.case_timeline_events
    ADD CONSTRAINT case_timeline_events_case_id_fkey FOREIGN KEY (case_id) REFERENCES public.cases(id) ON DELETE CASCADE;


--
-- Name: case_timeline_events case_timeline_events_performed_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.case_timeline_events
    ADD CONSTRAINT case_timeline_events_performed_by_fkey FOREIGN KEY (performed_by) REFERENCES public.users(id);


--
-- Name: clientDocumentTypes clientDocumentTypes_clientId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."clientDocumentTypes"
    ADD CONSTRAINT "clientDocumentTypes_clientId_fkey" FOREIGN KEY ("clientId") REFERENCES public.clients(id) ON DELETE CASCADE;


--
-- Name: clientDocumentTypes clientDocumentTypes_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."clientDocumentTypes"
    ADD CONSTRAINT "clientDocumentTypes_created_by_fkey" FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: clientDocumentTypes clientDocumentTypes_documentTypeId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."clientDocumentTypes"
    ADD CONSTRAINT "clientDocumentTypes_documentTypeId_fkey" FOREIGN KEY ("documentTypeId") REFERENCES public."documentTypes"(id) ON DELETE CASCADE;


--
-- Name: commission_batch_items commission_batch_items_batch_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.commission_batch_items
    ADD CONSTRAINT commission_batch_items_batch_id_fkey FOREIGN KEY (batch_id) REFERENCES public.commission_payment_batches(id) ON DELETE CASCADE;


--
-- Name: commission_batch_items commission_batch_items_commission_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.commission_batch_items
    ADD CONSTRAINT commission_batch_items_commission_id_fkey FOREIGN KEY (commission_id) REFERENCES public.commission_calculations(id) ON DELETE CASCADE;


--
-- Name: commission_calculations commission_calculations_approved_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.commission_calculations
    ADD CONSTRAINT commission_calculations_approved_by_fkey FOREIGN KEY (approved_by) REFERENCES public.users(id);


--
-- Name: commission_calculations commission_calculations_case_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.commission_calculations
    ADD CONSTRAINT commission_calculations_case_id_fkey FOREIGN KEY (case_id) REFERENCES public.cases(id) ON DELETE CASCADE;


--
-- Name: commission_calculations commission_calculations_client_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.commission_calculations
    ADD CONSTRAINT commission_calculations_client_id_fkey FOREIGN KEY (client_id) REFERENCES public.clients(id) ON DELETE CASCADE;


--
-- Name: commission_calculations commission_calculations_paid_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.commission_calculations
    ADD CONSTRAINT commission_calculations_paid_by_fkey FOREIGN KEY (paid_by) REFERENCES public.users(id);


--
-- Name: commission_calculations commission_calculations_rate_type_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.commission_calculations
    ADD CONSTRAINT commission_calculations_rate_type_id_fkey FOREIGN KEY (rate_type_id) REFERENCES public."rateTypes"(id) ON DELETE CASCADE;


--
-- Name: commission_calculations commission_calculations_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.commission_calculations
    ADD CONSTRAINT commission_calculations_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: commission_payment_batches commission_payment_batches_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.commission_payment_batches
    ADD CONSTRAINT commission_payment_batches_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: commission_payment_batches commission_payment_batches_processed_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.commission_payment_batches
    ADD CONSTRAINT commission_payment_batches_processed_by_fkey FOREIGN KEY (processed_by) REFERENCES public.users(id);


--
-- Name: commission_rate_types commission_rate_types_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.commission_rate_types
    ADD CONSTRAINT commission_rate_types_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: commission_rate_types commission_rate_types_rate_type_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.commission_rate_types
    ADD CONSTRAINT commission_rate_types_rate_type_id_fkey FOREIGN KEY (rate_type_id) REFERENCES public."rateTypes"(id) ON DELETE CASCADE;


--
-- Name: designations designations_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.designations
    ADD CONSTRAINT designations_created_by_fkey FOREIGN KEY ("createdBy") REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: designations designations_updated_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.designations
    ADD CONSTRAINT designations_updated_by_fkey FOREIGN KEY ("updatedBy") REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: documentTypeRates documentTypeRates_clientId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."documentTypeRates"
    ADD CONSTRAINT "documentTypeRates_clientId_fkey" FOREIGN KEY ("clientId") REFERENCES public.clients(id) ON DELETE CASCADE;


--
-- Name: documentTypeRates documentTypeRates_createdBy_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."documentTypeRates"
    ADD CONSTRAINT "documentTypeRates_createdBy_fkey" FOREIGN KEY ("createdBy") REFERENCES public.users(id);


--
-- Name: documentTypeRates documentTypeRates_documentTypeId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."documentTypeRates"
    ADD CONSTRAINT "documentTypeRates_documentTypeId_fkey" FOREIGN KEY ("documentTypeId") REFERENCES public."documentTypes"(id) ON DELETE CASCADE;


--
-- Name: documentTypeRates documentTypeRates_productId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."documentTypeRates"
    ADD CONSTRAINT "documentTypeRates_productId_fkey" FOREIGN KEY ("productId") REFERENCES public.products(id) ON DELETE CASCADE;


--
-- Name: documentTypes documentTypes_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."documentTypes"
    ADD CONSTRAINT "documentTypes_created_by_fkey" FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: dsaConnectorVerificationReports dsaConnectorVerificationReports_verification_task_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."dsaConnectorVerificationReports"
    ADD CONSTRAINT "dsaConnectorVerificationReports_verification_task_id_fkey" FOREIGN KEY (verification_task_id) REFERENCES public.verification_tasks(id) ON DELETE CASCADE;


--
-- Name: error_logs error_logs_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.error_logs
    ADD CONSTRAINT error_logs_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: field_user_commission_assignments field_user_commission_assignments_client_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.field_user_commission_assignments
    ADD CONSTRAINT field_user_commission_assignments_client_id_fkey FOREIGN KEY (client_id) REFERENCES public.clients(id) ON DELETE CASCADE;


--
-- Name: field_user_commission_assignments field_user_commission_assignments_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.field_user_commission_assignments
    ADD CONSTRAINT field_user_commission_assignments_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: field_user_commission_assignments field_user_commission_assignments_rate_type_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.field_user_commission_assignments
    ADD CONSTRAINT field_user_commission_assignments_rate_type_id_fkey FOREIGN KEY (rate_type_id) REFERENCES public."rateTypes"(id) ON DELETE CASCADE;


--
-- Name: field_user_commission_assignments field_user_commission_assignments_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.field_user_commission_assignments
    ADD CONSTRAINT field_user_commission_assignments_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: ai_reports fk_ai_reports_case_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ai_reports
    ADD CONSTRAINT fk_ai_reports_case_id FOREIGN KEY (case_id) REFERENCES public.cases(id) ON DELETE CASCADE;


--
-- Name: ai_reports fk_ai_reports_generated_by; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ai_reports
    ADD CONSTRAINT fk_ai_reports_generated_by FOREIGN KEY (generated_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: applicants fk_applicants_case; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.applicants
    ADD CONSTRAINT fk_applicants_case FOREIGN KEY (case_id) REFERENCES public.cases(id) ON DELETE CASCADE;


--
-- Name: attachments fk_attachments_case_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.attachments
    ADD CONSTRAINT fk_attachments_case_id FOREIGN KEY ("caseId") REFERENCES public.cases("caseId") ON DELETE CASCADE;


--
-- Name: attachments fk_attachments_case_uuid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.attachments
    ADD CONSTRAINT fk_attachments_case_uuid FOREIGN KEY (case_id) REFERENCES public.cases(id) ON DELETE CASCADE;


--
-- Name: autoSaves fk_autoSaves_case_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."autoSaves"
    ADD CONSTRAINT "fk_autoSaves_case_id" FOREIGN KEY ("caseId") REFERENCES public.cases("caseId") ON DELETE CASCADE;


--
-- Name: autoSaves fk_autosaves_case_uuid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."autoSaves"
    ADD CONSTRAINT fk_autosaves_case_uuid FOREIGN KEY (case_id) REFERENCES public.cases(id) ON DELETE CASCADE;


--
-- Name: builderVerificationReports fk_builder_verification_case_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."builderVerificationReports"
    ADD CONSTRAINT fk_builder_verification_case_id FOREIGN KEY (case_id) REFERENCES public.cases(id) ON DELETE CASCADE;


--
-- Name: builderVerificationReports fk_builder_verification_verified_by; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."builderVerificationReports"
    ADD CONSTRAINT fk_builder_verification_verified_by FOREIGN KEY (verified_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: businessVerificationReports fk_business_verification_case_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."businessVerificationReports"
    ADD CONSTRAINT fk_business_verification_case_id FOREIGN KEY (case_id) REFERENCES public.cases(id) ON DELETE CASCADE;


--
-- Name: businessVerificationReports fk_business_verification_verified_by; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."businessVerificationReports"
    ADD CONSTRAINT fk_business_verification_verified_by FOREIGN KEY (verified_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: caseDeduplicationAudit fk_caseDeduplicationAudit_case_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."caseDeduplicationAudit"
    ADD CONSTRAINT "fk_caseDeduplicationAudit_case_id" FOREIGN KEY ("caseId") REFERENCES public.cases("caseId") ON DELETE CASCADE;


--
-- Name: case_assignment_history fk_case_assignment_history_case_uuid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.case_assignment_history
    ADD CONSTRAINT fk_case_assignment_history_case_uuid FOREIGN KEY (case_id) REFERENCES public.cases(id) ON DELETE CASCADE;


--
-- Name: case_status_history fk_case_status_history_case; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.case_status_history
    ADD CONSTRAINT fk_case_status_history_case FOREIGN KEY ("caseId") REFERENCES public.cases("caseId") ON DELETE CASCADE;


--
-- Name: case_status_history fk_case_status_history_case_uuid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.case_status_history
    ADD CONSTRAINT fk_case_status_history_case_uuid FOREIGN KEY (case_id) REFERENCES public.cases(id) ON DELETE CASCADE;


--
-- Name: case_status_history fk_case_status_history_user; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.case_status_history
    ADD CONSTRAINT fk_case_status_history_user FOREIGN KEY ("transitionedBy") REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: caseDeduplicationAudit fk_casededuplicationaudit_case_uuid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."caseDeduplicationAudit"
    ADD CONSTRAINT fk_casededuplicationaudit_case_uuid FOREIGN KEY (case_id) REFERENCES public.cases(id) ON DELETE CASCADE;


--
-- Name: cases fk_cases_city_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cases
    ADD CONSTRAINT fk_cases_city_id FOREIGN KEY ("cityId") REFERENCES public.cities(id) ON DELETE SET NULL;


--
-- Name: cases fk_cases_client_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cases
    ADD CONSTRAINT fk_cases_client_id FOREIGN KEY ("clientId") REFERENCES public.clients(id) ON DELETE RESTRICT;


--
-- Name: cases fk_cases_created_by_backend_user; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cases
    ADD CONSTRAINT fk_cases_created_by_backend_user FOREIGN KEY ("createdByBackendUser") REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: cases fk_cases_product_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cases
    ADD CONSTRAINT fk_cases_product_id FOREIGN KEY ("productId") REFERENCES public.products(id) ON DELETE RESTRICT;


--
-- Name: cases fk_cases_rate_type_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cases
    ADD CONSTRAINT fk_cases_rate_type_id FOREIGN KEY ("rateTypeId") REFERENCES public."rateTypes"(id) ON DELETE SET NULL;


--
-- Name: cases fk_cases_verification_type_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cases
    ADD CONSTRAINT fk_cases_verification_type_id FOREIGN KEY ("verificationTypeId") REFERENCES public."verificationTypes"(id) ON DELETE RESTRICT;


--
-- Name: cities fk_cities_country; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cities
    ADD CONSTRAINT fk_cities_country FOREIGN KEY ("countryId") REFERENCES public.countries(id);


--
-- Name: cities fk_cities_state; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cities
    ADD CONSTRAINT fk_cities_state FOREIGN KEY ("stateId") REFERENCES public.states(id);


--
-- Name: clientProducts fk_client_products_client; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."clientProducts"
    ADD CONSTRAINT fk_client_products_client FOREIGN KEY ("clientId") REFERENCES public.clients(id);


--
-- Name: clientProducts fk_client_products_product; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."clientProducts"
    ADD CONSTRAINT fk_client_products_product FOREIGN KEY ("productId") REFERENCES public.products(id);


--
-- Name: commission_calculations fk_commission_verification_task; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.commission_calculations
    ADD CONSTRAINT fk_commission_verification_task FOREIGN KEY (verification_task_id) REFERENCES public.verification_tasks(id);


--
-- Name: departments fk_departments_created_by; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.departments
    ADD CONSTRAINT fk_departments_created_by FOREIGN KEY ("createdBy") REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: departments fk_departments_head; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.departments
    ADD CONSTRAINT fk_departments_head FOREIGN KEY ("departmentHeadId") REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: departments fk_departments_parent; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.departments
    ADD CONSTRAINT fk_departments_parent FOREIGN KEY ("parentDepartmentId") REFERENCES public.departments(id);


--
-- Name: departments fk_departments_updated_by; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.departments
    ADD CONSTRAINT fk_departments_updated_by FOREIGN KEY ("updatedBy") REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: designations fk_designations_department; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.designations
    ADD CONSTRAINT fk_designations_department FOREIGN KEY ("departmentId") REFERENCES public.departments(id);


--
-- Name: dsaConnectorVerificationReports fk_dsa_connector_verification_case_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."dsaConnectorVerificationReports"
    ADD CONSTRAINT fk_dsa_connector_verification_case_id FOREIGN KEY (case_id) REFERENCES public.cases(id) ON DELETE CASCADE;


--
-- Name: dsaConnectorVerificationReports fk_dsa_connector_verification_verified_by; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."dsaConnectorVerificationReports"
    ADD CONSTRAINT fk_dsa_connector_verification_verified_by FOREIGN KEY (verified_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: locations fk_locations_case_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.locations
    ADD CONSTRAINT fk_locations_case_id FOREIGN KEY ("caseId") REFERENCES public.cases("caseId") ON DELETE CASCADE;


--
-- Name: locations fk_locations_case_uuid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.locations
    ADD CONSTRAINT fk_locations_case_uuid FOREIGN KEY (case_id) REFERENCES public.cases(id) ON DELETE CASCADE;


--
-- Name: locations fk_locations_task_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.locations
    ADD CONSTRAINT fk_locations_task_id FOREIGN KEY (verification_task_id) REFERENCES public.verification_tasks(id) ON DELETE RESTRICT;


--
-- Name: mobile_notification_audit fk_mobile_notification_audit_case_uuid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mobile_notification_audit
    ADD CONSTRAINT fk_mobile_notification_audit_case_uuid FOREIGN KEY (case_id) REFERENCES public.cases(id) ON DELETE CASCADE;


--
-- Name: nocVerificationReports fk_noc_verification_case_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."nocVerificationReports"
    ADD CONSTRAINT fk_noc_verification_case_id FOREIGN KEY (case_id) REFERENCES public.cases(id) ON DELETE CASCADE;


--
-- Name: nocVerificationReports fk_noc_verification_verified_by; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."nocVerificationReports"
    ADD CONSTRAINT fk_noc_verification_verified_by FOREIGN KEY (verified_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: officeVerificationReports fk_office_verification_case_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."officeVerificationReports"
    ADD CONSTRAINT fk_office_verification_case_id FOREIGN KEY (case_id) REFERENCES public.cases(id) ON DELETE CASCADE;


--
-- Name: officeVerificationReports fk_office_verification_verified_by; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."officeVerificationReports"
    ADD CONSTRAINT fk_office_verification_verified_by FOREIGN KEY (verified_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: pincodeAreas fk_pincode_areas_area; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."pincodeAreas"
    ADD CONSTRAINT fk_pincode_areas_area FOREIGN KEY ("areaId") REFERENCES public.areas(id);


--
-- Name: pincodeAreas fk_pincode_areas_pincode; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."pincodeAreas"
    ADD CONSTRAINT fk_pincode_areas_pincode FOREIGN KEY ("pincodeId") REFERENCES public.pincodes(id);


--
-- Name: pincodes fk_pincodes_city; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pincodes
    ADD CONSTRAINT fk_pincodes_city FOREIGN KEY ("cityId") REFERENCES public.cities(id);


--
-- Name: productVerificationTypes fk_product_verification_types_product; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."productVerificationTypes"
    ADD CONSTRAINT fk_product_verification_types_product FOREIGN KEY ("productId") REFERENCES public.products(id);


--
-- Name: productVerificationTypes fk_product_verification_types_verification_type; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."productVerificationTypes"
    ADD CONSTRAINT fk_product_verification_types_verification_type FOREIGN KEY ("verificationTypeId") REFERENCES public."verificationTypes"(id);


--
-- Name: propertyApfVerificationReports fk_property_apf_verification_case_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."propertyApfVerificationReports"
    ADD CONSTRAINT fk_property_apf_verification_case_id FOREIGN KEY (case_id) REFERENCES public.cases(id) ON DELETE CASCADE;


--
-- Name: propertyApfVerificationReports fk_property_apf_verification_verified_by; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."propertyApfVerificationReports"
    ADD CONSTRAINT fk_property_apf_verification_verified_by FOREIGN KEY (verified_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: propertyIndividualVerificationReports fk_property_individual_verification_case_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."propertyIndividualVerificationReports"
    ADD CONSTRAINT fk_property_individual_verification_case_id FOREIGN KEY (case_id) REFERENCES public.cases(id) ON DELETE CASCADE;


--
-- Name: propertyIndividualVerificationReports fk_property_individual_verification_verified_by; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."propertyIndividualVerificationReports"
    ADD CONSTRAINT fk_property_individual_verification_verified_by FOREIGN KEY (verified_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: rateHistory fk_rate_history_rate; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."rateHistory"
    ADD CONSTRAINT fk_rate_history_rate FOREIGN KEY ("rateId") REFERENCES public.rates(id);


--
-- Name: rateTypeAssignments fk_rate_type_assignments_client; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."rateTypeAssignments"
    ADD CONSTRAINT fk_rate_type_assignments_client FOREIGN KEY ("clientId") REFERENCES public.clients(id);


--
-- Name: rateTypeAssignments fk_rate_type_assignments_product; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."rateTypeAssignments"
    ADD CONSTRAINT fk_rate_type_assignments_product FOREIGN KEY ("productId") REFERENCES public.products(id);


--
-- Name: rateTypeAssignments fk_rate_type_assignments_rate_type; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."rateTypeAssignments"
    ADD CONSTRAINT fk_rate_type_assignments_rate_type FOREIGN KEY ("rateTypeId") REFERENCES public."rateTypes"(id);


--
-- Name: rateTypeAssignments fk_rate_type_assignments_verification_type; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."rateTypeAssignments"
    ADD CONSTRAINT fk_rate_type_assignments_verification_type FOREIGN KEY ("verificationTypeId") REFERENCES public."verificationTypes"(id);


--
-- Name: rates fk_rates_client; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rates
    ADD CONSTRAINT fk_rates_client FOREIGN KEY ("clientId") REFERENCES public.clients(id);


--
-- Name: rates fk_rates_product; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rates
    ADD CONSTRAINT fk_rates_product FOREIGN KEY ("productId") REFERENCES public.products(id);


--
-- Name: rates fk_rates_rate_type; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rates
    ADD CONSTRAINT fk_rates_rate_type FOREIGN KEY ("rateTypeId") REFERENCES public."rateTypes"(id);


--
-- Name: rates fk_rates_verification_type; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rates
    ADD CONSTRAINT fk_rates_verification_type FOREIGN KEY ("verificationTypeId") REFERENCES public."verificationTypes"(id);


--
-- Name: residenceCumOfficeVerificationReports fk_res_cum_office_verification_case_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."residenceCumOfficeVerificationReports"
    ADD CONSTRAINT fk_res_cum_office_verification_case_id FOREIGN KEY (case_id) REFERENCES public.cases(id) ON DELETE CASCADE;


--
-- Name: residenceCumOfficeVerificationReports fk_res_cum_office_verification_verified_by; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."residenceCumOfficeVerificationReports"
    ADD CONSTRAINT fk_res_cum_office_verification_verified_by FOREIGN KEY (verified_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: residenceVerificationReports fk_residence_verification_case_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."residenceVerificationReports"
    ADD CONSTRAINT fk_residence_verification_case_id FOREIGN KEY (case_id) REFERENCES public.cases(id) ON DELETE CASCADE;


--
-- Name: residenceVerificationReports fk_residence_verification_verified_by; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."residenceVerificationReports"
    ADD CONSTRAINT fk_residence_verification_verified_by FOREIGN KEY (verified_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: states fk_states_country; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.states
    ADD CONSTRAINT fk_states_country FOREIGN KEY ("countryId") REFERENCES public.countries(id);


--
-- Name: task_assignment_history fk_task_assignment_assigned_by; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.task_assignment_history
    ADD CONSTRAINT fk_task_assignment_assigned_by FOREIGN KEY (assigned_by) REFERENCES public.users(id);


--
-- Name: task_assignment_history fk_task_assignment_assigned_to; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.task_assignment_history
    ADD CONSTRAINT fk_task_assignment_assigned_to FOREIGN KEY (assigned_to) REFERENCES public.users(id);


--
-- Name: task_assignment_history fk_task_assignment_case; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.task_assignment_history
    ADD CONSTRAINT fk_task_assignment_case FOREIGN KEY (case_id) REFERENCES public.cases(id);


--
-- Name: task_assignment_history fk_task_assignment_verification_task; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.task_assignment_history
    ADD CONSTRAINT fk_task_assignment_verification_task FOREIGN KEY (verification_task_id) REFERENCES public.verification_tasks(id) ON DELETE CASCADE;


--
-- Name: task_commission_calculations fk_task_commission_case; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.task_commission_calculations
    ADD CONSTRAINT fk_task_commission_case FOREIGN KEY (case_id) REFERENCES public.cases(id);


--
-- Name: task_commission_calculations fk_task_commission_rate_type; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.task_commission_calculations
    ADD CONSTRAINT fk_task_commission_rate_type FOREIGN KEY (rate_type_id) REFERENCES public."rateTypes"(id);


--
-- Name: task_commission_calculations fk_task_commission_user; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.task_commission_calculations
    ADD CONSTRAINT fk_task_commission_user FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: task_commission_calculations fk_task_commission_verification_task; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.task_commission_calculations
    ADD CONSTRAINT fk_task_commission_verification_task FOREIGN KEY (verification_task_id) REFERENCES public.verification_tasks(id) ON DELETE CASCADE;


--
-- Name: task_form_submissions fk_task_form_case; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.task_form_submissions
    ADD CONSTRAINT fk_task_form_case FOREIGN KEY (case_id) REFERENCES public.cases(id);


--
-- Name: task_form_submissions fk_task_form_submitted_by; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.task_form_submissions
    ADD CONSTRAINT fk_task_form_submitted_by FOREIGN KEY (submitted_by) REFERENCES public.users(id);


--
-- Name: task_form_submissions fk_task_form_verification_task; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.task_form_submissions
    ADD CONSTRAINT fk_task_form_verification_task FOREIGN KEY (verification_task_id) REFERENCES public.verification_tasks(id) ON DELETE CASCADE;


--
-- Name: territoryAssignmentAudit fk_territory_assignment_audit_performed_by; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."territoryAssignmentAudit"
    ADD CONSTRAINT fk_territory_assignment_audit_performed_by FOREIGN KEY ("performedBy") REFERENCES public.users(id) ON DELETE RESTRICT;


--
-- Name: territoryAssignmentAudit fk_territory_assignment_audit_user; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."territoryAssignmentAudit"
    ADD CONSTRAINT fk_territory_assignment_audit_user FOREIGN KEY ("userId") REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: userAreaAssignments fk_user_area_assignments_area; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."userAreaAssignments"
    ADD CONSTRAINT fk_user_area_assignments_area FOREIGN KEY ("areaId") REFERENCES public.areas(id) ON DELETE CASCADE;


--
-- Name: userAreaAssignments fk_user_area_assignments_assigned_by; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."userAreaAssignments"
    ADD CONSTRAINT fk_user_area_assignments_assigned_by FOREIGN KEY ("assignedBy") REFERENCES public.users(id) ON DELETE RESTRICT;


--
-- Name: userAreaAssignments fk_user_area_assignments_pincode; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."userAreaAssignments"
    ADD CONSTRAINT fk_user_area_assignments_pincode FOREIGN KEY ("pincodeId") REFERENCES public.pincodes(id) ON DELETE CASCADE;


--
-- Name: userAreaAssignments fk_user_area_assignments_user; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."userAreaAssignments"
    ADD CONSTRAINT fk_user_area_assignments_user FOREIGN KEY ("userId") REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: userAreaAssignments fk_user_area_assignments_user_pincode; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."userAreaAssignments"
    ADD CONSTRAINT fk_user_area_assignments_user_pincode FOREIGN KEY ("userPincodeAssignmentId") REFERENCES public."userPincodeAssignments"(id) ON DELETE CASCADE;


--
-- Name: userClientAssignments fk_user_client_assignments_assigned_by; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."userClientAssignments"
    ADD CONSTRAINT fk_user_client_assignments_assigned_by FOREIGN KEY ("assignedBy") REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: userClientAssignments fk_user_client_assignments_client; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."userClientAssignments"
    ADD CONSTRAINT fk_user_client_assignments_client FOREIGN KEY ("clientId") REFERENCES public.clients(id) ON DELETE CASCADE;


--
-- Name: userClientAssignments fk_user_client_assignments_user; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."userClientAssignments"
    ADD CONSTRAINT fk_user_client_assignments_user FOREIGN KEY ("userId") REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: userPincodeAssignments fk_user_pincode_assignments_assigned_by; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."userPincodeAssignments"
    ADD CONSTRAINT fk_user_pincode_assignments_assigned_by FOREIGN KEY ("assignedBy") REFERENCES public.users(id) ON DELETE RESTRICT;


--
-- Name: userPincodeAssignments fk_user_pincode_assignments_pincode; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."userPincodeAssignments"
    ADD CONSTRAINT fk_user_pincode_assignments_pincode FOREIGN KEY ("pincodeId") REFERENCES public.pincodes(id) ON DELETE CASCADE;


--
-- Name: userPincodeAssignments fk_user_pincode_assignments_user; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."userPincodeAssignments"
    ADD CONSTRAINT fk_user_pincode_assignments_user FOREIGN KEY ("userId") REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: userProductAssignments fk_user_product_assignments_assigned_by; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."userProductAssignments"
    ADD CONSTRAINT fk_user_product_assignments_assigned_by FOREIGN KEY ("assignedBy") REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: userProductAssignments fk_user_product_assignments_product; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."userProductAssignments"
    ADD CONSTRAINT fk_user_product_assignments_product FOREIGN KEY ("productId") REFERENCES public.products(id) ON DELETE CASCADE;


--
-- Name: userProductAssignments fk_user_product_assignments_user; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."userProductAssignments"
    ADD CONSTRAINT fk_user_product_assignments_user FOREIGN KEY ("userId") REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: users fk_users_department_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT fk_users_department_id FOREIGN KEY ("departmentId") REFERENCES public.departments(id);


--
-- Name: users fk_users_designation_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT fk_users_designation_id FOREIGN KEY ("designationId") REFERENCES public.designations(id);


--
-- Name: verification_attachments fk_verification_attachments_case_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.verification_attachments
    ADD CONSTRAINT fk_verification_attachments_case_id FOREIGN KEY (case_id) REFERENCES public.cases(id) ON DELETE CASCADE;


--
-- Name: verification_attachments fk_verification_attachments_task_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.verification_attachments
    ADD CONSTRAINT fk_verification_attachments_task_id FOREIGN KEY (verification_task_id) REFERENCES public.verification_tasks(id) ON DELETE RESTRICT;


--
-- Name: CONSTRAINT fk_verification_attachments_task_id ON verification_attachments; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON CONSTRAINT fk_verification_attachments_task_id ON public.verification_attachments IS 'Stage-1: Links photo evidence to a specific verification task. NULL for legacy records. RESTRICT deletion.';


--
-- Name: verification_attachments fk_verification_attachments_uploaded_by; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.verification_attachments
    ADD CONSTRAINT fk_verification_attachments_uploaded_by FOREIGN KEY ("uploadedBy") REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: verification_tasks fk_verification_tasks_assigned_by; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.verification_tasks
    ADD CONSTRAINT fk_verification_tasks_assigned_by FOREIGN KEY (assigned_by) REFERENCES public.users(id);


--
-- Name: verification_tasks fk_verification_tasks_assigned_to; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.verification_tasks
    ADD CONSTRAINT fk_verification_tasks_assigned_to FOREIGN KEY (assigned_to) REFERENCES public.users(id);


--
-- Name: verification_tasks fk_verification_tasks_case; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.verification_tasks
    ADD CONSTRAINT fk_verification_tasks_case FOREIGN KEY (case_id) REFERENCES public.cases(id) ON DELETE CASCADE;


--
-- Name: verification_tasks fk_verification_tasks_rate_type; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.verification_tasks
    ADD CONSTRAINT fk_verification_tasks_rate_type FOREIGN KEY (rate_type_id) REFERENCES public."rateTypes"(id);


--
-- Name: verification_tasks fk_verification_tasks_verification_type; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.verification_tasks
    ADD CONSTRAINT fk_verification_tasks_verification_type FOREIGN KEY (verification_type_id) REFERENCES public."verificationTypes"(id);


--
-- Name: verifications fk_verifications_applicant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.verifications
    ADD CONSTRAINT fk_verifications_applicant FOREIGN KEY (applicant_id) REFERENCES public.applicants(id) ON DELETE CASCADE;


--
-- Name: verifications fk_verifications_pincode; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.verifications
    ADD CONSTRAINT fk_verifications_pincode FOREIGN KEY (pincode_id) REFERENCES public.pincodes(id);


--
-- Name: verifications fk_verifications_type; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.verifications
    ADD CONSTRAINT fk_verifications_type FOREIGN KEY (verification_type_id) REFERENCES public."verificationTypes"(id);


--
-- Name: visits fk_visits_assignee; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.visits
    ADD CONSTRAINT fk_visits_assignee FOREIGN KEY (assigned_to) REFERENCES public.users(id);


--
-- Name: visits fk_visits_verification; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.visits
    ADD CONSTRAINT fk_visits_verification FOREIGN KEY (verification_id) REFERENCES public.verifications(id) ON DELETE CASCADE;


--
-- Name: form_quality_metrics form_quality_metrics_form_submission_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.form_quality_metrics
    ADD CONSTRAINT form_quality_metrics_form_submission_id_fkey FOREIGN KEY (form_submission_id) REFERENCES public.form_submissions(id) ON DELETE CASCADE;


--
-- Name: form_submissions form_submissions_case_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.form_submissions
    ADD CONSTRAINT form_submissions_case_id_fkey FOREIGN KEY (case_id) REFERENCES public.cases(id) ON DELETE CASCADE;


--
-- Name: form_submissions form_submissions_submitted_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.form_submissions
    ADD CONSTRAINT form_submissions_submitted_by_fkey FOREIGN KEY (submitted_by) REFERENCES public.users(id);


--
-- Name: form_submissions form_submissions_validated_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.form_submissions
    ADD CONSTRAINT form_submissions_validated_by_fkey FOREIGN KEY (validated_by) REFERENCES public.users(id);


--
-- Name: form_submissions form_submissions_verification_task_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.form_submissions
    ADD CONSTRAINT form_submissions_verification_task_id_fkey FOREIGN KEY (verification_task_id) REFERENCES public.verification_tasks(id) ON DELETE CASCADE;


--
-- Name: form_submissions form_submissions_verification_type_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.form_submissions
    ADD CONSTRAINT form_submissions_verification_type_id_fkey FOREIGN KEY (verification_type_id) REFERENCES public."verificationTypes"(id);


--
-- Name: form_validation_logs form_validation_logs_form_submission_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.form_validation_logs
    ADD CONSTRAINT form_validation_logs_form_submission_id_fkey FOREIGN KEY (form_submission_id) REFERENCES public.form_submissions(id) ON DELETE CASCADE;


--
-- Name: invoice_item_tasks invoice_item_tasks_case_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invoice_item_tasks
    ADD CONSTRAINT invoice_item_tasks_case_id_fkey FOREIGN KEY (case_id) REFERENCES public.cases(id) ON DELETE RESTRICT;


--
-- Name: invoice_item_tasks invoice_item_tasks_client_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invoice_item_tasks
    ADD CONSTRAINT invoice_item_tasks_client_id_fkey FOREIGN KEY (client_id) REFERENCES public.clients(id) ON DELETE RESTRICT;


--
-- Name: invoice_item_tasks invoice_item_tasks_invoice_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invoice_item_tasks
    ADD CONSTRAINT invoice_item_tasks_invoice_item_id_fkey FOREIGN KEY (invoice_item_id) REFERENCES public.invoice_items(id) ON DELETE CASCADE;


--
-- Name: invoice_item_tasks invoice_item_tasks_verification_task_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invoice_item_tasks
    ADD CONSTRAINT invoice_item_tasks_verification_task_id_fkey FOREIGN KEY (verification_task_id) REFERENCES public.verification_tasks(id) ON DELETE RESTRICT;


--
-- Name: invoice_items invoice_items_client_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invoice_items
    ADD CONSTRAINT invoice_items_client_id_fkey FOREIGN KEY (client_id) REFERENCES public.clients(id) ON DELETE RESTRICT;


--
-- Name: invoice_items invoice_items_invoice_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invoice_items
    ADD CONSTRAINT invoice_items_invoice_id_fkey FOREIGN KEY (invoice_id) REFERENCES public.invoices(id) ON DELETE CASCADE;


--
-- Name: invoice_items invoice_items_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invoice_items
    ADD CONSTRAINT invoice_items_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(id) ON DELETE SET NULL;


--
-- Name: invoice_items invoice_items_rate_type_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invoice_items
    ADD CONSTRAINT invoice_items_rate_type_id_fkey FOREIGN KEY (rate_type_id) REFERENCES public."rateTypes"(id) ON DELETE SET NULL;


--
-- Name: invoice_items invoice_items_verification_type_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invoice_items
    ADD CONSTRAINT invoice_items_verification_type_id_fkey FOREIGN KEY (verification_type_id) REFERENCES public."verificationTypes"(id) ON DELETE SET NULL;


--
-- Name: invoice_status_history invoice_status_history_changed_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invoice_status_history
    ADD CONSTRAINT invoice_status_history_changed_by_fkey FOREIGN KEY (changed_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: invoice_status_history invoice_status_history_invoice_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invoice_status_history
    ADD CONSTRAINT invoice_status_history_invoice_id_fkey FOREIGN KEY (invoice_id) REFERENCES public.invoices(id) ON DELETE CASCADE;


--
-- Name: invoices invoices_approved_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invoices
    ADD CONSTRAINT invoices_approved_by_fkey FOREIGN KEY (approved_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: invoices invoices_client_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invoices
    ADD CONSTRAINT invoices_client_id_fkey FOREIGN KEY (client_id) REFERENCES public.clients(id) ON DELETE RESTRICT;


--
-- Name: invoices invoices_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invoices
    ADD CONSTRAINT invoices_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: invoices invoices_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invoices
    ADD CONSTRAINT invoices_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(id) ON DELETE SET NULL;


--
-- Name: locations locations_recorded_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.locations
    ADD CONSTRAINT locations_recorded_by_fkey FOREIGN KEY ("recordedBy") REFERENCES public.users(id) ON DELETE RESTRICT;


--
-- Name: mobile_device_sync mobile_device_sync_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mobile_device_sync
    ADD CONSTRAINT "mobile_device_sync_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: mobile_notification_audit mobile_notification_audit_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mobile_notification_audit
    ADD CONSTRAINT "mobile_notification_audit_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: mobile_notification_queue mobile_notification_queue_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mobile_notification_queue
    ADD CONSTRAINT "mobile_notification_queue_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: nocVerificationReports nocVerificationReports_verification_task_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."nocVerificationReports"
    ADD CONSTRAINT "nocVerificationReports_verification_task_id_fkey" FOREIGN KEY (verification_task_id) REFERENCES public.verification_tasks(id) ON DELETE CASCADE;


--
-- Name: notification_batches notification_batches_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notification_batches
    ADD CONSTRAINT notification_batches_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: notification_delivery_log notification_delivery_log_notification_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notification_delivery_log
    ADD CONSTRAINT notification_delivery_log_notification_id_fkey FOREIGN KEY (notification_id) REFERENCES public.notifications(id) ON DELETE CASCADE;


--
-- Name: notification_preferences notification_preferences_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notification_preferences
    ADD CONSTRAINT notification_preferences_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: notificationTokens notification_tokens_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."notificationTokens"
    ADD CONSTRAINT notification_tokens_user_id_fkey FOREIGN KEY ("userId") REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: notification_tokens notification_tokens_user_id_fkey1; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notification_tokens
    ADD CONSTRAINT notification_tokens_user_id_fkey1 FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: notifications notifications_case_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_case_id_fkey FOREIGN KEY (case_id) REFERENCES public.cases(id) ON DELETE SET NULL;


--
-- Name: notifications notifications_task_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_task_id_fkey FOREIGN KEY (task_id) REFERENCES public.verification_tasks(id) ON DELETE CASCADE;


--
-- Name: notifications notifications_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: officeVerificationReports officeVerificationReports_verification_task_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."officeVerificationReports"
    ADD CONSTRAINT "officeVerificationReports_verification_task_id_fkey" FOREIGN KEY (verification_task_id) REFERENCES public.verification_tasks(id) ON DELETE CASCADE;


--
-- Name: performance_metrics performance_metrics_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.performance_metrics
    ADD CONSTRAINT performance_metrics_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: productDocumentTypes productDocumentTypes_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."productDocumentTypes"
    ADD CONSTRAINT "productDocumentTypes_created_by_fkey" FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: productDocumentTypes productDocumentTypes_documentTypeId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."productDocumentTypes"
    ADD CONSTRAINT "productDocumentTypes_documentTypeId_fkey" FOREIGN KEY ("documentTypeId") REFERENCES public."documentTypes"(id) ON DELETE CASCADE;


--
-- Name: productDocumentTypes productDocumentTypes_productId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."productDocumentTypes"
    ADD CONSTRAINT "productDocumentTypes_productId_fkey" FOREIGN KEY ("productId") REFERENCES public.products(id) ON DELETE CASCADE;


--
-- Name: propertyApfVerificationReports propertyApfVerificationReports_verification_task_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."propertyApfVerificationReports"
    ADD CONSTRAINT "propertyApfVerificationReports_verification_task_id_fkey" FOREIGN KEY (verification_task_id) REFERENCES public.verification_tasks(id) ON DELETE CASCADE;


--
-- Name: propertyIndividualVerificationReports propertyIndividualVerificationReports_verification_task_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."propertyIndividualVerificationReports"
    ADD CONSTRAINT "propertyIndividualVerificationReports_verification_task_id_fkey" FOREIGN KEY (verification_task_id) REFERENCES public.verification_tasks(id) ON DELETE CASCADE;


--
-- Name: rateHistory rateHistory_changedBy_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."rateHistory"
    ADD CONSTRAINT "rateHistory_changedBy_fkey" FOREIGN KEY ("changedBy") REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: rates rates_createdBy_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rates
    ADD CONSTRAINT "rates_createdBy_fkey" FOREIGN KEY ("createdBy") REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: refreshTokens refresh_tokens_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."refreshTokens"
    ADD CONSTRAINT refresh_tokens_user_id_fkey FOREIGN KEY ("userId") REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: residenceCumOfficeVerificationReports residenceCumOfficeVerificationReports_verification_task_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."residenceCumOfficeVerificationReports"
    ADD CONSTRAINT "residenceCumOfficeVerificationReports_verification_task_id_fkey" FOREIGN KEY (verification_task_id) REFERENCES public.verification_tasks(id) ON DELETE CASCADE;


--
-- Name: residenceVerificationReports residenceVerificationReports_verification_task_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."residenceVerificationReports"
    ADD CONSTRAINT "residenceVerificationReports_verification_task_id_fkey" FOREIGN KEY (verification_task_id) REFERENCES public.verification_tasks(id) ON DELETE CASCADE;


--
-- Name: role_permissions role_permissions_permission_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.role_permissions
    ADD CONSTRAINT role_permissions_permission_id_fkey FOREIGN KEY (permission_id) REFERENCES public.permissions(id) ON DELETE CASCADE;


--
-- Name: role_permissions role_permissions_role_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.role_permissions
    ADD CONSTRAINT role_permissions_role_id_fkey FOREIGN KEY (role_id) REFERENCES public.roles_v2(id) ON DELETE CASCADE;


--
-- Name: role_routes role_routes_role_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.role_routes
    ADD CONSTRAINT role_routes_role_id_fkey FOREIGN KEY (role_id) REFERENCES public.roles_v2(id) ON DELETE CASCADE;


--
-- Name: roles_v2 roles_v2_parent_role_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.roles_v2
    ADD CONSTRAINT roles_v2_parent_role_id_fkey FOREIGN KEY (parent_role_id) REFERENCES public.roles_v2(id) ON DELETE SET NULL;


--
-- Name: scheduled_reports scheduled_reports_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.scheduled_reports
    ADD CONSTRAINT scheduled_reports_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: security_audit_events security_audit_events_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.security_audit_events
    ADD CONSTRAINT security_audit_events_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: service_zone_rules service_zone_rules_service_zone_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.service_zone_rules
    ADD CONSTRAINT service_zone_rules_service_zone_id_fkey FOREIGN KEY (service_zone_id) REFERENCES public.service_zones(id);


--
-- Name: task_revocations task_revocations_reassigned_to_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.task_revocations
    ADD CONSTRAINT task_revocations_reassigned_to_user_id_fkey FOREIGN KEY (reassigned_to_user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: task_revocations task_revocations_revoked_by_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.task_revocations
    ADD CONSTRAINT task_revocations_revoked_by_user_id_fkey FOREIGN KEY (revoked_by_user_id) REFERENCES public.users(id) ON DELETE RESTRICT;


--
-- Name: task_revocations task_revocations_revoked_from_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.task_revocations
    ADD CONSTRAINT task_revocations_revoked_from_user_id_fkey FOREIGN KEY (revoked_from_user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: task_revocations task_revocations_task_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.task_revocations
    ADD CONSTRAINT task_revocations_task_id_fkey FOREIGN KEY (task_id) REFERENCES public.verification_tasks(id) ON DELETE CASCADE;


--
-- Name: template_reports template_reports_case_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.template_reports
    ADD CONSTRAINT template_reports_case_id_fkey FOREIGN KEY (case_id) REFERENCES public.cases(id) ON DELETE CASCADE;


--
-- Name: template_reports template_reports_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.template_reports
    ADD CONSTRAINT template_reports_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: trusted_devices trusted_devices_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trusted_devices
    ADD CONSTRAINT trusted_devices_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: userAreaAssignments userAreaAssignments_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."userAreaAssignments"
    ADD CONSTRAINT "userAreaAssignments_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: userClientAssignments userClientAssignments_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."userClientAssignments"
    ADD CONSTRAINT "userClientAssignments_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: userPincodeAssignments userPincodeAssignments_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."userPincodeAssignments"
    ADD CONSTRAINT "userPincodeAssignments_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: userProductAssignments userProductAssignments_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."userProductAssignments"
    ADD CONSTRAINT "userProductAssignments_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: user_roles user_roles_role_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT user_roles_role_id_fkey FOREIGN KEY (role_id) REFERENCES public.roles_v2(id) ON DELETE CASCADE;


--
-- Name: user_roles user_roles_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT user_roles_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: users users_manager_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_manager_id_fkey FOREIGN KEY (manager_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: users users_team_leader_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_team_leader_id_fkey FOREIGN KEY (team_leader_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: verification_attachments verification_attachments_deleted_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.verification_attachments
    ADD CONSTRAINT verification_attachments_deleted_by_fkey FOREIGN KEY (deleted_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: verification_attachments verification_attachments_verification_task_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.verification_attachments
    ADD CONSTRAINT verification_attachments_verification_task_id_fkey FOREIGN KEY (verification_task_id) REFERENCES public.verification_tasks(id) ON DELETE CASCADE;


--
-- Name: verification_tasks verification_tasks_area_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.verification_tasks
    ADD CONSTRAINT verification_tasks_area_id_fkey FOREIGN KEY (area_id) REFERENCES public.areas(id) ON DELETE SET NULL;


--
-- Name: verification_tasks verification_tasks_cancelled_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.verification_tasks
    ADD CONSTRAINT verification_tasks_cancelled_by_fkey FOREIGN KEY (cancelled_by) REFERENCES public.users(id);


--
-- Name: verification_tasks verification_tasks_parent_task_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.verification_tasks
    ADD CONSTRAINT verification_tasks_parent_task_id_fkey FOREIGN KEY (parent_task_id) REFERENCES public.verification_tasks(id);


--
-- Name: verification_tasks verification_tasks_reviewer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.verification_tasks
    ADD CONSTRAINT verification_tasks_reviewer_id_fkey FOREIGN KEY (reviewer_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: verification_tasks verification_tasks_revoked_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.verification_tasks
    ADD CONSTRAINT verification_tasks_revoked_by_fkey FOREIGN KEY (revoked_by) REFERENCES public.users(id);


--
-- Name: verification_tasks verification_tasks_service_zone_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.verification_tasks
    ADD CONSTRAINT verification_tasks_service_zone_id_fkey FOREIGN KEY (service_zone_id) REFERENCES public.service_zones(id);


--
-- Name: zone_rate_type_mapping zone_rate_type_mapping_rate_type_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.zone_rate_type_mapping
    ADD CONSTRAINT zone_rate_type_mapping_rate_type_id_fkey FOREIGN KEY (rate_type_id) REFERENCES public."rateTypes"(id);


--
-- Name: zone_rate_type_mapping zone_rate_type_mapping_service_zone_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.zone_rate_type_mapping
    ADD CONSTRAINT zone_rate_type_mapping_service_zone_id_fkey FOREIGN KEY (service_zone_id) REFERENCES public.service_zones(id);


--
-- PostgreSQL database dump complete
--

\unrestrict iC0bCh7To5NZbPBCxTPvStnGc93ArZHhMGKcis4f4Ll6G92dPxPpA5pe40qaE4M

